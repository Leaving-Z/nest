#include<bits/stdc++.h>
#define maxn 5005
using namespace std;
const int n = 5000;
const int mod = 998244353;
int T;
int dp[maxn][maxn];
int s[maxn],Ans[maxn];
int main()
{
    scanf("%d",&T);
    dp[1][1]=1;
    s[1]=1;Ans[1]=1;
    for(int i=2;i<=n;++i)
    {
        if(i&1)
        {
            for(int j=1;j<=i;++j)dp[i][j]=(dp[i][j]+(s[i-1]-s[j-1]+mod)%mod)%mod;
        }
        else
        {
            for(int j=1;j<=i;++j)dp[i][j]=(dp[i][j]+s[j-1])%mod;
        }
        for(int j=1;j<=i;++j)s[j]=(s[j-1]+dp[i][j])%mod;
        Ans[i]=s[i];
    }
    while(T--)
    {
        int x;
        scanf("%d",&x);
        printf("%d\n",(Ans[x]*2)%mod);
    }
}