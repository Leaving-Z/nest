#include<bits/stdc++.h>
#define maxn 5005
using namespace std;
const int mod = 998244353;
int T,n,m;
int dp[maxn*2][maxn];
int inv[maxn*2];
int fastpow(int a,int p)
{
    int ans=1;
    while(p)
    {
        if(p&1)ans=1ll*ans*a%mod;
        a=1ll*a*a%mod;p>>=1; 
    }
    return ans;
}
int main()
{
    for(int i=0;i<=10000;++i)inv[i]=fastpow(i,mod-2);
    scanf("%d",&T);
    while(T--)
    {
        int x;
        scanf("%d",&x);
        if(x==1)n++;
        else n+=2,m++;
    }
    dp[0][m]=1;
    for(int i=0;i<n;++i)
    {
        for(int j=1;j<=m;++j)
        {
            dp[i+1][j]=(dp[i+1][j]+1ll*dp[i][j]*(n-i-2*j)%mod*inv[n-i]%mod)%mod;
            dp[i+1][j-1]=(dp[i+1][j-1]+1ll*dp[i][j]*(2*j)%mod*inv[n-i]%mod)%mod;
        }
    }
    int tot=0,ans=0;
    for(int i=0;i<=n;++i)
    {
        ans=(ans+1ll*dp[i][0]*i%mod)%mod;
        tot=(tot+dp[i][0])%mod;
    }
    assert(tot==1);
    printf("%d\n",ans);
}