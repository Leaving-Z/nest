#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=30007;
const int maxm=60007;
const int maxk=207;
typedef long long LL;
int N,K;
struct E{
    int u,v;
    LL w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
LL sz[maxn],F[maxn][maxk],f[maxn][maxk];
int fa[maxn];
void dfs(int u)
{
    sz[u]=1;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        fa[v]=u;
        dfs(v);
        sz[u]+=sz[v];
        e[i].w=sz[v]*(N-sz[v]);
    }
    return ;
}
void dfs1(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dfs1(v);
        for(int k=1;k<=K;k++)
            F[u][k]+=F[v][k-1]+e[i].w;
    }
    return ;
}
void dfs2(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        f[v][1]=F[v][1]+e[i].w;
        for(int k=2;k<=K;k++)
            f[v][k]=F[v][k]+f[u][k-1]-F[v][k-2];
        dfs2(v);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&K);K++;
    int u,v;
    for(int i=1;i<N;i++)
        scanf("%d%d",&u,&v),addE(u,v),addE(v,u);
    dfs(1);
    dfs1(1);
    for(int i=1;i<=K;i++)
        f[1][i]=F[1][i];
    dfs2(1);
    LL ans=0;
    for(int i=1;i<=N;i++)
        ans=max(ans,f[i][K]);
    printf("%lld",ans);
    return 0;
}