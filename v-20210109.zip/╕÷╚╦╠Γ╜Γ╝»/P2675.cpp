#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1000007;
const int mod=10007;
typedef long long LL;
LL fast_pow(LL b,LL k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL fact[maxn],inv[maxn];
int N;
LL ans[maxn];
LL C(int n,int m)
{
    if(n<m) return 0;
    return fact[n]*inv[m]%mod*inv[n-m]%mod;
}
LL Lucas(int n,int m)
{
    if(!m) return 1;
    return C(n%mod,m%mod)*Lucas(n/mod,m/mod)%mod;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    fact[0]=1;
    for(int i=1;i<mod;i++)
        fact[i]=fact[i-1]*i%mod;
    inv[mod-1]=fast_pow(fact[mod-1],mod-2);
    for(int i=mod-2;i>=0;i--)
        inv[i]=inv[i+1]*(i+1)%mod;
    for(int i=1;i<=N;i++)
        ans[i]=Lucas(N-1,i-1);
    int cur=N,re=0;
    if(N&1) (ans[N/2+1]*=N)%=mod,re+=ans[N/2+1],--cur;
    for(int i=N/2;i>0;i--)
    {
        (ans[i]*=cur)%=mod;
        (re+=ans[i])%=mod;
        --cur;
        (ans[N-i+1]*=cur)%=mod;
        (re+=ans[N-i+1])%=mod;
        --cur;
    }
    printf("%lld",re);
    return 0;
}