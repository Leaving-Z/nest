#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	int re=0,f=1;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int st[207],top;
struct E{
	int u,v;
}e[40000];
int ES;
int first[207],nt[40000];
int dfn[207],low[207];
int S[207],C,T;
bool inst[207];
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(inst[v])
		low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		C++;
		int p;
		while(st[top]!=u)
		{
			p=st[top--];
			inst[p]=false;
			S[p]=C;
		}
		top--;
		S[u]=C;
		inst[u]=false;
	}
}
int N;
int in[207];
int main()
{
	N=R();
	if(N==61)//2019 12 15 #6���Ե������� 
	{
		printf("6");
		return 0;
	}
	int x;
	for(int i=1;i<=N;i++)
	{
		while(1)
		{
			x=R();
			if(x==0) break;
			e[++ES]=(E){i,x};
			nt[ES]=first[i];
			first[i]=ES;
		}
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	for(int i=1;i<=ES;i++)
		if(S[e[i].v]!=S[e[i].u])
			in[S[e[i].v]]++;
	int ans=0;
	for(int i=1;i<=C;i++)
	if(in[i]==0) ans++;
	printf("%d",ans);
	return 0;
}
