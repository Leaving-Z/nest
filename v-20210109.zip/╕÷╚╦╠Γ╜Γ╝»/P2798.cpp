#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=10007;
const int maxm=20007;
struct E{
	int u,v,T,t;
}e[maxm];
int S[maxn];
int N,M,K;
bool com1 (const E &x,const E &y)
{
	if(x.T!=y.T) return x.T<y.T;
	return x.t<y.t;
}
bool com2 (const E &x,const E &y)
{
	return min(x.T,x.t)<min(y.T,y.t);
}
inline int Re()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
int Kruskal()
{
	int cnT=0,cnt=1,f1,f2,ans=0;
	for(int i=1;i<=M;i++)
	{
		f1=f(e[i].u);f2=f(e[i].v);
		if(f1!=f2)
		{
			S[f1]=f2;
			cnT++;cnt++;
			ans=max(ans,e[i].T);
			if(cnT==K) break;
		}
	}
	sort(e+1,e+1+M,com2);
	for(int i=1;i<=M;i++)
	{
		if(cnt>=N) break;
		f1=f(e[i].u);f2=f(e[i].v);
		if(f1!=f2)
		{
			S[f1]=f2;
			cnt++;
			ans=max(ans,min(e[i].t,e[i].T));
		}
	}
	return ans;
}
int main()
{
	N=Re();K=Re();M=Re();
	int u,v,t,T;
	for(register int i=1;i<=M;i++)
	{
		u=Re();v=Re();T=Re();t=Re();
		e[i]=(E){u,v,T,t};
	}
	sort(e+1,e+1+M,com1);
	for(int i=1;i<=N;i++)
		S[i]=i;
	printf("%d",Kruskal());
	return 0;
}
