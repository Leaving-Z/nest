#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=2000007;
typedef long long LL;
int N,D;
LL p;
LL sum[maxn],A[maxn];
int q[maxn],head,tail;
bool check(int len)
{
	head=1;tail=0;
	for(int i=1;i<=N;i++)
	{
		while(head<=tail&&q[head]-D<i-len) ++head;
		while(head<=tail&&sum[q[tail]]-sum[max(0,q[tail]-D)]<=sum[i]-sum[max(0,i-D)]) --tail;
		q[++tail]=i;
		if(i>=len)
		{
			if(sum[i]-sum[i-len]-(sum[q[head]]-sum[max(0,q[head]-D)])<=p)
				return true;
		}
	}
	return false;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%lld%d",&N,&p,&D);
	for(int i=1;i<=N;i++)
		scanf("%lld",&A[i]),sum[i]=sum[i-1]+A[i];
	int ans=D,L=D,R=N,mid;
	while(L<=R)
	{
		mid=L+R>>1;
		if(check(mid)) ans=mid,L=mid+1;
		else R=mid-1;
	}
	printf("%d",ans);
	return 0;
}
