#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=50007;
struct Tree{
	int len,maxl,lt,suf,pre;
}TREE[maxn<<2];
int tag[maxn<<2];
int N,M;
#define mid (L+R>>1)
#define len(i) TREE[i].len
#define maxx(i) TREE[i].maxl
#define lt(i) TREE[i].lt
#define suf(i) TREE[i].suf
#define pre(i) TREE[i].pre
#define Ls (i<<1)
#define Rs (i<<1|1)
inline void Pushup(int L,int R,int i)
{
	pre(i)=pre(Ls);suf(i)=suf(Rs);
	if(pre(Ls)==len(Ls)) pre(i)+=pre(Rs);
	if(suf(Rs)==len(Rs)) suf(i)+=suf(Ls);
	if(maxx(Ls)>=maxx(Rs))
	{
		lt(i)=lt(Ls);
		maxx(i)=maxx(Ls);
	}
	else
	{
		lt(i)=lt(Rs);
		maxx(i)=maxx(Rs); 
	}
	if(suf(Ls)+pre(Rs)>maxx(i))
	{
		maxx(i)=suf(Ls)+pre(Rs);
		lt(i)=mid-suf(Ls)+1;
	}
	return ;
}
inline void Pushdown(int L,int R,int i)
{
	if(!tag[i]) return ;
	if(tag[i]==1)
	{
		lt(Ls)=maxx(Ls)=suf(Ls)=pre(Ls)=0;
		lt(Rs)=maxx(Rs)=suf(Rs)=pre(Rs)=0;
		tag[Ls]=tag[Rs]=tag[i];
		tag[i]=0;
	}
	else
	{
		lt(Ls)=L;lt(Rs)=mid+1;
		maxx(Ls)=suf(Ls)=pre(Ls)=len(Ls);
		maxx(Rs)=suf(Rs)=pre(Rs)=len(Rs);
		tag[Ls]=tag[Rs]=tag[i];
		tag[i]=0;
	}
	return ;
}
void Build(int L,int R,int i)
{
	len(i)=R-L+1;
	if(L==R)
	{
		lt(i)=L;
		maxx(i)=suf(i)=pre(i)=1;
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	Pushup(L,R,i);
	return ;
}
int Query(int L,int R,int k,int i)
{
	if(maxx(i)<k) return 0;
	Pushdown(L,R,i);
	int re;
	re=Query(L,mid,k,Ls);
	if(re) return re;
	else
	{
		if(suf(Ls)+pre(Rs)>=k) return mid-suf(Ls)+1;
		return Query(mid+1,R,k,Rs);
	}
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		if(!k)
		{
			tag[i]=1;
			lt(i)=maxx(i)=suf(i)=pre(i)=0;
		}
		else
		{
			tag[i]=2;
			lt(i)=L;
			maxx(i)=pre(i)=suf(i)=len(i);
		}
		return ;
	}
	Pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	Pushup(L,R,i);
	return ; 
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();M=R();
	int op,x,y;
	Build(1,N,1);
	for(register int i=1;i<=M;i++)
	{
		op=R();
		if(op==1)
		{
			x=R();
			y=Query(1,N,x,1);
			printf("%d\n",y);
			if(y) Update(1,N,y,y+x-1,0,1);
		}
		else
		{
			x=R();y=R();
			Update(1,N,x,x+y-1,1,1);
		}
	}
	return 0;
}
