#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int maxn=100007;
const int mod=1e9+7;
inline LL fast_pow(LL b)
{
	LL s=1,k=mod-2;
	while(k)
	{
		if(k&1) s=s*b%mod;
		b=b*b%mod;
		k>>=1;
	}
	return s;
}
struct Tree{
	LL sum,sum2;
}TREE[maxn<<2];
LL A[maxn];
int N,M;
inline LL R()
{
	char c;
	LL re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define sum(i) TREE[i].sum
#define sum2(i) TREE[i].sum2
void Build(int L,int R,int i)
{
	if(L==R)
	{
		sum2(i)=A[L]*A[L]%mod;
		sum(i)=A[L]%mod;
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	sum(i)=(sum(Ls)+sum(Rs))%mod;
	sum2(i)=(sum2(Ls)+sum2(Rs))%mod;
	return ;
}
void Update(int L,int R,LL x,LL k,int i)
{
	if(L==R)
	{
		sum(i)=k%mod;
		sum2(i)=k*k%mod;
		return ;
	}
	if(x<=mid) Update(L,mid,x,k,Ls);
	else Update(mid+1,R,x,k,Rs);
	sum(i)=(sum(Ls)+sum(Rs))%mod;
	sum2(i)=(sum2(Ls)+sum2(Rs))%mod;
	return ;
}
LL Query(int L,int R,LL l,LL r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		if(k) return sum2(i);
		else return sum(i);
	}
	LL re=0;
	if(l<=mid) re+=Query(L,mid,l,r,k,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,k,Rs);
	return re%mod;
}
int main()
{
	N=R();M=R();
	for(int i=1;i<=N;i++)
		A[i]=R();
	Build(1,N,1);
	LL op,x,y,tmp,tmp2,ave,inv;
	for(int i=1;i<=M;i++)
	{
		op=R();x=R();y=R();
		if(op==1) Update(1,N,x,y,1);
		else
		{
			inv=fast_pow(y-x+1);
			tmp=Query(1,N,x,y,0,1);
			tmp2=Query(1,N,x,y,1,1);
			ave=tmp*inv%mod;
			tmp2-=(2*ave%mod)*tmp%mod;tmp2%=mod;
			tmp2+=((y-x+1)*ave)%mod*ave%mod;tmp2%=mod;
			tmp2+=mod;tmp2%=mod;
			tmp2*=inv;tmp2%=mod;
			printf("%lld\n",tmp2);
		}
	}
	return 0;
}
