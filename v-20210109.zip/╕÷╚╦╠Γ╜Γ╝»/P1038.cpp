#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<cstring>
using namespace std;
queue <int> q;
const int maxn=107;
const int maxm=2507;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
int in[maxn],cnt[maxn],out[maxn];
int C[maxn],U[maxn];
inline void topo()
{
	for(int i=1;i<=N;i++)
	if(in[i]==0) q.push(i);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		if(C[u]<0) continue;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;in[v]--;
			cnt[v]=cnt[u]+1;
			C[v]+=C[u]*e[i].w;
			if(in[v]==0) q.push(v);
		}
	}
	return ;
}
int main()
{
	//freopen("P1038_1.in","r",stdin);
	scanf("%d%d",&N,&M);
	int u,v,w;
	for(int i=1;i<=N;i++)
		{scanf("%d%d",&C[i],&U[i]);if(!C[i]) C[i]-=U[i];}
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		in[v]++;out[u]++;
		addE(u,v,w);
	}
	topo();
	bool f=true;
	for(int i=1;i<=N;i++)
	if(out[i]==0&&C[i]>0) f=false,printf("%d %d\n",i,C[i]);
	if(f) printf("NULL");
	return 0;
}
