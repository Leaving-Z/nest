#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const double eps=0.00000001;
const double delta=0.00001;
int q[maxn],head,tail;
double sum[maxn],A[maxn],B[maxn];
int N,S,T;
bool check(double p)
{
    for(int i=1;i<=N;i++)
        B[i]=A[i]-p,sum[i]=sum[i-1]+B[i];
    head=1;tail=0;
    for(int i=1;i<=N;i++)
    {
        while(head<=tail&&q[head]<i-T) ++head;
        if(head<=tail&&sum[i]-sum[q[head]]>=eps) return true;
        if(i>S-2)
        {
            while(head<=tail&&sum[q[tail]]>sum[i-S+1]) --tail;
            q[++tail]=i-S+1;
        }
    }
    return false;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&S,&T);
    for(int i=1;i<=N;i++)
        scanf("%lf",&A[i]);
    double L=-10000,R=10000,mid,ans;
    while(L+delta<=R)
    {
        mid=(L+R)/2;
        if(check(mid)) L=mid+delta,ans=mid;
        else R=mid-delta;
    }
    printf("%.3f",ans);
    return 0;
}