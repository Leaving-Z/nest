#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=10007;
const int maxm=50007;
int st[maxn],top;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int dfn[maxn],low[maxn],sz[maxn];
bool ins[maxn];
int C,T,N,M;
inline void dfs(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;ins[u]=true;
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v])
		{
			dfs(v);
			low[u]=min(low[v],low[u]);
		}
		else if(ins[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		do{
			p=st[top--];
			ins[p]=false;
			sz[C]++;
		}while(p!=u);
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		addE(u,v);
	}
	for(register int i=1;i<=N;i++)
	if(dfn[i]==0) dfs(i);
	int ans=0;
	for(register int i=1;i<=C;i++)
	if(sz[i]>1) ans++;
	printf("%d",ans);
	return 0;
}
