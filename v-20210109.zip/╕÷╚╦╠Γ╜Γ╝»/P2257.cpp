#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=10000007;
const int lim=10000000;
int mu[maxn],prime[maxn],cnt;
long long g[maxn];
bool book[maxn];
void pre()
{
    mu[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,mu[i]=-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else {mu[i*prime[j]]=0;break;}
        }
    }
    int x;
    for(int i=1;i<=cnt;i++)
    {
        x=prime[i];
        for(int k=x;k<=lim;k+=x)
            g[k]+=mu[k/x];
    }
    for(int i=1;i<=lim;i++)
        g[i]+=g[i-1];
    return ;
}
int T,N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    pre();
    while(T--)
    {
        scanf("%d%d",&N,&M);
        if(N>M) swap(N,M);
        int L=1,R;
        long long ans=0;
        while(L<=N)
        {
            R=min(N/(N/L),M/(M/L));
            ans+=(g[R]-g[L-1])*(N/L)*(M/L);
            L=R+1;
        }
        printf("%lld\n",ans);
    }
    return 0;
}