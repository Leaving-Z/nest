#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<iostream>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxs=(1<<17)+7;
const int maxn=212;
const int mod=998244353;
int cnt;
LL N,K;
struct Matrix
{
    LL m[maxn][maxn];
    Matrix () {memset(m,0,sizeof(m));return ;}
}ini,trans;
Matrix operator * (const Matrix &x,const Matrix &y)
{
    Matrix t;
    for(int k=1;k<=cnt;k++)
        for(int i=1;i<=cnt;i++)
            for(int j=1;j<=cnt;j++)
                t.m[i][j]=(t.m[i][j]+x.m[i][k]*y.m[k][j])%mod;
    return t;
}
Matrix operator ^ (Matrix b,LL k)
{
    Matrix s;
    for(int i=1;i<=cnt;i++)
        s.m[i][i]=1;
    while(k)
    {
        if(k&1) s=s*b;
        b=b*b;
        k>>=1;
    }
    return s;
}
int nxt(int x)
{
    if((x>>K-1)&1) return ((x<<1)^(1<<K))^1;
    return (x<<1);
}
bool vis[maxs];
vector <int> m[maxn];
int sta[maxn],sz[maxn];
bool judge(int x)
{
    if(((x>>K-1)&1)&&(x&1)) return false;
    for(int i=0;i<K-1;i++)
    if((x&(1<<i))&&(x&(1<<i+1))) return false;
    return true;
}
void add(int x)
{
    if(vis[x]) return ;
    vis[x]=true;
    sta[++cnt]=x;sz[cnt]=1;
    m[cnt].push_back(x);
    x=nxt(x);
    while(!vis[x])
    {
        vis[x]=true;
        ++sz[cnt];m[cnt].push_back(x);
        x=nxt(x);
    }
    ini.m[1][cnt]=sz[cnt];
    return ;
}
void pre()
{
    int u,v,re;
    for(int i=1;i<=cnt;i++)
        for(int j=1;j<=cnt;j++)
        {
            re=0;
            u=sta[i];
            for(int k=0;k<m[j].size();k++)
            {
                v=m[j][k];
                if((u&v)==0) ++re;
            }
            trans.m[i][j]=re;
        }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&N,&K);
    int all=(1<<K)-1;
    for(int i=0;i<=all;i++)
    if(judge(i)) add(i);
    pre();
    trans=trans^(N-1);
    ini=ini*trans;
    int ans=0;
    for(int i=1;i<=cnt;i++)
        ans+=ini.m[1][i],ans%=mod;
    printf("%d",ans);
    return 0;
}