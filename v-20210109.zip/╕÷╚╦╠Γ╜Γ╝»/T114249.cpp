#include<cstdio>
#include<algorithm> 
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int sz[200007];
int DP[200007];
struct E{
	int u,v;
}e[400007];
int first[200007],nt[400007];
int core,MAX,num;
int N;
void DFS(int u,int fa)
{
	sz[u]=1;
	int v;
	int ans=0;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			DFS(v,u);
			sz[u]+=sz[v];
			ans=max(sz[v],ans);
		}
	}
	ans=max(N-sz[u],ans);
	DP[u]=max(ans,DP[u]);
	if(DP[u]<DP[core])
	{
		core=u;
		MAX=DP[core];
	}
	return ;
}
int main()
{
	freopen("prince.in","r",stdin);
	freopen("prince.out","w",stdout);
	N=R();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		e[i]=(E){u,v};
		nt[i]=first[u];
		first[u]=i;
		e[i+N]=(E){v,u};
		nt[i+N]=first[v];
		first[v]=i+N;
	}
	DP[core]=N+1;
	DFS(1,0);
	for(int i=1;i<=N;i++)
	if(DP[i]==MAX) num++;
	if(num==1)
		printf("%d",N-MAX);
	else printf("%d",MAX);
	return 0;
}
