#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=11;
const int maxs=(1<<10);
int gate[maxn][maxn][maxn][maxn];
int F[maxn][maxn][maxs];
struct node{
	int x,y,sta;
};
node q[maxn*maxn];
int head=1,tail=0;
int N,M,P,K,S;
int key[maxn][maxn];
int nxt[4][2]=
{
	{1,0},
	{-1,0},
	{0,1},
	{0,-1}
};
void BFS()
{
	node t;
	memset(F,0x3f,sizeof(F));
	int x,y,nx,ny;
	t.x=1;t.y=1;t.sta=key[1][1];
	q[++tail]=t;
	F[1][1][t.sta]=0;
	while(head<=tail)
	{
		t=q[head];++head;
		x=t.x;y=t.y;
		for(int i=0;i<4;i++)
		{
			nx=x+nxt[i][0];
			ny=y+nxt[i][1];
			if(nx<1||nx>N||ny<1||ny>M) continue;
			if(gate[x][y][nx][ny]!=-1)
			{
				if(gate[x][y][nx][ny]==0) continue;
				if(!(gate[x][y][nx][ny]&t.sta)) continue;
			}
			if(F[x][y][t.sta]+1<F[nx][ny][t.sta|key[nx][ny]])
			{
				F[nx][ny][t.sta|key[nx][ny]]=F[x][y][t.sta]+1;
				q[++tail]=(node){nx,ny,t.sta|key[nx][ny]};
			}	
		}
	}
	return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d%d",&N,&M,&P);
	scanf("%d",&K);
	memset(gate,-1,sizeof(gate));
	int x1,y1,x2,y2,ty;
	for(register int i=1;i<=K;i++)
	{
		scanf("%d%d%d%d%d",&x1,&y1,&x2,&y2,&ty);
		if(ty==0) gate[x1][y1][x2][y2]=gate[x2][y2][x1][y1]=0;
		else gate[x1][y1][x2][y2]=gate[x2][y2][x1][y1]=(1<<ty-1);
	}
	scanf("%d",&S);int all=(1<<S)-1;
	for(register int i=1;i<=S;i++)
	{
		scanf("%d%d%d",&x1,&y1,&ty);
		key[x1][y1]|=(1<<ty-1);
	}	
	BFS();
	int ans=0x3f3f3f3f;
	for(register int i=0;i<=all;i++)
		ans=min(ans,F[N][M][i]);
	printf("%d",ans==0x3f3f3f3f?-1:ans);
	return 0;
}
