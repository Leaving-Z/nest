#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=200007;
int N,Q;
int C[2][maxn];
void update(int *C,int x,int k) {while(x<=N) C[x]^=k,x+=x&(-x);}
int query(int *C,int x) {int re=0;while(x) re^=C[x],x&=(x-1);return re;}
int A[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        update(C[i&1],i,A[i]);
    }
    int op,l,r;
    while(Q--)
    {
        scanf("%d%d%d",&op,&l,&r);
        if(op==1)
        {
            update(C[l&1],l,A[l]);
            update(C[l&1],l,A[l]=r);
        }
        else
        {
            if((r-l+1)&1)
            printf("%d\n",query(C[l&1],r)^query(C[l&1],l-1));
            else puts("0");
        }
    }
    return 0;
}