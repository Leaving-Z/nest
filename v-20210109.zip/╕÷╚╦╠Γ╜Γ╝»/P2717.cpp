#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
typedef long long LL;
int A[maxn];
LL d[maxn],sum[maxn];
int C[maxn];
int N,K;
void update(int x,int k) {while(x<=N) C[x]+=k,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re+=C[x],x&=(x-1);return re;}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&K);
    for(int i=1;i<=N;i++)
        scanf("%lld",&sum[i]),sum[i]+=sum[i-1],d[i]=sum[i]-K*i;
    sort(d+1,d+2+N);
    int tot=unique(d+1,d+2+N)-d-1,id;
    long long ans=0;
    id=lower_bound(d+1,d+1+tot,0)-d;
    update(id,1);
    for(int i=1;i<=N;i++)
    {
        id=lower_bound(d+1,d+1+tot,sum[i]-K*i)-d;
        ans+=query(id);
        update(id,1);
    }
    printf("%lld",ans);
    return 0;
}