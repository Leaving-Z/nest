#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=37;
int bit[maxn],N;
int A[maxn];
int F[maxn][maxn][maxn][maxn];
void print()
{
    for(int i=1;i<=N;i++)
        printf("%d ",A[i]);
    puts("");
    return ;
}
int dfs(int cur,int pre,bool less,int z,int o)
{
    if(cur>N)
    {
        if(z>=o&&less)
        {/*print();*/return 1;}
        return 0;
    }
    if(less&&F[pre][cur][z][o]!=-1) return F[pre][cur][z][o];
    int re=0;
    int lim=less?1:bit[cur];
    for(int i=0;i<=lim;i++)
    {
        //A[cur]=i;
        if(i==0&&cur==pre) re+=dfs(cur+1,pre+1,true,z,o);
        else re+=dfs(cur+1,pre,less||i<bit[cur],z+(i==0),o+(i==1));
    }
    if(less) F[pre][cur][z][o]=re;
    return re;
}
int l,r;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&l,&r);
    r++;
    while(r)
    {
        bit[++N]=r&1;
        r>>=1;
    }
    for(int i=1;i<=N/2;i++)
        swap(bit[i],bit[N-i+1]);
    memset(F,-1,sizeof(F));
    int re1=dfs(1,1,false,0,0);
    //printf("####\n");
    N=0;
    while(l)
    {
        bit[++N]=l&1;
        l>>=1;
    }
    memset(F,-1,sizeof(F));
    for(int i=1;i<=N/2;i++)
        swap(bit[i],bit[N-i+1]);
    printf("%d",re1-dfs(1,1,false,0,0));
    return 0;
}