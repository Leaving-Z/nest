#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=15000007;
int TREE[maxn],Ls[maxn],Rs[maxn];
int tag[maxn];
#define mid (L+R>>1)
int cnt=1,root=1;
inline void pushdown(int L,int R,int i)
{
	if(tag[i]==-1) return ;
	if(!Ls[i]) Ls[i]=++cnt;
	if(!Rs[i]) Rs[i]=++cnt;
	tag[Ls[i]]=tag[Rs[i]]=tag[i];
	TREE[Ls[i]]=(mid-L+1)*tag[Ls[i]];
	TREE[Rs[i]]=(R-mid)*tag[Rs[i]];
	tag[i]=-1;
	return ;
}
void Update(int L,int R,int l,int r,int k,int &i)
{
	if(!i) i=++cnt;
	if(l<=L&&R<=r)
	{
		tag[i]=k;
		TREE[i]=k*(R-L+1);
		return ;
	}
	pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls[i]);
	if(r>mid) Update(mid+1,R,l,r,k,Rs[i]);
	TREE[i]=TREE[Ls[i]]+TREE[Rs[i]];
	return ;
}
int N,Q;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
int main()
{
	N=R();Q=R();
	int op,l,r;
	for(int i=1;i<=Q;i++)
	{
		l=R();r=R();op=R();
		if(op==1)
			Update(1,N,l,r,1,root);
		else Update(1,N,l,r,0,root);
		printf("%d\n",N-TREE[1]);
	}
	return 0;
}
