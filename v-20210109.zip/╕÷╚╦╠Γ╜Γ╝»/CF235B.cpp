#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
double f[maxn],A[maxn];
int N,K;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%lf",&A[i]);
    long double p1=0;
    for(int i=1;i<=N;i++)
    {
        f[i]=f[i-1]+(2*p1+1)*A[i];
        p1=(p1+1)*A[i];
    }
    printf("%.15f",f[N]);
    return 0;
}