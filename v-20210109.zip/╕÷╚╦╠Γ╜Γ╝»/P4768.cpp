#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=200007;
const int inf=0x3f3f3f3f;
const int maxm=800007;
struct E{
    int u,v,w,h;
}e[maxm];
bool operator < (const E &x,const E &y)
{
    return x.h>y.h;
}
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w,int h)
{
    e[++ES]=(E){u,v,w,h};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,T,M,Q,K,s;
int dis[maxn<<1];
struct VD{
    int u,dis;
};
bool operator < (const VD &x,const VD &y)
{
    return x.dis>y.dis;
}
priority_queue <VD> q;
void Dijkstra()
{
    memset(dis,0x3f,sizeof(dis));
    dis[1]=0;
    VD t;
    int u,v;
    t.u=1;t.dis=0;
    q.push(t);
    while(!q.empty())
    {
        t=q.top();q.pop();
        if(dis[t.u]<t.dis) continue;
        u=t.u;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(dis[u]+e[i].w<dis[v])
            {
                dis[v]=dis[u]+e[i].w;
                t.u=v;t.dis=dis[v];
                q.push(t);
            }
        }
    }
    return ;
}
int S[maxn<<1],ch[maxn<<1][2],fa[maxn<<1][20],mx[maxn<<1][20];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
void Kruskal()
{
    int cnt=N;
    sort(e+1,e+1+ES);
    int u,v,f1,f2;
    for(int i=1;i<=2*N;i++)
        S[i]=i;
    for(int i=1;i<=ES;i++)
    {
        u=e[i].u;v=e[i].v;
        f1=f(u);f2=f(v);
        if(f1!=f2)
        {
            ++cnt;
            ch[cnt][0]=f1;ch[cnt][1]=f2;
            S[f1]=S[f2]=cnt;
            fa[f1][0]=fa[f2][0]=cnt;
            mx[f1][0]=mx[f2][0]=e[i].h;
        }
    }
    return ;
}
void dfs(int u)
{
    int v;
    if(ch[u][0]) dfs(ch[u][0]),dis[u]=min(dis[u],dis[ch[u][0]]);
    if(ch[u][1]) dfs(ch[u][1]),dis[u]=min(dis[u],dis[ch[u][1]]);
    return ;
}
int lstans;
void reset()
{
    memset(ch,0,sizeof(ch));
    memset(mx,0x3f,sizeof(mx));
    lstans=0;
    memset(fa,0,sizeof(fa));ES=0;
    memset(first,0,sizeof(first));
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    while(T--)
    {
        reset();
        scanf("%d%d",&N,&M);
        int u,v,w,h;
        for(int i=1;i<=M;i++)
        {
            scanf("%d%d%d%d",&u,&v,&w,&h);
            addE(u,v,w,h);addE(v,u,w,h);
        }
        Dijkstra();
        Kruskal();
        int root=f(1);
        dfs(root);
        for(int i=1;i<20;i++)
            for(int j=1;j<=2*N;j++)
                fa[j][i]=fa[fa[j][i-1]][i-1],mx[j][i]=min(mx[fa[j][i-1]][i-1],mx[j][i-1]);
        scanf("%d%d%d",&Q,&K,&s);
        int val;
        while(Q--)
        {
            scanf("%d%d",&u,&val);
            u=(u+K*lstans-1)%N+1;
            val=(val+K*lstans)%(s+1);
            for(int i=19;i>=0;i--)
                if(mx[u][i]>val&&mx[u][i]!=inf) u=fa[u][i];
            printf("%d\n",lstans=(dis[u]==inf?0:dis[u]));
        }
    }
    return 0;
}