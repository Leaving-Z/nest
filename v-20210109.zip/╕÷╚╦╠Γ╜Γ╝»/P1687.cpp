#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=3007;
int F[maxn][maxn][2];
int N,K;
int w[maxn],cnt;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&K);
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&w[++cnt]);
		if(w[cnt]>119) --cnt;
	}
	if(cnt<K) {printf("You can't do it.");return 0;}
	memset(F,0x3f,sizeof(F));
	for(int i=0;i<=cnt;i++)
		F[i][0][1]=0;
	for(int i=1;i<=cnt;i++)
		for(int j=1;j<=min(i,K);j++)
		{
			F[i][j][0]=F[i-1][j][0];
			F[i][j][1]=F[i-1][j][1];
			if(F[i-1][j-1][0]+w[i]>119)
			{
				if(F[i-1][j-1][1]+1<F[i][j][1])
					F[i][j][1]=F[i-1][j-1][1]+1,F[i][j][0]=w[i];
				else if(F[i-1][j-1][1]+1==F[i][j][1])
					F[i][j][0]=min(w[i],F[i][j][0]);
			}
			else
			{
				if(F[i-1][j-1][1]<F[i][j][1])
					F[i][j][1]=F[i-1][j-1][1],F[i][j][0]=F[i-1][j-1][0]+w[i];
				else if(F[i-1][j-1][1]==F[i][j][1])
					F[i][j][0]=min(F[i-1][j-1][0]+w[i],F[i][j][0]);
			}
		}
	/*for(int i=1;i<=cnt;i++)
		for(int j=1;j<=min(i,K);j++)
			printf("F[%d][%d]={%d,%d}\n",i,j,F[i][j][0],F[i][j][1]);*/
	printf("%d",F[cnt][K][1]);
	return 0;
}
