#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1000007;
int S[maxn],A[maxn];
int N,M,p,q;
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d%d",&N,&M,&p,&q);
    for(register int i=1;i<=N;i++)
        S[i]=i;
    int l,r,f1;
    for(int i=M;i>0;i--)
    {
        l=(i*p+q)%N+1;
        r=(i*q+p)%N+1;
        if(l>r) swap(l,r);
        for(int j=r;j>=l;j=f(j))
        {
            if(!A[j])
            {
                A[j]=i;
                f1=f(j-1);
                S[j]=f1;
            }
        }
    }
    for(int i=1;i<=N;i++)
        printf("%d\n",A[i]);
    return 0;
}