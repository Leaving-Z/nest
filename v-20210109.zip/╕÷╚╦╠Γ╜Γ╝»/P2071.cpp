#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=6007;
struct E{
	int u,v;
}e[maxn<<4];
int first[maxn<<1],nt[maxn<<4],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u]; 
	first[u]=ES;
	return ;
}
int match[maxn<<1];
bool book[maxn<<1];
int N,sum;
inline bool dfs(int u)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!book[v])
		{
			book[v]=true;
			if(!match[v]||dfs(match[v]))
			{
				match[v]=u;match[u]=v;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	scanf("%d",&N);
	int v1,v2;
	for(int i=1;i<=(N<<1);i++)
	{
		scanf("%d%d",&v1,&v2);
		addE(i,v1+N*3);addE(i,v1+N*4);
		addE(i,v2+N*3);addE(i,v2+N*4);
	}
	for(int i=1;i<=(N<<1);i++)
	{
		memset(book,0,sizeof(book));
		if(dfs(i)) ++sum;
	}
	printf("%d",sum);
	return 0;
}
