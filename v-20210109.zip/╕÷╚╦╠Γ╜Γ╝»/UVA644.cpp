#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int Trie[107][3];
int prefix[107],word[107];
char s[17];
bool flag;
int all;
inline void Insert()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'0';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
		if(word[p]||(prefix[p]>0&&s[i+1]==0)) flag=true;
		prefix[p]++;
	}
	word[p]++;
	return ;
}
int T;
int main()
{
	while(scanf("%s",s)!=EOF)
	{
		Insert();
		while(scanf("%s",s)!=EOF)
		{
			if(s[0]=='9')
			{
				printf("Set %d is ",++T);
				if(flag)
					 printf("not ");
				printf("immediately decodable\n");
				memset(Trie,0,sizeof(Trie));
				memset(prefix,0,sizeof(prefix));
				memset(word,0,sizeof(word));
				all=0;flag=false;
				break;
			}
			if(!flag) Insert();
		}
	}
	return 0;
}
