#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=500007;
const int inf=0x7f7f7f7f;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re,f=1;
    char c;
    while(!isdigit(c=getchar()))
    if(c=='-') f=-1;
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re*f;
}
struct seg_tree{
    int lt,rt,mx,sum;
}tree[maxn<<2];
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.mx=max(x.mx,y.mx);
    t.lt=max(x.lt,x.sum+y.lt);
    t.rt=max(y.rt,y.sum+x.rt);
    t.mx=max(t.mx,x.rt+y.lt);
    t.sum=x.sum+y.sum;
    return t;
}
int M=1,N,Q;
int A[maxn];
void build()
{
    while(M<=N) M<<=1;
    for(int i=1;i<=N;i++)
        tree[i+M].lt=tree[i+M].mx=tree[i+M].rt=tree[i+M].sum=A[i];
    for(int i=M-1;i>0;i--)
        tree[i]=tree[i<<1]+tree[i<<1|1];
    return ;
}
seg_tree query(int l,int r)
{
    seg_tree lx,rx;
    lx.lt=0;lx.mx=-inf;lx.rt=0;
    rx.lt=0;rx.mx=-inf;rx.rt=0;
    for(l=l+M-1,r=r+M+1;l^r^1;l>>=1,r>>=1)
    {
        if(~l&1) lx=lx+tree[l^1];
        if(r&1) rx=tree[r^1]+rx;
    }
    return lx+rx;
}
void update(int x,int k)
{
    x+=M;
    tree[x].lt=tree[x].mx=tree[x].rt=tree[x].sum=k;
    while(x>>=1) tree[x]=tree[x<<1]+tree[x<<1|1];
    return ;
}
void print(int x)
{
    if(x<0) putchar('-'),x=-x;
    if(x>=10) print(x/10);
    putchar(x%10+'0');
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    //freopen("2.out","w",stdout);
    #endif
    N=R();Q=R();
    for(int i=1;i<=N;i++)
        A[i]=R();
    build();
    int op,l,r;
    while(Q--)
    {
        op=R();l=R();r=R();
        if(op==1)
        {
            if(l>r) swap(l,r);
            print(query(l,r).mx);
            puts("");
        }
        else update(l,r);
    }
    return 0;
}