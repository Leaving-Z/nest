#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=(1<<20)+7;
typedef unsigned int ui;
const ui b=131;
int T;
char s[maxn];
int N;
unsigned int sum[maxn],pb[maxn];
int f[maxn];
int mk[37];
int A[maxn];
int C[maxn];
void update(int x,int k)
{
	while(x<=27) C[x]++,x+=x&(-x);
	return ; 
}
int query(int x)
{
	int re=0;
	while(x) re+=C[x],x&=(x-1);
	return re;
}
int main()
{
	//freopen("1.in","r",stdin);
	//freopen("1.out","w",stdout);
	scanf("%d",&T);
	pb[0]=1;
	for(int i=1;i<maxn;i++)
		pb[i]=pb[i-1]*b;
	while(T--)
	{
		memset(mk,0,sizeof(mk));
		memset(C,0,sizeof(C));
		scanf("%s",s+1);
		N=strlen(s+1);
		for(int i=1;i<=N;i++)
			sum[i]=sum[i-1]*b+(ui)s[i];
		int tmp;
		f[N+1]=0;
		for(int i=N;i>0;i--)
		{
			tmp=s[i]-'a';
			if(mk[tmp]&1) f[i]=f[i+1]-1;
			else f[i]=f[i+1]+1;
			++mk[tmp];
		}
		ui t,val;
		int cnt,lp;
		memset(mk,0,sizeof(mk));
		long long res=0,tc;
		for(int i=2;i<N;i++)
		{
			t=sum[i];
			cnt=1;lp=i;
			for(int k=i+1;k+i-1<N;k+=i)
			{
				val=sum[k+i-1]-sum[k-1];
				if(val!=t*pb[k-1]) break;
				++cnt;lp=k+i-1;
			}
			tmp=s[i-1]-'a';
			if(mk[tmp]&1) A[i]=A[i-1]-1;
			else A[i]=A[i-1]+1;
			++mk[tmp];
			update(A[i]+1,1);
			tmp=f[lp+1];
			tc=query(tmp+1);
			/*
			for(int k=0;k<=tmp;k++)//ż������ 
				tc+=ans[k];*/
			res+=tc*((cnt+1)/2);
			lp-=i;
			if(lp>1)
			{
				tmp=f[lp+1];tc=query(tmp+1);
				/*for(int k=0;k<=tmp;k++)
					tc+=ans[k];*/
				res+=tc*(cnt/2);
			}
		}
		printf("%lld\n",res);
	}
	return 0;
}