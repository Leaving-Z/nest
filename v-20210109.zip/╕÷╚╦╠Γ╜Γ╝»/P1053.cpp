#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
int N,cnt;
int l[maxn],r[maxn];
int A[maxn],book[maxn],vis[maxn];
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d%d",&l[i],&r[i]);
	int f=1,v=l[1];
	while(cnt<2*N)
	{
		A[++cnt]=f;
		vis[f]++;
		if(l[v]!=f) f=v,v=l[v];
		else if(r[v]!=f) f=v,v=r[v];
		else {printf("-1");return 0;}
	}
	
	for(int i=1;i<=N;i++)
	if(vis[i]!=2) {printf("-1");return 0;}
	int maxx=0;
	for(int i=1;i<=cnt;i++)
		book[i-A[i]+N]++,maxx=max(maxx,book[i-A[i]+N]);
	memset(book,0,sizeof(book));
	for(int i=1;i<=cnt;i++)
		book[cnt-i+1-A[i]+N]++,maxx=max(maxx,book[cnt-i+1-A[i]+N]);
	printf("%d",N-maxx);
	return 0;
}
