#include<cstdio>
#include<algorithm>
using namespace std;
struct E{
	int u,v;
}e[3007];
int first[1507],nt[3007],ES;
int cost[1507];
int N;
int DP[1507][3];
int in[1507];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
void dfs(int u,int fa)
{
	int v;
	DP[u][1]=cost[u];
	bool flag=true;int minn=0x7f7f7f7f;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dfs(v,u);
		DP[u][1]+=min(DP[v][1],min(DP[v][0],DP[v][2]));
		if(DP[v][1]<DP[v][0])
		{
			flag=false;
			DP[u][0]+=DP[v][1];
		}
		else DP[u][0]+=DP[v][0];
		minn=min(minn,DP[v][1]-DP[v][0]);
		DP[u][2]+=min(DP[v][1],DP[v][0]);
	}
	if(flag)
	DP[u][0]+=minn;
	return ;
}
int main()
{
	scanf("%d",&N);
	int u,k,v;
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&u);
		scanf("%d%d",&cost[u],&k);
		while(k--)
		{
			scanf("%d",&v);
			addE(u,v);
			in[v]++;
		}
	}
	for(int i=1;i<=N;i++)
	if(in[i]==0)
	{
		dfs(i,0);
		printf("%d",min(DP[i][1],DP[i][0]));
		return 0;
	}
}
