#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=100007;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N;
int F[maxn][3];//0-> covered by father 1->build one 2->covered by son
inline void dfs(int u,int fa)
{
	int v,minn=0x7f7f7f7f;F[u][1]=1;
	bool f=true;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			F[u][1]+=min(F[v][0],min(F[v][1],F[v][2]));
			F[u][0]+=min(F[v][1],F[v][2]);
			if(F[v][1]<=F[v][2]) f=false;
			else minn=min(minn,F[v][1]-F[v][2]);
			F[u][2]+=min(F[v][1],F[v][2]);
		}
	}
	if(f) F[u][2]+=minn;
	return ;
}
int main()
{
	N=R();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	dfs(1,0);
	printf("%d",min(F[1][1],F[1][2]));
	return 0;
}
