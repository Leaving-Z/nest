#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1000007;
int f[maxn];
char s[maxn];
int stk[maxn],top;
int N;
int main()
{
	scanf("%s",s+1);
	N=strlen(s+1);
	int ans=0;
	for(int i=1;i<=N;i++)
	{
		if(s[i]=='('||s[i]=='[')
			stk[++top]=i;
		else
		{
			if(s[i]==')')
			{
				if(top&&s[stk[top]]=='(')
				{
					f[i]=i-stk[top]+1+f[stk[top]-1];
					--top;
				}
				else top=0;
			}
			else
			{
				if(top&&s[stk[top]]=='[')
				{
					f[i]=i-stk[top]+1+f[stk[top]-1];
					--top;
				}
				else top=0;
			}
		}
		ans=max(ans,f[i]);
	}
	for(int i=1;i<=N;i++)
	if(f[i]==ans)
	{
		for(int k=i-ans+1;k<=i;k++)
			putchar(s[k]);
		break;
	}
	return 0;
}
