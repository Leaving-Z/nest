#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=100007;
const int maxm=200007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,Q;
int A[maxn];
int fa[maxn],top[maxn],depth[maxn],sz[maxn];
int ix,son[maxn],id[maxn],anti[maxn];
void dfs1(int u)
{
	sz[u]=1;
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		depth[v]=depth[u]+1;
		fa[v]=u;
		A[v]=1;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[son[u]]<sz[v]) son[u]=v;
	}
	return ;
}
void dfs2(int u,int tp)
{
	int v;
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs2(son[u],tp);
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return ;
}
struct seg{
	int b,w;
}TREE[maxn<<2];
seg operator + (const seg &x,const seg &y)
{
	seg t=x;
	t.b+=y.b;t.w+=y.w;
	return t;
}
#define mid (L+R>>1)
#define black(i) TREE[i].b
#define white(i) TREE[i].w
#define node(i) TREE[i]
#define Ls (i<<1)
#define Rs (i<<1|1)
void Build(int L,int R,int i)
{
	if(L==R) {black(i)=A[anti[L]];return ;}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	node(i)=node(Ls)+node(Rs);
	return ;
}
void Update(int L,int R,int x,int k,int i)
{
	if(L==R)
	{
		if(k) black(i)=0,white(i)=1;
		else black(i)=1,white(i)=0;
		return ; 
	}
	if(x<=mid) Update(L,mid,x,k,Ls);
	else Update(mid+1,R,x,k,Rs);
	node(i)=node(Ls)+node(Rs);
	return ;
}
seg Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return node(i);
	seg t;t.b=0;t.w=0;
	if(l<=mid) t=t+Query(L,mid,l,r,Ls);
	if(r>mid) t=t+Query(mid+1,R,l,r,Rs);
	return t;
}
int Query_Path(int x,int y)
{
	int re1=0;seg re;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		re=Query(1,N,id[top[x]],id[x],1);
		if(re.w) return -1;
		re1+=re.b;
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	re=Query(1,N,id[x]+1,id[y],1);
	if(re.w) return -1;
	return re1+re.b;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();
	int u,v,w;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	dfs1(1);dfs2(1,1);
	Build(1,N,1);
	Q=R();
	while(Q--)
	{
		w=R();u=R();
		if(w==1)
		{
			v=depth[e[u*2].u]>depth[e[u*2].v]?e[u*2].u:e[u*2].v;
			Update(1,N,id[v],0,1);
		}
		else if(w==2)
		{
			v=depth[e[u*2].u]>depth[e[u*2].v]?e[u*2].u:e[u*2].v;
			Update(1,N,id[v],1,1);
		}
		else
		{
			v=R();
			printf("%d\n",Query_Path(u,v));
		}
	}
	return 0;
}
