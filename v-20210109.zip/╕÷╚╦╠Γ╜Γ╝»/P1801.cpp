#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cstdlib>
using namespace std;
const int maxn=200007;
struct Treap{
	int l,r,num,pri,s,v;
}TREE[maxn];
int N,M,all,root;
int in[maxn],que[maxn];
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define val(i) TREE[i].v
#define sz(i) TREE[i].s
#define c(i) TREE[i].num
#define p(i) TREE[i].pri
inline int Read()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Insert(int &i,const int &v)
{
	if(!i)
	{
		i=++all;val(i)=v;
		sz(i)=c(i)=1;L(i)=R(i)=0;
		p(i)=rand();
		return ;
	}
	++sz(i);
	if(v==val(i)) ++c(i);
	else if(v<val(i))
	{
		Insert(L(i),v);
		if(p(L(i))<p(i)) Zig(i);
	}
	else
	{
		Insert(R(i),v);
		if(p(R(i))<p(i)) Zag(i);
	}
	return ;
}
inline int KTH(int k)
{
	int i=root;
	while(i)
	{
		if(sz(L(i))<k&&sz(L(i))+c(i)>=k) return val(i);
		else if(sz(L(i))>=k) i=L(i);
		else k-=sz(L(i))+c(i),i=R(i);
	}
}
int main()
{
	N=Read();M=Read();
	for(register int i=1;i<=N;i++)
		in[i]=Read();
	for(register int i=1;i<=M;i++)
		que[i]=Read();
	int top=1;
	int i1=0,k=0;
	while(1)
	{
		while(i1!=que[top]&&i1<=N)
			Insert(root,in[++i1]);
		while(que[top]==i1&&i1<=N)
			printf("%d\n",KTH(++k)),top++;
		if(i1>N) break;
	}
	return 0;
}
