#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=100007;
const int maxh=107;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int F[maxh];
int N,C,H;
int h[maxn];
struct node{
	int v,id;
};
node q1[maxn],q2[maxn];
int h1=1,t1,h2=1,t2;
int main()
{
	N=R();C=R();
	for(int i=1;i<=N;i++)
		h[i]=R(),H=max(h[i],H);
	node t;
	for(int i=h[1];i<=H;i++)
	{
		t.v=(i-h[1])*(i-h[1])+C*i;
		t.id=i;
		while(h1<=t1&&q1[t1].v>=t.v) --t1;
		q1[++t1]=t;
		t.v-=2*C*i;
		while(h2<=t2&&q2[t2].v>=t.v) --t2;
		q2[++t2]=t;
	}
	for(int i=2;i<=N;i++)
	{
		memset(F,0x7f,sizeof(F));
		for(int j=h[i];j<=H;j++)
		{
			while(h1<=t1&&q1[h1].id<j) ++h1;
			if(h1<=t1) F[j]=min(F[j],q1[h1].v-j*C+(j-h[i])*(j-h[i]));
			while(h2<=t2&&q2[h2].id>j) ++h2;
			if(h2<=t2) F[j]=min(F[j],q2[h2].v+j*C+(j-h[i])*(j-h[i]));
		}
		h1=1;t1=0;h2=1;t2=0;
		for(int j=1;j<=H;j++)
		{
			t.v=F[j]+j*C;
			t.id=j;
			while(h1<=t1&&q1[t1].v>=t.v) --t1;
			q1[++t1]=t;
			t.v-=2*C*j;
			while(h2<=t2&&q2[t2].v>=t.v) --t2;
			q2[++t2]=t;
		}
	}
	int ans=0x7f7f7f7f;
	for(int i=1;i<=H;i++)
		ans=min(ans,F[i]);
	printf("%d",ans);
	return 0;
}
