#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#define CW true
using namespace std;
queue <int> q;
typedef long long LL;
int N,W,S,T,t;
const int maxm=2000007;
const int maxn=2020;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf,w;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf,int w)
{
	e[++ES]=(E){u,v,cf,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf,int w)
{
	addE(u,v,cf,w);addE(v,u,0,-w);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
bool book[maxn];
LL dis[maxn];
int pre[maxn][2],f[maxn];
inline int abs_(const int &x) {return x>0?x:-x;}
inline bool SPFA()
{
	int u,v;
	memset(dis,0x1f,sizeof(dis));
	memset(f,0x7f,sizeof(f));
	q.push(S);book[S]=CW;
	dis[S]=0;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				f[v]=min(f[u],cf(i));
				pre[v][0]=u;pre[v][1]=i;
				if(!book[v])
				{
					book[v]=CW;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=dis[T+1];
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int a[maxn];
int main()
{
	N=R();W=R();t=N+N+1;T=N+N+2;
	for(register int i=1;i<=N;i++)
		a[i]=R();
	int w;
	for(register int i=1;i<=N;i++)
	{
		add(i,t,1,W);add(S,i,1,0);
		for(register int j=1;j<i;j++)
		{
			w=abs_(a[i]-a[j]);
			if(w>=W) continue;
			add(i,j+N,1,w);
		}
	}
	for(register int i=1;i<=N;i++)
		add(i+N,T,1,0);
	add(t,T,inf,0);
	LL ans=0;
	while(SPFA())
	{
		ans+=dis[T]*f[T];
		Update();
	}
	printf("%lld",ans);
	return 0;
}
