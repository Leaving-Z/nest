#include<cstdio>
#include<cstring>
#include<cctype>
#include<algorithm>
using namespace std;
const int maxn=50007;
struct Line{
    int k,b,id;
}line[maxn];
bool operator < (const Line &x,const Line &y)
{
    if(x.k==y.k) return x.b>y.b;
    return x.k<y.k;
}
int N;
int stk[maxn],top;
int ans[maxn];
double getp(int x,int y)
{
    return 1.0*(line[y].b-line[x].b)/(line[x].k-line[y].k);
}
bool com(const int &x,const int &y)
{
    return line[x].id<line[y].id;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
    {
        scanf("%d%d",&line[i].k,&line[i].b);
        line[i].id=i;
    }
    sort(line+1,line+1+N);
    line[0].k=-100000000;
    for(int i=1;i<=N;i++)
    {
        if(i!=1&&line[i].k==line[i-1].k) continue;
        while(top>1&&getp(i,stk[top])<=getp(stk[top],stk[top-1])) --top;
        stk[++top]=i;
    }
    /*
    sort(stk+1,stk+1+top,com);
    for(int i=1;i<=top;i++)
        printf("%d ",line[stk[i]].id);*/
    for(int i=1;i<=top;i++)
        ans[i]=line[stk[i]].id;
    sort(ans+1,ans+1+top);
    for(int i=1;i<=top;i++)
        printf("%d ",ans[i]);
    return 0;
}