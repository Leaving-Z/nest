#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int F[107][107];
struct node{
	int h,w;
}A[107];
bool com(const node &x,const node &y)
{
	return x.h<y.h;
}
int N,k;
int main()
{
	scanf("%d%d",&N,&k);
	memset(F,0x7f,sizeof(F));
	for(int i=1;i<=N;i++)
		scanf("%d%d",&A[i].h,&A[i].w),F[i][1]=0;
	sort(A+1,A+1+N,com);
	for(int i=2;i<=N;i++)
		for(int j=1;j<i;j++)
			for(int l=2;l<=min(i,N-k);l++)
				F[i][l]=min(F[i][l],F[j][l-1]+abs(A[i].w-A[j].w));
	int ans=0x7f7f7f7f;
	for(int i=N-k;i<=N;i++)
		ans=min(ans,F[i][N-k]);
	printf("%d",ans);
	return 0;
}
