#include<cstdio>
#include<algorithm>
using namespace std;
int a[5][7],cnt[5];
bool f;
int op[5],use[5][4];
void cpy(int u,int x,int y)
{
	for(int i=1;i<=cnt[u];i++)
	{
		if(i==x||i==y) continue;
		a[u+1][++cnt[u+1]]=a[u][i];
	}
	use[u][1]=a[u][x];use[u][2]=a[u][y];
	use[u][3]=a[u+1][1];
	return ;
}
void print()
{
	for(int i=1;i<=3;i++)
	{
		if((op[i]&1)&&use[i][1]<use[i][2]) swap(use[i][1],use[i][2]);
		printf("%d",use[i][1]);
		if(op[i]==1) putchar('+');
		else if(op[i]==2) putchar('-');
		else if(op[i]==3) putchar('*');
		else putchar('/');
		printf("%d=%d\n",use[i][2],use[i][3]);
	}
	return ;
}
void dfs(int u)
{
	if(a[u][1]<=0) return ;
	if(u==4&&a[u][cnt[u]]==24) print(),exit(0);
	else if(u==4) return ;
	for(int i=1;i<=cnt[u];i++)
	{
		for(int j=1;j<=cnt[u];j++)
		{
			if(i==j) continue;
			cnt[u+1]=0;
			op[u]=1;
			a[u+1][++cnt[u+1]]=a[u][i]+a[u][j];
			cpy(u,i,j);
			dfs(u+1);
			
			cnt[u+1]=0;
			op[u]=2;
			a[u+1][++cnt[u+1]]=a[u][i]-a[u][j];
			cpy(u,i,j);
			dfs(u+1);
			
			cnt[u+1]=0;
			op[u]=3;
			a[u+1][++cnt[u+1]]=a[u][i]*a[u][j];
			cpy(u,i,j);
			dfs(u+1);
			
			if(a[u][j]!=0&&a[u][i]%a[u][j]==0)
			{
				cnt[u+1]=0;
				op[u]=4;
				a[u+1][++cnt[u+1]]=a[u][i]/a[u][j];
				cpy(u,i,j);
				dfs(u+1);
			}
		}
	}
}
int main()
{
	cnt[1]=4;
	scanf("%d%d%d%d",&a[1][1],&a[1][2],&a[1][3],&a[1][4]);
	dfs(1);
	printf("No answer!");
	return 0;
}
