#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#include<cctype>
using namespace std;
const int maxn=100007;
const int maxm=1000007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,M;
bool ins[maxn];
int dfn[maxn],low[maxn],C,T,stk[maxn],top,S[maxn];
int A[maxn],Max[maxn],Min[maxn];
void dfs(int u)
{
    int v;
    ins[u]=true;
    stk[++top]=u;
    dfn[u]=low[u]=++T;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
        else if(ins[v]) low[u]=min(low[u],dfn[v]);
    }
    if(dfn[u]==low[u])
    {
        int p;C++;
        do{
            p=stk[top--];
            S[p]=C;
            Max[C]=max(Max[C],A[p]);
            Min[C]=min(Min[C],A[p]);
            ins[p]=false;
        }while(p!=u);
    }
}
queue <int> q;
int in[maxn];
int ans;
void topo()
{
    for(int i=1;i<=C;i++)
    if(!in[i]) q.push(i);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            Min[v]=min(Min[v],Min[u]);
            in[v]--;
            if(!in[v]) q.push(v);
        }
    }
    return ;
}
int vis[maxn];
bool dfs_(int u)
{
    if(vis[u]) return vis[u]>0;
    if(u==S[N]) return vis[u]=1;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(dfs_(v)) vis[u]=1;
    }
    if(vis[u]==0) vis[u]=-1;
    return vis[u]>0;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    memset(Min,0x7f,sizeof(Min));
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    int u,v,ty;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d",&u,&v,&ty);
        addE(u,v);
        if(ty>1) addE(v,u);
    }
    for(int i=1;i<=N;i++)
    if(!dfn[i]) dfs(i);
    int t=ES;
    ES=0;memset(first,0,sizeof(first));
    for(int i=1;i<=t;i++)
    {
        if(S[e[i].u]!=S[e[i].v])
        {
            in[S[e[i].v]]++;
            addE(S[e[i].u],S[e[i].v]);
        }
    }
    topo();
    dfs_(S[1]);
    for(int i=1;i<=N;i++)
    if(vis[i]>0) ans=max(ans,Max[i]-Min[i]);
    printf("%d",ans);
    return 0;
}