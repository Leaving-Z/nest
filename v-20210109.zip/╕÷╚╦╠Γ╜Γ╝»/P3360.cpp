#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector> 
using namespace std;
const int maxn=307;
const int maxv=607;
vector <int> val[maxn],ti[maxn];
int F[maxn][maxv];
int T,N;
int W[maxn];
int son[maxn][2];
void build(int u,int k)
{
	int w,t,v;
	scanf("%d%d",&w,&t);w<<=1;
	v=++N;
	son[u][k]=v;W[v]=w;
	if(t)
	{
		for(int i=1;i<=t;i++)
		{
			scanf("%d",&w);val[v].push_back(w);
			scanf("%d",&w);ti[v].push_back(w);
		}
		return ;
	}
	else build(v,0),build(v,1);
}
void dfs(int u,int dis)
{
	if(!u) return ;
	for(int i=0;i<ti[u].size();i++)
		for(int j=T;j>=dis+ti[u][i];j--)
		F[u][j]=max(F[u][j],F[u][j-ti[u][i]]+val[u][i]);
	dfs(son[u][0],dis+W[son[u][0]]);
	dfs(son[u][1],dis+W[son[u][1]]);
	if(!son[u][0]&&!son[u][1]) return ;
	for(int i=T-dis;i>=0;i--)//ʣ��ʱ�� 
		for(int j=0;j<=i;j++)
			F[u][dis+i]=max(F[u][dis+i],F[son[u][0]][dis+j]+F[son[u][1]][dis+i-j]);
	return ;
}
int main()
{
	scanf("%d",&T);T--;
	N=1;
	build(1,0);
	dfs(1,0);
	printf("%d",F[1][T]);
	return 0;
}
