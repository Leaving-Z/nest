#include<cstdio>
#include<algorithm>
using namespace std;
inline int Read()
{
	int re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int C[1000007];
int lastp[1000007];
int A[1000007];
int N,M;
inline void Update(int x,int k)
{
	for(;x<=N;x+=(x&(-x)))
	C[x]+=k;
	return ;
}
inline int Q(int x)
{
	int ans=0;
	for(;x>0;x-=(x&(-x)))
	ans+=C[x];
	return ans;
}
struct q{
	int L,R,num;
}Question[1000007];
int ANS[1000007];
int low=1;
bool operator < (const q &a,const q &b)
{
	return a.R<b.R;
}
int main()
{
	N=Read();
	for(int i=1;i<=N;i++)
	A[i]=Read();
	M=Read();
	int l,r;
	for(int i=1;i<=M;i++)
	{
		l=Read();r=Read();
		Question[i]=(q){l,r,i};
	}
	sort(Question+1,Question+1+M);
	for(int i=1;i<=N;i++)
	{
		while(Question[low].R<i&&low<=M)
		{
			ANS[Question[low].num]=Q(Question[low].R)-Q(Question[low].L-1);
			low++;
		}
		Update(i,1);
		if(lastp[A[i]]!=0)
		Update(lastp[A[i]],-1);
		lastp[A[i]]=i;
	}
	while(low<=M)
	{
		ANS[Question[low].num]=Q(Question[low].R)-Q(Question[low].L-1);
		low++;
	}
	for(int i=1;i<=M;i++)
	printf("%d\n",ANS[i]);
	return 0;
}
