#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#include<cctype>
using namespace std;
queue <int> q;
const int Maxn=207;
const int maxn=807;
const int maxm=200007;
typedef long long LL;
LL inf;
struct E{
    int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES;
#define cf(i) e[i].cf
inline void reset()
{
    ES=1;
    memset(first,0,sizeof(first));
    return ;
}
inline void addE(int u,int v,int cf)
{
    e[++ES]=(E){u,v,cf};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int S,T;
int N,M;
inline void add(int u,int v,int cf)
{
    addE(u,v,cf);addE(v,u,0);
    return ;
}
int dep[maxn],cur[maxn];
bool BFS()
{
    q.push(S);
    memset(dep,0,sizeof(dep));
    dep[S]=1;
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(!dep[v]&&cf(i)>0)
            {
                dep[v]=dep[u]+1;
                q.push(v);
            }
        }
    }
    return dep[T]!=0;
}
int dfs(int u,int f)
{
    if(u==T) return f;
    int v,d,sum=0;
    for(int &i=cur[u];i;i=nt[i])
    {
        v=e[i].v;
        if(dep[v]==dep[u]+1&&cf(i)>0)
        {
            d=dfs(v,min(f,cf(i)));
            if(d>0)
            {
                sum+=d;f-=d;
                cf(i)-=d;cf(i^1)+=d;
                if(f<=0) return sum;
            }
        }
    }
    return sum;
}
int Dinic()
{
    int re=0;
    while(BFS())
    {
        memcpy(cur,first,sizeof(cur));
        re+=dfs(S,2e9);
    }
    return re;
}
LL m[Maxn][Maxn];
int cow[Maxn],lim[Maxn];
int tot;
bool check(LL p)
{
    reset();
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            if(m[i][j]<=p) add(i,j+N,2e9);
    for(int i=1;i<=N;i++)
        add(S,i,cow[i]),add(i+N,T,lim[i]);
    return Dinic()>=tot;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    T=2*N+1;
    int cap=0;
    for(int i=1;i<=N;i++)
        scanf("%d%d",&cow[i],&lim[i]),tot+=cow[i],cap+=lim[i];
    if(tot>cap) {printf("-1");return 0;}
    memset(m,0x3f,sizeof(m));
    inf=m[0][0];
    for(int i=1;i<=N;i++)
        m[i][i]=0;
    int u,v;
    LL w;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%lld",&u,&v,&w);
        m[u][v]=m[v][u]=min(m[u][v],w);
    }
    for(int k=1;k<=N;k++)
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
                m[i][j]=min(m[i][j],m[i][k]+m[k][j]);
    LL L=0,R=1e14,mid,ans=-1;
    while(L<=R)
    {
        mid=(L+R>>1);
        if(check(mid)) R=mid-1,ans=mid;
        else L=mid+1;
    }
    printf("%lld",ans);
    return 0;
}