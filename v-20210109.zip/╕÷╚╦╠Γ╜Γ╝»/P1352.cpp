#include<cstdio>
#include<algorithm>
using namespace std;
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v;
}e[12007];
int first[6007],nt[12007],ES;
int value[6007],in[6007];
int DP[6007][2];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
}
int N,root;
void dfs(int u)
{
	int v;
	DP[u][1]=value[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dfs(v);
		DP[u][0]+=max(DP[v][1],DP[v][0]);
		DP[u][1]+=DP[v][0];
	}
	return ;
}
int main()
{
	N=Read();
	int u,v;
	for(int i=1;i<=N;i++)
		value[i]=Read();
	while(1)
	{
		u=Read();v=Read();
		if(u==0||v==0) break;
		addE(v,u);
		in[u]++;
	}
	for(int i=1;i<=N;i++)
	if(in[i]==0)
	{
		root=i;
		dfs(i);
		printf("%d",max(DP[root][0],DP[root][1]));
		return 0;
	}
}
