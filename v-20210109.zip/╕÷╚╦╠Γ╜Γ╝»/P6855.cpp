#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=2007;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
typedef long long LL;
LL F1[maxn][maxn],F2[maxn][maxn],H1[maxn],H2[maxn],m[maxn][maxn];
int N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
            m[i][j]=R();
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        {
            F1[i][j]=m[i][j];
            if(i>1) F1[i][j]=max(F1[i][j],F1[i-1][j]+m[i][j]);
            if(j>1) F1[i][j]=max(F1[i][j],F1[i][j-1]+m[i][j]);
        }
    for(int i=N;i>=1;i--)
        for(int j=M;j>=1;j--)
        {
            F2[i][j]=m[i][j];
            if(i<N) F2[i][j]=max(F2[i][j],F2[i+1][j]+m[i][j]);
            if(j<M) F2[i][j]=max(F2[i][j],F2[i][j+1]+m[i][j]);
        }
    long long ans=1e18,tmp;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        {
            tmp=0;
            if(i>1&&j<M) tmp=max(tmp,H2[j]);
            if(i<N&&j>1) tmp=max(tmp,H1[i]);
            tmp=max(tmp,max(F1[i-1][j],F1[i][j-1])+max(F2[i+1][j],F2[i][j+1]));
            ans=min(ans,tmp);
            if(j<M) H2[j]=max(H2[j],F1[i][j]+F2[i][j+1]);
            if(i<N) H1[i]=max(H1[i],F1[i][j]+F2[i+1][j]);
        }
    printf("%lld",ans);
    return 0;
}