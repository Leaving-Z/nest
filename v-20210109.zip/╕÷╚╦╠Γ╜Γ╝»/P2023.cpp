#include<cstdio>
#include<algorithm>
using namespace std;
typedef unsigned long long LL;
inline LL Read()
{
	char c;
	LL f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
LL TREE[400007],add[400007],multi[400007];
LL N,M,P;
LL A[100007];
void Build(LL L,LL R,LL i)
{
	multi[i]=1;
	if(L==R)
	{
		TREE[i]=A[L];
		return ;
	}
	LL mid=L+R>>1;
	Build(L,mid,i<<1);
	Build(mid+1,R,i<<1|1);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	return ;
}
void LAZY(LL L,LL R,LL i)
{
	LL mid=L+R>>1;
	TREE[i<<1]=((TREE[i<<1]*multi[i])%P+(add[i]*(mid-L+1))%P)%P;
	TREE[i<<1|1]=((TREE[i<<1|1]*multi[i])%P+(add[i]*(R-mid))%P)%P;
	
	add[i<<1]*=multi[i];add[i<<1]%=P;
	add[i<<1]+=add[i];add[i<<1]%=P;
	
	add[i<<1|1]*=multi[i];add[i<<1|1]%=P;
	add[i<<1|1]+=add[i];add[i<<1|1]%=P;
	
	multi[i<<1]*=multi[i];multi[i<<1]%=P;
	multi[i<<1|1]*=multi[i];multi[i<<1|1]%=P;
	
	add[i]=0;multi[i]=1; 
	return ;
}
void Update(LL L,LL R,LL l,LL r,LL i,LL k,bool flag)
{
	if(l<=L&&R<=r)
	{
		if(flag)
		{
			add[i]*=k;
			multi[i]*=k;
			TREE[i]*=k;
			add[i]%=P;multi[i]%=P;TREE[i]%=P;
		}
		else
		{
			add[i]+=k;
			TREE[i]+=(R-L+1)*k;
			add[i]%=P;TREE[i]%=P;
		}
		return ;
	}
	LL mid=L+R>>1;
	LAZY(L,R,i);
	if(l<=mid) Update(L,mid,l,r,i<<1,k,flag);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k,flag);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	return ;
}
LL Query(LL L,LL R,LL l,LL r,LL i)
{
	if(l<=L&&R<=r)
		return TREE[i];
	LL mid=L+R>>1;
	LL re=0;
	LAZY(L,R,i);
	if(l<=mid)
	{
		re+=Query(L,mid,l,r,i<<1);
		re%=P;
	}
	if(r>mid)
	{
		re+=Query(mid+1,R,l,r,i<<1|1);
		re%=P;
	}
	return re;
}
int main()
{
	N=Read();P=Read();
	LL s,x,y,k;
	for(LL i=1;i<=N;i++)
	A[i]=Read();
	Build(1,N,1);
	M=Read();
	for(LL i=1;i<=M;i++)
	{
		s=Read();x=Read();y=Read();
		if(s==1)
		{
			k=Read();
			Update(1,N,x,y,1,k,true);
		}
		else if(s==2)
		{
			k=Read();
			Update(1,N,x,y,1,k,false);
		}
		else
		printf("%llu\n",Query(1,N,x,y,1));
	}
	return 0;
}
