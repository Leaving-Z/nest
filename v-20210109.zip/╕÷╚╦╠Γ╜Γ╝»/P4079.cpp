#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<cmath>
using namespace std;
const int maxn=1007;
const int maxm=20007;
const double eps=1e-7;
struct E{
    int u,v,x,y;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int x,int y)
{
    e[++ES]=(E){u,v,x,y};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,M,T;
bool vis[maxn];
double sp[maxn];
void dfs(int u,double x)
{
    if(vis[u]) return ;
    sp[u]=x;
    vis[u]=true;
    int v;
    double s;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        s=x*e[i].y/e[i].x;
        dfs(v,s);
    }
    return ;
}
void reset()
{
    memset(vis,0,sizeof(vis));
    memset(first,0,sizeof(first));ES=0;
    memset(sp,0,sizeof(sp));
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    int cas=0;
    scanf("%d",&T);
    while(cas<T)
    {
        reset();
        scanf("%d%d",&N,&M);
        int u,v,x,y;
        for(int i=1;i<=M;i++)
        {
            scanf("%d%d%d%d",&u,&v,&x,&y);
            addE(u,v,x,y);
            addE(v,u,y,x);
        }
        dfs(1,100);
        double s;
        bool f=true;
        for(int i=1;i<=ES;i++)
        {
            u=e[i].u;v=e[i].v;
            s=sp[u]*e[i].y/e[i].x;
            if(fabs(s-sp[v])>eps) {f=false;break;}
        }
        ++cas;
        printf("Case #%d: ",cas);
        if(f) puts("Yes");
        else puts("No");
    }
    return 0;
}