#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1000007;
typedef unsigned long long ull;
struct E{
	int u,v;
}e[maxn];
int first[67],nt[maxn],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int d[maxn];//��ɢ����
bool hv[67],book[maxn];
// ��iλ�Ƿ����  ��i��������û�� 
ull A[maxn];
int N,M,C,K;
int main()
{
	
	scanf("%d%d%d%d",&N,&M,&C,&K);
	for(int i=1;i<=N;i++)
		scanf("%llu",&A[i]);
	int x,y;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&x,&y);
		d[i]=y;
		addE(x,y);
	}
	sort(d+1,d+1+M);
	for(int i=1;i<=M;i++)
		e[i].v=lower_bound(d+1,d+1+M,e[i].v)-d;
	int cnt=0;
	for(int i=1;i<=N;i++)
	{
		for(int k=0;k<K;k++)
		{
			if(A[i]&(1ull<<k))
			{
				if(hv[k]) continue;
				hv[k]=true;++cnt;
				for(int l=first[k];l;l=nt[l])
				{
					y=e[l].v;
					book[y]=true;
				}
			}
		}	
	}
	int ans=0;
	bool f;
	for(int k=0;k<K;k++)
	{
		f=true;
		for(int i=first[k];i;i=nt[i])
		{
			y=e[i].v;
			if(!book[y]) f=false;
		}
		ans+=f?1:0;
	}
	if(ans==64)
	{
        if(N)
		printf("%llu",((1ull<<63)-N)*2+N);
        else printf("18446744073709551616");
	}
	else
	{
		printf("%llu",(1ull<<ans)-N);
	}
	return 0;
}