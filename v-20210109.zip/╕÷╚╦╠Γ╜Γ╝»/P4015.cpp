#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
const int maxn=21000;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,w;
}e[maxn];
int first[maxn],nt[maxn],ES=1;
int CF[maxn],cf1[maxn];
#define cf(i) CF[i]
inline void addE(int u,int v,int cf,int w)
{
	e[++ES]=(E){u,v,w};
	CF[ES]=cf1[ES]=cf;
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M,S,T;
int ans1,ans2;
int dis[maxn],f[maxn],pre[maxn][2];
bool book[maxn];
queue <int> q;
bool op(int x,int y,int s)
{
	if(s==1) return x<y;
	return x>y;
}
inline bool EK(int s)
{
	int u,v;
	memset(dis,s*0x7f,sizeof(dis));
	memset(f,0x7f,sizeof(f));
	q.push(S);
	book[S]=true;dis[S]=0;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&op(dis[u]+e[i].w,dis[v],s))
			{
				dis[v]=dis[u]+e[i].w;
				pre[v][0]=u;pre[v][1]=i;
				f[v]=min(f[u],cf(i));
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	if(s==1) return dis[T]!=inf;
	return dis[T]!=dis[T+1];
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int A[maxn];
int main()
{
	//freopen("P4015_6.in","r",stdin);
	M=R();N=R();S=0;T=N+M+1;
	int u,v,cf,w;
	for(register int i=1;i<=M;i++)
		addE(S,i,R(),0),addE(i,S,0,0);
	for(register int i=1;i<=N;i++)
		A[i]=R(),addE(i+M,T,A[i],0),addE(T,i+M,0,0);
	for(register int i=1;i<=M;i++)
		for(register int j=1;j<=N;j++)
		{
			w=R();
			addE(i,j+M,A[j],w);
			addE(j+M,i,0,-w);
		}
	while(EK(1))
	{
		ans1+=f[T]*dis[T];
		Update();
	}
	memcpy(CF,cf1,sizeof(cf1));
	while(EK(-1))
	{
		ans2+=f[T]*dis[T];
		Update();
	}
	printf("%d\n%d",ans1,ans2);
	return 0;
}
