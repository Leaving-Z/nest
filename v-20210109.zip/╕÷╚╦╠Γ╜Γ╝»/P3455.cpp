#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=50007;
int mu[maxn],prime[maxn],cnt;
bool book[maxn];
void pre()
{
    mu[1]=1;
    for(int i=2;i<=50000;i++)
    {
        if(!book[i]) {prime[++cnt]=i;mu[i]=-1;}
        for(int j=1;j<=cnt&&i*prime[j]<=50000;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else {mu[i*prime[j]]=0;break;}
        }
    }
    for(int i=1;i<=50000;i++)
        mu[i]+=mu[i-1];
    return ;
}
int calc(int n,int m)
{
    if(n<m) swap(n,m);
    int L=1,R,res=0;
    while(L<=m)
    {
        R=min(n/(n/L),m/(m/L));
        res+=(mu[R]-mu[L-1])*(n/L)*(m/L);
        L=R+1;
    }
    return res;
}
int T;
int a,b,k;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    pre();
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&a,&b,&k);
        printf("%d\n",calc(a/k,b/k));
    }
    return 0;
}