#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=1000007;
typedef long long LL;
int A[maxn];
struct seg_tree{
    LL c,sum;
}TREE[maxn<<2];
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.c=x.c+y.c;
    t.sum=x.sum+y.sum;
    return t;
}
#define Ls (i<<1)
#define Rs (i<<1|1)
#define mid (L+R>>1)
#define c(i) TREE[i].c
#define sum(i) TREE[i].sum
#define v(i) TREE[i]
int N,M;
void Update(int L,int R,int x,int k1,int k2,int i)
{
    if(L==R)
    {
        c(i)+=k1;
        sum(i)+=k2;
        return ;
    }
    if(x<=mid) Update(L,mid,x,k1,k2,Ls);
    else Update(mid+1,R,x,k1,k2,Rs);
    v(i)=v(Ls)+v(Rs);
    return ;
}
seg_tree Query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return v(i);
    seg_tree re;re.sum=re.c=0;
    if(l<=mid) re=re+Query(L,mid,l,r,Ls);
    if(r>mid) re=re+Query(mid+1,R,l,r,Rs);
    return re;
}
int d[maxn],id[maxn],anti[maxn];
int op[maxn][3];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    char qwq[7];
    for(int i=1;i<=M;i++)
    {
        scanf("%s",qwq);scanf("%d%d",&op[i][1],&op[i][2]);
        d[i]=op[i][2];
        if(qwq[0]=='U') op[i][0]=1;
    }
    sort(d+1,d+1+M);
    int tot=unique(d+1,d+1+M)-d-1;
    for(int i=1;i<=M;i++)
    {
        id[i]=lower_bound(d+1,d+1+tot,op[i][2])-d;
        anti[id[i]]=op[i][2];
    }
    Update(0,tot,0,N,0,1);
    seg_tree t;
    for(int i=1;i<=M;i++)
    {
        if(op[i][0])
        {
            Update(0,tot,A[op[i][1]],-1,-anti[A[op[i][1]]],1);
            A[op[i][1]]=id[i];
            Update(0,tot,id[i],1,op[i][2],1);
        }
        else
        {
            t=Query(0,tot,0,id[i]-1,1);
            if(1ll*op[i][1]*op[i][2]<=t.sum+op[i][2]*(N-t.c)) puts("TAK");
            else puts("NIE");
        }
    }
    return 0;
}