#include<cstdio>
#include<algorithm>
using namespace std;
struct E{
	int u,v,w;
}Edge[400005];
int first[5005],nt[400005],s[5005];
int N,M;
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int _find(int x)
{
	return s[x]==x?x:s[x]=_find(s[x]);
}
void merge_(int x,int y)
{
	int t1=_find(x),t2=_find(y);
	s[t2]=s[t1];
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);
	int u,v,w;
	for(int i=1;i<=N;i++)
		s[i]=i;
	for(int i=0;i<M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		Edge[i]=(E){u,v,w};
		Edge[i+M]=(E){v,u,w};
		nt[i]=first[u];
		nt[i+M]=first[v];
		first[u]=i;
		first[v]=i+M;
	}
	sort(Edge,Edge+2*M);
	int k=0,ans=0;
	for(int i=0;i<2*M;i++)
	{
		if(_find(Edge[i].u)!=_find(Edge[i].v))
		{
			merge_(Edge[i].u,Edge[i].v);
			ans=max(ans,Edge[i].w);
			k++;
		}
		if(k==N-1) break;
	}
	if(k==N-1) printf("%d",ans);
	else printf("-1");
	return 0;
} 
