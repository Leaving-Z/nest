#include<cstdio>
#include<algorithm>
using namespace std;
const int MOD=99999997;
inline int Read()
{
	int f=1,re;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int N;
int C[200007];
int a[100007],b[100007],c[100007],d[100007],s[100007];
bool com1(int j,int k)
{
	return a[j]<a[k];
}
bool com2(int j,int k)
{
	return b[j]<b[k];
}
void Update(int x,int k)
{
	while(x<=N)
	{
		C[x]+=k;
		x+=x&(-x);
	}
	return ;
}
int Query(int x)
{
	int re=0;
	while(x>0)
	{
		re+=C[x];
		x-=x&(-x);
	}
	return re;
}
void Rank()
{
	N=Read();
	for(register int i=1;i<=N;i++)
	{
		a[i]=Read();
		c[i]=i;
	}
	for(register int i=1;i<=N;i++)
	{
		b[i]=Read();
		d[i]=i;
	}
	sort(c+1,c+1+N,com1);
	sort(d+1,d+1+N,com2);
	for(register int i=1;i<=N;i++)
		s[c[i]]=d[i];
}
int ans;
int main()
{
	Rank();
	for(register int i=N;i>0;--i)
	{
		ans+=Query(s[i]-1);
		Update(s[i],1);
		ans%=MOD;
	}
	printf("%d",ans);
	return 0;
}
