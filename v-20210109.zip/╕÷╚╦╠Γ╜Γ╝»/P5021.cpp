#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=50007;
const int maxm=100007;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,M;
int re,lim;
int mx[maxn];
int c[maxn],fa[maxn];
bool book[maxn];
void dfs(int u)
{
    int v;
    int cnt=0;
    mx[u]=0;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        fa[v]=u;
        dfs(v);
    }
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        c[++cnt]=mx[v]+e[i].w;
        book[cnt]=false;
    }
    sort(c+1,c+1+cnt);
    int p;
    while(c[cnt]>=lim&&cnt>0) ++re,--cnt;
    for(int i=1;i<=cnt;i++)
    {
        if(book[i]) continue;
        book[i]=true;
        p=lower_bound(c+1,c+1+cnt,lim-c[i])-c;
        if(p>cnt) {book[i]=false;continue;}
        while(p<cnt&&book[p]) ++p;
        if(!book[p]&&c[i]+c[p]>=lim) book[p]=true,++re;
        else book[i]=false;
    }
    while(cnt)
    {
        if(!book[cnt]) {mx[u]=c[cnt];break;}
        --cnt;
    }
    return ;
}
bool check()
{
    re=0;
    dfs(1);
    return re>=M;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,w;
    for(int i=1;i<N;i++)
        scanf("%d%d%d",&u,&v,&w),addE(u,v,w),addE(v,u,w);
    int L=0,R=1e9,ans;
    while(L<=R)
    {
        lim=L+R>>1;
        if(check()) ans=lim,L=lim+1;
        else R=lim-1;
    }
    printf("%d",ans);
    return 0;
}