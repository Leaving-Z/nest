#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
LL F[100007],N,T,ans;
struct ingre{
	LL a,b,c;
}it[57];
bool com(const ingre &x,const ingre &y)
{
	return x.c*y.b<x.b*y.c;
}
LL R()
{
	char c;
	LL re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	T=R();N=R();
	for(register int i=1;i<=N;i++) it[i].a=R();
	for(register int i=1;i<=N;i++) it[i].b=R();
	for(register int i=1;i<=N;i++) it[i].c=R();
	sort(it+1,it+1+N,com);
	for(register int i=1;i<=N;i++)
		for(register int j=T;j>=it[i].c;j--)
			F[j]=max(F[j],F[j-it[i].c]+it[i].a-j*it[i].b),ans=max(ans,F[j]);
	printf("%lld",ans);
	return 0;
}
