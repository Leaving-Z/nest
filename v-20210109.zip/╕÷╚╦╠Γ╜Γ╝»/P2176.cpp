#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=107;
const int maxm=10007;
int N,M;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ; 
}
int dis[maxn],pre[maxn],pre1[maxn];
bool book[maxn];
void SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	dis[1]=0;book[1]=true;
	q.push(1);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				pre[v]=i;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		addE(u,v,w);addE(v,u,w);
	}
	SPFA();
	memcpy(pre1,pre,sizeof(pre));
	int t=dis[N],ans=0;
	u=N;
	while(u!=1)
	{
		e[pre1[u]].w<<=1;
		e[pre1[u]^1].w<<=1;
		SPFA();
		ans=max(ans,dis[N]-t);
		e[pre1[u]].w>>=1;
		e[pre1[u]^1].w>>=1;
		u=e[pre1[u]].u;
	}
	printf("%d",ans);
	return 0;
}
