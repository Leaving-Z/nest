#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
queue <int> q;
struct E{
	int u,v;
}e[100007],ex[100007];
int ES;
inline int R()
{
	char c;
	int f=1,re=0;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int first[10007],nt[100007];
int dfn[10007],low[10007];
int C,T,S[10007];
int pt[10007];
int st[10007],top;
bool inst[10007];
int ans;
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(inst[v])
		low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int p;
		C++;
		while(p=st[top--])
		{
			inst[p]=false;
			S[p]=u;
			if(p==u) break;
			pt[u]+=pt[p];
		}
	}
	return ;
}
int N,M;
int dp[10007],in[10007];
void DP()
{
	for(int i=1;i<=N;i++)
	if(S[i]==i&&in[i]==0) q.push(i),dp[i]=pt[i];
	int t,v;
	while(!q.empty())
	{
		t=q.front();q.pop();
		for(int i=first[t];i;i=nt[i])
		{
			v=ex[i].v;
			dp[v]=max(dp[t]+pt[v],dp[v]);
			in[v]--;
			if(in[v]==0) q.push(v);
		}
	}
	for(int i=1;i<=N;i++)
	ans=max(ans,dp[i]);
	return ;
}
int main()
{
	N=R();M=R();
	for(int i=1;i<=N;i++)
		pt[i]=R();
	int u,v;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		e[i]=(E){u,v};
		nt[i]=first[u];
		first[u]=i;
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	memset(first,0,sizeof(first));
	memset(nt,0,sizeof(nt));
	for(int i=1;i<=M;i++)
	{
		if(S[e[i].u]!=S[e[i].v])
		{
			ex[++ES]=(E){S[e[i].u],S[e[i].v]};
			in[S[e[i].v]]++;
			nt[ES]=first[S[e[i].u]];
			first[S[e[i].u]]=ES;
		}
	}
	DP();
	printf("%d",ans);
	return 0;
}
