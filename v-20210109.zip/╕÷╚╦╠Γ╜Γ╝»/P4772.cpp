#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
#include<string>
#include<iostream>
using namespace std;
const int maxm=507;
const int maxn=17;
const int maxs=(1<<17);
int R,C,N;
char m[maxm][maxm];
int d[maxm][maxm];
int p[maxn][2];
int dis[maxn][maxn];
int F[maxs][maxn];
struct node
{
    int x,y;
};
int nxt[4][2]=
{
    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
};
queue <node> q;
void BFS(int sx,int sy)
{
    memset(d,-1,sizeof(d));
    node t;t.x=sx;t.y=sy;
    d[sx][sy]=0;
    q.push(t);
    int x,y,nx,ny;
    while(!q.empty())
    {
        t=q.front();q.pop();
        x=t.x;y=t.y;
        for(int i=0;i<4;i++)
        {
            nx=x+nxt[i][0];ny=y+nxt[i][1];
            if(nx<1||nx>R||ny<1||ny>C||m[nx][ny]=='*'||d[nx][ny]!=-1) continue;
            d[nx][ny]=d[x][y]+1;
            q.push((node){nx,ny});
        }
    }
    return ;
}
string ans,s;
void dfs(int u,int sta,int d)
{
    s[N-d]='A'+u-1;
    if(u==1)
    {
        if(ans.length()==0)
            ans=s;
        else if(s<ans) ans=s;
        return ;
    }
    int nxt=sta^(1<<u-1);
    for(int i=1;i<=N;i++)
    if((nxt&(1<<i-1))!=0&&F[nxt][i]+dis[i][u]==F[sta][u])
        dfs(i,nxt,d+1);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&R,&C,&N);
    for(int i=1;i<=R;i++)
        scanf("%s",m[i]+1);
    for(int i=1;i<=R;i++)
        for(int j=1;j<=C;j++)
        if(isalpha(m[i][j])) p[m[i][j]-'A'+1][0]=i,p[m[i][j]-'A'+1][1]=j;
    for(int i=1;i<=N;i++)
    {
        BFS(p[i][0],p[i][1]);
        for(int j=1;j<=N;j++)
        if(i!=j) dis[i][j]=d[p[j][0]][p[j][1]];
    }
    int all=(1<<N)-1;
    memset(F,0x7f,sizeof(F));
    F[1][1]=0;
    for(int i=1;i<=all;i++)
    {
        for(int j=1;j<=N;j++)
        {
            if((i&(1<<j-1))==0) continue;
            if(F[i][j]==0x7f7f7f7f) continue;
            for(int k=1;k<=N;k++)
            {
                if(i&(1<<k-1)) continue;
                if(F[i|(1<<k-1)][k]>F[i][j]+dis[j][k])
                {
                    F[i|(1<<k-1)][k]=F[i][j]+dis[j][k];
                }
            }
        }
    }
    int minn=1e9;
    for(int i=2;i<=N;i++)
        minn=min(minn,F[all][i]);
    s.resize(20);
    for(int i=2;i<=N;i++)
    if(F[all][i]==minn) dfs(i,all,1);
    printf("%d\n",minn);
    cout<<ans;
    return 0;
}