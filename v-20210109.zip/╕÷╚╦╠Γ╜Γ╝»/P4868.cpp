#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
	char c;
	int re;
	while(!isdigit(c=getchar()));
	re=c-48;
	while(isdigit(c=getchar()))
	re=re*10+c-48;
	return re;
}
const int maxn=100007;
typedef long long LL;
LL A[maxn],sum[maxn];
LL TREE[maxn<<2],tag[maxn<<2];
int N,Q;
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
void pushdown(int L,int R,int i)
{
	if(!tag[i]) return ;
	TREE[Ls]+=(mid-L+1)*tag[i];
	tag[Ls]+=tag[i];
	TREE[Rs]+=(R-mid)*tag[i];
	tag[Rs]+=tag[i];
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,LL k,int i)
{
	if(l<=L&&R<=r) {TREE[i]+=(R-L+1)*k;tag[i]+=k;return ;}
	pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	TREE[i]=TREE[Ls]+TREE[Rs];
	return ;
}
LL Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return TREE[i];
	pushdown(L,R,i);
	LL re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;
}
int main()
{
	N=R();Q=R();
	for(int i=1;i<=N;i++)
		A[i]=R(),sum[i]=A[i]+sum[i-1],Update(1,N,i,i,sum[i],1);
	char s[7];
	LL x,y;
	while(Q--)
	{
		scanf("%s",s);x=R();
		if(s[0]=='Q') printf("%lld\n",Query(1,N,1,x,1));
		else
		{
			y=R();
			Update(1,N,x,N,y-A[x],1);
			A[x]=y; 
		}
	}
	return 0;
}
