#include<cstdio>
#include<algorithm>
#include<cstring>
#include<string>
#include<map>
#include<iostream>
using namespace std;
const int maxn=8007;
const int maxm=24007;
map <string, int> mp;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,cnt;
string s;
int stk[maxn],top,S[maxn],C;
int dfn[maxn],low[maxn],T;
bool ins[maxn];
void dfs(int u)
{
	stk[++top]=u;
	dfn[u]=low[u]=++T;
	ins[u]=true;
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v])
		{
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int main()
{
	cin.tie(0);
	cin>>N;
	int x,y;
	for(register int i=1;i<=N;i++)
	{
		cin>>s;
		mp[s]=++cnt;
		x=cnt;
		cin>>s;
		mp[s]=++cnt;
		y=cnt;
		addE(x,y);
	}
	cin>>M;
	for(register int i=1;i<=M;i++)
	{
		cin>>s;
		y=mp[s];
		cin>>s;
		x=mp[s];
		addE(x,y);
	}
	for(register int i=1;i<=cnt;i++)
	if(!dfn[i]) dfs(i);
	for(register int i=1;i<=cnt;i+=2)
	{
		if(S[i]!=S[i+1]) puts("Safe");
		else puts("Unsafe");
	}
	return 0;
}
