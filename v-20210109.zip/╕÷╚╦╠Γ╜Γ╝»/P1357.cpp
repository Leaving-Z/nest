#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=37;
const int mod=1e9+7;
typedef long long LL;
struct Matrix {
    LL m[maxn][maxn];
    Matrix() {memset(m,0,sizeof(m));return ;}
}trans;
int all;
Matrix operator * (const Matrix &x,const Matrix &y)
{
    Matrix t;
    for(int k=0;k<=all;k++)
        for(int i=0;i<=all;i++)
            for(int j=0;j<=all;j++)
                t.m[i][j]=(t.m[i][j]+x.m[i][k]*y.m[k][j]%mod)%mod;
    return t;
}
Matrix operator ^ (Matrix b,LL k)
{
    Matrix s;
    for(int i=0;i<=all;i++)
        s.m[i][i]=1;
    while(k)
    {
        if(k&1) s=s*b;
        b=b*b;
        k>>=1;
    }
    return s;
}
LL N;
int M,K;
int bitsum[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%d%d",&N,&M,&K);
    all=(1<<M)-1;
    for(int i=1;i<=all;i++)
        bitsum[i]=bitsum[i>>1]+(i&1);
    int tmp;
    for(int i=0;i<=all;i++)
    {
        if(bitsum[i]>K) continue;
        tmp=(i<<1)&all;
        if(bitsum[tmp]<=K) trans.m[i][tmp]=1;
        tmp|=1;
        if(bitsum[tmp]<=K) trans.m[i][tmp]=1;
    }
    trans=trans^N;
    int ans=0;
    for(int i=0;i<=all;i++)
    {
        ans+=trans.m[i][i];
        if(ans>=mod) ans-=mod;
    }
    printf("%d",ans);
    return 0;
}