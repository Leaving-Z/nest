#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
typedef long long LL;
LL A,B,C;
struct Hash_table{
	static const LL MOD=1999997;
	LL Hash[MOD],V[MOD],stk[MOD],top;
	//Hash_table() {memset(Hash,-1,sizeof(Hash));}
	inline void Insert(LL val,LL mi)
	{
		LL h=val%MOD;
		while(Hash[h]&&Hash[h]!=val) h++;
		Hash[h]=val;V[h]=mi;
		stk[++top]=h;
		return ;
	}
	inline LL find(LL val)
	{
		LL h=val%MOD;
		while(Hash[h]&&Hash[h]!=val) h++;
		return Hash[h]==val?V[h]:-1;
	}
}H;
inline LL fast_pow(LL b,LL k)
{
	LL s=1;
	while(k)
	{
		if(k&1) s=(s*b)%C;
		b=(b*b)%C;
		k>>=1;
	}
	return s;
}
LL N;
int main()
{
	scanf("%lld%lld",&A,&C);
	LL sqrtm=ceil(sqrt(C));
	LL ti=fast_pow(A,sqrtm);
	LL t=ti;
	for(LL i=1;i<=sqrtm;i++)
	{
		H.Insert(t,i*sqrtm);
		t=t*ti%C;
	}
	scanf("%lld",&N);
	LL x,y,ans;
	for(int i=1;i<=N;i++)
	{
		scanf("%lld%lld",&x,&y);
		t=x;
		for(int j=0;j<sqrtm;j++)
		{
			if((ans=H.find(t))!=-1)
			{
				ans-=j;
				printf("%lld\n",fast_pow(y,ans));
				break;
			}
			t=t*A%C;
		}
	}
	return 0;
}
