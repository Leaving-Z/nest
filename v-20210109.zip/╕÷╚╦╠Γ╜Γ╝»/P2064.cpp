#include<cstdio>
#include<algorithm>
using namespace std;
int S;
int ans=0x7f7f7f7f;
void dfs(int u,int sum)
{
    if(!sum)
    {
        ans=min(ans,u);
        return ;
    }
    --sum;
    for(int i=2;i<=9;i++)
    if(sum%i==0) dfs(u+1,sum/i);
    return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
    scanf("%d",&S);
    if(S==1) {printf("-1");return 0;}
    for(int i=1;i*i<=S;i++)
    if(S%i==0)
    {
        if(S/i!=S) dfs(0,i);
        dfs(0,S/i);
	}
    if(ans==0x7f7f7f7f) printf("-1");
    else printf("%d",ans);
    return 0;
}
