#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=507;
int sum[maxn];
int F[maxn][maxn];
int N,K;
inline void print(int u)
{
	if(u==0) return ;
	for(register int i=u;i>=0;i--)
		if(i==0||sum[u]-sum[i-1]>F[K][N])
		{
			print(i);
			printf("%d %d\n",i+1,u);
			return ;
		}
}
int main()
{
	scanf("%d%d",&N,&K);
	for(register int i=1;i<=N;i++)
		scanf("%d",&sum[i]),sum[i]+=sum[i-1];
	memset(F,0x7f,sizeof(F));
	for(register int i=1;i<=N;i++)
		F[1][i]=sum[i];
	for(int i=2;i<=K;i++)//�������� 
		for(int j=1;j<=N;j++)//����λ�� 
			for(int k=2;k<=j;k++)//��ʼλ�� 
			{
				if(max(F[i-1][k-1],sum[j]-sum[k-1])<F[i][j])
					F[i][j]=max(F[i-1][k-1],sum[j]-sum[k-1]);
			}
	print(N);
	return 0;
}
