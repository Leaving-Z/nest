#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
const LL p=1e9+7;
LL a,b,N,ans;
LL f[1000007];
inline LL fast_pow(LL ba,LL k)
{
	LL s=1;
	while(k)
	{
		if(k&1) s=(s*ba)%p;
		ba=(ba*ba)%p;
		k>>=1;
	}
	return s;
}
int main()
{
	scanf("%lld%lld%lld",&a,&b,&N);
	f[0]=1;
	for(int i=1;i<=N;i++)
		f[i]=(f[i-1]*i)%p;
	LL x;bool flag;
	for(int i=0;i<=N;i++)
	{
		x=i*a+(N-i)*b;flag=true;
		while(x)
		{
			if(x%10!=a&&x%10!=b)
			{
				flag=false;
				break;
			}
			x/=10;
		}
		if(flag) ans=(ans+(f[N]*fast_pow(f[i]*f[N-i]%p,p-2))%p)%p;
	}
	printf("%lld",ans);
	return 0; 
}
