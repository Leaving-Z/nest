#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=5000007; 
typedef long long LL;
int A[maxn],C[maxn];
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();M=R();
	for(register int i=1;i<=N;i++)
		A[i]=R();
	int x,y,z;
	for(register int i=1;i<=M;i++)
	{
		x=R();y=R();z=R();
		C[x]+=z;
		C[y+1]-=z;
	}
	int ans=0x7f7f7f7f;
	for(register int i=1;i<=N;i++)
	{
		C[i]+=C[i-1];
		A[i]+=C[i];
		ans=min(A[i],ans);
	}
	printf("%d",ans);
	return 0;
}
