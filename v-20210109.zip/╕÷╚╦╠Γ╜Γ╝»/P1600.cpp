#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<vector>
#include<ctime>
using namespace std;
const int maxn=300007;
const int maxm=600007;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
inline void swap_(int &x,int &y)
{
    int t=x;
    x=y;
    y=t;
    return ;
}
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int dep[maxn],fa[maxn],son[maxn],sz[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dep[v]=dep[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int top[maxn];
void dfs2(int u,int tp)
{
    top[u]=tp;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int LCA(int x,int y)
{
    while(top[x]!=top[y])
    {
        if(dep[top[x]]<dep[top[y]]) swap_(x,y);
        x=fa[top[x]];
    }
    return dep[x]>dep[y]?y:x;
}
int t1[maxn],t2[maxn<<1];
int ans[maxn],w[maxn];
int N,M;
vector <int> l1[maxn],l2[maxn],add[maxn];
int book[maxn];
void dfs(int u)
{
    int mk1=t1[dep[u]+w[u]],mk2=t2[dep[u]-w[u]+N];
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dfs(v);
    }
    t1[dep[u]]+=book[u];
    for(int i=0;i<add[u].size();i++)
    {
        v=add[u][i];
        t2[v]++;
    }
    ans[u]+=t1[dep[u]+w[u]]-mk1+t2[dep[u]-w[u]+N]-mk2;
    for(int i=0;i<l1[u].size();i++)
    {
        v=l1[u][i];
        t1[v]--;
    }
    for(int i=0;i<l2[u].size();i++)
    {
        v=l2[u][i];
        t2[v]--;
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    int u,v;
    for(int i=1;i<N;i++)
    {
        u=R();v=R();
        addE(u,v);addE(v,u);
    }
    dfs1(1);dfs2(1,1);
    for(int i=1;i<=N;i++)
        w[i]=R();
    int dis,lca;
    while(M--)
    {
        u=R();v=R();
        lca=LCA(u,v);
        dis=dep[u]+dep[v]-2*dep[lca];
        book[u]++;
        add[v].push_back(dep[v]-dis+N);
        l1[lca].push_back(dep[u]);
        l2[lca].push_back(dep[v]-dis+N);
        if(dep[u]==dep[lca]+w[lca]) ans[lca]--;
    }
    dfs(1);
    for(int i=1;i<=N;i++)
        printf("%d ",ans[i]);
    return 0;
}