#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=10000007;
const int mod=100000001;
int A[maxn];
long long a,b,c,a1;
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    scanf("%lld%lld%lld%lld",&a,&b,&c,&a1);
    A[1]=a1;
    for(int i=2;i<=N;i++)
        A[i]=(a*A[i-1]+b)%mod;
    for(int i=1;i<=N;i++)
        A[i]=A[i]%c+1;
    double ans=0;
    A[N+1]=A[1];
    for(int i=1;i<=N;i++)
        ans+=min(A[i],A[i+1])/(1.0*A[i]*A[i+1]);
    printf("%.3f",ans);
    return 0;
}
