#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=525017;
const int maxm=525017;
const int maxb=21;
const int SIZE=maxn*maxb;
int ch[SIZE][2],all,root[maxn],book[SIZE],f[SIZE];
int W[maxn];
int N;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
void pushup(int p,int cnt)
{
    f[p]=0;
    f[p]^=f[ch[p][0]];
    if(book[ch[p][1]]&1) f[p]^=(1<<cnt);
    f[p]^=f[ch[p][1]];
    return ;
}
void insert(int p,int val,int cnt)
{
    ++book[p];
    if(cnt==maxb) return ;
    int t;
    if(val&(1<<cnt)) t=1;
    else t=0;
    if(!ch[p][t]) ch[p][t]=++all;
    insert(ch[p][t],val,cnt+1);
    pushup(p,cnt);
    return ;
}
void add(int p,int cnt)
{
    if(cnt==maxb) return ;
    swap(ch[p][0],ch[p][1]);
    if(ch[p][0]) add(ch[p][0],cnt+1);
    pushup(p,cnt);
    return ;
}
int merge(int i1,int i2)
{
    if(!i1||!i2) return i1+i2;
    book[i1]+=book[i2];
    f[i1]^=f[i2];
    ch[i1][0]=merge(ch[i1][0],ch[i2][0]);
    ch[i1][1]=merge(ch[i1][1],ch[i2][1]);
    return i1;
}
long long ans=0;
void dfs(int u)
{
    int v;
    root[u]=++all;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dfs(v);
        root[u]=merge(root[u],root[v]);
    }
    add(root[u],0);
    insert(root[u],W[u],0);
    ans+=f[root[u]];
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("tree9.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&W[i]);
    int u;
    for(int i=2;i<=N;i++)
        scanf("%d",&u),addE(u,i);
    dfs(1);
    printf("%lld",ans);
    //printf("\n%d",all);
    return 0;
}