#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
inline int LOG(int x)//�ǵü�һ 
{
	if(x==1) return 0;
	int k=1;
	while((1<<k)<=x)
	k++;
	return k;
}
int all,ask;
int RMQ[1000007][30];
int ans[1000007];
int main()
{
	memset(RMQ,0x7f,sizeof(RMQ));
	all=Read();ask=Read();
	for(int i=1;i<=all;i++)
	RMQ[i][0]=Read();
	for(int j=1;(1<<j)<=all;j++)
		for(int i=1;(1<<j)+i-1<=all;i++)
		RMQ[i][j]=min(RMQ[i][j-1],RMQ[i+(1<<j-1)][j-1]);
	int L,R,k;
	for(int i=1;i<=ask;i++)
	{
		L=Read();R=Read();
		if(L>R)//log(0)RE 
		swap(L,R); 
		if(L==R)
		{
			ans[i]=RMQ[L][0];
			continue;
		}
		int k=LOG(R-L+1)-1;
		ans[i]=min(RMQ[L][k],RMQ[R-(1<<k)+1][k]);
	}
	for(int i=1;i<=ask;i++)
	printf("%d ",ans[i]);
	return 0;
}
