#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
const int maxn=100007;
LL sum[maxn];
LL A[maxn];
struct node{
	int L,R;
}range[maxn];
int st[maxn];
int top,N;
inline LL Read()
{
	char c;
	LL re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=Read();
	for(register int i=1;i<=N;i++)
	{
		A[i]=Read();
		sum[i]=sum[i-1]+A[i];
		range[i].L=range[i].R=i;
		while(top>0&&A[i]<A[st[top]])
		{
			range[i].L=range[st[top]].L;
			range[st[top]].R=i-1;
			--top;
		}
		st[++top]=i;
	}
	while(top) range[st[top--]].R=N;
	LL ans=-1;
	for(int i=1;i<=N;i++)
		ans=max(ans,A[i]*(sum[range[i].R]-sum[range[i].L-1]));
	printf("%lld",ans);
	return 0;
}
