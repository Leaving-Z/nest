#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int N,K;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=100007;
const int maxm=200007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int pre[maxn],dis[maxn],fa[maxn];
void dfs(int u)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			dis[v]=dis[u]+e[i].w;
			pre[v]=i;
			dfs(v);
		}
	}
	return ;
}
int maxE[maxn][2],len;
void dfs1(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs1(v,u);
			if(maxE[v][0]+e[i].w>=maxE[u][0]) maxE[u][1]=maxE[u][0],maxE[u][0]=maxE[v][0]+e[i].w;
			else if(maxE[v][0]+e[i].w>maxE[u][1]) maxE[u][1]=maxE[v][0]+e[i].w;
		}
	}
	len=max(len,maxE[u][0]+maxE[u][1]);
	return ;
}
int l,r;
void solve_2()
{
	int u=l;
	while(u!=r)
	{
		e[pre[u]^1].w=e[pre[u]].w=-1;
		u=e[pre[u]].u;
	}
	dfs1(r,0);
	return ;
}
int main()
{
	N=R();K=R();
	int u,v;
	int ans=2*(N-1);
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v,1);addE(v,u,1);
	}
	dfs(1);
	int maxx=0;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],r=i;
	memset(fa,0,sizeof(fa));
	dis[r]=0;
	dfs(r);
	maxx=0;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],l=i;
	if(K==2)
		solve_2();
	printf("%d",ans-maxx-len+K);
	return 0;
}
