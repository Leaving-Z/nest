#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
const int maxn=1007;
const int maxv=60007;
const int lim=20000;
const int mod=998244353;
int N;
int h[maxn];
int f[maxv],g[maxv];
int main()
{
	scanf("%d",&N);
	int maxx=0;
	for(int i=1;i<=N;i++)
		scanf("%d",&h[i]),maxx=max(maxx,h[i]);
	int ans=0;
	for(int d=-maxx;d<=maxx;d++)
	{
		memset(g,0,sizeof(g));
		for(int i=1;i<=N;i++)
		{
			f[i]=g[h[i]-d+lim];
			g[h[i]+lim]+=f[i]+1;
			g[h[i]+lim]%=mod;
			ans+=f[i];ans%=mod;
		}
	}
	printf("%d",(ans+N)%mod);
	return 0;
}
