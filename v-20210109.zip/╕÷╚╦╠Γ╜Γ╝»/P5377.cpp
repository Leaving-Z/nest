#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=67;
typedef long long LL;
LL C[maxn][maxn];
LL ans[maxn];
int N;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	C[0][0]=1;
	for(int i=1;i<=65;i++)
	{
		C[i][0]=1;
		for(int j=1;j<=i;j++)
			C[i][j]=C[i-1][j-1]+C[i-1][j];
	}
	ans[0]=1;
	ans[1]=1;
	for(int i=2;i<=65;i++)
		ans[i]=ans[i-1]+C[i-1][3]+i-1;
	while(scanf("%d",&N)!=EOF) printf("%lld\n",ans[N]);
	return 0;
}
