#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1000007;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<15,stdin),TT==SS)?EOF:*SS++)
char BB[1<<15],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
struct range{
    int l,r,id;
}q[maxn];
bool operator < (const range &x,const range &y)
{
    return x.r<y.r;
}
int C[maxn];
int A[maxn],d[maxn],id[maxn];
int N,Q;
void update(int x,int k) {while(x<=N) C[x]^=k,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re^=C[x],x&=(x-1);return re;}
int sum[maxn],pre[maxn],lt[maxn],ans[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    for(int i=1;i<=N;i++)
        A[i]=d[i]=R(),sum[i]=sum[i-1]^A[i];
    Q=R();
    sort(d+1,d+1+N);
    int tot=unique(d+1,d+1+N)-d-1;
    for(int i=1;i<=N;i++)
        id[i]=lower_bound(d+1,d+1+tot,A[i])-d,pre[i]=lt[id[i]],lt[id[i]]=i;
    for(int i=1;i<=Q;i++)
        q[i].l=R(),q[i].r=R(),q[i].id=i;
    sort(q+1,q+1+Q);
    int tmp=1;
    for(int i=1;i<=Q;i++)
    {
        while(tmp<=q[i].r)
        {
            if(pre[tmp]) update(pre[tmp],d[id[tmp]]);
            update(tmp,d[id[tmp]]);
            ++tmp;
        }
        ans[q[i].id]=query(q[i].r)^query(q[i].l-1)^(sum[q[i].r]^sum[q[i].l-1]);
    }
    for(int i=1;i<=Q;i++)
        printf("%d\n",ans[i]);
    return 0;
}