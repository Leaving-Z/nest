#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=1007;
const int maxm=20007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,K;
int dis[maxn];
bool book[maxn];
bool SPFA(int p)
{
	memset(dis,0x3f,sizeof(dis));
	dis[1]=0;book[1]=true;
	q.push(1);
	int u,v,w;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			w=e[i].w>p?1:0;
			if(dis[u]+w<dis[v])
			{
				dis[v]=dis[u]+w;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[N]<=K;
}
#define mid (l+r>>1)
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d%d",&N,&M,&K);
	int u,v,w;
	int l=0,r=0,ans=-1;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		addE(u,v,w);addE(v,u,w);
		r=max(r,w);
	}
	while(l<=r)
	{
		if(SPFA(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
