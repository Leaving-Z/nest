#include<cstdio>
#include<algorithm>
#include<cstring>
#define R (L+len-1)
using namespace std;
int N;
int A[207],x[207];
int F[207][207];
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&A[i]);
		A[i+N]=A[i];
	}
	for(int len=2;len<=N;len++)
	{
		for(int L=1;L+len-1<=N*2;L++)
		{
			for(int k=L;k<R;k++)
				F[L][R]=max(F[L][R],F[L][k]+F[k+1][R]+A[L]*A[R+1]*A[k+1]);
		}
	}
	int ans=-1;
	for(int i=1;i<=N;i++)
	ans=max(ans,F[i][i+N-1]);
	printf("%d",ans);
	return 0;
}
