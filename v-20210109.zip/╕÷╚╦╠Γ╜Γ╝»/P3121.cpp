#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#include<iostream>
using namespace std;
const int maxn=100007;
queue <int> q;
char s[maxn],s1[maxn];
int Trie[maxn][26];
int fail[maxn];
int book[maxn];
int N,all;
int st[maxn],top,stk[maxn];
inline void Insert()
{
	int p=0,t,w=strlen(s1);
	for(int i=0;s1[i];i++)
	{
		t=s1[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	book[p]=w;
	return ;
}
inline void Ready()
{
	int u,v;
	for(int i=0;i<26;i++)
	if(Trie[0][i]) q.push(Trie[0][i]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<26;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v);
			else Trie[u][i]=Trie[fail[u]][i];
		}
	}
	return ;
}
inline void AC_Auto()
{
	Ready();
	int p=0;
	for(int i=0;s[i];i++)
	{
		stk[++top]=s[i];
		p=Trie[p][s[i]-'a'];
		st[top]=p;
		if(book[p])
		{
			top-=book[p];
			p=st[top];
		}
	}
	return ;
} 
int main()
{
	scanf("%s",s);
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s1);
		Insert();
	}
	AC_Auto();
	for(int i=1;i<=top;i++)
		putchar(stk[i]);
	return 0;
}
