#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1007;
const int maxm=4007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int color[maxn],match[maxn];
bool book[maxn];
inline void paint(int u,int c)
{
	int v;
	color[u]=c;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!color[v])
			paint(v,-c);
	}
	return ;
}
inline bool dfs(int u)
{
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!book[v])
		{
			book[v]=true;
			if(!match[v]||dfs(match[v]))
			{
				match[u]=v;match[v]=u;
				return true;
			}
		}
	}
	return false;
}
int N,M;
int main()
{
	N=R();M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R()+1;v=R()+1;
		addE(u,v);addE(v,u);
	}
	for(register int i=1;i<=N;i++)
	{
		if(!color[i])
			paint(i,1);
	}
	int ans=0;
	for(register int i=1;i<=N;i++)
	{
		if(color[i]==1)
		{
			memset(book,0,sizeof(book));
			if(dfs(i)) ++ans;
		}
	}
	printf("%d",N-ans);
	return 0;
}
