#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
struct Tree{
	int pre[2],suf[2];
	int sum[2];
	int len;
	int maxx[2];
}TREE[maxn<<2];
int tag[maxn<<2],rev[maxn<<2];
#define pre(i,j) TREE[i].pre[j]
#define suf(i,j) TREE[i].suf[j]
#define maxx(i,j) TREE[i].maxx[j]
#define sum(i,j) TREE[i].sum[j]
#define len(i) TREE[i].len
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
int A[maxn];
inline void Pushup(int i)
{
	for(int k=0;k<2;k++)
	{
		pre(i,k)=pre(Ls,k);
		suf(i,k)=suf(Rs,k);
		if(pre(Ls,k)==len(Ls)) pre(i,k)+=pre(Rs,k);
		if(suf(Rs,k)==len(Rs)) suf(i,k)+=suf(Ls,k);
		maxx(i,k)=max(maxx(Ls,k),max(maxx(Rs,k),suf(Ls,k)+pre(Rs,k)));
		sum(i,k)=sum(Ls,k)+sum(Rs,k);
	}
	return ;
}
void Build(int L,int R,int i)
{
	len(i)=R-L+1;tag[i]=-1;
	if(L==R)
	{
		pre(i,A[L])=suf(i,A[L])=sum(i,A[L])=maxx(i,A[L])=1; 
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	Pushup(i);
	return ;
}
inline void Set(int i)
{
	int x=tag[i]^1;
	pre(i,x)=suf(i,x)=sum(i,x)=maxx(i,x)=0;
	x^=1;
	pre(i,x)=suf(i,x)=sum(i,x)=maxx(i,x)=len(i);
	return ;
}
inline void Turn(int x)
{
	swap(pre(x,0),pre(x,1));
	swap(suf(x,0),suf(x,1));
	swap(sum(x,0),sum(x,1));
	swap(maxx(x,0),maxx(x,1));
	if(tag[x]!=-1) tag[x]^=1;
	else rev[x]^=1;
	return ;
}
inline void Pushdown(int i)
{
	if(tag[i]!=-1)
	{
		rev[i]=0;
		tag[Ls]=tag[Rs]=tag[i];
		Set(Ls),Set(Rs);
	}
	if(rev[i]) Turn(Ls),Turn(Rs);
	rev[i]=0;
	tag[i]=-1;
	return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		if(k!=2) tag[i]=k,Set(i);
		else Turn(i);
		return ;
	}
	Pushdown(i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	Pushup(i);
	return ;
}
int Query_sum(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return sum(i,1);
	Pushdown(i);
	int re=0;
	if(l<=mid) re+=Query_sum(L,mid,l,r,Ls);
	if(r>mid) re+=Query_sum(mid+1,R,l,r,Rs);
	return re;
}
struct Tri{
	int pre,maxx,suf;
	Tri(int p=0,int m=0,int s=0)
		{this->pre=p,this->maxx=m,this->suf=s;} 
};
Tri Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return Tri(pre(i,1),maxx(i,1),suf(i,1));
	Tri p,q,re;
	bool f1=false,f2=false;
	Pushdown(i);
	
	if(l<=mid) p=Query(L,mid,l,r,Ls),f1=true;
	if(r>mid) q=Query(mid+1,R,l,r,Rs),f2=true;
	
	re.maxx=max(q.maxx,max(p.maxx,p.suf+q.pre));
	
	if(f1) re.pre=p.pre;
	else re.pre=q.pre;
	
	if(f1&&p.pre==min(mid,r)-max(l,L)+1) re.pre+=q.pre;
	
	if(f2) re.suf=q.suf;
	else re.suf=p.suf;
	
	if(f2&&q.suf==min(r,R)-max(mid+1,l)+1) re.suf+=p.suf;
	return re;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
int main()
{
	N=R();M=R();
	for(int i=1;i<=N;i++)
		A[i]=R();
	Build(1,N,1);
	int op,l,r;
	for(int i=1;i<=M;i++)
	{
		op=R();l=R()+1;r=R()+1;
		if(op==0) Update(1,N,l,r,0,1);
		else if(op==1) Update(1,N,l,r,1,1);
		else if(op==2) Update(1,N,l,r,2,1);
		else if(op==3) printf("%d\n",Query_sum(1,N,l,r,1));
		else printf("%d\n",Query(1,N,l,r,1).maxx);
	}
	return 0;
}
