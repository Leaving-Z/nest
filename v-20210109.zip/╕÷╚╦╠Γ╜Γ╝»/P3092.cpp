#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int F[(1<<16)+7];//point
int DP[(1<<16)+7];
int sum[100007];
int val[(1<<16)+7];
int cost[100007],coin[17];
int N,K,ans=0x7f7f7f7f,all;
inline int Find(int val,int l,int r)
{
	int mid;
	while(l<=r)
	{
		mid=l+r>>1;
		if(sum[mid]==val) return mid;
		else if(sum[mid]<val) l=mid+1;
		else r=mid-1;
	}
	return r;
}
int main()
{
	scanf("%d%d",&K,&N);
	for(int i=1;i<=K;i++)
		scanf("%d",&coin[i]),all+=coin[i];
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&cost[i]);
		sum[i]=sum[i-1]+cost[i];
	}
	int p,t;
	memset(DP,0x7f,sizeof(DP));DP[0]=0;
	for(int i=0;i<(1<<K);i++)
	{
		for(int j=0;(1<<j)<=i;j++)
		{
			if(i&(1<<j))
			{
				t=i^(1<<j);
				p=Find(coin[j+1]+sum[F[t]],F[t]+1,N);
				if(F[i]<p)
				{
					DP[i]=DP[t]+coin[j+1];
					F[i]=p;
					if(p==N) ans=min(DP[i],ans);
				}
			}
		}
	}
	printf("%d",all>=ans?all-ans:-1);
	return 0;
}
