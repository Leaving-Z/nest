#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<cmath>
using namespace std;
const double pi=acos(-1);
int T;
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&N);
        double tmp=pi/N;
        double ini=tmp*3/4,ans=0;
        int cnt=0;
        for(int i=1;i<=N/2;i++)
        {
            ans+=sin(ini);
            ini+=tmp;
        }
        ini-=pi/2;
        for(int i=1;i<=N/2+1;i++)
        {
            ans+=cos(ini);
            ini+=tmp;
        }
        printf("%.8lf\n",ans);
    }
    return 0;
}