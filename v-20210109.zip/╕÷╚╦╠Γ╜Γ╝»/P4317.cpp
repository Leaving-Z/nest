#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=57;
typedef long long LL;
const LL mod=10000007;
LL F[maxn][maxn][2];
int bit[maxn],N;
int des;
LL fast_pow(LL b,LL k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL dfs(int cur,int sum,bool less)
{
    if(cur>N) return sum==des;
    if(~F[cur][sum][less]) return F[cur][sum][less];
    int lim=less?1:bit[cur];
    LL re=0;
    for(int i=0;i<=lim;i++)
        re+=dfs(cur+1,sum+(i==1),i<bit[cur]||less);
    return F[cur][sum][less]=re;
}
LL n;
LL ans[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld",&n);
    while(n)
    {
        bit[++N]=n&1;
        n>>=1;
    }
    for(int i=1;i<=N/2;i++)
        swap(bit[i],bit[N-i+1]);
    for(int i=1;i<=N;i++)
    {
        memset(F,-1,sizeof(F));
        des=i;
        ans[i]=dfs(1,0,false);
    }
    LL ANS=1;
    for(int i=1;i<=N;i++)
        ANS=ANS*fast_pow(1ll*i,ans[i])%mod;
    printf("%lld",ANS);
    return 0;
}