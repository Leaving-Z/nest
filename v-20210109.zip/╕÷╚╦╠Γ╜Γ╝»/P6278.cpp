#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=100007;
int TREE[maxn<<2];
int N;
int A[maxn];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1) 
void Update(int L,int R,int x,int i)
{
	if(L==R) {TREE[i]++;return ;}
	if(x<=mid) Update(L,mid,x,Ls);
	else Update(mid+1,R,x,Rs);
	TREE[i]=TREE[Ls]+TREE[Rs];
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l>r) return 0;
	if(l<=L&&R<=r) return TREE[i];
	int re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;
}
int big[maxn];
long long ans[maxn];
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		A[i]=R(),big[i]=Query(0,N,A[i]+1,N,1),Update(0,N,A[i],1);
	for(register int i=1;i<=N;i++)
		ans[A[i]]+=big[i];
	for(register int i=1;i<=N;i++)
		ans[i]+=ans[i-1];
	printf("0"); 
	for(register int i=1;i<N;i++)
		printf("\n%lld",ans[i-1]);
	return 0;
}
