#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1000007;
const int maxm=1000007;
const int inf=0x7f7f7f7f;
typedef long long LL;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
LL f[maxn],A[maxn],B[maxn],stk[maxn],top;
int N,T,C;
void dfs(int u)
{
    int v,cnt=0,st=top;
    f[u]=A[u];
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dfs(v);++cnt;
        stk[++top]=f[v];
    }
    if(!cnt) return ;
    sort(stk+st+1,stk+st+cnt+1);
    B[u]=(cnt*A[u]-1)/T+1;
    if(cnt<B[u]) f[u]=inf;
    else
    {
        f[u]=0;
        for(int i=st+1;i<=st+B[u];i++)
            f[u]+=stk[i];
    }
    top=st;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&T,&C);
    int u;
    for(int i=1;i<=N;i++)
        scanf("%d%d",&u,&A[i]),addE(u,i);
    A[0]=C;
    dfs(0);
    printf("%lld",f[0]);
    return 0;
}