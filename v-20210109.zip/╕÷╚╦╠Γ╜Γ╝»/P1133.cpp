#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=100007;
int F[maxn][5];
int N,V[maxn][4],ans;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		V[i][1]=R(),V[i][2]=R(),V[i][3]=R();
	for(register int i=2;i<=N;i++)
	{
		F[i][4]=max(F[i-1][2],F[i-1][1])+V[i][3];
		F[i][3]=F[i-1][1]+V[i][2];
		F[i][2]=F[i-1][4]+V[i][2];
		F[i][1]=max(F[i-1][3],F[i-1][4])+V[i][1];
	}
	ans=max(F[N][4]+max(V[1][1],V[1][2]),
	max(F[N][3]+V[1][1],max(F[N][2]+V[1][3],F[N][1]+max(V[1][2],V[1][3]))));
	printf("%d",ans);
	return 0;
}
