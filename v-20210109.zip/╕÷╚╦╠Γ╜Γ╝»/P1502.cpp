#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=40007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
int TREE[maxn<<2]; 
int T;
int N,W,H;
struct Line{
	int x,y,h,v;
}line[maxn];
bool operator < (const Line &x,const Line &y)
{
	if(x.h==y.h) return x.v>y.v;
	return x.h<y.h;
}
int d[maxn];
int id[maxn][2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define val(i) TREE[i]
int tag[maxn<<2];
void pushdown(int i)
{
	if(!tag[i]) return ;
	val(Ls)+=tag[i];tag[Ls]+=tag[i];
	val(Rs)+=tag[i];tag[Rs]+=tag[i];
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		val(i)+=k;
		tag[i]+=k;
		return ;
	}
	pushdown(i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	val(i)=max(val(Ls),val(Rs));
	return ;
}
void solve()
{
	N=R();W=R();H=R();
	int x,y,w;
	for(int i=1;i<=N;i++)
	{
		x=R();y=R();w=R();
		line[2*i-1]=(Line){x-W+1,x,y,w};
		line[2*i]=(Line){x-W+1,x,y+H-1,-w};
		d[2*i-1]=x-W+1;
		d[2*i]=x;
	}
	sort(line+1,line+1+2*N);
	sort(d+1,d+1+2*N);
	int tot=unique(d+1,d+1+2*N)-d-1;
	for(int i=1;i<=2*N;i++)
	{
		id[i][0]=lower_bound(d+1,d+1+tot,line[i].x)-d;
		id[i][1]=lower_bound(d+1,d+1+tot,line[i].y)-d;
	}
	int ans=0;
	for(int i=1;i<2*N;i++)
	{
		Update(1,tot,id[i][0],id[i][1],line[i].v,1);
		ans=max(ans,val(1));
	}
	printf("%d\n",ans);
	return ;
}
int main()
{
	T=R();
	while(T--)
	{
		solve();
		memset(TREE,0,sizeof(TREE));
		memset(tag,0,sizeof(tag));
	}
	return 0;
}
