#include<cstdio>
#include<algorithm>
#include<iostream>
using namespace std;
int F[20007];
int N,k;
struct Task{
	int l,t;
}task[20007];
int num=1,book[20007];
bool operator < (const Task &x,const Task &y)
{
	return x.l>y.l;
}
signed main()
{
	cin>>N>>k;
	for(register int i=1;i<=k;i++)
	{
		cin>>task[i].l>>task[i].t;
		book[task[i].l]++;
	}
	sort(task+1,task+1+k);
	for(register int i=N;i>0;i--)
	{
		if(!book[i]) F[i]=F[i+1]+1;
		else
		{
			for(register int j=1;j<=book[i];j++)
				F[i]=max(F[i],F[i+task[num].t]),num++;
		}
	}
	cout<<F[1];
	return 0;
}
