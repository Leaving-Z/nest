#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
typedef long long LL;
const int maxn=200007;
const int mod=1e9+7;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL fact[maxn],inv[maxn];
LL C(int n,int m)
{
    return fact[n]*inv[n-m]%mod*inv[m]%mod;
}
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    N<<=1;
    for(int i=fact[0]=1;i<=N;i++)
        fact[i]=fact[i-1]*i%mod;
    inv[N]=fast_pow(fact[N],mod-2);
    for(int i=N-1;i>=0;i--)
        inv[i]=inv[i+1]*(i+1)%mod;
    N>>=1;
    printf("%lld",((C(2*N-1,N)*2-N)%mod+mod)%mod);
    return 0;
}