#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
typedef long long LL;
queue <int> q;
const int maxn=30007;
const int maxm=300007;
const int inf=1e9;
struct E{
	int u,v;
	LL cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,LL cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,LL cf)
{
	addE(u,v,cf);
	addE(v,u,0);
	return ;
}
#define cf(i) e[i].cf
int all;
int N,M;
int id[107][107];
int cur[maxn],cnt[maxn];
int S,T;
bool BFS()
{
	int u,v;
	memset(cnt,0,sizeof(cnt));
	q.push(S);cnt[S]=1;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cnt[v]==0&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline LL dfs(int u,LL f)
{
	if(u==T) return f;
	int v;
	LL sum=0,d;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min(f,(LL)cf(i)));
			if(d>0)
			{
				cf(i)-=d;
				cf(i^1)+=d;
				sum+=d;
				f-=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			id[i][j]=++all;
	T=all*3+1;
	int x;
	long long ans=0;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%d",&x),add(S,id[i][j],x),ans+=x;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%d",&x),add(id[i][j],T,x),ans+=x;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			scanf("%d",&x);ans+=x;
			add(S,id[i][j]+all,x);
			add(id[i][j]+all,id[i][j],inf);
			if(i>1) add(id[i][j]+all,id[i-1][j],inf);
			if(i<N) add(id[i][j]+all,id[i+1][j],inf);
			if(j>1) add(id[i][j]+all,id[i][j-1],inf);
			if(j<M) add(id[i][j]+all,id[i][j+1],inf);
		}
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			scanf("%d",&x);ans+=x;
			add(id[i][j]+2*all,T,x);
			add(id[i][j],id[i][j]+2*all,inf);
			if(i>1) add(id[i-1][j],id[i][j]+2*all,inf);
			if(i<N) add(id[i+1][j],id[i][j]+2*all,inf);
			if(j>1) add(id[i][j-1],id[i][j]+2*all,inf);
			if(j<M) add(id[i][j+1],id[i][j]+2*all,inf);
		}
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans-=dfs(S,inf);
	}
	printf("%lld",ans);
	return 0;
}
