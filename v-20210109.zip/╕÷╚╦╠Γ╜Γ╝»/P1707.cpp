#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long lll;
inline lll R()
{
    lll re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
struct Matrix{
    lll m[12][12];
    Matrix () {memset(m,0,sizeof(m));return ;}
};
Matrix ini;
Matrix trans;
lll x,y,z,p,q,r,t,u,v,w,mod,n;
Matrix operator * (const Matrix &A,const Matrix &B)
{
    Matrix t;
    for(int i=1;i<=11;i++)
        for(int j=1;j<=11;j++)
            for(int k=1;k<=11;k++)
                t.m[i][j]=(t.m[i][j]+(A.m[i][k]*B.m[k][j]%mod+mod))%mod;
    return t;
}
Matrix operator ^ (Matrix b,lll k)
{
    Matrix s;
    for(int i=1;i<=11;i++)
        s.m[i][i]=1;
    while(k)
    {
        if(k&1) s=s*b;
        b=b*b;
        k>>=1;
    }
    return s;
}
void print(lll x)
{
	if(x>=10) print(x/10);
	putchar(x%10+48);
	return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    n=R();mod=R();
    p=R();q=R();r=R();t=R();
    u=R();v=R();w=R();
    x=R();y=R();z=R();
    trans.m[1][1]=p;trans.m[2][1]=q;trans.m[3][1]=1;trans.m[5][1]=1;
    trans.m[7][1]=r;trans.m[8][1]=t-4*r;trans.m[9][1]=4*r-2*t+1;

    trans.m[1][2]=1;

    trans.m[1][3]=1;trans.m[3][3]=u;trans.m[4][3]=v;trans.m[5][3]=1;
    trans.m[10][3]=1;

    trans.m[3][4]=1;

    trans.m[1][5]=1;trans.m[3][5]=1;trans.m[5][5]=x;trans.m[6][5]=y;
    trans.m[8][5]=1;trans.m[11][5]=1;

    trans.m[5][6]=1;

    trans.m[7][7]=1;trans.m[8][7]=2;trans.m[9][7]=1;

    trans.m[8][8]=1;trans.m[9][8]=1;

    trans.m[9][9]=1;

    trans.m[10][10]=w;

    trans.m[11][11]=z;

    ini.m[1][1]=ini.m[1][3]=ini.m[1][5]=3;
    ini.m[1][2]=ini.m[1][4]=ini.m[1][6]=1;
    ini.m[1][7]=9;ini.m[1][8]=3;
    ini.m[1][9]=1;
    ini.m[1][10]=w;ini.m[1][11]=z;

    trans=trans^(n-2);

    ini=ini*trans;

    printf("nodgd %lld\n",(long long)ini.m[1][1]);
    printf("Ciocio %lld\n",(long long)ini.m[1][3]);
    printf("Nicole %lld",(long long)ini.m[1][5]);

    return 0;
}
