#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int mod=998244353;
typedef long long LL;
const int maxn=3000007;
LL p2[maxn];
int N,T;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&T);
	p2[0]=1;
	for(int i=1;i<maxn;i++)
		p2[i]=(p2[i-1]<<1)%mod; 
	while(T--)
	{
		scanf("%d",&N);
		int re=0,x;
		for(int i=1;i<=N;i++)
			scanf("%d",&x),re|=x;
		printf("%lld\n",re*p2[N-1]%mod);
	}
	return 0;
}
