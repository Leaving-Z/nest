#include<bits/stdc++.h>
#include<set>
#include<algorithm>
using namespace std;
const int maxn=100007;
typedef long long LL;
LL m[maxn],r[maxn];
LL rew[maxn],a[maxn];
inline LL R()
{
	LL re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
LL N,M,T;
LL g,ATK;
inline void Exgcd(LL a,LL b,LL &x,LL &y)
{
	if(!b)
	{
		g=a;
		x=1;y=0;
		return ;
	}
	Exgcd(b,a%b,y,x);
	y-=(a/b)*x;
	return ;
}
inline LL X(LL ai,LL b,LL m)
{
	LL s=0;
	while(b)
	{
		if(b&1) s=(s+ai)%m;
		ai=(ai<<1)%m;
		b>>=1;
	}
	return s;
}
inline LL ExCRT()
{
	LL ans=0,lcm=1,A,B,C,x,y;
	for(int i=1;i<=N;i++)
	{
		A=X(lcm,a[i],m[i]);B=m[i];
		C=((r[i]-X(a[i],ans,m[i]))%m[i]+m[i])%m[i];
		Exgcd(A,B,x,y);
		x=(x%m[i]+m[i])%m[i];
		if(C%g) return -1;
		ans+=X(C/g,x,m[i]/g)*lcm;
		lcm=lcm*(m[i]/g);
		ans=(ans%lcm+lcm)%lcm;
	}
	if(ans<ATK)
	{
		x=(ATK-ans)%lcm==0?(ATK-ans)/lcm:(ATK-ans)/lcm+1;
		ans=ans+x*lcm;
	}
	return ans;
}
int main()
{
	T=R();
	while(T--)
	{
		multiset<LL>sword;
		ATK=0;
		N=R();M=R();
		for(register int i=1;i<=N;i++)
			r[i]=R();
		for(register int i=1;i<=N;i++)
			m[i]=R();
		for(register int i=1;i<=N;i++)
			rew[i]=R();
		for(register int i=1;i<=M;i++)
			sword.insert(R());
		multiset<LL>::iterator it;
		for(register int i=1;i<=N;i++)
		{
			it=sword.upper_bound(r[i]);
			if(it!=sword.begin()) it--; 
			a[i]=(*it);
			sword.erase(it);
			sword.insert(rew[i]);
			ATK=max(ATK,r[i]%a[i]==0?r[i]/a[i]:r[i]/a[i]+1);
		}
		printf("%lld\n",ExCRT());		
	}
	return 0;
}
