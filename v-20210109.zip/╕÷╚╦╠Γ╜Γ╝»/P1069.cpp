#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int n=100007;
int prime[n],cnt;
bool vis[n];
void pre()
{
    for(int i=2;i<n;i++)
    {
        if(!vis[i]) prime[++cnt]=i;
        for(int j=1;j<=cnt&&i*prime[j]<n;j++)
        {
            vis[i*prime[j]]=true;
            if(i%prime[j]==0) break;
        }
    }
    return ;
}
int m1,m2;
int di[n],mi[n],tot;
int N;
int S[10007];
bool book[n];
int ans=0x7f7f7f7f;
void solve(int x)
{
    int t=1,d,mii=0,sum=0,re=0;
    while(x!=1&&t<=cnt)
    {
        while(x&&t<=cnt&&x%prime[t]) ++t;
        if(t>cnt) return ;
        d=prime[t];
        if(book[d]) ++sum;
        else 
        {
            while(x!=1&&x%d==0) x/=d;
            continue;
        }
        mii=0;
        while(x!=1&&x%d==0)
        {
            x/=d;
            mii++;
        }
        re=max(re,(mi[d]-1)/mii+1);
    }
    if(sum!=tot) return ;
    if(x!=1) return ;
    ans=min(ans,re);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    pre();
    scanf("%d",&N);
    scanf("%d%d",&m1,&m2);
    int t=1;
    if(m1==1)
    {
        printf("0");
        return 0;
    }
    while(m1!=1)
    {
        while(m1%prime[t]) ++t;
        di[++tot]=prime[t];
        book[prime[t]]=true;
        while(m1!=1&&m1%prime[t]==0)
        {
            m1/=prime[t];
            mi[prime[t]]++;
        }
        mi[prime[t]]*=m2;
    }
    int d,mii;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&S[i]);
        solve(S[i]);
    }
    printf("%d\n",ans==0x7f7f7f7f?-1:ans);
    return 0;
}