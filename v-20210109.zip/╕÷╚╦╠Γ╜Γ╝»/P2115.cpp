#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const double eps=0.00000001;
const double delta=0.00001;
double A[maxn],B[maxn],sum[maxn];
int N;
int q[maxn],head,tail;
bool check(double p)
{
    for(int i=1;i<=N;i++)
        B[i]=A[i]-p,sum[i]=sum[i-1]+B[i];
    head=1;tail=0;
    q[++tail]=1;
    for(int i=2;i<N;i++)
    {
        if(sum[i]-sum[q[head]]+eps>sum[N]) return true;
        while(head<=tail&&sum[q[tail]]>sum[i]) --tail;
        q[++tail]=i;
    }
    return false;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%lf",&A[i]);
    double L=0,R=1000000000,mid,ans;
    while(L+delta<=R)
    {
        mid=(L+R)/2;
        if(check(mid)) ans=mid,R=mid-delta;
        else L=mid+delta;
    }
    printf("%.3f",ans);
    return 0;
}