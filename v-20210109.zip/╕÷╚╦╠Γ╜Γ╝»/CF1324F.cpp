#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
const int maxm=400007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int W[maxn];
int F[maxn],f[maxn];
int N;
void dfs1(int u,int fa)
{
    int v;
    F[u]=W[u];
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        dfs1(v,u);
        if(F[v]>0) F[u]+=F[v];
    }
    return ;
}
void dfs2(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        if(F[v]>0)
            f[v]=max(f[u],F[v]);
        else
        {
            f[v]=F[v];
            if(f[u]>0) f[v]+=f[u];
        }
        dfs2(v,u);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int x;
    for(int i=1;i<=N;i++)
        scanf("%d",&x),W[i]=x?1:-1;
    int u,v;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);addE(v,u);
    }
    dfs1(1,0);
    f[1]=F[1];
    dfs2(1,0);
    for(int i=1;i<=N;i++)
        printf("%d ",f[i]);
    return 0;
}