#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
const int maxm=200007;
const int J=18;
typedef long long LL;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline LL R()
{
    LL re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
struct E{
    int u,v;
    LL w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,LL w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N;
LL T;
LL dis[maxn][J+1];
int fa[maxn][J+1],sum[maxn];
void dfs1(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dis[v][0]=e[i].w;
        fa[v][0]=u;
        dfs1(v);
    }
    return ;
}
int up(int x)
{
    LL t=T;
    for(int k=J;k>=0;k--)
        if(dis[x][k]<=t) t-=dis[x][k],x=fa[x][k];
    return fa[x][0];
}
void dfs2(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dfs2(v);
        sum[u]+=sum[v];
    }
    return ;
}
void print(int x)
{
    if(x>=10) print(x/10);
    putchar(x%10+'0');
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();T=R();
    int u;LL w;
    for(int i=2;i<=N;i++)
    {
        u=R();w=R();
        addE(u,i,w);
    }
    dfs1(1);
    for(int j=1;j<=J;j++)
        for(int i=1;i<=N;i++)
            fa[i][j]=fa[fa[i][j-1]][j-1],dis[i][j]=dis[i][j-1]+dis[fa[i][j-1]][j-1];
    for(int i=1;i<=N;i++)
        sum[i]++,sum[up(i)]--;
    dfs2(1);
    for(int i=1;i<=N;i++)
        print(sum[i]),puts("");
    return 0;
}