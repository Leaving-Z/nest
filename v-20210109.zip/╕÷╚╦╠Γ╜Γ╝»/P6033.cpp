#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int maxn=1e7+7;
LL n,x,ans;
LL A[maxn],t[100007];
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
queue <LL> q1,q2;
LL choose()
{
	LL t;
	if(q1.empty())
		{t=q2.front();q2.pop();return t;}
	else if(q2.empty())
		{t=q1.front();q1.pop();return t;}
	else
	{
		if(q1.front()<q2.front())
		{t=q1.front();q1.pop();return t;}
		else
		{t=q2.front();q2.pop();return t;}
	}
}
int main(){
    n=R();
    for(int i=1;i<=n;i++) A[i]=R(),t[A[i]]++;
    LL ans=0,tmp;
    int cnt=0;
    for(int i=1;i<=100001;i++)
    {
    	if(t[i])
    	{
    		while(t[i])
    		{
    			q1.push(i);
    			t[i]--;
			}
		}
	}
	LL x,y;
	while(q1.size()+q2.size()>=2)
	{
		x=choose();
		y=choose();
		ans+=x+y;
		q2.push(x+y);
	}
    printf("%lld",ans);
    return 0;
}
