#include<cstdio>
#include<algorithm>
using namespace std;
inline int R()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
typedef long long LL;
struct E{
	int u,v,w;
}e[1000007];
int first[500007],nt[1000007];
int N,S;
LL maxE[500007];
LL under[500007],top;
LL dis[500007];
LL ans;
LL longest;
void DFS(int u,int fa)
{
	LL v,w;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;w=e[i].w;
		if(v!=fa)
		{
			DFS(v,u);
			maxE[u]=max(maxE[u],maxE[v]+w);
		}
	}
	return ;
}
void DFS1(int u,int fa)
{
	LL v,w;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;w=e[i].w;
		if(v!=fa)
		{
			ans+=maxE[u]-maxE[v]-w;
			DFS1(v,u);
		}
	}
	return ;
}
int main()
{
	N=R();S=R();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		e[i]=(E){u,v,w};
		nt[i]=first[u];
		first[u]=i;
		e[i+N]=(E){v,u,w};
		nt[i+N]=first[v];
		first[v]=i+N;
	}
	DFS(S,0);
	DFS1(S,0); 
	printf("%lld",ans);
	return 0;
}
