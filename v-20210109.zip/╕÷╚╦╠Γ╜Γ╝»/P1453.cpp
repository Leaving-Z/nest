#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int val[maxn];
int N;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int S[maxn];
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
int F[maxn][2],lt,rt;
void dfs(int u,int fa)
{
	int v;
	F[u][1]=val[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa) continue;
		dfs(v,u);
		F[u][0]+=max(F[v][0],F[v][1]);
		F[u][1]+=F[v][0];
	}
	return ;
}
int main()
{
	N=R();
	for(int i=1;i<=N;i++)
		val[i]=R(),S[i]=i;
	int u,v,f1,f2;
	for(int i=1;i<=N;i++)
	{
		u=R()+1;v=R()+1;
		f1=f(u);f2=f(v);
		if(f1==f2) lt=u,rt=v;
		else S[f1]=f2,addE(u,v),addE(v,u);
	}
	val[0]=-1e9;
	swap(val[0],val[rt]);
	dfs(lt,0);
	int ans1=F[lt][1],ans2=F[lt][0];
	swap(val[0],val[rt]);
	swap(val[0],val[lt]);
	memset(F,0,sizeof(F));
	dfs(rt,0);
	int ans3=F[rt][1];
	double K;
	scanf("%lf",&K);
	printf("%.1f",K*max(ans1,max(ans3,ans2)));
	return 0;
}
