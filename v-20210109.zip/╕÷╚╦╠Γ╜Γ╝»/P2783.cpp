#include<cstdio>
#include<algorithm>
using namespace std;
const int J=20;
int st[10007],top;
inline int R()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
struct E{
	int u,v;
}s[100007],e[100007];
int ES;
int firsts[10007],nts[100007],first[10007],nt[100007];
int S[10007];
int C,T;
int dfn[10007],low[10007];
int N,M,Q;
int f[10007][21],depth[10007];
bool inst[10007];
void print(int x)
{
	if(x==0)
	{
		printf("0");
		return ;
	}
	if(x==1)
	{
		printf("1");
		return ;
	}
	print(x>>1);
	printf("%d",x%2);
	return ;
}
void DFS(int u)
{
	for(int i=0;i<J;i++)
	f[u][i+1]=f[f[u][i]][i];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=f[u][0])
		{
			depth[v]=depth[u]+1;
			f[v][0]=u;
			DFS(v);
		}	
	}
	return ;
}
int LCA(int x,int y)
{
	if(depth[x]<depth[y]) swap(x,y);
	int k=depth[x]-depth[y];
	for(int i=0;(1<<i)<=k;i++)
	if((1<<i)&k) x=f[x][i];
	if(x==y) return x;
	for(int i=J;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])
		{
			x=f[x][i];
			y=f[y][i];
		}
	}
	return f[x][0];
}
void Tarjan(int u,int fa)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	for(int i=firsts[u];i;i=nts[i])
	{
		if(s[i].v==fa) continue;
		if(dfn[s[i].v]==0)
		{
			Tarjan(s[i].v,u);
			low[u]=min(low[u],low[s[i].v]);
		}
		else if(inst[s[i].v]) low[u]=min(low[u],dfn[s[i].v]);
	}
	if(low[u]==dfn[u])
	{
		int p;
		C++;
		while(st[top]!=u)
		{
			p=st[top--];
			S[p]=C;
			inst[p]=false;
		}
		top--;
		S[u]=C;
	}
}
int main()
{
	N=R();M=R();
	int u,v;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		s[i]=(E){u,v};
		nts[i]=firsts[u];
		firsts[u]=i;
		s[i+M]=(E){v,u};
		nts[i+M]=firsts[v];
		firsts[v]=i+M;
	}
	Q=R();
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i,0);
	for(int i=1;i<=M;i++)
	{
		u=s[i].u;v=s[i].v;
		if(S[u]!=S[v])
		{
			e[++ES]=(E){S[u],S[v]};
			nt[ES]=first[S[u]];
			first[S[u]]=ES;
			e[++ES]=(E){S[v],S[u]};
			nt[ES]=first[S[v]];
			first[S[v]]=ES;
		}
	}
	DFS(1);
	int lca,ans;
	for(int i=1;i<=Q;i++)
	{
		u=R();v=R();
		lca=LCA(S[u],S[v]);
		ans=depth[S[u]]+depth[S[v]]-2*depth[lca]+1;
		print(ans);
		printf("\n");
	}
	return 0;
}
