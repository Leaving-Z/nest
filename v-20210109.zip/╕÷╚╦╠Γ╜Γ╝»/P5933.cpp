#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=17;
const int maxs=(1<<17)-1;
const int mod=1e9+7;
typedef long long LL;
LL m[maxn][maxn];
LL res[maxs];
LL f[maxs];
int N;
LL pre(int x)
{
    LL re=1;
    for(int i=1;i<=N;i++)
    {
        if((x&(1<<i-1))==0) continue;
        for(int j=i+1;j<=N;j++)
        if(x&(1<<j-1)) (re*=(m[i][j]+1))%=mod;
    }
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            scanf("%lld",&m[i][j]);
    int all=(1<<N)-1;
    for(int i=1;i<=all;i++)
        res[i]=pre(i);
    LL tmp;
    for(int i=1;i<=N;i++)
        f[1<<i-1]=1;
    for(int i=1;i<=all;i++)
    {
        tmp=0;
        for(int j=i&(i-1);j;j=i&(j-1))
        if(j&1) (tmp+=(f[j]*res[i^j])%mod)%=mod;
        f[i]=((res[i]-tmp)%mod+mod)%mod;
    }
    printf("%lld",f[all]);
    return 0;
}