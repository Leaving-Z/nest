#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
int TREE[maxn<<2];
int A[maxn];
int N,M;
inline int max_(const int &x,const int &y) {return x>y?x:y;}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
void Build(int L,int R,int i)
{
	if(L==R) {TREE[i]=A[L];return ;}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	TREE[i]=max_(TREE[Ls],TREE[Rs]);
	return ;
}
void Update(int L,int R,int x,int k,int i)
{
	if(L==R) {TREE[i]=max_(TREE[i],k);return ;}
	if(x<=mid) Update(L,mid,x,k,Ls);
	else Update(mid+1,R,x,k,Rs);
	TREE[i]=max_(TREE[Ls],TREE[Rs]); 
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return TREE[i];
	int re=0;
	if(l<=mid) re=Query(L,mid,l,r,Ls);
	if(r>mid) re=max_(re,Query(mid+1,R,l,r,Rs));
	return re;
}
inline int Re()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=Re();M=Re();
	for(register int i=1;i<=N;i++)
		A[i]=Re();
	Build(1,N,1);
	char s[7];int l,r;
	for(register int i=1;i<=M;i++)
	{
		scanf("%s",s);l=Re();r=Re();
		if(s[0]=='Q') printf("%d\n",Query(1,N,l,r,1));
		else Update(1,N,l,r,1);
	}
	return 0;
}
