#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=500007;
typedef long long LL;
struct seg_tree{
    LL I,O,IO,OI,IOI;
}tree[maxn<<2];
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.I=x.I+y.I;
    t.O=x.O+y.O;
    t.IO=x.IO+y.IO+x.I*y.O;
    t.OI=x.OI+y.OI+x.O*y.I;
    t.IOI=x.IOI+y.IOI+x.IO*y.I+x.I*y.OI;
    return t;
}
#define ls (i<<1)
#define rs (i<<1|1)
char s[maxn];
int M;
int N,Q;
void build()
{
    M=1;
    while(M<N) M<<=1;
    for(int i=1;i<=N;i++)
        tree[i+M].I=(s[i]=='I'),tree[i+M].O=(s[i]=='O');
    for(int i=M-1;i;i--) tree[i]=tree[ls]+tree[rs];
    return ;
}
void update(int i)
{
    i+=M;
    swap(tree[i].I,tree[i].O);
    while(i>>=1) tree[i]=tree[ls]+tree[rs];
    return ;
}
seg_tree query(int l,int r)
{
    seg_tree lre,rre;
    lre.I=lre.IO=lre.IOI=lre.O=lre.OI=0;
    rre.I=rre.IO=rre.IOI=rre.O=rre.OI=0;
    for(l=l+M-1,r=r+M+1;l^r^1;l>>=1,r>>=1)
    {
        if(~l&1) lre=lre+tree[l^1];
        if(r&1) rre=tree[r^1]+rre;
    }
    return lre+rre;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();Q=R();
    char c;
    while((c=getchar())!='I'&&c!='O');
    s[1]=c;
    for(int i=2;i<=N;i++)
        s[i]=getchar();
    build();
    int op,l,r;
    while(Q--)
    {
        op=R();
        if(op==1)
        {
            l=R();
            c=getchar();
            if(s[l]!=c) update(l),s[l]=c;
        }
        else
        {
            l=R();r=R();
            printf("%lld\n",query(l,r).IOI);
        }
    }
    return 0;
}