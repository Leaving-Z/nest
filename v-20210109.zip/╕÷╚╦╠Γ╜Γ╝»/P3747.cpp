#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
typedef long long LL;
const int maxn=50007;
const int maxlim=40;
const int maxsz=(1<<15);
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N,Q,P,C;
int A[maxn];
LL c1[maxlim+1][maxsz+7],c2[maxlim+1][maxsz+7];
int p[maxlim+1],mp;
LL phi(int x)
{
    LL re=x;
    for(int i=2;i*i<=x;i++)
    {
        if(x%i==0)
        {
            re=re*(i-1)/i;
            while(x%i==0) x/=i;
        }
    }
    if(x!=1) re=re*(x-1)/x;
    return re;
}
#define MOD(b,k) (b>=k?b%k+k:b)
void prepow(int k)
{
    int mod=p[k],b=C;
    c1[k][0]=1;c2[k][0]=1;
    for(int i=1;i<=maxsz;i++) c1[k][i]=MOD(c1[k][i-1]*b,mod);
    b=c1[k][maxsz];
    for(int i=1;i<=maxsz;i++) c2[k][i]=MOD(c2[k][i-1]*b,mod);
    return ;
}
void pre()
{
    p[0]=P;
    while(p[mp]!=1) p[mp+1]=phi(p[mp]),++mp;
    for(int i=0;i<=mp;i++) prepow(i);
    return ;
}
LL fast_pow(int k,int mod) {return MOD(c1[mod][k&(maxsz-1)]*c2[mod][k>>15],p[mod]);}
int calc(int pos,int k,int lim)
{
    if(k==lim) return MOD(A[pos],p[k]);
    if(p[k]==1) return MOD(C,p[k]);
    return fast_pow(calc(pos,k+1,lim),k);
}
int val[maxn][maxlim+1];
int sum[maxn<<2],tms[maxn<<2];
#define ls (i<<1)
#define rs (i<<1|1)
void build(int L,int R,int i)
{
    if(L==R)
    {
        sum[i]=val[L][0];
        return ;
    }
    int mid=L+R>>1;
    build(L,mid,ls);
    build(mid+1,R,rs);
    sum[i]=(sum[ls]+sum[rs])%P;
    return ;
}
void update(int L,int R,int l,int r,int i)
{
    if(tms[i]>mp) return ;
    if(L==R)
    {
        sum[i]=val[L][++tms[i]];
        return ;
    }
    int mid=L+R>>1;
    if(l<=mid) update(L,mid,l,r,ls);
    if(r>mid) update(mid+1,R,l,r,rs);
    sum[i]=(sum[ls]+sum[rs])%P;
    tms[i]=min(tms[ls],tms[rs]);
    return ;
}
int query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return sum[i];
    int re=0;
    int mid=L+R>>1;
    if(l<=mid) re+=query(L,mid,l,r,ls);
    if(r>mid) re+=query(mid+1,R,l,r,rs);
    return re%P;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    N=R();Q=R();P=R();C=R();
    pre();
    for(int i=1;i<=N;i++)
    {
        A[i]=R();
        for(int k=0;k<=mp+1;k++)
            val[i][k]=calc(i,0,k)%P;
    }
    int op,l,r;
    build(1,N,1);
    while(Q--)
    {
        op=R();l=R();r=R();
        if(op==0) update(1,N,l,r,1);
        else printf("%d\n",query(1,N,l,r,1));
    }
    return 0;
}