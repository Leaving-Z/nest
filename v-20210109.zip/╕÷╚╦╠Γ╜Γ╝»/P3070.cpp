#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
#include<cctype>
using namespace std;
queue <int> q;
const int maxn=2507;
const int maxm=10007;
const int Maxn=57;
const int MAXN=17;
const int maxs=(1<<16)+7;
struct E
{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int num[Maxn][Maxn],cnt;
char m[Maxn][Maxn];
void paint(int x,int y)
{
    if(m[x][y]!='X') return ;
    if(num[x][y]) return ;
    num[x][y]=cnt;
    paint(x+1,y);paint(x-1,y);
    paint(x,y+1);paint(x,y-1);
    return ;
}
int R,C,N;
int p[MAXN],f[maxs][MAXN],dis[MAXN][MAXN],d[maxn];
bool book[maxn];
void SPFA(int s)
{
    memset(d,0x7f,sizeof(d));
    book[s]=true;d[s]=0;
    int u,v;
    q.push(s);
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(d[u]+e[i].w<d[v])
            {
                d[v]=d[u]+e[i].w;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    cin>>R>>C;
    for(int i=1;i<=R;i++)
        cin>>m[i]+1;
    for(int i=1;i<=R;i++)
        for(int j=1;j<=C;j++)
        {
            if(num[i][j]) continue;
            if(m[i][j]=='S') num[i][j]=++cnt;
            else if(m[i][j]=='X') p[++N]=++cnt,paint(i,j);
        }
    for(int i=1;i<=R;i++)
    {
        for(int j=1;j<=C;j++)
        {
            if(m[i][j]=='.') continue;
            if(m[i-1][j]=='S')
                addE(num[i][j],num[i-1][j],1),addE(num[i-1][j],num[i][j],(m[i][j]=='S'));
            if(m[i][j-1]=='S')
                addE(num[i][j],num[i][j-1],1),addE(num[i][j-1],num[i][j],(m[i][j]=='S'));
            if(m[i+1][j]=='S')
                addE(num[i][j],num[i+1][j],1),addE(num[i+1][j],num[i][j],(m[i][j]=='S'));
            if(m[i][j+1]=='S')
                addE(num[i][j],num[i][j+1],1),addE(num[i][j+1],num[i][j],(m[i][j]=='S'));
        }
    }
    for(int i=1;i<=N;i++)
    {
        SPFA(p[i]);
        for(int j=1;j<=N;j++)
            dis[i][j]=d[p[j]];
    }
    memset(f,0x7f,sizeof(f));
    for(int i=1;i<=N;i++)
        f[1<<i-1][i]=0;
    int all=(1<<N)-1;
    for(int i=1;i<=all;i++)
    {
        for(int j=1;j<=N;j++)
        {
            if((i&(1<<j-1))==0) continue;
            for(int k=1;k<=N;k++)
            if((i&(1<<k-1))==0) f[i|(1<<k-1)][k]=min(f[i|(1<<k-1)][k],f[i][j]+dis[j][k]);
        }
    }
    int ans=1e9;
    for(int i=1;i<=N;i++)
        ans=min(ans,f[all][i]);
    printf("%d",ans);
    return 0;
}