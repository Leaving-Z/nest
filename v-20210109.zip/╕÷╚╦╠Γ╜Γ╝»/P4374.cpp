#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
inline int R()
{
	int re;
	char c;
	while(!isdigit(c=getchar()));
	re=c-48;
	while(isdigit(c=getchar()))
	re=re*10+c-48;
	return re;
}
const int maxn=50007;
const int maxm=100007;
const int inf=0x7f7f7f7f;
int N,M;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int sz[maxn],fa[maxn],depth[maxn],son[maxn];
void dfs1(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		depth[v]=depth[u]+1;
		fa[v]=u;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
	return ;
}
int top[maxn],id[maxn],anti[maxn],ix;
void dfs2(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs2(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return ;
}
int TREE[maxn<<2],tag[maxn<<2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define v(i) TREE[i]
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline void pushdown(int i)
{
	if(tag[i]==inf) return ;
	v(Ls)=min_(v(Ls),tag[i]);
	v(Rs)=min_(v(Rs),tag[i]);
	tag[Ls]=min_(tag[Ls],tag[i]);
	tag[Rs]=min_(tag[Rs],tag[i]);
	tag[i]=inf;
	return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		v(i)=min_(v(i),k);
		tag[i]=min_(tag[i],k);
		return ;
	}
	pushdown(i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	return ;
}
int Query(int L,int R,int x,int i)
{
	if(L==R) return v(i);
	pushdown(i);
	if(x<=mid) return Query(L,mid,x,Ls);
	else return Query(mid+1,R,x,Rs);
}
void Update_Path(int x,int y,int k)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],k,1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x]+1,id[y],k,1);
	return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();M=R();
	int u,v,w;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	dfs1(1);dfs2(1,1);
	memset(TREE,0x7f,sizeof(TREE));
	memset(tag,0x7f,sizeof(tag));
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		Update_Path(u,v,w);
	}
	for(int i=1;i<=ES;i+=2)
	{
		u=depth[e[i].v]>depth[e[i].u]?e[i].v:e[i].u;
		w=Query(1,N,id[u],1);
		if(w==inf) w=-1;
		printf("%d\n",w);
	}
	return 0;
}