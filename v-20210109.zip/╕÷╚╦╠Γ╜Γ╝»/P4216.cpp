#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=200007;
const int maxm=200007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
struct Query{
    int x,y,c,id,t;
}q[maxn];
bool operator < (const Query &x,const Query &y)
{
    if(x.c!=y.c) return x.c<y.c;
    return x.id<y.id;
}
int dep[maxn],sz[maxn],son[maxn],top[maxn],fa[maxn],id[maxn],ix;
int N,Q;
void dfs1(int u)
{
    sz[u]=1;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dep[v]=dep[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int C[maxn];
void update(int x) {while(x<=N) C[x]++,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re+=C[x],x&=(x-1);return re;}
int sum(int l,int r)
{
    if(l>r) return 0;
    return query(r)-query(l-1);
}
int lca;
int query_path(int x,int y)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        re+=sum(id[top[x]],id[x]);
        x=fa[top[x]];
    }
    if(dep[x]>dep[y]) swap(x,y);
    lca=x;
    re+=sum(id[x],id[y]);
    return re;
}
int ans[maxn][2];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    int x;
    for(int i=1;i<=N;i++)
    {
        x=R();
        if(x) addE(x,i);
    }
    dfs1(1);dfs2(1,1);
    Q=R();
    int op,y,c;
    int cnt=0;
    for(int i=1;i<=Q;i++)
    {
        op=R();
        if(op==1)
        {
            x=R();y=R();c=R();
            q[i]=(Query){x,y,i-c-1,i,++cnt};
        }
        else
        {
            x=R();
            q[i]=(Query){x,0,i,i,0};
        }
    }
    sort(q+1,q+1+Q);
    for(int i=1;i<=Q;i++)
    {
        if(q[i].y)
        {
            ans[q[i].t][1]=query_path(q[i].x,q[i].y);
            ans[q[i].t][0]=dep[q[i].x]+dep[q[i].y]-2*dep[lca]+1;
        }
        else update(id[q[i].x]);
    }
    for(int i=1;i<=cnt;i++)
        printf("%d %d\n",ans[i][0],ans[i][1]);
    return 0;
}