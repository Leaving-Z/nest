#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxv=10007;
const int maxn=27;
int v[maxn];
long long F[maxv];
int N,V;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	F[0]=1;
	scanf("%d%d",&N,&V);
	for(int i=1;i<=N;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<=N;i++)
		for(int j=v[i];j<=V;j++)
			F[j]+=F[j-v[i]];
	printf("%lld",F[V]);
	return 0;
}
