#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=10007;
const int maxv=1007;
int N;
int F[maxv];
char s[7];
int St,Et,V;
struct Pack{
	int v,c;
}pack[maxn*14];
int cnt;
void subpack(int num,int c,int v)
{
	for(int k=1;k<=num&&c*k<=V;k<<=1)
	{
		pack[++cnt]=(Pack){v*k,c*k};
		num-=k;
	}
	if(num&&num*c<=V) pack[++cnt]=(Pack){v*num,c*num};
	return ;
}
int main()
{
	St=R()*60;
	St+=R();
	Et=R()*60;
	Et+=R();
	V=Et-St;
	N=R();
	int t,v,c;
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d%d",&c,&v,&t);
		if(t==0) subpack(V,c,v);
		else subpack(t,c,v);
	}
	for(int i=1;i<=cnt;i++)
		for(int j=V;j>=pack[i].c;j--)
			F[j]=max(F[j],F[j-pack[i].c]+pack[i].v);
	printf("%d",F[V]);
	return 0;
}
