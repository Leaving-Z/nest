#include<algorithm>
#include<cstdio>
using namespace std;
const int N=200007;
typedef long long LL;
LL maxE[N],maxe[N];
struct E{
	int u,v,w;
}e[2*N];
int first[N],nt[2*N];
bool visit[N];
LL sum,ans;
void DFS(int u,int fa)
{
	visit[u]=true;
	for(int i=first[u];i;i=nt[i])
	{
		int v=e[i].v,w=e[i].w;
		if(!visit[v])
		{
			DFS(e[i].v,u);
			if(maxE[v]+w>maxE[u])
			{
				maxe[u]=maxE[u];
				maxE[u]=maxE[v]+w;
			}
			else if(maxE[v]+w>maxe[u])
			maxe[u]=maxE[v]+w;
		}
		ans=max(ans,maxe[u]+maxE[u]);
	}
	return ;
}
int s,n;
int main()
{
	scanf("%d%d",&n,&s);
	int u,v,w;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		sum+=(LL)w;
		e[i]=(E){u,v,w};
		nt[i]=first[u];
		first[u]=i;
		e[i+n]=(E){v,u,w};
		nt[i+n]=first[v];
		first[v]=i+n;
	}
	DFS(s,0);
	printf("%lld",sum*2-ans); 
	return 0;
} 
