#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
#include<cstdlib>
using namespace std;
const int maxn=40007;
const int inf=0x7f7f7f7f;
struct Treap
{
    int v,p;
    int ls,rs;
}tree[maxn];
int root,cnt;
int N;
#define v(i) tree[i].v
#define ls(i) tree[i].ls
#define rs(i) tree[i].rs
#define p(i) tree[i].p
inline void Zig(int &i)
{
    int x=ls(i);
    int y=rs(x);
    rs(x)=i;ls(i)=y;
    i=x;
    return ;
}
inline void Zag(int &i)
{
    int x=rs(i);
    int y=ls(x);
    ls(x)=i;rs(i)=y;
    i=x;
    return ;
}
void insert(int &i,int v)
{
    if(!i)
    {
        i=++cnt;p(i)=rand();
        v(i)=v;ls(i)=rs(i)=0;
        return ;
    }
    if(v==v(i)) return ;
    if(v<v(i))
    {
        insert(ls(i),v);
        if(p(ls(i))<p(i)) Zig(i);
    }
    else
    {
        insert(rs(i),v);
        if(p(rs(i))<p(i)) Zag(i);
    }
    return ;
}
int find(int v)
{
    int u=root,re=inf;
    while(u)
    {
        re=min(re,abs(v(u)-v));
        if(!re) return re;
        if(v<v(u)) u=ls(u);
        else u=rs(u);
    }
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int x;
    scanf("%d",&x);
    int ans=x;
    insert(root,x);
    for(int i=1;i<N;i++)
    {
        scanf("%d",&x);
        ans+=find(x);
        insert(root,x);
    }
    printf("%d",ans);
    return 0;
}