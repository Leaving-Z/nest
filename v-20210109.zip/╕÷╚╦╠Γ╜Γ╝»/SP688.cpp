#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<set>
using namespace std;
const int maxn=100007;
const int maxp=500007;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N,K,p;
int A[maxp],f[maxp],book[maxn];
bool in[maxn];
int sta[maxn];
struct node{
    int num,val;
};
bool operator < (const node &x,const node &y)
{
    if(x.val!=y.val) return x.val>y.val;
    return x.num<y.num;
}
multiset <node> s;
void solve()
{
    N=R();K=R();p=R();
    for(int i=1;i<=p;i++)
        A[i]=R();
    memset(book,0x3f,sizeof(book));
    memset(sta,0,sizeof(sta));
    memset(in,0,sizeof(in));
    for(int i=p;i>0;i--)
    {
        f[i]=book[A[i]];
        book[A[i]]=i;
    }
    int ans=0;
    node t;s.clear();
    multiset <node> ::iterator it;
    for(int i=1;i<=p;i++)
    {
        t.num=A[i];t.val=f[i];
        if(in[t.num])
        {
            t.val=sta[t.num];
            it=s.lower_bound(t);
            s.erase(it);
            t.val=f[i];
            s.insert(t);
            sta[t.num]=f[i];
        }
        else if(s.size()<K)
        {
            ++ans;
            s.insert(t);
            in[t.num]=true;
            sta[t.num]=t.val;
        }
        else if(s.size()==K)
        {
            it=s.begin();++ans;
            in[(*it).num]=false;
            s.erase(it);
            in[t.num]=true;
            sta[t.num]=t.val;
            s.insert(t);
        }
    }
    printf("%d\n",ans);
    return ;
}
int H;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    H=R();
    while(H--) solve();
    return 0;
}