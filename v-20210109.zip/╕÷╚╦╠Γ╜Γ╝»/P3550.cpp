#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=500007;
typedef long long LL;
LL M,D;
int N;
LL A[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld%d",&M,&D,&N);
    for(int i=1;i<=N;i++)
        scanf("%lld",&A[i]);
    LL k=M-D;
    sort(A+1,A+1+N);
    int p=lower_bound(A+1,A+1+N,k)-A;
    if(p>N) {printf("0");return 0;}
    if(!k) p=0;
    int x=N,ans=1;
    LL tmp=0;
    while(tmp<D&&x)
    {
        if(x==p) x--;
        if(!x) break;
        A[x]-=D-tmp;
        if(A[x]<0) break;
        tmp+=A[x];++ans;
        --x;
    }
    if(tmp<D)
    {
        A[p]-=D-tmp;
        if(A[p]<0) printf("0");
        else
        {
            tmp+=A[p];
            if(tmp<M) printf("0");
            else printf("%d",ans);
        }
    }
    else
    {
        if(tmp>=M) --ans;
        printf("%d",ans);
    }
    return 0;
}