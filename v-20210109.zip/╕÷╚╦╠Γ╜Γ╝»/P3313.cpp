#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=100007;
const int maxm=200007;
int A[maxn],root[maxn],W[maxn];
int N,Q;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int depth[maxn],fa[maxn],sz[maxn],son[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[son[u]]<sz[v]) son[u]=v;
    }
    return ;
}
int top[maxn],id[maxn],anti[maxn],ix;
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;anti[ix]=u;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
struct seg_tree{
    int ls,rs;
    int val,sum;
}TREE[maxn*40];
#define Ls(i) TREE[i].ls
#define Rs(i) TREE[i].rs
#define v(i) TREE[i].val
#define sum(i) TREE[i].sum
#define mid (L+R>>1)
int cnt;
void Update(int L,int R,int x,int v,int &i)
{
    if(!i) i=++cnt;
    if(L==R) {v(i)=sum(i)=v;return ;}
    if(x<=mid) Update(L,mid,x,v,Ls(i));
    else Update(mid+1,R,x,v,Rs(i));
    sum(i)=sum(Ls(i))+sum(Rs(i));
    v(i)=max(v(Ls(i)),v(Rs(i)));
    return ;
}
int Query_max(int L,int R,int l,int r,int i)
{
    if(!i) return 0;
    if(l<=L&&R<=r) return v(i);
    int re=0;
    if(l<=mid) re=max(re,Query_max(L,mid,l,r,Ls(i)));
    if(r>mid) re=max(re,Query_max(mid+1,R,l,r,Rs(i)));
    return re;
}
int Query_sum(int L,int R,int l,int r,int i)
{
    if(!i) return 0;
    if(l<=L&&R<=r) return sum(i);
    int re=0;
    if(l<=mid) re+=Query_sum(L,mid,l,r,Ls(i));
    if(r>mid) re+=Query_sum(mid+1,R,l,r,Rs(i));
    return re;
}
int Query_Path_max(int x,int y,int rt)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re=max(re,Query_max(1,N,id[top[x]],id[x],rt));
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re=max(re,Query_max(1,N,id[x],id[y],rt));
    return re;
}
int Query_Path_sum(int x,int y,int rt)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re+=Query_sum(1,N,id[top[x]],id[x],rt);
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re+=Query_sum(1,N,id[x],id[y],rt);
    return re;
}
char qwq[7];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();Q=R();
    for(register int i=1;i<=N;i++)
        W[i]=R(),A[i]=R();
    int u,v;
    for(register int i=1;i<N;i++)
    {
        u=R();v=R();
        addE(u,v);addE(v,u);
    }
    dfs1(1);dfs2(1,1);
    for(register int i=1;i<=N;i++)
        Update(1,N,id[i],W[i],root[A[i]]);
    while(Q--)
    {
        scanf("%s",qwq);u=R();v=R();
        if(qwq[0]=='Q')
        {
            if(qwq[1]=='S') printf("%d\n",Query_Path_sum(u,v,root[A[u]]));
            else printf("%d\n",Query_Path_max(u,v,root[A[u]]));
        }
        else
        {
            if(qwq[1]=='C')
            {
                Update(1,N,id[u],0,root[A[u]]);
                Update(1,N,id[u],W[u],root[v]);
                A[u]=v;
            }
            else
            {
                Update(1,N,id[u],v,root[A[u]]);
                W[u]=v;
            }
        }
    }
    return 0;
}