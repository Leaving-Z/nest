#include<bits/stdc++.h>
#include<queue>
using namespace std;
queue <int> q;
priority_queue <int,vector<int>,greater<int> > qq;
const int maxn=2007;
const int maxm=200007;
const int inf=0x7f7f7f7f;
int N,K,M,ans,S,T;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
int need[maxn];
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ; 
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	q.push(S);cnt[S]=1;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cnt[v]==0&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline int DFS(int u,int f)
{
	if(u==T) return f;
	int v,sum=0,d;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=DFS(v,min_(f,cf(i)));
			if(d>0)
			{
				sum+=d;
				f-=d;
				cf(i)-=d;
				cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	K=R();N=R();S=0;T=N+K+1;
	int cf;
	for(register int i=1;i<=K;i++)
	{
		need[i]=cf=R();M+=cf;
		addE(i+N,T,cf);
		addE(T,i+N,0);
	}
	int x,v;
	for(register int i=1;i<=N;i++)
	{
		x=R();
		for(register int j=1;j<=x;j++)
		{
			v=R()+N;
			addE(i,v,1);
			addE(v,i,0);
		}
	}
	for(register int i=1;i<=N;i++)
		addE(S,i,1),addE(i,S,0);
	while(BFS())//Dinic
		ans+=DFS(S,inf);
	if(ans<M)
		printf("No Solution!");
	else
	{
		for(register int i=1;i<=K;i++)
		{
			//if(!need[i]) continue;
			printf("%d:",i);
			for(int j=first[i+N];j;j=nt[j])
				if(e[j].v!=T&&cf(j^1)==0)
				qq.push(e[j].v);
			while(!qq.empty()) printf(" %d",qq.top()),qq.pop();
			printf("\n");
		}
	}
	return 0;
}
