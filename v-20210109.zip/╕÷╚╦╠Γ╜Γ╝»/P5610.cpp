#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
const int maxn=500007;
namespace io {
	const int __SIZE = (1 << 21) + 1;
	char ibuf[__SIZE], *iS, *iT, obuf[__SIZE], *oS = obuf, *oT = oS + __SIZE - 1, __c, qu[55]; int __f, qr, _eof;
	#define Gc() (iS == iT ? (iT = (iS = ibuf) + fread (ibuf, 1, __SIZE, stdin), (iS == iT ? EOF : *iS ++)) : *iS ++)
	inline void flush () { fwrite (obuf, 1, oS - obuf, stdout), oS = obuf; }
	inline void gc (char &x) { x = Gc(); }
	inline void pc (char x) { *oS ++ = x; if (oS == oT) flush (); }
	inline void pstr (const char *s) { int __len = strlen(s); for (__f = 0; __f < __len; ++__f) pc (s[__f]); }
	inline void gstr (char *s) { for(__c = Gc(); __c < 32 || __c > 126 || __c == ' ';)  __c = Gc();
		for(; __c > 31 && __c < 127 && __c != ' ' && __c != '\n' && __c != '\r'; ++s, __c = Gc()) *s = __c; *s = 0; }
	template <class I> inline bool gi (I &x) { _eof = 0;
		for (__f = 1, __c = Gc(); (__c < '0' || __c > '9') && !_eof; __c = Gc()) { if (__c == '-') __f = -1; _eof |= __c == EOF; }
		for (x = 0; __c <= '9' && __c >= '0' && !_eof; __c = Gc()) x = x * 10 + (__c & 15), _eof |= __c == EOF; x *= __f; return !_eof; }
	template <class I> inline void print (I x) { if (!x) pc ('0'); if (x < 0) pc ('-'), x = -x;
		while (x) qu[++ qr] = x % 10 + '0',  x /= 10; while (qr) pc (qu[qr --]); }
	struct Flusher_ {~Flusher_(){flush();}}io_flusher_;
} using io::pc; using io::gc; using io::pstr; using io::gstr; using io::gi; using io::print;
int Memory[maxn*60],*ITT=Memory;
struct Vec{
    int *BEG,*EN,*_ITT,sz;
    void init(int *b,int *e) {BEG=_ITT=b,EN=e;return ;}
    int* begin() {return BEG;}
    int* end() {return EN;}
    int size() {return sz;}
    int& operator [] (const int &x) {return BEG[x];}
    void push_back(int x) {*_ITT++=x;++sz;return ;}
}M[maxn],F[maxn];
int N,Q;
int A[maxn];
int pos;
int sz[maxn],sz1[maxn];
int S[maxn*40];
#define ps(p,x) (sz[p]+x)
int f(int x)
{
    while(x!=S[ps(pos,x)])
        x=S[ps(pos,x)]=S[ps(pos,S[ps(pos,x)])];
    return x;
    return S[ps(pos,x)]==x?x:S[ps(pos,x)]=f(S[ps(pos,x)]);
}
long long C[maxn];
void update(int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&(-x);
    return ;
}
long long query(register int l,register int r)
{
    long long re=0;
    l--;
    while(r>l) re+=C[r],r&=r-1;
    while(l>r) re-=C[l],l&=l-1;
    return re;
}
int book[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    gi(N);gi(Q);
    int t;
    int lim=0;
    for(int i=1;i<=N;i++)
    {
        gi(A[i]);
        lim=max(lim,A[i]);
        C[i]+=A[i];
        t=i+(i&(-i));
        if(t<=N) C[t]+=C[i];
        book[A[i]]++;
    }
    for(register int i=2;i<=lim;i++)
        for(register int j=i;j<=lim;j+=i)
        if(book[j]) ++sz1[j],sz[i]+=book[j];
    for(int i=2;i<=lim;i++)
    {
        if(sz[i])
        {
            ++sz[i];
            M[i].init(ITT,ITT+sz[i]);
            ITT+=sz[i];
        }
        if(sz1[i])
        {
            F[i].init(ITT,ITT+sz1[i]);
            ITT+=sz1[i];
        }
    }
    for(register int i=2;i<=lim;i++)
        for(register int j=i;j<=lim;j+=i)
        if(book[j]) F[j].push_back(i);
    for(register int i=1;i<=N;i++)
    {
        t=F[A[i]].sz;
        for(int k=0;k<t;k++)
            M[F[A[i]][k]].push_back(i);
    }
    for(register int i=2;i<=lim;i++)
    {
        if(sz[i])
        {
            M[i].push_back(N+1);
            for(int j=0;j<sz[i];j++)
                S[sz[i-1]+j]=j;
        }
        sz[i]+=sz[i-1];
    }
    int op,p,nxt;
    long long lst=0,l,r,x;
    while(Q--)
    {
        gi(op);
        gi(l);l^=lst;
        gi(r);r^=lst;
        if(op==1)
        {
            gi(x);x^=lst;
            if(sz[x]==sz[x-1]) continue;
            l=lower_bound(M[x].begin(),M[x].end(),l)-M[x].begin();
            r=upper_bound(M[x].begin(),M[x].end(),r)-M[x].begin();
            for(register int i=l;i<r;i=nxt)
            {
                pos=x-1;
                nxt=f(i+1);
                p=M[x][i];
                if(A[p]%x==0)
                {
                    t=A[p]/x;
                    update(p,t-A[p]);
                    A[p]=t;
                }
                if(A[p]%x) S[sz[x-1]+i]=nxt;
            }
        }
        else print(lst=query(l,r)),pstr("\n");
    }
    return 0;
}