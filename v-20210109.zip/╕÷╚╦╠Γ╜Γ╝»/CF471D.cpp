#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
int kmp[maxn];
int A[maxn],B[maxn];
int N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    for(int i=N;i>0;i--)
        A[i]-=A[i-1];
    A[1]=-1e8;
    for(int i=1;i<=M;i++)
        scanf("%d",&B[i]);
    for(int i=M;i>0;i--)
        B[i]-=B[i-1];
    for(int i=1;i<M;i++)
        B[i]=B[i+1];
    M--;
    for(int i=2,j=0;i<=M;i++)
    {
        while(j&&B[i]!=B[j+1]) j=kmp[j];
        if(B[i]==B[j+1]) ++j;
        kmp[i]=j;
    }
    int ans=0;
    for(int i=1,j=0;i<=N;i++)
    {
        while(j&&(j==M||A[i]!=B[j+1])) j=kmp[j];
        if(A[i]==B[j+1]) ++j;
        if(j==M) ++ans;
    }
    printf("%d",ans);
    return 0;
}