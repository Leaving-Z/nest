#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<iostream>
using namespace std;
typedef long long LL;
const int maxn=507;
const LL modb=1e9+7;
const LL modp=1e9+6;
const LL A=19260817;
LL fast_pow(LL b,LL k,LL mod)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
char s1[maxn],s[maxn];
int nxt[maxn];
int N,len;
int stk[maxn],top;
bool judge(char c)
{
    return c=='+'||c=='-'||c=='*'||c=='^'||isdigit(c)||c=='a'||c=='('||c==')';
}
void pre()
{
    len=0;top=0;
    int l=strlen(s1+1);
    for(int i=1;i<=l;i++)
    {
        if(s1[i]=='(') stk[++top]=i;
        if(s1[i]==')')
        {
            if(top>0) --top;
            else s1[i]=0;
        }
    }
    while(top) s1[stk[top--]]=0;
    for(int i=1;i<=l;i++)
        if(judge(s1[i])) s[++len]=s1[i];
    for(int i=1;i<=len;i++)
    {
        if(s[i]=='(') stk[++top]=i;
        if(s[i]==')') nxt[stk[top--]]=i+1;
    }
    return ;
}
bool finda(int L,int R)
{
    for(int i=L;i<=R;i++)
    {
        if(s[i]=='(') i=nxt[i];
        if(i>R) break;
        if(s[i]=='+'||s[i]=='-') return true;
    }
    return false;
}
bool findb(int L,int R)
{
    for(int i=L;i<=R;i++)
    {
        if(s[i]=='(') i=nxt[i];
        if(i>R) break;
        if(s[i]=='*') return true;
    }
    return false;
}
int findc(int L,int R)
{
    int t=0;
    for(int i=L;i<=R;i++)
    {
        if(s[i]=='(') i=nxt[i];
        if(i>R) break;
        if(s[i]=='^') t=i;
    }
    return t;
}
LL calc(int L,int R,LL mod)
{
    if(s[L]=='a') return A;
    else
    {
        LL re=0;
        for(int i=L;i<=R;i++)
        if(isdigit(s[i])) re=re*10+s[i]-48,re%=mod;
        return re;
    }
}
LL solve(int L,int R,LL mod)
{
    if(s[L]=='('&&nxt[L]==R+1) return solve(L+1,R-1,mod);
    if(finda(L,R))
    {
        int lt=L,ty=1;
        LL re=0;
        for(int i=L;i<=R;i++)
        {
            if(s[i]=='(') i=nxt[i];
            if(i>R) break;
            if(s[i]=='+'||s[i]=='-')
            {
                re+=ty*solve(lt,i-1,mod);
                re%=mod;re+=mod;re%=mod;
                if(s[i]=='+') lt=i+1,ty=1;
                else lt=i+1,ty=-1;
            }
        }
        re+=ty*solve(lt,R,mod);
        re%=mod;re+=mod;re%=mod;
        return re;
    }
    if(findb(L,R))
    {
        int lt=L;
        LL re=1;
        for(int i=L;i<=R;i++)
        {
            if(s[i]=='(') i=nxt[i];
            if(i>R) break;
            if(s[i]=='*')
            {
                re*=solve(lt,i-1,mod);
                re%=mod;re+=mod;re%=mod;
                lt=i+1;
            }
        }
        re*=solve(lt,R,mod);
        re%=mod;re+=mod;re%=mod;
        return re;
    }
    int p=findc(L,R);
    if(p) return fast_pow(solve(L,p-1,modb),solve(p+1,R,modp),mod);
    else return calc(L,R,mod);
}
LL ans;
void getl(char *str)
{
    char c;
    int i=1;
    if(scanf("%c",&c)==EOF) return ;
    while(c!='\n')
    {
        str[i]=c,++i;
        if(scanf("%c",&c)==EOF) return ;
    }
    if(str[i]=='\r') str[i]=0;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    getl(s1);
    pre();
    ans=solve(1,len,modb);
    memset(s,0,sizeof(s));
    memset(s1,0,sizeof(s1));
    getl(s);
    N=calc(1,strlen(s+1),modb);
    LL re;
    for(int i=1;i<=N;i++)
    {
        memset(s,0,sizeof(s));
        memset(s1,0,sizeof(s1));
        getl(s1);
        pre();
        re=solve(1,len,modb);
        if(re==ans) putchar('A'+i-1);
    }
    return 0;
}