#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=3000407;
typedef long long LL;
LL A[maxn];
//-4713->maxn
bool is41(int y)
{
	return y%4==0;
}
bool is42(int y)
{
	return y%4==0&&y%100!=0||y%400==0;
}
int s4[13]={0,31,29,31,30,31,30,31,31,30,31,30,31};
//             1  2  3  4  5  6  7  8  9  10 11 12
int nom[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int spc[13]={0,31,28,31,30,31,30,31,31,30,21,30,31};
int y4,yn;
void work(int d,int mon[])
{
	int res=0,p;
	for(int i=1;i<=12;i++)
	{
		p=i;
		if(res+mon[i]>=d) break;
		else res+=mon[i];
	}
	if(mon[p]==21&&d-res>=5)
	{
		printf("%d %d",d-res+10,p);
	}
	else printf("%d %d",d-res,p);
	return ;
}
int main()
{

	for(int i=1;i<=12;i++)
		y4+=s4[i];
	for(int i=1;i<=12;i++)
		yn+=nom[i];
	A[0]=y4-1;//?
	for(int i=1;i<4713;i++)
	{
		if(is41(i)) A[i]=A[i-1]+y4;
		else A[i]=A[i-1]+yn;
	}
	A[4713]=A[4712];
	for(int i=4714;i<=6295;i++)
	{
		if(is41(i-4713)) A[i]=A[i-1]+y4;
		else A[i]=A[i-1]+yn;
	}
	A[6295]-=10;
	for(int i=6296;i<maxn;i++)
	{
		if(is42(i-4713)) A[i]=A[i-1]+y4;
		else A[i]=A[i-1]+yn;
	}
	int Q,p,ans;
	LL d,sum400=A[3000400]-A[3000000];
	scanf("%d",&Q);
	while(Q--)
	{
		scanf("%lld",&d);
		p=lower_bound(A,A+maxn,d)-A;
		if(p==maxn)
		{
			d-=A[3000000];
			ans=d/sum400*400;
			d%=sum400;
			d+=A[3000000];
			p=lower_bound(A,A+maxn,d)-A;
			if(is42(p-4713)) work(d-A[p-1],s4);
			else work(d-A[p-1],nom);
			printf(" %lld\n",p-4713ll+ans);
		}
		else if(p-4713==1582)
		{
			work(d-A[p-1],spc);
			printf(" 1582\n");
		}
		else if(p<4713)
		{
			if(p==0)
			{
				work(d+1,s4);
				printf(" %d BC\n",4713);
			}
			else
			{
				if(is41(p)) work(d-A[p-1],s4);
				else work(d-A[p-1],nom);
				printf(" %d BC\n",4713-p);
			}
		}
		else if(p>4713&&p<6295)
		{
			if(is41(p-4713))
			{
				work(d-A[p-1],s4);
			}
			else work(d-A[p-1],nom);
			printf(" %d\n",p-4713);
		}
		else if(p>6295)
		{
			if(is42(p-4713)) work(d-A[p-1],s4);
			else work(d-A[p-1],nom);
			printf(" %d\n",p-4713);
		}
	}
	return 0;
}