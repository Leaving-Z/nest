#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
inline void swap_(LL &x,LL &y)
{
	LL t=x;x=y;y=t;
	return ;
}
struct sta{
	LL x,y,z;
	void sort()
	{
		if(x>y) swap_(x,y);
		if(y>z) swap_(y,z);
		if(x>y) swap_(x,y);
		return ;
	}
};
sta a,b;
LL cal(LL x,LL y)
{
	if(x%y==0) return x/y-1;
	else
	{
		LL t=x/y;
		return t+cal(y,x%y);
	}
}
bool operator == (sta x,sta y)
{
	x.sort();y.sort();
	return x.x==y.x&&x.y==y.y&&x.z==y.z;
}
sta getre(sta x,LL step)
{
	if(!step) return x;
	LL dis1=x.y-x.x,dis2=x.z-x.y;
	if(dis1==dis2) return x;
	bool f=false;
	if(dis1<dis2) swap_(dis1,dis2),f=true;
	LL t;
	if(dis1%dis2==0) t=min(step,dis1/dis2-1);
	else t=min(step,dis1/dis2);
	if(f)
	{
		x.x+=dis2*t;
		x.y+=dis2*t;
	}
	else
	{
		x.y-=dis2*t;
		x.z-=dis2*t;
	}
	if(t==step) return x;
	else return getre(x,step-t);
}
#define mid (L+R>>1)
int main()
{
	LL dis1,dis2;
	scanf("%lld%lld%lld",&a.x,&a.y,&a.z);
	scanf("%lld%lld%lld",&b.x,&b.y,&b.z);
	a.sort();b.sort();
	dis1=a.y-a.x,dis2=a.z-a.y; 
	LL d1=cal(dis1,dis2);
	sta root1=getre(a,d1);
	dis1=b.y-b.x;dis2=b.z-b.y;
	LL d2=cal(dis1,dis2);
	sta root2=getre(b,d2);
	if(root1==root2) puts("YES");
	else {printf("NO");return 0;}
	LL L=0,R=max(d1,d2),ans;
	if(d1<d2) swap(a,b),swap_(d1,d2);
	a=getre(a,d1-d2);
	while(L<=R)
	{
		if(getre(a,mid)==getre(b,mid)) ans=mid,R=mid-1;
		else L=mid+1;
	}
	printf("%lld",ans*2+d1-d2);
	return 0;
}
