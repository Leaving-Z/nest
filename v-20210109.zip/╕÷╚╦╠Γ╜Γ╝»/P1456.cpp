#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
int fa[maxn];
int N,Q;
int ch[maxn][2],val[maxn],dist[maxn];
int f(int x) {return fa[x]==x?x:fa[x]=f(fa[x]);}
int merge(int x,int y)
{
    if(!x||!y) return x|y;
    if(val[x]<val[y]) swap(x,y);
    ch[x][1]=merge(ch[x][1],y);
    if(dist[ch[x][0]]<dist[ch[x][1]]) swap(ch[x][0],ch[x][1]);
    dist[x]=dist[ch[x][1]]+1;
    return fa[ch[x][0]]=fa[ch[x][1]]=fa[x]=x;
}
int update(int x)
{
    val[x]>>=1;
    int t=merge(ch[x][0],ch[x][1]);
    ch[x][0]=ch[x][1]=0;
    return fa[x]=fa[t]=merge(x,t);
}
void solve()
{
    if(scanf("%d",&N)==EOF) exit(0);
    for(int i=1;i<=N;i++)
        scanf("%d",&val[i]),fa[i]=i,ch[i][0]=ch[i][1]=0;
    int x,y,f1,f2;
    scanf("%d",&Q);
    while(Q--)
    {
        scanf("%d%d",&x,&y);
        f1=f(x);f2=f(y);
        if(f1==f2) puts("-1");
        else
        {
            f1=update(f1);f2=update(f2);
            fa[f1]=fa[f2]=merge(f1,f2);
            printf("%d\n",val[fa[f1]]);
        }
    }
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    while(1) solve();
    return 0;
}