#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
struct E{
	int u,v,w;
}e[500007];
int first[250007],nt[500007],ES;
inline void addE(const int &u,const int &v,const int &w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int book[250007],dis[250007];
char s[507][507];
queue <int> q;
int N,M,S,T;
inline void SPFA()
{
	memset(book,0,sizeof(book));
	memset(dis,0x3f,sizeof(dis));
	dis[S]=0;
	int t;
	q.push(S);book[S]=true;
	while(!q.empty())
	{
		t=q.front();q.pop();book[t]=false;
		for(int i=first[t];i;i=nt[i])
		{
			if(dis[t]+e[i].w<dis[e[i].v])
			{
				dis[e[i].v]=dis[t]+e[i].w;
				if(!book[e[i].v])
				{
					q.push(e[i].v);
					book[e[i].v]=true;
				}
			}
		}
	}
	printf("%d\n",dis[T]);
	return ;
}
int main()
{
	int t,x,y;
	while(scanf("%d%d",&N,&M)&&N&&M)
	{
		memset(s,0,sizeof(s));
		ES=0;
		memset(first,0,sizeof(first));
		memset(nt,0,sizeof(nt));
		for(int i=1;i<=N;i++)
			scanf("%s",s[i]+1);
		for(int i=1;i<=N;i++)
			for(int j=1;j<=M;j++)
			{
				if(s[i][j]==s[i-1][j]) t=0;
				else t=1;
				if(i>1)
				addE((i-1)*M+j,(i-2)*M+j,t);
				
				if(s[i][j]==s[i+1][j]) t=0;
				else t=1;
				if(i<N)
				addE((i-1)*M+j,i*M+j,t);
				
				if(s[i][j]==s[i][j+1]) t=0;
				else t=1;
				if(j<M)
				addE((i-1)*M+j,(i-1)*M+j+1,t);
				
				if(s[i][j]==s[i][j-1]) t=0;
				else t=1;
				if(j>1)
				addE((i-1)*M+j,(i-1)*M+j-1,t);
			}
		scanf("%d%d",&x,&y);
		S=x*M+y+1;
		scanf("%d%d",&x,&y);
		T=x*M+y+1;
		SPFA();
	}
	return 0;
}
