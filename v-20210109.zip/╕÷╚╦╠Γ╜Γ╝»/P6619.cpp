#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=2400007;
int d[maxn];
int op[maxn][4];
int N;
int C1[maxn],C2[maxn];
void update(int C[],int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&(-x);
    return ;
}
int query(int C[],int x)
{
    int re=0;
    while(x) re+=C[x],x&=(x-1);
    return re;
}
int find()
{
    int p=0,np;
    int sumc=0,sumf=0,c,f;
    for(int i=21;i>=0;i--)
    {
        np=p+(1<<i);
        c=sumc+C1[np];f=sumf+C2[np];
        if(c<f)
        {
            sumc=c;
            sumf=f;
            p=np;
        }
    }
    return p;
}
int lst(int val)
{
    int p=0,np;
    int sumc=0,c;
    for(int i=21;i>=0;i--)
    {
        np=p+(1<<i);
        c=sumc+C2[np];
        if(c>=val)
        {
            p=np;
            sumc=c;
        }
    }
    return p;
}
int anti[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    int cnt=0;
    for(int i=1;i<=N;i++)
    {
        op[i][0]=R();
        if(op[i][0]==1)
        {
            op[i][1]=R();op[i][2]=R();op[i][3]=R();
            d[++cnt]=op[i][2];
        }
        else op[i][1]=R();
    }
    sort(d+1,d+1+cnt);
    int tot=unique(d+1,d+1+cnt)-d-1;
    int x;
    for(int i=1;i<=N;i++)
    {
        if(op[i][0]==1)
            x=lower_bound(d+1,d+1+tot,op[i][2])-d,anti[x]=op[i][2],op[i][2]=x;
    }
    int p,res1,res2;
    for(int i=1;i<=N;i++)
    {
        if(op[i][0]==1)
        {
            if(op[i][1]==1) update(C2,1,op[i][3]),update(C2,op[i][2]+1,-op[i][3]);
            else update(C1,op[i][2],op[i][3]);
        }
        else
        {
            p=op[i][1];
            if(op[p][1]==1) update(C2,1,-op[p][3]),update(C2,op[p][2]+1,op[p][3]);
            else update(C1,op[p][2],-op[p][3]);
        }
        p=find();
        res1=query(C1,p);
        res2=query(C2,p+1);
        if(res1==0&&res2==0) puts("Peace");
        else if(res1>res2)
            printf("%d %d\n",anti[p],res1<<1);
        else
        {
            p=lst(res2);
            printf("%d %d\n",anti[p],res2<<1);
        }
    }
    return 0;
}