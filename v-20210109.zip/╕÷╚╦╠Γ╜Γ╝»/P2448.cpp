#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
typedef long long LL;
int d[maxn*3];
int x[maxn],y[maxn];
int N;
int A[maxn*3],cnt,val[maxn*3];
LL C[maxn*3];
int tot;
void update(int x,int k)
{
	while(x<=tot) C[x]+=k,x+=x&(-x);
	return ;
}
LL query(int x)
{
	LL re=0;
	while(x) re+=C[x],x&=(x-1);
	return re;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		d[++cnt]=x[i],d[++cnt]=x[i]-1,d[++cnt]=x[i]+1;
		d[++cnt]=y[i],d[++cnt]=y[i]-1,d[++cnt]=y[i]+1;
	}
	sort(d+1,d+1+cnt);
	tot=unique(d+1,d+1+cnt)-d-1;
	for(int i=1;i<=tot;i++)
		A[i]=d[i],val[i]=d[i+1]-d[i-1]-1;
	int a,b;
	for(int i=1;i<=N;i++)
	{
		a=lower_bound(d+1,d+1+tot,x[i])-d;
		b=lower_bound(d+1,d+1+tot,y[i])-d;
		swap(A[a],A[b]);
	}
	LL ans=0;
	for(int i=1;i<=tot;i++)
	{
		a=lower_bound(d+1,d+1+tot,A[i])-d;
		ans+=query(tot)-query(a);
		update(a,val[i]);
	}
	printf("%lld",ans);
	return 0;
}
