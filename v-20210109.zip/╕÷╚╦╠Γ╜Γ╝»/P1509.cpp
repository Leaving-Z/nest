#include<cstdio>
#include<algorithm>
using namespace std;
int F[107][107];
int DP[107][107];
struct fff{
	int rmb,rp,t;
}npy[107];
int N,RMB,RP;
int main()
{
	scanf("%d",&N);
	for(register int i=1;i<=N;i++)
		scanf("%d%d%d",&npy[i].rmb,&npy[i].rp,&npy[i].t);
	scanf("%d%d",&RMB,&RP);
	for(register int i=1;i<=N;i++)
		for(register int j=RMB;j>=npy[i].rmb;j--)
			for(register int k=RP;k>=npy[i].rp;k--)
			if(F[j-npy[i].rmb][k-npy[i].rp]+1>F[j][k])
			{
				F[j][k]=F[j-npy[i].rmb][k-npy[i].rp]+1;
				DP[j][k]=DP[j-npy[i].rmb][k-npy[i].rp]+npy[i].t;
			}
			else if(F[j-npy[i].rmb][k-npy[i].rp]+1==F[j][k])
				DP[j][k]=min(DP[j][k],DP[j-npy[i].rmb][k-npy[i].rp]+npy[i].t);
	printf("%d",DP[RMB][RP]);
	return 0;
}
