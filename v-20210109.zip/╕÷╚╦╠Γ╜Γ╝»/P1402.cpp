#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=407;
const int maxm=45007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int cnt[maxn],cur[maxn];
int N,P,Q,S,T;
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	q.push(S);cnt[S]=1;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int sum=0,d,v;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min_(f,cf(i)));
			if(d>0)
			{
				sum+=d;f-=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	N=R();P=R();Q=R();T=Q+N+N+P+1;
	int s;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=P;j++)
		{
			s=R();
			if(s) add(Q+N+i,Q+N+N+j,1);
		}
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=Q;j++)
		{
			s=R();
			if(s) add(j,Q+i,1);
		}
	for(register int i=1;i<=Q;i++)
		add(S,i,1);
	for(register int i=1;i<=P;i++)
		add(Q+N+N+i,T,1);
	for(register int i=1;i<=N;i++)
		add(Q+i,Q+N+i,1);
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
