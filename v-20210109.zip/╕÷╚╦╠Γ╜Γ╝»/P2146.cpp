#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct E{
	int u,v;
}e[200007];
int ES;
int first[100007],nt[200007];
void addE(int u,int v)
{
	ES++;
	e[ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	ES++;
	e[ES]=(E){v,u};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
int N,Q;
int TREE[400007],add[400007];
char op[17];
int fa[100007],depth[100007],top[100007],sz[100007],son[100007];
int id[100007]/*index->num*/,anti[100007];//num->index
int ix;
void DFS(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			depth[v]=depth[u]+1;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[son[u]]<sz[v]) son[u]=v;
		}
	}
	return ;
}
void dfs(int u,int s)
{
	id[u]=++ix;
	anti[ix]=u;
	top[u]=s;
	if(son[u]) dfs(son[u],s);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u]&&v!=son[u])
		dfs(v,v);
	}
	return ;
}
void LAZY(int L,int R,int i)
{
	if(add[i]==-1) return ;
	int mid=L+R>>1;
	if(add[i]==1)
	{
		TREE[i<<1]=mid-L+1;
		add[i<<1]=1;
		TREE[i<<1|1]=R-mid;
		add[i<<1|1]=1;
	}
	else
	{
		TREE[i<<1]=0;
		add[i<<1]=0;
		TREE[i<<1|1]=0;
		add[i<<1|1]=0;
	}
	add[i]=-1;
	return ;
}
void Update(int L,int R,int l,int r,int i,int k)
{
	if(l<=L&&R<=r)
	{
		if(k==1)
		{
			TREE[i]=(R-L+1);
			add[i]=1;
		}
		else
		{
			add[i]=0;
			TREE[i]=0;
		}
		return ;
	}
	int mid=L+R>>1;
	LAZY(L,R,i);
	if(l<=mid) Update(L,mid,l,r,i<<1,k);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
		return TREE[i];
	int mid=L+R>>1;
	LAZY(L,R,i);
	int ans=0;
	if(l<=mid) ans+=Query(L,mid,l,r,i<<1);
	if(r>mid) ans+=Query(mid+1,R,l,r,i<<1|1);
	return ans;
}
int Query_Path(int x,int y)
{
	int ans=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		ans+=Query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	ans+=Query(1,N,id[x],id[y],1);
	return ans;
}
void Update_Path(int x,int y,int k)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],1,k);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x],id[y],1,k);
	return ;
}
int main()
{
	memset(add,-1,sizeof(add));
	scanf("%d",&N);
	int v;
	for(int i=1;i<N;i++)
	{
		scanf("%d",&v);
		addE(i+1,v+1);
	}
	DFS(1);
	dfs(1,1);
	scanf("%d",&Q);
	int x,A;
	for(int i=1;i<=Q;i++)
	{
		scanf("%s",op);scanf("%d",&x);x++;
		if(op[0]=='i')
		{
			A=Query_Path(x,1);
			Update_Path(x,1,1);
			printf("%d\n",depth[x]+1-A);
		}
		else
		{
			A=Query(1,N,id[x],id[x]+sz[x]-1,1);
			Update(1,N,id[x],id[x]+sz[x]-1,1,0);
			printf("%d\n",A);
		}
	}
	return 0;
} 
