#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long LL;
int Trie[600007][70];
LL end[600007];
int N,all;
LL C[500007],num[500007];
char s[10];
inline void Insert(LL x)
{
	LL p=0,t;
	for(LL i=0;s[i];i++)
	{
		t=s[i]-'A';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	end[p]=x;
	return ;
}
inline LL R()
{
	LL p=0,t;
	for(LL i=0;s[i];i++)
	{
		t=s[i]-'A';
		p=Trie[p][t];
	}
	return end[p];
}
inline void Update(LL x)
{
	while(x<=N)
	{
		++C[x];
		x+=x&(-x);
	}
	return ;
}
inline long long Query(LL x)
{
	long long sum=0;
	while(x>0)
	{
		sum+=C[x];
		x-=x&(-x);
	}
	return sum;
}
int main()
{
	scanf("%d",&N);
	for(LL i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert(i);
	}
	for(LL i=1;i<=N;i++)
	{
		scanf("%s",s);
		num[i]=R();
	}
	long long ans=0;
	for(LL i=1;i<=N;i++)
	{
		Update(num[i]);
		ans+=i-Query(num[i]);
	}
	printf("%lld",ans);
	return 0;
}
