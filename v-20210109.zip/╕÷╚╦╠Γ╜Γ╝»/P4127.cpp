#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
typedef long long LL;
const int maxn=20;
const int maxs=180;
LL L,R;
int A[maxn],cnt;
LL f[2][maxn][maxs][maxs];
void sep(LL x)
{
    cnt=0;
    while(x)
    {
        A[++cnt]=x%10;
        x/=10;
    }
    for(int i=1;i<=cnt/2;i++)
        swap(A[i],A[cnt-i+1]);
    return ;
}
int mod;
LL dfs(int u,int sum,int r,bool less)
{
    if(sum>mod) return 0;
    if(u>cnt)
    {
        if(sum==mod&&r==0) return 1;
        return 0;
    }
    if(f[less][u][sum][r]!=-1) return f[less][u][sum][r];
    LL re=0;
    int lim=less?9:A[u];
    for(int i=0;i<=lim;i++)
        re+=dfs(u+1,sum+i,(r*10+i)%mod,less||i<A[u]);
    return f[less][u][sum][r]=re;
}
LL calc(LL x)
{
    sep(x);
    LL res=0;
    for(int i=1;i<=170;i++)
    {
        mod=i;
        memset(f,-1,sizeof(f));
        res+=dfs(1,0,0,false);
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&L,&R);
    LL ans1=calc(R),ans2=calc(L-1);
    printf("%lld",ans1-ans2);
    return 0;
}