#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=100007;
struct E{
	int u,v,w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
int dis[maxn],fa[maxn];
inline void dfs(int u)
{
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			dis[v]=dis[u]^e[i].w;
			fa[v]=u;
			dfs(v);
		}
	}
	return ;
}
int main()
{
	N=R();
	int u,v,w;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);addE(v,u,w);
	}
	dfs(1);
	M=R();
	for(register int i=1;i<=M;i++)
		printf("%d\n",dis[R()]^dis[R()]);
	return 0;
}
