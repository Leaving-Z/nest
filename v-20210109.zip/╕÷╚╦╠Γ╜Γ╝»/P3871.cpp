#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;
const int maxn=110007;
struct Treap{
	int l,r,num,pri,v,s;
}TREE[maxn];
int N,M,root,all;
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define val(i) TREE[i].v
#define p(i) TREE[i].pri
#define sz(i) TREE[i].s
#define c(i) TREE[i].num
char s[7];
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Insert(int &i,const int &v)
{
	if(!i)
	{
		i=++all;p(i)=rand();
		val(i)=v;sz(i)=c(i)=1;
		L(i)=R(i)=0;
		return ;
	}
	++sz(i);
	if(v==val(i)) ++c(i);
	else if(v<val(i))
	{
		Insert(L(i),v);
		if(p(L(i))<p(i)) Zig(i);
	}
	else
	{
		Insert(R(i),v);
		if(p(R(i))<p(i)) Zag(i);
	}
	return ;
}
inline int KTH(int k)
{
	int i=root;
	while(i)
	{
		if(sz(L(i))+c(i)>=k&&sz(L(i))<k) return val(i);
		else if(sz(L(i))>=k) i=L(i);
		else k-=sz(L(i))+c(i),i=R(i);
	}
	return 0;
}
inline int Read()
{
	int re,f=1;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=Read();
	int x;
	for(int i=1;i<=N;i++)
	{
		x=Read();
		Insert(root,x);
	}
	M=Read();
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s);
		if(s[0]=='a')
		{
			x=Read();
			Insert(root,x);
			N++;
		}
		else
		{
			if(N%2) printf("%d\n",KTH((N+1)/2));
			else printf("%d\n",min(KTH(N/2),KTH(N/2+1)));
		}
	}
	return 0;
}
