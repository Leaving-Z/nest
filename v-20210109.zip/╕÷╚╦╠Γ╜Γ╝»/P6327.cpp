#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=200007;
struct Tree{
	double sums,sumc;
}TREE[maxn<<2];
long long tag[maxn<<2];
int A[maxn];
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define sums(i) TREE[i].sums
#define sumc(i) TREE[i].sumc
void Build(int L,int R,int i)
{
	if(L==R)
	{
		sums(i)=sin(A[L]);
		sumc(i)=cos(A[L]);
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	sums(i)=sums(Ls)+sums(Rs);
	sumc(i)=sumc(Ls)+sumc(Rs);
	return ;
}
inline void add(int i,long long k)
{
	double s=sin(k),c=cos(k),ts=sums(i),tc=sumc(i);
	tag[i]+=k;
	sums(i)=ts*c+tc*s;
	sumc(i)=tc*c-ts*s;
	return ;
}
inline void pushdown(int i)
{
	if(!tag[i]) return ;
	add(Ls,tag[i]);
	add(Rs,tag[i]);
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,long long k,int i)
{
	if(l<=L&&R<=r)
	{
		add(i,k);
		return ;
	}
	pushdown(i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	sums(i)=sums(Ls)+sums(Rs);
	sumc(i)=sumc(Ls)+sumc(Rs);
	return ;
}
double Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return sums(i);
	pushdown(i);
	double re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		A[i]=R();
	Build(1,N,1);
	M=R();
	int op,x,y,z;
	for(register int i=1;i<=M;i++)
	{
		op=R();
		if(op==1)
		{
			x=R();y=R();z=R();
			Update(1,N,x,y,(long long)z,1); 
		}
		else
		{
			x=R();y=R();
			printf("%.1f\n",Query(1,N,x,y,1));
		}
	}
	return 0;
}
