#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
const int maxn=100007;
const int maxm=200007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,Q;
int dep[maxn];
const int lim=100000;
int t[maxn<<2];
struct node{
    int val;
    int id,anc;
}qu[maxn];
vector <node> q[maxn];
int cnt;
bool vis[maxn];
void pre(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        dep[v]=dep[u]+1;
        pre(v,u);
    }
    return ;
}
void findq(int u,int fa,int an)
{
    int v;
    for(int i=0;i<(int)q[u].size();i++)
        qu[++cnt]=q[u][i],qu[cnt].val+=lim-dep[u],qu[cnt].anc=an;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        findq(v,u,an);
    }
    return ;
}
void dfs(int u,int fa)
{
    t[dep[u]+lim]++;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        dfs(v,u);
    }
    return ;
}
int root,sz[maxn],maxsz[maxn];
void findrt(int u,int fa,int totsz)
{
    int v;
    sz[u]=1;
    maxsz[u]=0;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        findrt(v,u,totsz);
        sz[u]+=sz[v];
        maxsz[u]=max(maxsz[u],sz[v]);
    }
    maxsz[u]=max(maxsz[u],totsz-sz[u]);
    if(!root||maxsz[u]<maxsz[root]) root=u;
    return ;
}
int tmp[maxn];
int ans[maxn];
bool bk[maxn<<2];
int d[maxn<<2];
void dec(int u,int fa)
{
    int v;
    if(bk[dep[u]+lim]) d[dep[u]+lim]++;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        dec(v,u);
    }
    return ;
}
void calc(int u)
{
    cnt=0;
    dep[u]=0;
    
    for(int i=0;i<(int)q[u].size();i++)
        qu[++cnt]=q[u][i],qu[cnt].val+=lim,qu[cnt].anc=u;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(vis[v]) continue;
        dep[v]=1;
        pre(v,u);
        findq(v,u,v);
    }
    for(int i=1;i<=cnt;i++)
        tmp[i]=t[qu[i].val];
    t[lim]++;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(vis[v]) continue;
        dfs(v,u);
    }
    for(int i=1;i<=cnt;i++)
        ans[qu[i].id]+=t[qu[i].val]-tmp[i];
    int p=0,st=0;
    for(int i=1;i<=cnt;i++)
    {
        if(qu[i].anc==u) continue;
        p=qu[i].anc;st=i;
        while(i<=cnt&&qu[i].anc==p)
        {
            bk[qu[i].val]=true;
            ++i;
        }
        dec(p,u);
        for(int k=st;k<i;k++)
            ans[qu[k].id]-=d[qu[k].val];
        for(int k=st;k<i;k++)
            bk[qu[k].val]=0,d[qu[k].val]=0;
        if(i>cnt) break;
        else --i;
    }
    return ;
}
void solve(int u)
{
    int v;
    vis[u]=true;
    calc(u);
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(vis[v]) continue;
        root=0;
        findrt(v,u,sz[u]);
        solve(root);
    }
    return ;
}
int T;
void reset()
{
    memset(first,0,sizeof(first));
    ES=0;
    for(int i=1;i<=N;i++)
        q[i].clear();
    memset(ans,0,sizeof(ans));
    memset(vis,0,sizeof(vis));
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d",&N,&Q);
        reset();
        int u,v;
        for(int i=1;i<N;i++)
        {
            scanf("%d%d",&u,&v);
            addE(u,v);addE(v,u);
        }
        node t;
        for(int i=1;i<=Q;i++)
        {
            t.id=i;
            scanf("%d%d",&u,&t.val);
            q[u].push_back(t);
        }
        root=0;
        findrt(1,0,N);
        solve(root);
        for(int i=1;i<=Q;i++)
            printf("%d\n",ans[i]);
    }
    return 0;
}