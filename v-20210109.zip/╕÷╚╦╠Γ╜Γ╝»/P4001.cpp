#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=1000007;
const int maxm=12000007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,cf);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int cnt[maxn],cur[maxn];
int N,M,S,T;
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&!cnt[v])
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int v,d,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min(cf(i),f));
			if(d>0)
			{
				cf(i)-=d;cf(i^1)+=d;
				sum+=d;f-=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
inline int num(int i,int j)
{
	return (i-1)*M+j;
}
int main()
{
	N=R();M=R();S=1;T=N*M;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<M;j++)
			add(num(i,j),num(i,j+1),R());
	for(register int i=1;i<N;i++)
		for(register int j=1;j<=M;j++)
			add(num(i,j),num(i+1,j),R());
	for(register int i=1;i<N;i++)
		for(register int j=1;j<M;j++)
			add(num(i,j),num(i+1,j+1),R());
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;	
}
