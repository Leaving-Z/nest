#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=300007;
const int maxm=600007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,s;
int dis[maxn],pre[maxn];
bool acc[maxm];
void dfs1(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa) continue;
		dis[v]=dis[u]+e[i].w;
		pre[v]=i^1;
		dfs1(v,u);
	}
	return ;
}
int W[maxn],A[maxn],B[maxn],cnt;
void dfs2(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||acc[i]) continue;
		dfs2(v,u);
		W[u]=max(W[u],W[v]+e[i].w);
	}
	return ;
}
int q[maxn],head=1,tail;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();s=R();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
		addE(v,u,w);
	}
	dfs1(1,0);
	int lt,rt,maxx=-1;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],lt=i;
	dis[lt]=0;
	dfs1(lt,0);
	maxx=-1;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],rt=i;
	while(lt!=rt)
	{
		acc[pre[rt]]=acc[pre[rt]^1]=true;
		A[++cnt]=dis[rt];
		dfs2(rt,0);
		B[cnt]=W[rt];
		rt=e[pre[rt]].v;
	}
	int re=0x7f7f7f7f;
	int l=1;
	for(int i=1;i<=N;i++)
	{
		while(head<=tail&&B[i]>=B[q[tail]]) --tail;
		q[++tail]=i;
		while(A[l]-A[i]>s) l++;
		while(head<=tail&&q[head]<l) ++head;
		re=min(re,max(maxx-A[l],max(A[i],B[q[head]])));
	}
	printf("%d",re);
	return 0;
}
