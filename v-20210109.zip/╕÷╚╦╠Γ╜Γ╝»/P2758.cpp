#include<cstdio>
#include<cstring>
int F[2007][2007];
int len1,len2;
char A[2007],B[2007];
inline int min_(const int &x,const int &y) {return x<y?x:y;}
int main()
{
	scanf("%s",A+1);
	scanf("%s",B+1);
	len1=strlen(A+1);
	len2=strlen(B+1);
	for(register int i=1;i<=len1;i++)
		F[i][0]=i;
	for(register int j=1;j<=len2;j++)
		F[0][j]=j;
	for(register int i=1;i<=len1;i++)
		for(register int j=1;j<=len2;j++)
		if(A[i]==B[j]) F[i][j]=F[i-1][j-1];
		else F[i][j]=min_(F[i-1][j-1],min_(F[i-1][j],F[i][j-1]))+1;
	printf("%d",F[len1][len2]);
	return 0;
 } 
