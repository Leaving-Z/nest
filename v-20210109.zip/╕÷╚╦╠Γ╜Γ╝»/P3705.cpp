#include<cstdio>
#include<queue>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=207;
const int maxm=60007;
const double eps=1e-8;
struct E{
    int u,v,cf;
    double w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
int CF[maxm];
inline void addE(int u,int v,int cf,int w)
{
    e[++ES]=(E){u,v,cf,1.0*w};
    CF[ES]=cf;
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int cf,int w)
{
    addE(u,v,cf,w);
    addE(v,u,0,-w);
    return ;
}
int N,S,T;
int A[maxn][maxn],B[maxn][maxn];
void rebuild(double L)
{
    double w;
    for(int i=2;i<=ES;i++)
    {
        cf(i)=CF[i];
        if(e[i].u<=N&&e[i].v<=2*N)
        {
            w=A[e[i].u][e[i].v-N]-L*B[e[i].u][e[i].v-N];
            e[i].w=-w;
            e[i^1].w=w;
        }
    }
    return ;
}
double dis[maxn];
int pre[maxn][2],f[maxn];
bool book[maxn];
queue <int> q;
bool SPFA()
{
    q.push(S);
    for(int i=1;i<=T;i++)
        dis[i]=1e18;
    dis[S]=0;
    f[S]=0x7f7f7f7f;
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&dis[u]+e[i].w<dis[v])
            {
                dis[v]=dis[u]+e[i].w;
                f[v]=min(f[u],cf(i));
                pre[v][0]=u;
                pre[v][1]=i;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return dis[T]<1e17;
}
void update()
{
    int u=T;
    while(u!=S)
    {
        cf(pre[u][1])-=f[T];
        cf(pre[u][1]^1)+=f[T];
        u=pre[u][0];
    }
    return ;
}
bool check(double L)
{
    rebuild(L);
    double res=0;
    while(SPFA())
    {
        res+=dis[T]*f[T];
        update();
    }
    res=-res;
    return res>=0;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            scanf("%d",&A[i][j]);
    S=2*N+1;
    T=S+1;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            scanf("%d",&B[i][j]);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            add(i,j+N,1,0);
    for(int i=1;i<=N;i++)
        add(S,i,1,0),add(i+N,T,1,0);
    double L=0,R=1e8,mid,ans;
    while(R-L>eps)
    {
        mid=(L+R)/2;
        if(check(mid)) ans=mid,L=mid;
        else R=mid;
    }
    printf("%.6f",ans);
    return 0;
}