#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=500007;
int root[maxn],cnt;
struct seg_tree{
    int ls,rs,val;
}TREE[maxn*40];
#define Ls(i) TREE[i].ls
#define Rs(i) TREE[i].rs
#define mid (L+R>>1)
#define v(i) TREE[i].val
inline int cp(int i)
{
    TREE[++cnt]=TREE[i];
    return cnt;
}
int Update(int L,int R,int x,int i)
{
    i=cp(i);
    if(L==R)
    {
        v(i)++;return i;
    }
    if(x<=mid) Ls(i)=Update(L,mid,x,Ls(i));
    else Rs(i)=Update(mid+1,R,x,Rs(i));
    v(i)=v(Ls(i))+v(Rs(i));
    return i;
}
int Query(int L,int R,int k,int i1,int i2)
{
    if(L==R) return L;
    if(v(Ls(i2))-v(Ls(i1))>=k) return Query(L,mid,k,Ls(i1),Ls(i2));
    else if(v(Rs(i2))-v(Rs(i1))>=k) return Query(mid+1,R,k,Rs(i1),Rs(i2));
    else return 0;
}
int N,M;
int A[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    for(register int i=1;i<=N;i++)
        A[i]=R();
    for(register int i=1;i<=N;i++)
        root[i]=Update(0,N,A[i],root[i-1]);
    int l,r,len;
    while(M--)
    {
        l=R();r=R();
        len=r-l+1;
        printf("%d\n",Query(0,N,len/2+1,root[l-1],root[r]));
    }
    return 0;
}