#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxn=100007;
const int mod=1e9+9;
int N;
LL C[maxn];
LL sum[maxn],id[maxn],d[maxn];
void update(int x,LL k)
{
	while(x<=N+2) C[x]=(C[x]+k)%mod,x+=x&(-x);
	return ;
}
LL query(int x)
{
	LL re=0;
	while(x) re=(re+C[x])%mod,x-=x&(-x);
	return re;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%lld",&sum[i]),sum[i]+=sum[i-1],d[i]=sum[i];
	sort(d+1,d+2+N);
	int tot=unique(d+1,d+2+N)-d-1;
	for(int i=0;i<=N;i++)
		id[i]=lower_bound(d+1,d+1+tot,sum[i])-d;
	update(id[0],1ll);
	LL res=0;
	for(int i=1;i<=N;i++)
	{
		res=query(id[i]);
		update(id[i],res);
	}
	printf("%lld",res);
	return 0;
}
