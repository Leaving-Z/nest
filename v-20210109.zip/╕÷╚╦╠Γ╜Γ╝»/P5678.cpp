#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=101;
typedef long long LL;
const LL lim=9223372036854775807ll;
struct Matrix{
    LL m[maxn][maxn];
}b,t,s;
LL f[maxn];
int N,K;
Matrix operator * (const Matrix &x,const Matrix &y)
{
    memset(t.m,0,sizeof(t.m));
    for(int k=1;k<=K;k++)
        for(int i=1;i<=K;i++)
            for(int j=1;j<=K;j++)
                t.m[i][j]|=(x.m[i][k]&y.m[k][j]);
    return t;
}
Matrix power(int k)
{
    for(int i=1;i<=K;i++)
        s.m[i][i]=lim;
    while(k)
    {
        if(k&1) s=s*b;
        b=b*b;
        k>>=1;
    }
    return s;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&K);
    for(int i=1;i<=K;i++)
        scanf("%lld",&f[i]);
    for(int i=1;i<=K;i++)
        scanf("%lld",&b.m[i][K]);
    for(int i=1;i<K;i++)
        b.m[i+1][i]=lim;
    if(N<K) printf("%lld",f[N+1]);
    else
    {
        b=power(N-K+1);
        LL ans=0;
        for(int i=1;i<=K;i++)
            ans|=f[i]&b.m[i][K];
        printf("%lld",ans);
    }
    return 0;
}