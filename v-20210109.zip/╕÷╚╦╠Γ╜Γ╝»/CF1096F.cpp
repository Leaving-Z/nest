#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxn=200007;
const int mod=998244353;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) (s*=b)%=mod;
        (b*=b)%=mod;
        k>>=1;
    }
    return s;
}
LL fact[maxn];
int N;
int A[maxn];
int sum[maxn],sum0[maxn];
int C[maxn];
void update(int x)
{
    while(x<=N) C[x]++,x+=x&(-x);
    return ;
}
int query(int x)
{
    int re=0;
    while(x) re+=C[x],x&=(x-1);
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        if(A[i]==-1) A[i]=0;
        sum0[i]+=sum0[i-1]+(A[i]==0);
        if(A[i]>N) {printf("0");return 0;}
        sum[A[i]]++;
    }
    for(int i=2;i<=N;i++)
        sum[i]+=sum[i-1];
    fact[0]=1;
    for(int i=1;i<=N;i++)
        fact[i]=fact[i-1]*i%mod;
    LL x,y;
    LL ans=0;
    if(sum[0])
    for(int i=1;i<=N;i++)
    {
        if(A[i]==0) continue;
        x=A[i]-sum[A[i]];
        y=sum0[N]-sum0[i];
        (ans+=x*y%mod*fact[sum[0]-1]%mod)%=mod;
        x=(N-A[i])-(sum[N]-sum[A[i]]);
        y=sum0[i];
        (ans+=x*y%mod*fact[sum[0]-1]%mod)%=mod;
    }
    x=1ll*sum[0]*(sum[0]-1)/2%mod;
    if(sum[0]>1) y=fact[sum[0]-2];
    else y=0;
    (ans+=y*x%mod*x%mod)%=mod;
    y=0;
    for(int i=1;i<=N;i++)
    {
        if(A[i]==0) continue;
        x=query(N)-query(A[i]);
        (y+=x)%=mod;
        update(A[i]);
    }
    if(sum[0]>0) x=fact[sum[0]];
    else x=1;
    (ans+=y*x%mod)%=mod;
    (ans*=fast_pow(fact[sum[0]],mod-2))%=mod;
    printf("%lld",ans);
    return 0;
}