#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=50007;
typedef long long LL;
int N,D;
LL A[maxn];
int bel[maxn],ans_bel[maxn];
bool check(LL p)
{
	LL hp=0,cnt=1;
	memset(bel,0,sizeof(bel));
	for(int i=1;i<=D;i++)
	{
		hp/=2;
		while(cnt<=N&&hp<p) bel[cnt]=i,hp+=A[cnt++];
		if(hp<p) return false;
	}
	return true;
}
#define mid (L+R>>1)
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout);
	#endif
	scanf("%d%d",&N,&D);
	LL L=1,R=0;
	for(int i=1;i<=N;i++)
		scanf("%lld",&A[i]),R+=A[i];
	LL ans=0;
	while(L<=R)
	{
		if(check(mid)) ans=mid,memcpy(ans_bel,bel,sizeof(bel)),L=mid+1;
		else R=mid-1;
	}
	printf("%lld",ans);
	for(int i=1;i<=N;i++)
		printf("\n%d",ans_bel[i]?ans_bel[i]:D);
	return 0;
}
