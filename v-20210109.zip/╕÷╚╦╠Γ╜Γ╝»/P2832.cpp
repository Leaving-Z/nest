#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=10007;
const int maxm=200007;
int N,M;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int dis[maxn][2];
bool book[maxn];
int pre[maxn];
void SPFA()
{
    memset(dis,0x3f,sizeof(dis));
    q.push(N);book[N]=true;
    dis[N][0]=dis[N][1]=0;
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(dis[u][0]+e[i].w+dis[u][1]<dis[v][0])
            {
                dis[v][0]=dis[u][0]+e[i].w+dis[u][1];
                dis[v][1]=dis[u][1]+1;
                pre[v]=u;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
            else if(dis[u][0]+e[i].w+dis[u][1]==dis[v][0]&&dis[u][1]+1<dis[v][1])
            {
                dis[v][1]=dis[u][1]+1;
                pre[v]=u;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,w;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        addE(v,u,w);
    }
    SPFA();
    printf("%d\n",dis[1][0]);
    u=1;
    while(pre[u]) printf("%d ",u),u=pre[u];
    printf("%d",N);
    return 0;
}