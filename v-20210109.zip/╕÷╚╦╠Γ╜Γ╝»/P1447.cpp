#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int lim=100000;
bool book[maxn];
int mu[maxn],prime[maxn],cnt;
void pre()
{
    mu[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) {prime[++cnt]=i;mu[i]=-1;}
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else break;
        }
    }
    for(int i=1;i<=lim;i++)
        mu[i]+=mu[i-1];
    return ;
}
long long calc(int n,int m)
{
    int L=1,R;
    long long res=0;
    if(n>m) swap(n,m);
    while(L<=n)
    {
        R=min(n/(n/L),m/(m/L));
        res+=1ll*(mu[R]-mu[L-1])*(n/L)*(m/L);
        L=R+1;
    }
    return res;
}
int N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int L=1,R;
    pre();
    if(N>M) swap(N,M);
    long long ans=0;
    while(L<=N)
    {
        R=min(N/(N/L),M/(M/L));
        ans+=(L+R)*(R-L+1ll)/2*calc(N/L,M/L);
        L=R+1;
    }
    printf("%lld",ans*2-1ll*N*M);
    return 0;
}