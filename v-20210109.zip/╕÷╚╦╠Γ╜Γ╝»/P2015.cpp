#include<cstdio>
#include<algorithm>
using namespace std;
struct E{
	int u,v,w;
}e[207];
int first[107],nt[207],ES;
void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u,w};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
int DP[107][107];
int sz[107],fa[107];
int N,Q;
void dfs(int u)
{
	int v;
	sz[u]=1;
	int LE,RE;
	bool flag=true; 
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		if(flag) LE=i;
		else RE=i;
		flag=false;
		fa[v]=u;
		dfs(v);
		sz[u]+=sz[v];
	}
	if(flag) return ;
	int lt=min(Q,sz[u]);
	int t1,t2,t,tk;
	for(int i=1;i<=lt;i++)
	{
		t1=e[LE].w+DP[e[LE].v][i-1];
		t2=e[RE].w+DP[e[RE].v][i-1];
		DP[u][i]=max(t1,t2);
		for(int j=1;j<i;j++)
		{
			t=e[LE].w+DP[e[LE].v][j-1]+e[RE].w+DP[e[RE].v][i-j-1];
			DP[u][i]=max(DP[u][i],t);
		}
	}
	return ;
}
int main()
{
	scanf("%d%d",&N,&Q);
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		addE(u,v,w);
	}
	dfs(1);
	printf("%d",DP[1][Q]);
	return 0;
} 
