#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int maxb=57;
const LL tjq=2008;
LL d[maxb],ans;
void insert(LL x)
{
	for(int i=50;i>=0;i--)
	{
		if(x&(1ll<<i))
		{
			if(d[i]) x^=d[i];
			else
			{
				++ans;
				d[i]=x;
				return ;
			}
		}
	}
	return ;
}
int N,M;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&M);
	LL tmp;
	char s[57];
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s+1);tmp=0;
		for(int j=1;j<=N;j++)
			if(s[j]=='O') tmp|=(1ll<<j-1);
		insert(tmp);
	}
	printf("%lld",(1ll<<ans)%tjq);
	return 0;
}
