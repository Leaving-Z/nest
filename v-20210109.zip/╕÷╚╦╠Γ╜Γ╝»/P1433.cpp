#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
typedef long double db;
const int maxn=(1<<17)+7;
db F[maxn][17];
db m[17][17];
int N,all;
db x[17],y[17];
inline db getd(int A,int B)
{
	return sqrt((x[A]-x[B])*(x[A]-x[B])+(y[A]-y[B])*(y[A]-y[B]));
} 
int main()
{
	scanf("%d",&N);all=1<<N;
	for(register int i=1;i<all;i++)
		for(register int j=1;j<=N;j++)
			F[i][j]=2000000000;
	for(register int i=1;i<=N;i++)
		scanf("%Lf%Lf",&x[i],&y[i]);
	for(register int i=1;i<=N;i++)
	{
		for(register int j=1;j<=N;j++)
		if(i==j) continue;
		else m[i][j]=m[j][i]=getd(i,j);
		F[1<<i-1][i]=getd(0,i);
	}
	for(register int i=0;i<all;i++)
	{
		for(register int j=1;j<=N;j++)
		{
			if(!(i&(1<<j-1))) continue;
			for(register int k=1;k<=N;k++)
			if(i&(1<<k-1)) continue;
			else F[i|(1<<k-1)][k]=min(F[i|(1<<k-1)][k],F[i][j]+m[j][k]);
		}
	}
	db ans=2000000000;
	for(int i=1;i<=N;i++)
		ans=min(ans,F[all-1][i]);
	printf("%.2Lf",ans);
	return 0;
}
