#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=207;
const int maxm=21007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
int cf1[maxm],w1[maxm];
#define cf(i) cf1[i]
inline void addE(int u,int v,int cf,int w)
{
	e[++ES]=(E){u,v,w};
	w1[ES]=cf(ES)=cf;
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf,int w)
{
	addE(u,v,cf,w);addE(v,u,0,-w);
	return ;
}
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int N,S,T;
int pre[maxn][2],f[maxn],dis[maxn];
bool book[maxn];
inline bool SPFA(int s)
{
	if(s<0) memset(dis,~0x3f,sizeof(dis));
	else memset(dis,0x3f,sizeof(dis));
	memset(f,0x7f,sizeof(f));
	dis[S]=0;book[S]=true;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&(dis[u]+e[i].w-dis[v])*s<0)
			{
				dis[v]=dis[u]+e[i].w;
				pre[v][0]=u;pre[v][1]=i;
				f[v]=min(cf(i),f[u]);
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=dis[T+1];
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int main()
{
	N=R();T=N<<1|1;
	for(register int i=1;i<=N;i++)
	{
		add(S,i,1,0);
		for(register int j=1;j<=N;j++)
			add(i,N+j,1,R());
		add(N+i,T,1,0);
	}
	int ans1=0,ans2=0;
	while(SPFA(1))
	{
		ans1+=f[T]*dis[T];
		Update();
	}
	memcpy(cf1,w1,sizeof(cf1));
	while(SPFA(-1))
	{
		ans2+=f[T]*dis[T];
		Update();
	}
	printf("%d\n%d",ans1,ans2);
	return 0;
}
