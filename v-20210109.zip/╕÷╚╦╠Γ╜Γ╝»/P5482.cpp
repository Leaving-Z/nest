#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<cmath>
#include<ctime>
using namespace std;
const int maxn=100007;
struct node{
    int ls,rs,p,sz,c,v;
};
int N;
struct Treap{
    node T[maxn];
    int root,all;
    #define ls(i) T[i].ls
    #define rs(i) T[i].rs
    #define v(i) T[i].v
    #define sz(i) T[i].sz
    #define c(i) T[i].c
    #define p(i) T[i].p
    void zig(int &x)
    {
        int y=ls(x);
        ls(x)=rs(y);
        rs(y)=x;
        sz(y)=sz(x);
        sz(x)=sz(ls(x))+sz(rs(x))+c(x);
        x=y;
        return ;
    }
    void zag(int &x)
    {
        int y=rs(x);
        rs(x)=ls(y);
        ls(y)=x;
        sz(y)=sz(x);
        sz(x)=sz(ls(x))+sz(rs(x))+c(x);
        x=y;
        return ;
    }
    void insert(int &i,int val)
    {
        if(!i)
        {
            i=++all;
            ls(i)=rs(i)=0;
            sz(i)=c(i)=1;
            p(i)=rand();
            v(i)=val;
            return ;
        }
        ++sz(i);
        if(val==v(i)) ++c(i);
        else if(val<v(i))
        {
            insert(ls(i),val);
            if(p(ls(i))>p(i)) zig(i);
        }
        else
        {
            insert(rs(i),val);
            if(p(rs(i))>p(i)) zag(i);
        }
        return ;
    }
    void Del(int &i,int val)
    {
        if(val==v(i))
        {
            if(c(i)>1) --c(i),--sz(i);
            else if(!ls(i)||!rs(i)) i=ls(i)+rs(i);
            else if(p(ls(i))>p(rs(i))) zig(i),Del(i,val);
            else zag(i),Del(i,val);
            return ;
        }
        --sz(i);
        if(val<v(i)) Del(ls(i),val);
        else Del(rs(i),val);
        return ;
    }
    int rk(int x)
    {
        int u=root,re=0;
        while(u)
        {
            if(v(u)==x) return re+sz(ls(u))+c(u);
            if(x<v(u)) u=ls(u);
            else re+=sz(ls(u))+c(u),u=rs(u);
        }
        return re;
    }
}n,p;
int mk[maxn],book[maxn];
bool bk[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("P5482_1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    srand(time(NULL));
    scanf("%d",&N);
    int cnt=0;
    char qwq[7];
    int a,b,c,tmp=0,v;
    for(int i=1;i<=N;i++)
    {
        //printf("# %d\n",i);
        scanf("%s",qwq);
        if(qwq[0]=='A')
        {
            ++cnt;
            scanf("%d%d%d",&a,&b,&c);
            if(a==0)
            {
                book[cnt]=(b>c);
                tmp+=book[cnt];
            }
            else if(a>0)
            {
                //v=(c-b)/a+1;
                v=floor((1.0*(c-b))/a)+1;
                mk[cnt]=1;
                book[cnt]=v;
                p.insert(p.root,v);
            }
            else
            {
                //v=(c-b)/a;if((c-b)%a==0) v--;
                v=ceil((1.0*(c-b))/a)-1;
                mk[cnt]=-1;
                book[cnt]=v;
                n.insert(n.root,v);
            }
        }
        else if(qwq[0]=='D')
        {
            scanf("%d",&a);
            if(bk[a]) continue;
            bk[a]=true;
            if(mk[a]==0) tmp-=book[a];
            else if(mk[a]==1) p.Del(p.root,book[a]);
            else n.Del(n.root,book[a]);
        }
        else
        {
            scanf("%d",&a);
            c=p.rk(a);
            c+=n.T[n.root].sz-n.rk(a-1);
            c+=tmp;
            printf("%d\n",c);
        }
    }
    return 0;
}