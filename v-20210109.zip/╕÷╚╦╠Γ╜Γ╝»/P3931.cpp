#include<bits/stdc++.h>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=400007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,S,T;
inline void dfs(int u,int fa)
{
	int v;
	bool f=true;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			cf(i^1)=0;
			f=false;
			dfs(v,u);
		}
	}
	if(f) addE(u,T,inf),addE(T,u,0);
	return ;
}
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&!cnt[v])
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y)
{
	return x<y?x:y;
}
inline int DFS(int u,int f)
{
	if(u==T) return f;
	int v,d,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i))
		{
			d=DFS(v,min_(f,cf(i)));
			if(d>0)
			{
				cf(i)-=d;
				cf(i^1)+=d;
				sum+=d;
				f-=d;
				if(f<=d) return sum;
			}
		}
	}
	return sum;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();S=R();
	int u,v,cf;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();cf=R();
		addE(u,v,cf);addE(v,u,cf);
	}
	dfs(S,0);
	long long ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=DFS(S,inf);
	}
	printf("%lld",ans);
	return 0;
}
