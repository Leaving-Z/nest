#include<cstdio>
#include<algorithm>
#include<stack>
using namespace std;
inline int R()
{
	int f=1,re=0;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int st[107],top;
struct E{
	int u,v;
}e[10007];
int ES;
int first[107],nt[10007];
int N;
int dfn[107],low[107],S[107];
int C,T;
int in[107],out[107];
bool inst[107];
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(inst[v])
		low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		C++;
		int p;
		while(st[top]!=u)
		{
			p=st[top--];
			inst[p]=false;
			S[p]=C;
		}
		top--;
		inst[u]=false;
		S[u]=C;
	}
	return ;
}
int main()
{
	N=R();
	int x;
	for(int i=1;i<=N;i++)
	{
		while(1)
		{
			x=R();
			if(x==0) break;
			e[++ES]=(E){i,x};
			nt[ES]=first[i];
			first[i]=ES;
		}
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	for(int i=1;i<=ES;i++)
	{
		if(S[e[i].u]!=S[e[i].v])
		{
			in[S[e[i].v]]++;
			out[S[e[i].u]]++;
		}
	}
	int ind=0,outd=0;
	for(int i=1;i<=C;i++)
	{
		if(in[i]==0) ind++;
		if(out[i]==0) outd++;
	}
	int ans;
	if(C==1)
	ans=0;
	else
	ans=max(ind,outd);
	printf("%d\n%d",ind,ans);
	return 0;	
}
