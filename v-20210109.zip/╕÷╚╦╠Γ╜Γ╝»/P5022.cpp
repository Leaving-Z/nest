#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
const int maxn=5007;
int N,M;
vector <int> m[maxn];
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int tmp[maxn],cnt;
int ans[maxn];
bool vis[maxn],use[maxn][maxn];
int forbidx,forbidy;
inline void dfs(int u)
{
	if(vis[u]) return ;
	vis[u]=true;tmp[++cnt]=u;
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(u==forbidx&&v==forbidy||v==forbidx&&u==forbidy) continue;
		dfs(v);
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		m[u].push_back(v);
		m[v].push_back(u);
	}
	for(register int i=1;i<=N;i++)
		sort(m[i].begin(),m[i].end());
	for(register int i=1;i<=N;i++)
		for(register int j=m[i].size()-1;j>=0;j--)
			addE(i,m[i][j]);
	if(M==N-1)
	{
		dfs(1);
		for(register int i=1;i<=N;i++)
			printf("%d ",tmp[i]);
	}
	else
	{
		for(register int i=1;i<=ES;i++)
		{
			memset(vis,0,sizeof(vis));cnt=0;
			forbidx=e[i].u;forbidy=e[i].v;
			if(use[forbidx][forbidy]) continue;
			use[forbidx][forbidy]=use[forbidy][forbidx]=true;
			dfs(1);
			if(cnt<N) continue;
			if(ans[1]==0) memcpy(ans,tmp,sizeof(ans));
			else
			{
				bool f=true;
				for(register int j=1;j<=cnt;j++)
				if(tmp[j]>ans[j]) {f=false;break;}
				else if(tmp[j]<ans[j]) break;
				if(f) memcpy(ans,tmp,sizeof(ans));
			}
		}
		for(register int i=1;i<=N;i++)
			printf("%d ",ans[i]);
	}
	return 0;
}
