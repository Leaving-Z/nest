#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=200007;
const int maxm=400007;
typedef long long LL;
int N;
struct E{
	int u,v;
	LL w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
bool acc[maxm];
int S[maxn];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int pre[maxn];
void dfs1(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||acc[i]) continue;
		pre[v]=i^1;
		dfs1(v,u);
	}
	return ;
}
LL maxE[maxn][2],D;
void dfs2(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||acc[i]) continue;
		dfs2(v,u);
		if(maxE[v][0]+e[i].w>maxE[u][0])
		{
			maxE[u][1]=maxE[u][0];
			maxE[u][0]=maxE[v][0]+e[i].w;
		}
		else if(maxE[v][0]+e[i].w>maxE[u][1])
			maxE[u][1]=maxE[v][0]+e[i].w;
	}
	D=max(D,maxE[u][0]+maxE[u][1]);
	return ;
}
LL B[maxm],C[maxm],w[maxn];
int vis[maxn],tot,len;
void dfs3(int u,int fa)
{
	if(!vis[u]) len++;
	vis[u]++;
	C[tot]=w[u];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		if(acc[i])
		{
			v=e[i].v;
			if(i==fa||vis[v]>1) continue;
			B[tot+1]=B[tot]+e[i].w;
			tot++;
			dfs3(v,i^1);
		}
	}
	return ;
}
int lt,rt;
struct node{
	int num;
	LL val;
};
bool operator < (const node &x,const node &y)
{
	return x.val<y.val;
}
priority_queue <node> q1,q2;
node getval(int i,int ty)
{
	if(ty)
	{
		while(q2.top().num<i&&q2.size()>1) q2.pop();
		return q2.top();
	}
	else
	{
		while(q1.top().num<i&&q1.size()>1) q1.pop();
		return q1.top();
	}
}
LL work()
{
	dfs1(lt,0);
	LL re=0;
	while(rt)
	{
		acc[pre[rt]]=acc[pre[rt]^1]=true;
		dfs2(rt,0);
		re=max(re,D);
		w[rt]=maxE[rt][0];
		rt=e[pre[rt]].v;
	}
	tot=1;
	dfs3(lt,0);
	node t1,t2,tmp1,tmp2;
	for(int i=1;i<=len;i++)
	{
		t1.num=i;t1.val=C[i]-B[i];
		q1.push(t1);
		t1.val=C[i]+B[i];
		q2.push(t1);
	}
	LL t=1e18;
	for(int i=len+1;i<=tot;i++)
	{
		t1=getval(i-len,0);t2=getval(i-len,1);
		if(t1.num==t2.num)
		{
			q1.pop();q2.pop();
			tmp1=getval(i-len,0);tmp2=getval(i-len,1);
			t=min(t,max(t1.val+tmp2.val,t2.val+tmp1.val));
			q1.push(t1);q2.push(t2);
		}
		else t=min(t,t1.val+t2.val);
		t1.num=i;t1.val=C[i]-B[i];
		q1.push(t1);
		t1.val=C[i]+B[i];
		q2.push(t1);
	}
	return max(t,re);
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		S[i]=i;
	int u,v,f1,f2;LL w;
	for(int i=1;i<=N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
		addE(v,u,w);
		f1=f(u);f2=f(v);
		if(f1==f2) acc[ES]=acc[ES^1]=true,lt=u,rt=v;
		else S[f1]=f2;
	}
	printf("%lld",work());
	return 0;
}
