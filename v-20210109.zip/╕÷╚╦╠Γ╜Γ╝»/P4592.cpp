#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const int maxb=31;
const int maxm=200007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int sz[maxn],fa[maxn],son[maxn],dep[maxn],W[maxn];
int N,Q;
void dfs1(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		fa[v]=u;
		dep[v]=dep[u]+1;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[son[u]]<sz[v]) son[u]=v;
	}
	return ;
}
int top[maxn],id[maxn],ix,anti[maxn];
int trie[maxn*40][2],all,root[maxn],book[maxn*40];
void insert(int a,int b,int val,int cnt)
{
	if(cnt<0) return ;
	int t;
	if(val&(1<<cnt)) t=1;
	else t=0;
	trie[a][t^1]=trie[b][t^1];
	trie[a][t]=++all;
	book[all]=book[trie[b][t]]+1;
	insert(trie[a][t],trie[b][t],val,cnt-1);
	return ;
}
void dfs2(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs2(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return ;
}
int query(int a,int b,int val,int cnt)
{
	if(cnt<0) return 0;
	int t=0;
	if(val&(1<<cnt)) t=0;
	else t=1;
	if(book[trie[b][t]]-book[trie[a][t]]>0)
		return (1<<cnt)+query(trie[a][t],trie[b][t],val,cnt-1);
	else return query(trie[a][t^1],trie[b][t^1],val,cnt-1);
}
int query(int l,int r,int val)
{
	return query(root[l-1],root[r],val,30);
}
int query_path(int x,int y,int val)
{
	int re=0;
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		re=max(re,query(id[top[x]],id[x],val));
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	re=max(re,query(id[x],id[y],val));
	return re;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&Q);
	for(int i=1;i<=N;i++)
		scanf("%d",&W[i]);
	int u,v,w;
	for(int i=1;i<N;i++)
		scanf("%d%d",&u,&v),addE(u,v),addE(v,u);
	dfs1(1);dfs2(1,1);
	for(int i=1;i<=N;i++)
	{
		root[i]=++all;
		insert(root[i],root[i-1],W[anti[i]],30);
	}
	int op;
	while(Q--)
	{
		scanf("%d",&op);
		if(op==1)
		{
			scanf("%d%d",&u,&w);
			printf("%d\n",query(id[u],id[u]+sz[u]-1,w));
		}
		else
		{
			scanf("%d%d%d",&u,&v,&w);
			printf("%d\n",query_path(u,v,w));
		}
	}
	return 0;
}
