#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=107;
char m[107][107];
int N,M,T;
int Sx,Sy,Ex,Ey;
int nxt[4][2]=
{
	{1,0},
	{0,1},
	{-1,0},
	{0,-1}
};
int F[maxn][maxn][17];
inline int abs_(const int &x) {return x>=0?x:-x;}
inline int dfs(int x,int y,int step)
{
	if(step>T) return 0;
	if(F[x][y][step]!=-1) return F[x][y][step];
	if(x==Ex&&y==Ey&&step==T) return 1;
	if(abs_(x-Ex)+abs_(y-Ey)>T) return 0;
	int re=0;
	int nx,ny;
	for(int i=0;i<4;i++)
	{
		nx=x+nxt[i][0];
		ny=y+nxt[i][1];
		if(m[nx][ny]=='.') re+=dfs(nx,ny,step+1);
	}
	return F[x][y][step]=re;
}
int main()
{
	scanf("%d%d%d",&N,&M,&T);
	for(int i=1;i<=N;i++)
		scanf("%s",m[i]+1);
	scanf("%d%d%d%d",&Sx,&Sy,&Ex,&Ey);
	memset(F,-1,sizeof(F)); 
	printf("%d",dfs(Sx,Sy,0));
	return 0;
}
