#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const int maxm=300007;
#define getchar() (SS == TT && (TT = (SS = BB) + fread(BB,1,1 << 15,stdin),TT == SS) ? EOF : *SS++)
char BB[1<<15],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
typedef long long LL;
int N,M;
struct E{
    int u,v;
    LL w;
}e[maxm],ed[maxm];
bool operator < (const E &x,const E &y)
{
    return x.w<y.w;
}
int first[maxn],nt[maxm],ES,EdS;
inline void addE(int u,int v,LL w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
bool book[maxm];
int S[maxn];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
LL Kruskal()
{
    int cnt=1;LL re=0;
    int f1,f2;
    for(register int i=1;i<=EdS;i++)
    {
        f1=f(ed[i].u);f2=f(ed[i].v);
        if(f1!=f2)
        {
            book[i]=true;
            re+=ed[i].w;++cnt;
            S[f2]=f1;
            addE(ed[i].u,ed[i].v,ed[i].w);addE(ed[i].v,ed[i].u,ed[i].w);
            if(cnt==N) break;
        }
    }
    return re;
}
int sz[maxn],fa[maxn],depth[maxn],son[maxn];
int A[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        fa[v]=u;
        A[v]=e[i].w;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int top[maxn],id[maxn],anti[maxn],ix;
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;anti[ix]=u;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
struct seg_tree{
    int v1,v2;
}TREE[maxn<<2];
#define v1(i) TREE[i].v1
#define v2(i) TREE[i].v2
#define v(i) TREE[i]
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;t.v1=t.v2=-1;
    t.v1=max(x.v1,y.v1);
    if(x.v1>y.v1) t.v2=max(x.v2,y.v1);
    else if(x.v1<y.v1) t.v2=max(x.v1,y.v2);
    return t;
}
void Build(int L,int R,int i)
{
    if(L==R)
    {
        v1(i)=A[anti[L]];
        return ;
    }
    int mid=L+R>>1,Ls=i<<1,Rs=i<<1|1;
    Build(L,mid,Ls);
    Build(mid+1,R,Rs);
    v(i)=v(Ls)+v(Rs);
    return ;
}
seg_tree Query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return v(i);
    seg_tree t;t.v1=t.v2=-1;
    int mid=L+R>>1,Ls=i<<1,Rs=i<<1|1;
    if(l<=mid) t=t+Query(L,mid,l,r,Ls);
    if(r>mid) t=t+Query(mid+1,R,l,r,Rs);
    return t;
}
seg_tree Query_Path(int x,int y)
{
    seg_tree t;
    t.v1=t.v2=-1;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        t=t+Query(1,N,id[top[x]],id[x],1);
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    t=t+Query(1,N,id[x]+1,id[y],1);
    return t;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    int u,v;
    LL w;
    for(register int i=1;i<=M;i++)
    {
        u=R();v=R();w=R();
        if(u==v) continue;
        ed[++EdS]=(E){u,v,w};
    }
    sort(ed+1,ed+1+EdS);
    for(register int i=1;i<=N;i++)
        S[i]=i;
    LL ans1=Kruskal(),ans2=5e18;
    dfs1(1);dfs2(1,1);Build(1,N,1);
    register seg_tree t;
    for(register int i=1;i<=EdS;i++)
    {
        if(book[i]) continue;
        t=Query_Path(ed[i].u,ed[i].v);
        if(ed[i].w!=t.v1) ans2=min(ans2,ed[i].w-t.v1);
        else if(t.v2!=-1) ans2=min(ans2,ed[i].w-t.v2);
    }
    printf("%lld",ans1+ans2);
    return 0;
}