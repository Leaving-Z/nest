#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
#include<queue>
using namespace std;
const int maxn=307;
const int maxm=24007;
struct E{
    int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
int CF[maxm],in[maxn];
inline void addE(int u,int v,int cf)
{
    e[++ES]=(E){u,v,cf};
    CF[ES]=cf;
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int cf)
{
    addE(u,v,cf);
    addE(v,u,0);
    return ;
}
int N,M,S,T;
int dep[maxn];
queue <int> q;
int fa[maxn];
int f(int x) {return fa[x]==x?x:fa[x]=f(fa[x]);}
vector <int> m[maxn],ans[maxn];
bool BFS()
{
    memset(dep,0,sizeof(dep));
    dep[S]=1;
    q.push(S);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&!dep[v])
            {
                dep[v]=dep[u]+1;
                q.push(v);
            }
        }
    }
    return dep[T]!=0;
}
int cur[maxn];
int dfs(int u,int f)
{
    if(u==T) return f;
    int d,sum=0,v;
    for(int &i=cur[u];i;i=nt[i])
    {
        v=e[i].v;
        if(cf(i)>0&&dep[v]==dep[u]+1)
        {
            d=dfs(v,min(f,cf(i)));
            if(d>0)
            {
                sum+=d;
                f-=d;
                cf(i)-=d;
                cf(i^1)+=d;
                if(f<=0) return sum;
            }
        }
    }
    return sum;
}
int Dinic()
{
    int res=0;
    while(BFS())
    {
        memcpy(cur,first,sizeof(cur));
        res+=dfs(S,0x7f7f7f7f);
    }
    return res;
}
void topo()
{
    for(int i=1;i<=N;i++)
    if(!in[i]) q.push(i),ans[fa[i]].push_back(i);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=0;i<(int)m[u].size();i++)
        {
            v=m[u][i];
            --in[v];
            if(!in[v]) ans[fa[v]].push_back(v),q.push(v);
        }
    }
    return ;
}
bool vis[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v;
    S=2*N+1;T=2*N+2;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        m[u].push_back(v);
        in[v]++;
        add(u,v+N,1);
    }
    for(int i=1;i<=N;i++)
        add(S,i,1),add(i+N,T,1),fa[i]=i;
    int t=Dinic();
    int f1,f2;
    for(int i=2;i<=ES;i++)
    {
        if(CF[i]&&!cf(i)&&e[i].u!=S&&e[i].v!=S&&e[i].u!=T&&e[i].v!=T)
        {
            u=e[i].u>N?e[i].u-N:e[i].u;v=e[i].v>N?e[i].v-N:e[i].v;
            f1=f(u);f2=f(v);
            fa[f2]=f1;
            //printf("%d %d\n",u,v);
        }
    }
    for(int i=1;i<=N;i++)
        f(fa[i]);
    //for(int i=1;i<=N;i++) printf("%d ",fa[i]);puts("");
    topo();
    for(int i=1;i<=N;i++)
    if(ans[i].size())
    {
        for(int k=0;k<(int)ans[i].size();k++)
            printf("%d ",ans[i][k]);
        puts("");
    }
    printf("%d",N-t);
    return 0;
}