#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    char c;
    int re;
    while(!isdigit((c=getchar())));
    re=c-48;
    while(isdigit(c=getchar())) re=re*10+c-48;
    return re;
}
const int maxn=2007;
int N,M;
int h[maxn][maxn],lx[maxn][maxn],rx[maxn][maxn];
int m[maxn][maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
            m[i][j]=R(),lx[i][j]=rx[i][j]=j,h[i][j]=1;
    for(int i=1;i<=N;i++)
    {
        for(int j=2;j<=M;j++)
        if(m[i][j]^m[i][j-1]) lx[i][j]=lx[i][j-1];
        for(int j=M-1;j>0;j--)
        if(m[i][j]^m[i][j+1]) rx[i][j]=rx[i][j+1];
    }
    int x;
    int ans1=0,ans2=0;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        {
            if(i>1&&(m[i][j]^m[i-1][j]))
            {
                lx[i][j]=max(lx[i-1][j],lx[i][j]);
                rx[i][j]=min(rx[i-1][j],rx[i][j]);
                h[i][j]=h[i-1][j]+1;
            }
            x=min(h[i][j],(rx[i][j]-lx[i][j]+1));
            ans1=max(ans1,x*x);
            ans2=max(ans2,h[i][j]*(rx[i][j]-lx[i][j]+1));
        }
    printf("%d\n%d",ans1,ans2);
    return 0;
}