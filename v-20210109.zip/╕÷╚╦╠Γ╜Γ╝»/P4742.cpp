#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<ctime>
using namespace std;
queue <int> q;
const int maxn=200007;
const int maxm=500007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int A1[maxn],A[maxn],B[maxn];
int res[maxn][2];
int dfn[maxn],low[maxn],stk[maxn],S[maxn];
bool ins[maxn];
int C,T,top;
void dfs(int u)
{
    ins[u]=true;
    dfn[u]=low[u]=++T;
    stk[++top]=u;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
        else if(ins[v]) low[u]=min(low[u],dfn[v]);
    }
    if(low[u]==dfn[u])
    {
        int p;C++;
        do{
            p=stk[top--];
            S[p]=C;
            ins[p]=false;
            A[C]+=A1[p];
            B[C]=max(B[C],A1[p]);
        }while(p!=u);
    }
    return ;
}
int in[maxn];
int N,M;
void topo()
{
    for(int i=1;i<=N;i++)
    if(!in[i]) q.push(i),res[i][0]=A[i],res[i][1]=B[i];
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            --in[v];
            if(res[u][0]+A[v]>res[v][0])
            {
                res[v][0]=res[u][0]+A[v];
                res[v][1]=max(res[u][1],B[v]);
            }
            else if(res[u][0]+A[v]==res[v][0]&&max(res[u][1],B[v])>res[v][1])
                res[v][1]=max(res[u][1],B[v]);
            if(!in[v]) q.push(v);
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%d",&A1[i]);
    int u,v;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);
    }
    for(int i=1;i<=N;i++)
    if(!dfn[i]) dfs(i);
    ES=0;
    memset(first,0,sizeof(first));
    for(int i=1;i<=M;i++)
    {
        u=e[i].u;v=e[i].v;
        if(S[u]!=S[v])
            addE(S[u],S[v]),in[S[v]]++;
    }
    topo();
    int ans1=0,ans2=0;
    for(int i=1;i<=C;i++)
    if(res[i][0]>ans1) ans1=res[i][0],ans2=res[i][1];
    else if(res[i][0]==ans1) ans2=max(ans2,res[i][1]);
    printf("%d %d",ans1,ans2);
    return 0;
}