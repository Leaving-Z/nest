#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int maxn=100007;
struct Treap{
	int l,r,pri,s,num,v;
}TREE[maxn];
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define val(i) TREE[i].v
#define p(i) TREE[i].pri
#define c(i) TREE[i].num
#define sz(i) TREE[i].s
int N,root,all;
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Insert(int &i,int v)
{
	if(!i)
	{
		i=++all;p(i)=rand();
		L(i)=R(i)=0;val(i)=v;
		sz(i)=c(i)=1;
		return ;
	}
	++sz(i);
	if(v==val(i)) ++c(i);
	else if(v<val(i))
	{
		Insert(L(i),v);
		if(p(L(i))<p(i)) Zig(i);
	}
	else
	{
		Insert(R(i),v);
		if(p(R(i))<p(i)) Zag(i);
	}
	return ;
}
inline int KTH(int k)
{
	int i=root;
	while(i)
	{
		if(sz(L(i))+c(i)>=k&&sz(L(i))<k) return val(i);
		else if(sz(L(i))>=k) i=L(i);
		else k-=sz(L(i))+c(i),i=R(i);
	}
}
inline int Read()
{
	int re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=Read();
	int x;
	for(int i=1;i<=N;i++)
	{
		x=Read();
		Insert(root,x);
		if(i%2)
			printf("%d\n",KTH(i+1>>1));
	}
	return 0;
}
