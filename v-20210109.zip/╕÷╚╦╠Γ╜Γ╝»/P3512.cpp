#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=3000007;
struct node{
    int val,num;
};
struct que{
    node q[maxn];
    int head,tail;
    que() {head=1;tail=0;return ;}
    bool empty() {return head>tail;}
    node front() {return q[head];}
    node back() {return q[tail];}
    void push (const node &x)
    {
        q[++tail]=x;
        return ;
    }
    void pop_front() {++head;return ;}
    void pop_back() {--tail;return ;}
};
que q1,q2;
int N,K,ans;
int A[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    K=R();N=R();
    for(register int i=1;i<=N;i++)
        A[i]=R();
    int t=0;
    for(register int i=1;i<=N;i++)
    {
        while(!q1.empty()&&q1.back().val<A[i]) q1.pop_back();
        q1.push((node){A[i],i});
        while(!q2.empty()&&q2.back().val>A[i]) q2.pop_back();
        q2.push((node){A[i],i});
        while(q1.front().val-q2.front().val>K)
        {
            if(q1.front().num<q2.front().num) t=q1.front().num,q1.pop_front();
            else t=q2.front().num,q2.pop_front();
        }
        ans=max(ans,i-t);
    }
    printf("%d",ans);
    return 0;
}