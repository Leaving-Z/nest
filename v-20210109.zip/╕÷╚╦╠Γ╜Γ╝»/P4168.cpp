#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int SIZE=220;
int cnt[maxn/SIZE+7][maxn];
int mk[maxn];
int bl[maxn],A[maxn],d[maxn],anti[maxn];
int N;
int ans[maxn/SIZE+7][maxn/SIZE+7];
int calc(int l,int r,int v)
{
    return mk[v]+max(0,cnt[bl[r]-1][v]-cnt[bl[l]][v]);
}
void update(int l,int r,int k)
{
    for(int i=l;i<=r&&bl[l]==bl[i];i++)
        mk[A[i]]+=k;
    for(int i=r;i>=l&&bl[i]==bl[r];i--)
        mk[A[i]]+=k;
    return ;
}
int query(int l,int r)
{
    int t=-1,re,tmp;
    update(l,r,1);
    if(re=ans[bl[l]+1][bl[r]-1]) t=calc(l,r,re);
    for(int i=l;i<=r&&bl[l]==bl[i];i++)
    {
        tmp=calc(l,r,A[i]);
        if(tmp>t||(tmp==t&&A[i]<re)) re=A[i],t=tmp;
    }
    for(int i=r;i>=l&&bl[r]==bl[i];i--)
    {
        tmp=calc(l,r,A[i]);
        if(tmp>t||(tmp==t&&A[i]<re)) re=A[i],t=tmp;
    }
    update(l,r,-1);
    return re;
}
int Q;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    scanf("%d%d",&N,&Q);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]),bl[i]=(i-1)/SIZE+1,d[i]=A[i];
    sort(d+1,d+1+N);
    int tot=unique(d+1,d+1+N)-d-1;
    for(int i=1;i<=tot;i++)
        anti[i]=d[i];
    for(int i=1;i<=N;i++)
        A[i]=lower_bound(d+1,d+1+tot,A[i])-d;
    int re,t,l,r;
    for(int i=1;i<=bl[N];i++)
    {
        memset(mk,0,sizeof(mk));re=0;
        for(int j=(i-1)*SIZE+1;j<=N;j++)
        {
            ++mk[A[j]];
            if(mk[A[j]]>mk[re]||(mk[A[j]]==mk[re]&&re>A[j])) re=A[j];
            if(j%SIZE==0||j==N) ans[i][bl[j]]=re;
        }
    }
    memset(mk,0,sizeof(mk));
    for(int i=1;i<=N;i++)
    {
        ++mk[A[i]];
        if(i%SIZE==0||i==N)
        {
            for(int j=1;j<=tot;j++)
                cnt[bl[i]][j]=mk[j];
        }
    }
    int lst=0;
    memset(mk,0,sizeof(mk));
    for(int i=1;i<=Q;i++)
    {
        scanf("%d%d",&l,&r);
        l=(l+lst-1)%N+1;r=(r+lst-1)%N+1;
        if(l>r) swap(l,r);
        printf("%d\n",lst=anti[query(l,r)]);
    }
    return 0;
}