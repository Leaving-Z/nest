#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
vector <int> item[107];
int price[107][1007];
int N,V,K;
int DP[1007];
int main()
{
	V=Read();N=Read();
	int t,k,w;
	for(int i=1;i<=N;i++)
	{
		w=Read();t=Read();k=Read();
		item[k].push_back(t);
		price[k][item[k].size()]=w;
	}
	for(int i=1;i<=102;i++)
	{
		if(item[i].size()==0) continue;
		for(int v=V;v>=0;v--)
		{
			for(int j=0;j<item[i].size();j++)
			{
				if(price[i][j+1]<=v)
				DP[v]=max(DP[v],DP[v-price[i][j+1]]+item[i][j]);
			}
		}
	}
	printf("%d",DP[V]);
	return 0;
}
