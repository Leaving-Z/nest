#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL dif[80007];
int a[80007];
int N,op,F,maxx,minn;
LL mod;
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
char s;
int main()
{
	LL sum=0,ans=0;
	N=R();op=R();mod=(LL)R();minn=R();maxx=R();
	int l,r,x;
	for(int i=1;i<=op;i++)
	{
		scanf("\n%c",&s);
		l=R();r=R();
		if(s=='A')
		{
			x=R();
			dif[l]+=x;
			dif[r+1]-=x;
		}
		else
		{
			sum=0,ans=0;
			for(int j=1;j<=r;j++)
			{
				sum+=dif[j];
				if(j>=l&&sum*j%mod<=maxx
				&&sum*j%mod>=minn) ans++;
			}
			printf("%lld\n",ans);
		}
	}
	F=R();
	sum=0;
	for(int i=1;i<=N;i++)
	{
		sum+=dif[i];
		a[i]=(sum*i)%mod>=minn&&(sum*i)%mod<=maxx;
		a[i]+=a[i-1];
	}
	for(register int i=1;i<=F;i++)
	{
		l=R();r=R();
		printf("%d\n",a[r]-a[l-1]);
	}
	return 0;
}
