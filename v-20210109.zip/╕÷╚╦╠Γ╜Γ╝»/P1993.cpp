#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
const int inf=1e8;
queue <int> q;
inline int R()
{
	int f=1;
	int re=0;
	char c;
	while((c=getchar())<'0'||c>'9')
		if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
		re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v,w;
}e[40000];
int first[10005],nt[40000],dis[10005];
int times[10005],book[10005],cnt[10005];
int N,M,ES;
bool SPFA(int S)
{
	for(int i=1;i<=N;i++)
		dis[i]=inf;
	q.push(S);
	book[S]=1;
	times[S]=1;
	cnt[S]=1;
	int t;
	while(!q.empty())
	{
		t=q.front();q.pop();
		book[t]=0;
		for(int i=first[t];i;i=nt[i])
		{
			if(dis[t]+e[i].w<dis[e[i].v])
			{
				cnt[e[i].v]=cnt[t]+1;
				dis[e[i].v]=dis[t]+e[i].w;
				if(cnt[e[i].v]>N) return false;
				if(book[e[i].v]==0)
				{
					q.push(e[i].v);
					book[e[i].v]=1;
					times[e[i].v]++;
					if(times[e[i].v]>N) return false;
				}
			}
		}
	}
	return true;
}
int main()
{
	int f;
	int a,b,c;
	N=R();M=R();
	for(int i=1;i<=M;i++)
	{
		f=R();
		if(f==1)
		{
			a=R();b=R();c=R();
			e[++ES]=(E){a,b,-c};
			nt[ES]=first[a];
			first[a]=ES;
		}
		else if(f==2)
		{
			a=R();b=R();c=R();
			e[++ES]=(E){b,a,c};
			nt[ES]=first[b];
			first[b]=ES;
		}
		else if(f==3)
		{
			a=R();b=R();
			e[++ES]=(E){a,b,0};
			nt[ES]=first[a];
			first[a]=ES;
			e[++ES]=(E){b,a,0};
			nt[ES]=first[b];
			first[b]=ES;
		}
	}
	for(int i=M+1;i<=M+N;i++)
	{
		e[++ES]=(E){0,i-M,0};
		nt[ES]=first[0];
		first[0]=ES;
	}
	if(SPFA(0)) printf("Yes");
	else printf("No");
	return 0;
}
