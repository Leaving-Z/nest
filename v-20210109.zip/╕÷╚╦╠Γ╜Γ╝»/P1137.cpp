#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=200007;
int N,M;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int in[maxn],cnt[maxn];
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline void print(int x)
{
	if(x>=10) print(x/10);
	putchar(x%10+48);
	return ;
}
void topo()
{
	for(int i=1;i<=N;i++)
	if(in[i]==0) q.push(i),cnt[i]=1;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			in[v]--;
			cnt[v]=max(cnt[v],cnt[u]+1);
			if(in[v]==0) q.push(v);
		}
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		in[v]++;
		addE(u,v); 
	}
	topo();
	for(int i=1;i<=N;i++)
		print(cnt[i]),puts("");
	return 0;
}
