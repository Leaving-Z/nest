#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int N,all,W;
int F[(1<<18)+7],r[(1<<18)+7];
int A[27];
inline int min_(const int &x,const int &y) {return x<y?x:y;}
int main()
{
	scanf("%d%d",&N,&W);all=1<<N;
	register int i,j;
	for(i=0;i<N;++i)	
		scanf("%d",&A[i]);
	memset(F,0x3f,sizeof(F));
	F[0]=1;r[0]=W;
	for(i=0;i<all;++i)
	{
		for(j=0;j<N;j++)
		{
			if(i&(1<<j)) continue;
			if(r[i]>=A[j]&&F[i|(1<<j)]>=F[i])
			{
				F[i|(1<<j)]=F[i];
				r[i|(1<<j)]=max(r[i|(1<<j)],r[i]-A[j]);
			}
			else if(r[i]<A[j]&&F[i|(1<<j)]>=F[i]+1)
			{
				F[i|(1<<j)]=F[i]+1;
				r[i|(1<<j)]=max(r[i|(1<<j)],W-A[j]);
			}
		}
	}
	printf("%d",F[all-1]);
	return 0;
}
