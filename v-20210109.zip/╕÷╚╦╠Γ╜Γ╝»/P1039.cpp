#include<cstdio>
#include<cstring>
#include<iostream>
#include<string>
#include<map>
#include<cctype>
using namespace std;
const int maxn=107;
struct statement{
    int spk;//statement's author
    bool jd;//if it's a judgement of a criminal
    bool is;//if the speaker says someone is guilty
    int cri;//the person who is judged
    int date;//the date in this statement
}A[maxn];
bool ht[maxn];//if a person is honest
int N,M,P,cnt;
bool f,im;//if the problem is already solved
int ans=-1;//the criminal
int g[maxn];//if a person is unknown/guilty/good
bool book[maxn];
int check()
{
    memset(g,-1,sizeof(g));
    memset(book,0,sizeof(book));
    int spk,t;
    int sum=0,gum=0;//judged criminal/good
    int date=0;//the date
    for(int i=1;i<=cnt;i++)
    {
        spk=A[i].spk;
        if(A[i].jd)
        {
            t=A[i].cri;
            if(ht[spk])
            {
                if(A[i].is)
                {
                    if(g[t]==-1) g[t]=1,++gum;
                    else if(g[t]!=1) return -2;
                }
                else
                {
                    if(g[t]==-1) g[t]=0,ans=t,++sum;
                    else if(g[t]!=0) return -2;
                }
            }
            else
            {
                if(A[i].is)
                {
                    if(g[t]==-1) g[t]=0,ans=t,++sum;
                    else if(g[t]!=0) return -2;
                }
                else
                {
                    if(g[t]==-1) g[t]=1,++gum;
                    else if(g[t]!=1) return -2;
                }
            }
        }
        else
        {
            if(ht[spk])
                if(date!=0&&date==A[i].date) return -2;
                else book[A[i].date]=true;
            else
            {
                if(book[A[i].date]) return -2;
                if(date==0) date=A[i].date;
                else if(date!=A[i].date) return -2;
            }
        }
    }
    if(gum==N-1)
    {
        for(int i=1;i<=N;i++)
        if(g[i]==-1) {ans=i;return 1;}
    }
    if(sum>1) {ans=-1;return -1;}
    else if(sum==0) return 0;
    return 1;
}
void dfs(int u,int sum)
{
    if(f) return ;
    if(sum==M)
    {
        int t=check();
        if(t==-2) return ;
        if(t!=0) im=true;
        if(t==1) f=true;
        return ;
    }
    if(u>N) return ;
    ht[u]=true;
    dfs(u+1,sum+1);
    ht[u]=false;
    dfs(u+1,sum);
    return ;
}
string s;
int ix;
map <string,int> mp;
void rubish(int i)
{
    getline(cin,s);
    --cnt;
    return ;
}
void rubish(int i,string s1)
{
    getline(cin,s);
    if(i==P&&s==s1) return ;
    if(s.length()!=1) --cnt;
    return ;
}
string name[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("P1039_4.in","r",stdin);
    #endif
    cin>>N>>M>>P;
    s="Monday";mp[s]=1;
    s="Tuesday";mp[s]=2;
    s="Wednesday";mp[s]=3;
    s="Thursday";mp[s]=4;
    s="Firday";mp[s]=5;
    s="Saturday";mp[s]=6;
    s="Sunday";mp[s]=7;
    for(int i=1;i<=N;i++)
    {
        cin>>s;
        mp[s]=++ix;
        name[ix]=s;
    }
    int spk,t;
    for(int i=1;i<=P;i++)
    {
        ++cnt;t=0;
        cin>>s;
        s.pop_back();
        spk=mp[s];
        cin>>s;
        A[cnt].spk=spk;
        if(s=="I")
        {
            A[cnt].jd=true;A[cnt].cri=spk;
            cin>>s;
            if(s!="am") {rubish(i);continue;}
            cin>>s;
            if(s=="not")
            {
                A[cnt].is=false;
                cin>>s;
                if(s!="guilty.") rubish(i);
                else rubish(i,s);
            }
            else if(s=="guilty.") A[cnt].is=true,rubish(i,s);
            else rubish(i);
        }
        else
        {
            if(s=="Today")
            {
                A[cnt].jd=false;
                cin>>s;
                if(s!="is") rubish(i);
                else
                {
                    cin>>s;
                    s.pop_back();
                    t=mp[s];
                    if(!t) rubish(i);
                    else A[cnt].date=t,rubish(i,s);
                }
                
            }
            else
            {
                A[cnt].jd=true;
                t=mp[s];
                if(!t) rubish(i);
                else
                {
                    A[cnt].cri=t;
                    cin>>s;
                    if(s!="is") rubish(i);
                    else
                    {
                        cin>>s;
                        if(s=="not")
                        {
                            A[cnt].is=false;
                            cin>>s;
                            if(s!="guilty.") rubish(i);
                            else rubish(i,s);
                        }
                        else if(s=="guilty.")
                            A[cnt].is=true,rubish(i,s);
                        else rubish(i);
                    }
                }
            }
            
        }
    }
    if(cnt==0)
    {
        if(N!=1)
            cout<<"Cannot Determine";
        else cout<<name[1];
        return 0;
    }
    dfs(1,0);
    if(f) cout<<name[ans];
    else if(im)
    {
        if(N!=1) cout<<"Cannot Determine";
        else cout<<name[1];
    }
    else cout<<"Impossible";
    return 0;
}