#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=80007;
const int maxm=800007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M,S,T,all;
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&!cnt[v])
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int d,v,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cf(i)>0&&cnt[v]==cnt[u]+1)
		{
			d=dfs(v,min(f,cf(i)));
			if(d>0)
			{
				f-=d;sum+=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
inline int num(int i,int j)
{
	return (i-1)*N+j;
}
bool m[2007][2007];
int main()
{
	N=R();M=R();T=2*N*N+1;all=N*N;
	int x,y;
	for(register int i=1;i<=M;i++)
		x=R(),y=R(),m[x][y]=true;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=N;j++)
		{
			if(m[i][j]) continue;
			x=num(i,j);
			add(x,x+all,1);
			if(i+j&1) add(S,x,inf);
			else add(x+all,T,inf);
			if(i>2&&j>1) add(x+all,num(i-2,j-1),inf);
			if(j>2&&i>1) add(x+all,num(i-1,j-2),inf);
			if(i<N-1&&j<N) add(x+all,num(i+2,j+1),inf);
			if(i<N&&j<N-1) add(x+all,num(i+1,j+2),inf);
			if(i>2&&j<N) add(x+all,num(i-2,j+1),inf);
			if(i>1&&j<N-1) add(x+all,num(i-1,j+2),inf);
			if(j>2&&i<N) add(x+all,num(i+1,j-2),inf);
			if(j>1&&i<N-1) add(x+all,num(i+2,j-1),inf);
		}
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans+=dfs(S,inf);
	}
	printf("%d",all-M-ans);
	return 0;
}
