#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
typedef long long LL;
LL A[maxn];
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%lld",&A[i]);
    LL sum1=0,sum2=0;
    for(int i=N;i>1;i--)
        A[i]-=A[i-1];
    for(int i=2;i<=N;i++)
    {
        if(A[i]>0) sum1+=A[i];
        else sum2-=A[i];
    }
    printf("%lld\n%lld",max(sum1,sum2),abs(sum1-sum2)+1);
    return 0;
}