#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
const int maxn=50007;
const int maxm=100007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
typedef long long LL;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,Q;
struct Query{
	int u,s,id;
	bool f;
}q[maxm];
bool operator < (const Query &x,const Query &y)
{
	return x.u<y.u;
}
int fa[maxn],sz[maxn],son[maxn],dep[maxn];
void dfs1(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dep[v]=dep[u]+1;
		fa[v]=u;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
	return ;
}
int top[maxn],id[maxn],ix;
void dfs2(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;
	if(son[u]) dfs2(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==son[u]) continue;
		dfs2(v,v);
	}
	return ;
}
LL sum[maxn<<2],add[maxn<<2];
#define ls (i<<1)
#define rs (i<<1|1)
void pushdown(int L,int R,int i)
{
	if(!add[i]) return ;
	int mid=L+R>>1;
	sum[ls]+=add[i]*(mid-L+1);
	sum[rs]+=add[i]*(R-mid);
	add[ls]+=add[i];
	add[rs]+=add[i];
	add[i]=0;
	return ;
}
void update(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		sum[i]+=(R-L+1);
		add[i]++;
		return ;
	}
	pushdown(L,R,i);
	int mid=L+R>>1;
	if(l<=mid) update(L,mid,l,r,ls);
	if(r>mid) update(mid+1,R,l,r,rs);
	sum[i]=sum[ls]+sum[rs];
	return ;
}
LL query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return sum[i];
	LL re=0;
	pushdown(L,R,i);
	int mid=L+R>>1;
	if(l<=mid) re+=query(L,mid,l,r,ls);
	if(r>mid) re+=query(mid+1,R,l,r,rs);
	return re;
}
void update(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		update(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	update(1,N,id[x],id[y],1);
	return ;
}
LL query(int x,int y)
{
	LL re=0;
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		re+=query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	re+=query(1,N,id[x],id[y],1);
	return re;
}
LL ans[maxn];
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&Q);
	int u;
	for(int i=2;i<=N;i++)
		scanf("%d",&u),addE(++u,i);
	dfs1(1);dfs2(1,1);
	int cnt=0;
	int l,r,t=Q;
	while(Q--)
	{
		scanf("%d%d%d",&l,&r,&u);
		l++;r++;u++;
		q[++cnt]=(Query){l-1,u,Q,true};
		q[++cnt]=(Query){r,u,Q,false};
	}
	sort(q+1,q+1+cnt);
	int cur=1;
	LL tmp;
	for(int i=1;i<=cnt;i++)
	{
		while(cur<=q[i].u) update(1,cur++);
		tmp=query(1,q[i].s);
		if(q[i].f) ans[q[i].id]-=tmp;
		else ans[q[i].id]+=tmp;
	}
	while(t--) printf("%lld\n",ans[t]%201314);
	return 0;
}
