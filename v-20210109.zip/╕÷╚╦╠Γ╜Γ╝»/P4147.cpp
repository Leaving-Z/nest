#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1007;
int m[maxn][maxn];
int lx[maxn][maxn],rx[maxn][maxn],h[maxn][maxn];
int N,M;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	register char c;
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			while(!isalpha(c=getchar()));
			if(c=='F') m[i][j]=1;
			lx[i][j]=rx[i][j]=j;
			h[i][j]=1;
		}
	for(int i=1;i<=N;i++)
	{
		for(int j=2;j<=M;j++)
		if(m[i][j-1]) lx[i][j]=lx[i][j-1];

		for(int j=M-1;j>0;j--)
		if(m[i][j+1]) rx[i][j]=rx[i][j+1];
	}
	int ans=0;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		if(m[i][j])
		{
			if(i>1&&m[i-1][j])
			{
				lx[i][j]=max(lx[i][j],lx[i-1][j]);
				rx[i][j]=min(rx[i][j],rx[i-1][j]);
				h[i][j]=h[i-1][j]+1;
			}
			 ans=max(ans,(rx[i][j]-lx[i][j]+1)*h[i][j]);
		}
	printf("%d",ans*3);
	return 0;
}