#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
struct Tree{
	int len,pre,suf,maxx,l,r;
}TREE[maxn<<2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define len(i) TREE[i].len
#define pre(i) TREE[i].pre
#define suf(i) TREE[i].suf
#define v(i) TREE[i].maxx
#define lt(i) TREE[i].l
#define rt(i) TREE[i].r
void Pushup(int i)
{
	pre(i)=pre(Ls);suf(i)=suf(Rs);
	lt(i)=lt(Ls);rt(i)=rt(Rs);
	v(i)=max(v(Ls),v(Rs));
	if(rt(Ls)!=lt(Rs))
	{
		if(pre(Ls)==len(Ls)) pre(i)+=pre(Rs);
		if(suf(Rs)==len(Rs)) suf(i)+=suf(Ls);
		v(i)=max(v(i),suf(Ls)+pre(Rs));
	}
	return ;
}
void Build(int L,int R,int i)
{
	len(i)=R-L+1;
	if(L==R)
	{
		lt(i)=rt(i)=0;
		pre(i)=suf(i)=v(i)=1;
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	Pushup(i);
}
void Update(int L,int R,int x,int i)
{
	if(L==R)
	{
		lt(i)^=1;rt(i)^=1;
		return ;
	}
	if(x<=mid) Update(L,mid,x,Ls);
	else Update(mid+1,R,x,Rs);
	Pushup(i);
	return ;
}
int N,Q;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();Q=R();
	Build(1,N,1);
	int x;
	for(register int i=1;i<=Q;i++)
	{
		x=R();
		Update(1,N,x,1);
		printf("%d\n",TREE[1].maxx);
	}
	return 0;
}
