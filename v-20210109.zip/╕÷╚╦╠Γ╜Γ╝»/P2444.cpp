#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#include<iostream>
using namespace std;
queue <int> q;
int Trie[30007][2];
bool end[30007];
int fail[30007];
int N,all;
char s[30007];
inline void Insert()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'0';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	end[p]=true;
	return ;
}
inline void Ready()
{
	int u,v;
	if(Trie[0][0]) q.push(Trie[0][0]);
	if(Trie[0][1]) q.push(Trie[0][1]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<2;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v);
			else Trie[u][i]=Trie[fail[u]][i];
			if(end[fail[v]]) end[v]=true;
		}
	}
	return ;
}
bool vis[30007],c[30007];
inline void DFS(int u)
{
	vis[u]=true;
	for(int i=0;i<2;i++)
	{
		if(vis[Trie[u][i]])
		{
			printf("TAK");
			exit(0);
		}
		if(!end[Trie[u][i]]&&!c[Trie[u][i]])
		{
			c[Trie[u][i]]=true;
			DFS(Trie[u][i]);
		}
	}
	vis[u]=false;
	return ;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert();
	}
	Ready();
	DFS(0);
	printf("NIE");
	return 0;
}
