#include<cstdio>
#include<algorithm>
using namespace std;
int gcd(int a,int b)
{
	return a%b==0?b:gcd(b,a%b);
}
struct E{
	int u,v,w;
}e[5007];
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int N,M;
int first[507],nt[5007];
int s[507];
int f(int x)
{
	return s[x]==x?x:f(s[x]);
}
void _merge(int x,int y)
{
	s[f(x)]=f(y);
	return ;
}
void init()
{
	for(int i=1;i<=N;i++)
		s[i]=i;
	return ;
}
int S,T;
int main()
{
	scanf("%d%d",&N,&M);
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		e[i]=(E){u,v,w};
		nt[i]=first[u];
		first[u]=i;
	}
	scanf("%d%d",&S,&T); 
	sort(e+1,e+1+M);
	int ans1=2e8,ans2=1;
	int tup,tdown,k=0;
	for(int i=1;i<=M;i++)
	{
		tup=-1;tdown=2e8;k=0;
		init();
		for(int j=i;j<=M;j++)
		{
			if(f(S)==f(T)) break;
			if(f(e[j].u)==f(e[j].v)) continue;
			k++;
			if(tup<e[j].w) tup=e[j].w;
			if(tdown>e[j].w) tdown=e[j].w;
			_merge(e[j].u,e[j].v);
		}
		if(f(S)==f(T))
		{
			if(ans2*tup<ans1*tdown)
			{
				ans2=tdown;
				ans1=tup;
			}
		
		}
	}
	if(ans2==1&&ans1==2e8) printf("IMPOSSIBLE");
	else
	{
		if(ans1%ans2==0)
			printf("%d",ans1/ans2);
		else
		{
			int g;
			g=gcd(ans1,ans2);
			printf("%d/%d",ans1/g,ans2/g);
		}
	}
	return 0;
}
