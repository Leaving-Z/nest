#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=257;
int F[maxn][maxn],N,ans;
#define R (L+len-1)
int main()
{
	scanf("%d",&N);
	for(register int i=1;i<=N;i++)
		scanf("%d",&F[i][i]);
	for(register int len=1;len<=N;len++)
		for(register int L=1;R<=N;L++)
			for(register int k=L;k<=R;k++)
			{
				if(F[L][k]==F[k+1][R])
				{
					F[L][R]=max(F[L][R],F[L][k]+1);
					ans=max(ans,F[L][R]);
				}
			}
	printf("%d",ans);
	return 0;
}
