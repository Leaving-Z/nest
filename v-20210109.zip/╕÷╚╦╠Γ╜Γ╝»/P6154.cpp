#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
#include<cstdlib>
#include<ctime>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=700007;
const int mod=998244353;
typedef long long LL;
LL fast_pow(LL b,LL k)
{
    LL s=1;
    while(k)
    {
        if(k&1) (s*=b)%=mod;
        (b*=b)%=mod;
        k>>=1;
    }
    return (int)s;
}
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
LL p[maxn],res[maxn],in[maxn];
int N,M;
void topo()
{
    for(int i=1;i<=N;i++)
    {
        p[i]=1;
        if(!in[i]) q.push(i);
    }
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            (p[v]+=p[u])%=mod;
            (res[v]+=res[u]+p[u])%=mod;
            --in[v];
            if(!in[v]) q.push(v);
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v;
    for(int i=1;i<=M;i++)
        scanf("%d%d",&u,&v),addE(u,v),in[v]++;
    topo();
    LL ans1=0,ans2=0;
    for(int i=1;i<=N;i++)
        (ans1+=res[i])%=mod,(ans2+=p[i])%=mod;
    printf("%lld",ans1*fast_pow(ans2,mod-2)%mod);
    return 0;
}