#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=350;
const int maxm=57;
int F[maxm][maxm][maxm][maxm];
int A[maxn];
int num[5];
int N,M;
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		scanf("%d",&A[i]);
	int x;
	for(int i=1;i<=M;i++)
		scanf("%d",&x),num[x]++;
	F[0][0][0][0]=A[1];
	int steps,val;
	for(int i=0;i<=num[1];i++)
		for(int j=0;j<=num[2];j++)
			for(int k=0;k<=num[3];k++)
				for(int l=0;l<=num[4];l++)
				{
					val=0;
					if(i!=0) val=max(F[i-1][j][k][l],val);
					if(j!=0) val=max(F[i][j-1][k][l],val);
					if(k!=0) val=max(F[i][j][k-1][l],val);
					if(l!=0) val=max(F[i][j][k][l-1],val);
					steps=i+(j<<1)+k*3+(l<<2)+1;
					F[i][j][k][l]=max(F[i][j][k][l],val+A[steps]);
				}
	printf("%d",F[num[1]][num[2]][num[3]][num[4]]);
	return 0;
}
