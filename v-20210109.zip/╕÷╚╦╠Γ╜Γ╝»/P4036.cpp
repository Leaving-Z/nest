#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
typedef unsigned int ui;
int son[maxn][2],p[maxn],sz[maxn],all,root;
ui val[maxn],pb[maxn],hs[maxn];
const ui b=131;
int N,len;
void pushup(int x)
{
	hs[x]=hs[son[x][0]]+val[x]*pb[sz[son[x][0]]]+hs[son[x][1]]*pb[sz[son[x][0]]+1];
    sz[x]=sz[son[x][0]]+sz[son[x][1]]+1;
	return ;
}
int ship(int k)
{
	++all;
	hs[all]=val[all]=k;p[all]=rand();sz[all]=1;son[all][0]=son[all][1]=0;
	return all;
}
void split(int i,int k,int &x,int &y)
{
	if(!i) {x=y=0;return ;}
	if(sz[son[i][0]]+1<=k)
	{
		x=i;
		split(son[i][1],k-sz[son[i][0]]-1,son[i][1],y);
	}
	else
	{
		y=i;
		split(son[i][0],k,x,son[i][0]);
	}
	pushup(i);
	return ;
}
int merge(int x,int y)
{
	if(!x||!y) return x|y;
	if(p[x]<p[y])
	{
		son[x][1]=merge(son[x][1],y);
		pushup(x);
		return x;
	}
	else
	{
		son[y][0]=merge(x,son[y][0]);
		pushup(y);
		return y;
	}
}
void insert(int pos,int k)
{
	int x,y;
	split(root,pos,x,y);
	root=merge(merge(x,ship(k)),y);
	return ;
}
void update(int pos,int k)
{
	int x,y,z;
	split(root,pos,x,z);
	split(x,pos-1,x,y);
	hs[y]=val[y]=k;
	root=merge(merge(x,y),z);
	return ;
}
char s[maxn],qwq[7];
ui hash(int l,int r)
{
    int x,y,z;
    split(root,r,x,z);
    split(x,l-1,y,x);
    ui re=hs[x];
    root=merge(merge(y,x),z);
    return re;
}
bool check(int p1,int p2,int l)
{
    if(p1+l-1>len||p2+l-1>len) return false;
	return hash(p1,p1+l-1)==hash(p2,p2+l-1);
}
int LCP(int p1,int p2)
{
	int L=0,R=len,mid,ans=0;
    while(L<=R)
    {
        mid=L+R>>1;
        if(check(p1,p2,mid)) ans=mid,L=mid+1;
        else R=mid-1;
    }
    return ans;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    srand(time(NULL));
	scanf("%s",s+1);
	len=N=strlen(s+1);
    pb[0]=1;
    for(int i=1;i<maxn;i++)
        pb[i]=pb[i-1]*b;
	for(int i=1;i<=N;i++)
		insert(i,(int)s[i]);
	scanf("%d",&N);
    int x,y;
	for(int i=1;i<=N;i++)
	{
        scanf("%s",qwq);
        if(qwq[0]=='Q')
        {
            scanf("%d%d",&x,&y);
            printf("%d\n",LCP(x,y));
        }
        else if(qwq[0]=='R')
        {
            scanf("%d",&x);
            scanf("%s",qwq);
            update(x,qwq[0]);
        }
        else
        {
            scanf("%d",&x);
            scanf("%s",qwq);
            insert(x,qwq[0]);
            ++len;
        }
	}
    return 0;
}