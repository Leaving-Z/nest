#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
LL DP[35][35];
LL N;
LL q[35][3];
LL Break[35][35];
int head,tail;
void dfs(int l,int r)
{
	if(l>r) return ;
	if(l==r)
	{
		printf("%d ",l);
		return ;
	}
	printf("%lld ",Break[l][r]);
	dfs(l,Break[l][r]-1);
	dfs(Break[l][r]+1,r);
	return ;
}
int main()
{
	scanf("%lld",&N);
	DP[N+1][N+1]=1;
	for(int i=1;i<=N;i++)
	{
		scanf("%lld",&DP[i][i]);
		DP[i][i-1]=1;
	}
	for(int L=N;L>0;L--)
		for(int R=L+1;R<=N;R++)
		for(int k=L;k<=R;k++)
		{
			if(DP[L][R]<DP[L][k-1]*DP[k+1][R]+DP[k][k])
			{
				DP[L][R]=DP[L][k-1]*DP[k+1][R]+DP[k][k];
				Break[L][R]=k;
			}
		}
	int l,r,k,k1;
	printf("%lld\n",DP[1][N]);
	dfs(1,N);
	return 0;
}
