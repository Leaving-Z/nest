#include<cstdio>
#include<algorithm>
#include<cstring>
#include<set>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=200007;
const int maxm=400007;
int N,M,Q;
int A[maxn];
struct E{
	int u,v;
};
struct Graph{
	E e[maxm];
	int first[maxn],nt[maxm],ES;
	inline void addE(int u,int v)
	{
		e[++ES]=(E){u,v};
		nt[ES]=first[u];
		first[u]=ES;
		return ;
	}
};
Graph G,T;
int stk[maxn],stop;
int low[maxn],dfn[maxn],Tix;
int cnt;
int S[maxn],C;
void Dfs(int u)
{
	int v;
	low[u]=dfn[u]=++Tix;
	stk[++stop]=u;
	for(int i=G.first[u];i;i=G.nt[i])
	{
		v=G.e[i].v;
		if(!dfn[v])
		{
			Dfs(v);
			low[u]=min(low[u],low[v]);
			if(low[v]==dfn[u])
			{
				++cnt;
				int p;
				do{
					p=stk[stop--];
					T.addE(cnt,p);
					T.addE(p,cnt);
					//printf("%d ",p);
				}while(p!=v);
				T.addE(cnt,u);
				T.addE(u,cnt);
				//printf("%d\n",u);
			}
		}
		else low[u]=min(low[u],dfn[v]);
	}
	return ;
}
int id[maxn],fa[maxn],top[maxn],sz[maxn];
int ix,son[maxn],depth[maxn],anti[maxn];
void DFS(int u)
{
	sz[u]=1;
	int v;
	for(int i=T.first[u];i;i=T.nt[i])
	{
		v=T.e[i].v;
		if(v==fa[u]) continue;
		fa[v]=u;
		depth[v]=depth[u]+1;
		DFS(v);
		sz[u]+=sz[v];
		if(sz[son[u]]<sz[v]) son[u]=v;
	}
	return ;
}
void dfs(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=T.first[u];i;i=T.nt[i])
	{
		v=T.e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs(v,v);
	}
	return ;
}
int TREE[maxn<<2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define val(i) TREE[i]
void Build(int L,int R,int i)
{
	if(L==R) {val(i)=A[anti[L]];return ;}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	val(i)=min(val(Ls),val(Rs));
	return ;
}
void Update(int L,int R,int x,int k,int i)
{
	if(L==R) {val(i)=k;return ;}
	if(x<=mid) Update(L,mid,x,k,Ls);
	else Update(mid+1,R,x,k,Rs);
	val(i)=min(val(Ls),val(Rs));
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return val(i);
	int re=0x7f7f7f7f;
	if(l<=mid) re=Query(L,mid,l,r,Ls);
	if(r>mid) re=min(re,Query(mid+1,R,l,r,Rs));
	return re;
}
int Query_Path(int x,int y)
{
	int re=0x7f7f7f7f;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		re=min(re,Query(1,cnt,id[top[x]],id[x],1));
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	re=min(re,Query(1,cnt,id[x],id[y],1));
	if(x>N) re=min(re,A[fa[x]]);
	return re;
}
multiset <int> s[maxn];
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();M=R();Q=R();
	cnt=N;
	for(register int i=1;i<=N;i++)
		A[i]=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		G.addE(u,v);G.addE(v,u);
	}
	Dfs(1);DFS(1);dfs(1,1);
	for(register int i=1;i<=N;i++)
	if(fa[i]) s[fa[i]].insert(A[i]);
	for(register int i=N+1;i<=cnt;i++)
		A[i]=*s[i].begin();
	Build(1,cnt,1);
	char qwq[7];
	while(Q--)
	{
		scanf("%s",qwq+1);u=R();v=R();
		if(qwq[1]=='C')
		{
			Update(1,cnt,id[u],v,1);
			if(fa[u])
			{
				s[fa[u]].erase(s[fa[u]].lower_bound(A[u]));
				s[fa[u]].insert(v);
				if(*s[fa[u]].begin()!=A[fa[u]])
				{
					A[fa[u]]=*s[fa[u]].begin();
					Update(1,cnt,id[fa[u]],A[fa[u]],1);
				}
			}
			A[u]=v;
		}
		else printf("%d\n",Query_Path(u,v));
	}
	return 0;
}
