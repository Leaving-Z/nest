#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
int TREE[maxn*80];
int cnt,root[maxn],len[maxn];
int Ls[maxn*80],Rs[maxn*80];
int N;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
#define mid (L+R>>1)
inline int cp(int i)
{
	TREE[++cnt]=TREE[i];
	Ls[cnt]=Ls[i];
	Rs[cnt]=Rs[i];
	return cnt;
}
int Update(int L,int R,int x,int k,int i)
{
	i=cp(i);
	if(L==R) {TREE[i]=k;return i;}
	if(x<=mid) Ls[i]=Update(L,mid,x,k,Ls[i]);
	else Rs[i]=Update(mid+1,R,x,k,Rs[i]);
	return i;
}
int Query(int L,int R,int x,int i)
{
	if(L==R) return TREE[i];
	if(x<=mid) return Query(L,mid,x,Ls[i]);
	else return Query(mid+1,R,x,Rs[i]);
}
char s[7];
int main()
{
	N=R();
	int cur=0,x;
	for(register int i=1;i<=N;i++)
	{
		scanf("%s",s);
		if(s[0]=='T')
		{
			scanf("%s",s);
			root[cur+1]=Update(1,N,len[cur]+1,(int)s[0],root[cur]);
			++cur;len[cur]=len[cur-1]+1;
		}
		else if(s[0]=='U')
		{
			x=R();
			++cur;
			root[cur]=root[cur-x-1];
			len[cur]=len[cur-x-1];
		}
		else
		{
			x=R();
			printf("%c\n",(char)Query(1,N,x,root[cur]));
		}
	}
	return 0;
}
