#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int Trie[500007][27];
int word[500007];
bool book[500007];
int N,M,all;
char s[57];
inline void Insert()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	word[p]++;
	return ;
}
inline int check()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			return -1;
		p=Trie[p][t];
	}
	if(word[p]==0) return -1;
	if(book[p]) return 0;
	book[p]=true;
	return 1;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert();
	}
	scanf("%d",&M);
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s);
		N=check();
		if(N==-1)
			printf("WRONG\n");
		else if(N==0) printf("REPEAT\n");
		else printf("OK\n");
	}
	return 0;
}
