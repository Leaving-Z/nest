#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
const int maxm=300007;
const int mod=1e9+7;
typedef long long LL;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int c[maxn];
int dfn[maxn],low[maxn],T;
int stk[maxn],top,C,S[maxn];
bool ins[maxn];
LL ans[maxn],cost;
void dfs(int u)
{
	stk[++top]=u;
	ins[u]=true;
	dfn[u]=low[u]=++T;
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v])
		{
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
		else if(ins[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p,minn=0x7f7f7f7f;C++;
		do{
			p=stk[top--];
			S[p]=C;
			ins[p]=false;
			if(c[p]<minn) minn=c[p],ans[C]=0;
			if(c[p]==minn) ans[C]++;
		}while(p!=u);
		cost+=minn;
	}
	return ;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		c[i]=R();
	M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		addE(u,v);
	}
	for(register int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	LL ANS=1;
	for(register int i=1;i<=C;i++)
		ANS=ANS*ans[i]%mod;
	printf("%lld %lld",cost,ANS);
	return 0;
}
