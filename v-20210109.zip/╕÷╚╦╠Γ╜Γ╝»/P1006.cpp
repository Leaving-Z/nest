#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int F[107][57][57];
int m[57][57];
int N,M;
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%d",&m[i][j]);
	memset(F,-1,sizeof(F));
	F[2][1][1]=0;
	int x,y,xx,yy,re;
	for(int k=3;k<=N+M-1;k++)
		for(int i=1;i<N;i++)
			for(int j=i+1;j<=N;j++)
			{
				x=i;y=k-i;
				xx=j;yy=k-j;
				re=F[k][i][j];
				re=max(F[k][i][j],max(F[k-1][i][j],max(F[k-1][i-1][j],max(F[k-1][i][j-1],F[k-1][i-1][j-1]))));
				if(re==-1) continue;
				F[k][i][j]=re+m[x][y]+m[xx][yy];
			}
	printf("%d",F[M+N-1][N-1][N]);
	return 0;
}
