#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=2007;
typedef long long LL;
struct E{
	int u,v;
	LL w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
LL F[maxn][maxn];
LL sz[maxn];
int N,K;
void dfs(int u,int fa)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			for(int j=min((int)sz[u],K);j>=0;j--)
				for(int k=sz[v];k>=0;k--)
					F[u][k+j]=max(F[u][k+j],F[u][j]+F[v][k]+e[i].w*k*(K-k)+e[i].w*(sz[v]-k)*(N-K-(sz[v]-k)));
			sz[u]+=sz[v];
		}
	}
	return ;
}
int main()
{
	scanf("%d%d",&N,&K);
	int u,v;LL w;
	for(register int i=1;i<N;i++)
	{
		scanf("%d%d%lld",&u,&v,&w);
		addE(u,v,w);addE(v,u,w);
	}
	dfs(1,0);
	printf("%lld",F[1][K]);
	return 0;
}
