#include<bits/stdc++.h>
using namespace std;
const int maxn=300007;
int cnt[maxn],depth[maxn];
int A[maxn];
int N;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ; 
}
const int J=20;
int fa[maxn][J+1];
inline void init(int u)
{
	for(int i=1;(1<<i)<=depth[u];i++)
		fa[u][i]=fa[fa[u][i-1]][i-1];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u][0])
		{
			depth[v]=depth[u]+1;
			fa[v][0]=u;
			init(v);
		}
	}
	return ;
}
inline int LCA(int x,int y)
{
	if(depth[x]<depth[y]) swap(x,y);
	int d=depth[x]-depth[y];
	for(int i=0;i<=J;i++)
		if((1<<i)&d) x=fa[x][i];
	if(x==y) return y;
	for(int i=J;i>=0;i--)
	{
		if(fa[x][i]!=fa[y][i])
		{
			x=fa[x][i];
			y=fa[y][i];
		}
	}
	return fa[x][0];
}
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
inline void dfs(int u)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u][0])
		{
			dfs(v);
			cnt[u]+=cnt[v];
		}
	}
	return ;
}
inline void print(int x)
{
	if(x>9) print(x/10);
	putchar(x%10+48); 
}
int main()
{
	N=R();
	int u,v;
	for(register int i=1;i<=N;i++)
		A[i]=R();
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	init(1);
	int lca;
	for(register int i=1;i<N;i++)
	{
		cnt[A[i]]++;cnt[A[i+1]]++;
		cnt[lca=LCA(A[i],A[i+1])]--;
		cnt[fa[lca][0]]--;
	}
	dfs(1);
	for(register int i=2;i<=N;i++)
		cnt[A[i]]--;
	for(register int i=1;i<=N;i++)
		print(cnt[i]),puts("");
	return 0;
}
