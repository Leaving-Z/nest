#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=5007;
const int maxm=500007;
const int mod=80112002;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int f[maxn];
int N,M;
inline int dfs(int u)
{
	int v;
	if(f[u]) return f[u];
	if(first[u]==0) return f[u]=1;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		f[u]=(f[u]+dfs(v))%mod;
	}
	return f[u];
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int in[maxn];
int main()
{
	N=R();M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		in[v]++;
		addE(u,v);
	}
	int ans=0;
	for(register int i=1;i<=N;i++)
	{
		if(in[i]==0)
			ans=(ans+dfs(i))%mod;
	}
	printf("%d",ans);
	return 0;
}
