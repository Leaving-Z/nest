#include<cstdio>
#include<algorithm>
using namespace std;
#define mid (L+R>>1)
inline int Read()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct Tree{
	int num,l,r,lazy;
}TREE[400007];
struct E{
	int u,v;
}e[200007];
int first[100007],nt[200007],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
} 
int N,M;
int C[100007];
int fa[100007],depth[100007],top[100007],id[100007],anti[100007],sz[100007],son[100007];
void DFS(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			depth[v]=depth[u]+1;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[son[u]]<sz[v]) son[u]=v;
		}
	}
	return ;
}
int ix,Lc,Rc;
void dfs(int u,int s)
{
	id[u]=++ix;anti[ix]=u;
	top[u]=s;
	if(son[u]) dfs(son[u],s);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs(v,v);
	}
	return ;
}
void Build(int L,int R,int i)
{
	if(L==R)
	{
		TREE[i].num=1;
		TREE[i].l=TREE[i].r=C[anti[L]];
		return ;
	}
	Build(L,mid,i<<1);
	Build(mid+1,R,i<<1|1);
	TREE[i].num=TREE[i<<1].num+TREE[i<<1|1].num;
	if(TREE[i<<1].r==TREE[i<<1|1].l) TREE[i].num--;
	TREE[i].l=TREE[i<<1].l;
	TREE[i].r=TREE[i<<1|1].r;
	return ;
}
inline void LAZY(int i)
{
	if(TREE[i].lazy)
	{
		TREE[i<<1].l=TREE[i<<1|1].l
		=TREE[i<<1].r=TREE[i<<1|1].r
		=TREE[i<<1].lazy=TREE[i<<1|1].lazy
		=TREE[i].lazy;
		TREE[i<<1].num=TREE[i<<1|1].num=1;
		TREE[i].lazy=0;
	}
	return ;
}
void Update(int L,int R,int l,int r,int i,int k)
{
	if(l<=L&&R<=r)
	{
		TREE[i].num=1;
		TREE[i].l=TREE[i].r=k;
		TREE[i].lazy=k;
		return ;
	}
	LAZY(i);
	if(l<=mid) Update(L,mid,l,r,i<<1,k);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
	TREE[i].num=TREE[i<<1].num+TREE[i<<1|1].num;
	if(TREE[i<<1].r==TREE[i<<1|1].l) TREE[i].num--;
	TREE[i].l=TREE[i<<1].l;
	TREE[i].r=TREE[i<<1|1].r;
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		if(l==L) Lc=TREE[i].l;
		if(R==r) Rc=TREE[i].r;
		return TREE[i].num;
	}
	int ans=0;bool fl=true,fr=true;
	LAZY(i);
	if(l<=mid)
		ans+=Query(L,mid,l,r,i<<1),fl=false;
	if(r>mid)
		ans+=Query(mid+1,R,l,r,i<<1|1),fr=false;
	if(fl||fr)
	return ans;
	else
	{
		if(TREE[i<<1].r==TREE[i<<1|1].l)
		ans--;
		return ans;
	}
}
void Update_Path(int x,int y,int k)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],1,k);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x],id[y],1,k);
	return ;
}
int Query_Path(int x,int y)
{
	int ll=-1,rr=-1;
	int ans=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]])
		{swap(x,y);swap(ll,rr);}
		ans+=Query(1,N,id[top[x]],id[x],1);
		if(Rc==ll) ans--;
		ll=Lc;x=fa[top[x]];
	}
	if(depth[x]>depth[y])
	{swap(x,y);swap(ll,rr);}
	ans+=Query(1,N,id[x],id[y],1);
	if(ll==Lc) ans--;
	if(rr==Rc) ans--;
	return ans;
}
int main()
{
	N=Read();M=Read();
	for(int i=1;i<=N;i++)
		C[i]=Read();
	int u,v,c;
	for(int i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);
	}
	DFS(1);dfs(1,1);
	Build(1,N,1);
	char s[10];
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s);
		u=Read();v=Read();
		if(s[0]=='C')
		{
			c=Read();
			Update_Path(u,v,c);
		}
		else if(s[0]=='Q')
			printf("%d\n",Query_Path(u,v));
	}
	return 0;
}
