#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=300007;
double f[maxn],A[maxn];
int N,K;
char s[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    scanf("%s",s+1);
    for(int i=1;i<=N;i++)
    if(s[i]=='o') A[i]=1;
    else if(s[i]=='x') A[i]=0;
    else A[i]=0.5;
    long double p1=0;
    for(int i=1;i<=N;i++)
    {
        f[i]=f[i-1]+(2*p1+1)*A[i];
        p1=(p1+1)*A[i];
    }
    printf("%.4f",f[N]);
    return 0;
}