#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=1000007;
int N,M,S,c,T;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
struct Pigeon{
	int t,id;
}d[maxn];
bool operator < (const Pigeon &x,const Pigeon &y)
{
	return x.t<y.t;
}
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int dis[maxn];
bool book[maxn];
void SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	dis[S]=0;book[S]=true;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
int main()
{
	N=R();M=R();S=R();c=R();
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
		addE(v,u,w);
	}
	SPFA();
	T=R();
	for(int i=1;i<=T;i++)
	{
		d[i].t=R();
		d[i].id=R();
	}
	sort(d+1,d+1+T);
	int ans;d[T+1].t=0;d[++T].id=c;
	for(int i=1;i<=T;i++)
	{
		if(dis[d[i].id]<d[i+1].t)
		{printf("%d",max(dis[d[i].id],d[i].t));return 0;}
	}
	printf("%d",max(dis[d[T].id],d[T].t));
	return 0;
}
