#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=10000007;
bool book[maxn];
int phi[maxn],prime[maxn],cnt;
long long p;
void pre()
{
    for(int i=2;i<maxn;i++)
    {
        if(!book[i]) prime[++cnt]=i,phi[i]=i-1;
        for(int j=1;j<=cnt&&i*prime[j]<maxn;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) phi[i*prime[j]]=phi[i]*(prime[j]-1);
            else {phi[i*prime[j]]=phi[i]*prime[j];break;}
        }
    }
    return ;
}
long long fast_pow(int k,int mod)
{
    long long b=2,s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
long long calc(int mod)
{
    if(mod==1||mod==2) return 0;
    return fast_pow(calc(phi[mod])+phi[mod],mod);
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    pre();
    int T;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%lld",&p);
        printf("%lld\n",calc(p));
    }
    return 0;
}