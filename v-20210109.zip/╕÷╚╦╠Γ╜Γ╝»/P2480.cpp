#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int MOD=999911659;
const int mod1=2;
const int mod2=3;
const int mod3=4679;
const int mod4=35617;
typedef long long LL;
LL fast_pow(LL b,int k,int mod)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL fact[40007],inv[40007];
void pre(int p)
{
    fact[0]=1;
    for(int i=1;i<p;i++)
        fact[i]=fact[i-1]*i%p;
    inv[p-1]=fast_pow(fact[p-1],p-2,p);
    for(int i=p-2;i>=0;i--)
        inv[i]=inv[i+1]*(i+1)%p;
    return ;
}
LL C(int n,int m,int mod)
{
    if(m>n) return 0;
    return (int)(fact[n]*inv[m]%mod*inv[n-m]%mod);
}
LL Lucas(int n,int m,int mod)
{
    if(m==0) return 1;
    return C(n%mod,m%mod,mod)*Lucas(n/mod,m/mod,mod)%mod;
}
int m[7],r[7];
int g;
void Exgcd(int a,int b,int &x,int &y)
{
    if(!b) {g=a,x=1,y=0;return ;}
    Exgcd(b,a%b,y,x);
    y-=(a/b)*x;
    return ;
}
LL ExCRT()
{
    int prod=1,x,y,c;
    LL ans=0;
    for(int i=1;i<=4;i++)
    {
        Exgcd(prod,m[i],x,y);
        c=((r[i]-ans)%m[i]+m[i])%m[i];
        x=((x*(c/g))%(m[i]/g)+m[i]/g)%(m[i]/g);
        ans=ans+x*prod;
        prod=prod*m[i]/g;
        ans%=prod;
    }
    return ans;
}
int N,G;
LL solve(int d)
{
    m[1]=mod1;pre(mod1);r[1]=Lucas(N,N/d,mod1);
    m[2]=mod2;pre(mod2);r[2]=Lucas(N,N/d,mod2);
    m[3]=mod3;pre(mod3);r[3]=Lucas(N,N/d,mod3);
    m[4]=mod4;pre(mod4);r[4]=Lucas(N,N/d,mod4);
    LL re=ExCRT();
    return re;
}
LL sep(int x)
{
    LL re=0,t;
    for(int i=1;i*i<=x;i++)
    {
        if(x%i==0)
        {
            t=solve(i);
            re=(re+t)%(MOD-1);
            //printf("%lld\n",t);
            if(i*i!=x)
            {
                t=solve(x/i);
                //printf("%lld\n",t);
                re=(re+t)%(MOD-1);
            }
        }
    }
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&G);
    if(G%MOD==0) {printf("0");return 0;}
    LL ans=sep(N);
    //printf("%d\n",ans);
    printf("%lld\n",fast_pow(G,ans,MOD));
    return 0;
}