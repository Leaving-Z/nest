#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
const int maxn=50007;
const int SIZE=240;
typedef long long LL;
struct query{
    int l,r,id;
}q[maxn];
bool com1(const query &x,const query &y)
{
    return x.l<y.l||x.l==y.l&&x.r<y.r;
}
bool com2(const query &x,const query &y)
{
    return x.r<y.r;
}
int A[maxn];
LL ans[maxn];
int N,Q,K;
vector <query> m[maxn];
LL num[maxn];
void solve(int k)
{
    sort(m[k].begin(),m[k].end(),com2);
    LL res=0;
    memset(num,0,sizeof(num));
    for(int i=m[k][0].l;i<=m[k][0].r;i++)
    {
        res-=num[A[i]]*num[A[i]];
        ++num[A[i]];
        res+=num[A[i]]*num[A[i]];
    }
    ans[m[k][0].id]=res;
    int l,r,d;
    for(int i=1;i<(int)m[k].size();i++)
    {
        if(m[k][i].l>m[k][i-1].l)
            l=m[k][i-1].l,r=m[k][i].l-1,d=-1;
        else
            l=m[k][i].l,r=m[k][i-1].l-1,d=1;
        for(int j=l;j<=r;j++)
        {
            res-=num[A[j]]*num[A[j]];
            num[A[j]]+=d;
            res+=num[A[j]]*num[A[j]];
        }
        for(int j=m[k][i-1].r+1;j<=m[k][i].r;j++)
        {
            res-=num[A[j]]*num[A[j]];
            num[A[j]]++;
            res+=num[A[j]]*num[A[j]];
        }
        ans[m[k][i].id]=res;
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&Q,&K);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    for(int i=1;i<=Q;i++)
        scanf("%d%d",&q[i].l,&q[i].r),q[i].id=i;
    sort(q+1,q+1+Q,com1);
    int x;
    for(int i=1;i<=Q;i++)
        x=(i-1)/SIZE+1,m[x].push_back(q[i]);
    for(int i=1;i<=(Q-1)/SIZE+1;i++)
        solve(i);
    for(int i=1;i<=Q;i++)
        printf("%lld\n",ans[i]);
    return 0;
}