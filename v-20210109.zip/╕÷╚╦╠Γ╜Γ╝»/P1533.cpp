#include<cstdio>
#include<algorithm>
#include<cctype>
#include<cstring>
using namespace std;
const int maxn=300007;
struct seg_tree{
    int ls,rs,v;
}TREE[maxn*40];
int root[maxn],cnt;
inline int cp(int i)
{
    TREE[++cnt]=TREE[i];
    return cnt;
}
#define ls(i) TREE[i].ls
#define rs(i) TREE[i].rs
#define mid (L+R>>1)
#define v(i) TREE[i].v
int Update(int L,int R,int x,int i)
{
    i=cp(i);
    if(L==R) {v(i)++;return i;}
    if(x<=mid) ls(i)=Update(L,mid,x,ls(i));
    else rs(i)=Update(mid+1,R,x,rs(i));
    v(i)=v(ls(i))+v(rs(i));
    return i;
}
int Query(int L,int R,int k,int i1,int i2)
{
    if(L==R) return L;
    if(v(ls(i2))-v(ls(i1))>=k) return Query(L,mid,k,ls(i1),ls(i2));
    else return Query(mid+1,R,k-v(ls(i2))+v(ls(i1)),rs(i1),rs(i2));
}
int A[maxn],d[maxn],id[maxn];
int N,Q;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);scanf("%d",&Q);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]),d[i]=A[i];
    sort(d+1,d+1+N);
    int tot=unique(d+1,d+1+N)-d-1;
    for(int i=1;i<=N;i++)
        id[i]=lower_bound(d+1,d+1+tot,A[i])-d;
    for(int i=1;i<=N;i++)
        root[i]=Update(1,tot,id[i],root[i-1]);
    int l,r,k;
    while(Q--)
    {
        scanf("%d%d%d",&l,&r,&k);
        k=Query(1,tot,k,root[l-1],root[r]);
        printf("%d\n",d[k]);
    }
    return 0;
}
