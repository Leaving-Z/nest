#include<cstdio>
#include<algorithm>
using namespace std;
inline int Read()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v;
}e[1000007];
int first[500007],nt[1000007],ES;
int N;
int DP[500007][2];
int fa[500007];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u};
	nt[ES]=first[v];
	first[v]=ES;
}
void dfs(int u)
{
	int v;
	DP[u][1]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			dfs(v);
			DP[u][0]+=max(DP[v][1],DP[v][0]);
			DP[u][1]+=DP[v][0];
		}
	}
	return ;
}
int main()
{
	N=Read();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);
	}
	dfs(1);
	printf("%d",max(DP[1][1],DP[1][0]));
	return 0;
}
