#include<bits/stdc++.h>
using namespace std;
double F[1007];
int T,N;
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&N);
		F[N]=0;
		for(int i=N-1;i>=0;i--)
			F[i]=F[i+1]+N/(double)(N-i);
		printf("%.2lf\n",F[0]);
	}
	return 0;
}
