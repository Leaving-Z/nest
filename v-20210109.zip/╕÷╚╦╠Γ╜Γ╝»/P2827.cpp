#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=7100007;
const int inf=0x7f7f7f7f;
struct Qu{
    int q[maxn];
    int head,tail;
    Qu() {head=1,tail=0;return ;}
    int front()
    {
        if(head<=tail) return q[head];
        else return -inf;
    }
    void pop() {++head;return ;}
    void push(const int &x) {q[++tail]=x;return ;}
    bool empty() {return head>tail;}
}q1,q2,q3;
int N,M,Q,u,v,t;
int ans[maxn];
bool com(const int &x,const int &y)
{
    return x>y;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("P2827_5.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    scanf("%d%d%d",&N,&M,&Q);
    scanf("%d%d%d",&u,&v,&t);
    int x,y,z,d=0;
    for(int i=1;i<=N;i++)
        scanf("%d",&x),q1.push(x);
    sort(q1.q+1,q1.q+1+N,com);
    for(int i=1;i<=M;i++)
    {
        x=max(q1.front(),max(q2.front(),q3.front()));
        if(x==q1.front()) q1.pop();
        else if(x==q2.front()) q2.pop();
        else q3.pop();
        x+=d;
        ans[i]=x;
        y=1ll*x*u/v;
        z=x-y;
        d+=Q;
        if(z>y) swap(z,y);
        q2.push(y-d);q3.push(z-d);
    }
    for(int i=1;i*t<=M;i++)
        printf("%d ",ans[i*t]);
    putchar('\n');
    for(int i=1;i<=N+M;i++)
    {
        x=max(q1.front(),max(q2.front(),q3.front()));
        if(x==q1.front()) q1.pop();
        else if(x==q2.front()) q2.pop();
        else q3.pop();
        x+=d;
        ans[i]=x;
    }
    for(int i=1;i*t<=M+N;i++)
        printf("%d ",ans[i*t]);
    return 0;
}