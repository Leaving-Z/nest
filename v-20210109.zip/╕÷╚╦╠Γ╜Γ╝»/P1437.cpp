#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=51;
int f[maxn][maxn][maxn*maxn/2];
int N,M;
int m[maxn][maxn],sum[maxn][maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int ans=0;
    for(int i=1;i<=N;i++)
        for(int j=i;j<=N;j++)
            scanf("%d",&m[i][j]);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=i;j++)
            sum[i][j]=sum[i][j-1]+m[j][i];
    memset(f,-63,sizeof(f));
    for(int i=0;i<=N;i++)
        f[i][0][0]=0;
    for(int i=1;i<=N;i++)
        for(int j=0;j<=min(M,i*(i+1)/2);j++)
            for(int k=0;k<=i;k++)
                for(int l=max(0,k-1);l<=i;l++)
                {
                    if(j>=k)
                        f[i][k][j]=max(f[i][k][j],f[i-1][l][j-k]+sum[i][k]);
                    ans=max(f[i][k][j],ans);
                }
    printf("%d",ans);
    return 0;
}