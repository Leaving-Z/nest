#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct E{
	int u,v;
}e[157];
int first[157],nt[157],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int P,N;
int in[157],root,out[157];
int sz[157],DP[157][157];
int ans=0x7f7f7f7f;
void dfs(int u)
{
	int v,lt;
	sz[u]=1;
	DP[u][1]=out[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dfs(v);
		sz[u]+=sz[v];
		lt=min(sz[u],P);
		for(int V=lt;V>=0;V--)
			for(int j=1;j<V;j++)
				DP[u][V]=min(DP[u][V],DP[u][V-j]+DP[v][j]-1);
	}
	if(u==root) ans=min(DP[u][P],ans);
	else ans=min(DP[u][P]+1,ans);
	return ;
}
int main()
{
	memset(DP,0x7f,sizeof(DP));
	scanf("%d%d",&N,&P);
	int u,v;
	for(int i=1;i<N;i++)
	{
		scanf("%d%d",&u,&v);
		addE(u,v);
		in[v]++;out[u]++;
	}
	for(int i=1;i<=N;i++)
	{
		if(in[i]==0)
		{
			root=i;
			dfs(root);
			printf("%d",ans);
			return 0;
		}
	}
}
