#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
char m[107][207];
bool book[107][207];
int nt[4][2]={{-1,0},{0,1},{1,0},{0,-1}};
int N;
int ans;
inline void DFS(int x,int y)
{
	if(book[x][y]) return ;
	book[x][y]=true;
	int nx,ny;
	for(int i=0;i<4;i++)
	{
		nx=x+nt[i][0];ny=y+nt[i][1];
		if(nx<1||nx>N||ny<1||ny>strlen(m[x]+1)) continue;
		if(m[nx][ny]<'a'||m[nx][ny]>'z') continue;
		DFS(nx,ny);
	}
	return ;
}
int main()
{
	cin>>N;
	cin.getline(m[0],sizeof(m[0]));
	for(int i=1;i<=N;i++)
		cin.getline(m[i]+1,sizeof(m[i]));
	for(int i=1;i<=N;i++)
		for(int j=1;j<=strlen(m[i]+1);j++)
		if(book[i][j]==false&&m[i][j]>='a'&&m[i][j]<='z') DFS(i,j),ans++;
	printf("%d",ans);
	return 0;
} 
