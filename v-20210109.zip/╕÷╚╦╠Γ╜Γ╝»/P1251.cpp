#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
using namespace std;
const int maxn=5007;
const int maxm=10000007;
const int inf=0x7f7f7f7f;
#define getchar() (SS == TT && (TT = (SS = BB) + fread(BB,1,1 << 15,stdin),TT == SS) ? EOF : *SS++)
char BB[1<<15],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
typedef long long LL;
struct E{
    int u,v,w,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int w,int cf)
{
    e[++ES]=(E){u,v,w,cf};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int w,int cf)
{
    addE(u,v,w,cf);addE(v,u,-w,0);
    return ;
}
int N,M,S,T;
int pi,qi,pc,qc;
LL dis[maxn];
int f[maxn],pre[maxn][2];
bool book[maxn];
int q[maxm*2];
int head,tail;
bool SPFA()
{
    memset(dis,0x7f,sizeof(dis));
    memset(f,0x7f,sizeof(f));
    head=1;tail=0;
    q[++tail]=S;dis[S]=0;
    book[S]=true;
    int u,v;
    while(head<=tail)
    {
        u=q[head];++head;book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&dis[u]+e[i].w<dis[v])
            {
                dis[v]=dis[u]+e[i].w;
                f[v]=min(f[u],cf(i));
                pre[v][0]=u;pre[v][1]=i;
                if(!book[v])
                {
                    book[v]=true;
                    q[++tail]=v;
                }
            }
        }
    }
    return f[T]!=inf;
}
void Update()
{
    int u=T;
    while(u!=S)
    {
        cf(pre[u][1])-=f[T];
        cf(pre[u][1]^1)+=f[T];
        u=pre[u][0];
    }
    return ;
}
int A[maxn];
int mk[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    for(int i=1;i<=N;i++)
        A[i]=R();
    M=R();
    pi=R();pc=R();
    qi=R();qc=R();
    T=N*2+2;
    for(int i=1;i<=N;i++)
    {
        add(S,i*2,M,A[i]);
        add(S,i*2+1,0,A[i]);
        if(i+pi<=N)
        add(i*2+1,i*2+pi*2,pc,inf);
        if(i+qi<=N)
        add(i*2+1,i*2+qi*2,qc,inf);
        if(i!=N) add(i*2+1,i*2+3,0,inf);
        add(i*2,T,0,A[i]);
    }
    LL ans=0;
    while(SPFA())
    {
        ans+=dis[T]*f[T];
        Update();
    }
    printf("%lld",ans);
    return 0;
}