#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
const int maxn=50007;
struct node{
	int x,h;
}C[maxn];
int N,D;
bool cr[maxn][2];
bool com(const node &x,const node &y)
{
	return x.x<y.x;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct qu{
	int q[maxn],head,tail;
	qu() {head=1;tail=0;}
	int f()
	{
		return q[head];
	}
	int b()
	{
		return q[tail];
	}
	void popf()
	{
		if(head<=tail) ++head;
		return ; 
	}
	void popb()
	{
		if(head<=tail) --tail;
		return ;
	}
	void push(int x)
	{
		q[++tail]=x;
		return ;
	}
	bool empty()
	{
		return head>tail;
	}
	void clear()
	{
		head=1;tail=0;
		return ;
	}
}q;
int main()
{
	N=R();D=R();
	for(register int i=1;i<=N;i++)
		C[i].x=R(),C[i].h=R();
	sort(C+1,C+1+N,com);
	for(register int i=1;i<=N;i++)
	{
		while(!q.empty()&&C[q.f()].x<C[i].x-D)
			q.popf();
		
		if(!q.empty()&&C[q.f()].h>=C[i].h*2)
			cr[i][0]=true;
		
		while(!q.empty()&&C[q.b()].h<=C[i].h)
			q.popb();
		
		q.push(i);
	}
	q.clear();
	for(register int i=N;i>0;i--)
	{
		while(!q.empty()&&C[q.f()].x>C[i].x+D)
			q.popf();
		
		if(!q.empty()&&C[q.f()].h>=C[i].h*2)
			cr[i][1]=true;
		
		while(!q.empty()&&C[q.b()].h<=C[i].h)
			q.popb();
		
		q.push(i);
	}
	int ans=0;
	for(register int i=1;i<=N;i++)
	ans+=cr[i][0]&&cr[i][1];
	printf("%d",ans);
	return 0; 
}
