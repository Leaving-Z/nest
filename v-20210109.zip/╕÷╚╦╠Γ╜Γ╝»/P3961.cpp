#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
const int maxn=107;
struct node{
	int x,y,t,v;
}tmp[maxn];
vector <int> v[maxn],t[maxn];
int bel[maxn];
bool operator < (const node &x,const node &y)
{
	return x.y<y.y;
}
int cnt,sum[maxn];
int N,T;
int F[40007];
int main()
{
	scanf("%d%d",&N,&T);
	for(register int i=1;i<=N;i++)
		scanf("%d%d%d%d",&tmp[i].x,&tmp[i].y,&tmp[i].t,&tmp[i].v);
	sort(tmp+1,tmp+1+N);
	for(register int i=1;i<=N;i++)
		for(register int j=i+1;j<=N;j++)
		if(tmp[i].x*tmp[j].y==tmp[i].y*tmp[j].x)
		{
			if(!bel[i]&&!bel[j])
			{
				bel[i]=++cnt;
				t[cnt].push_back(tmp[i].t);v[cnt].push_back(tmp[i].v);
				bel[j]=cnt;
				t[cnt].push_back(tmp[j].t);v[cnt].push_back(tmp[j].v);
			}
		}
	for(register int i=1;i<=N;i++)
	if(!bel[i]) bel[i]=++cnt,t[bel[i]].push_back(tmp[i].t),v[bel[i]].push_back(tmp[i].v);
	for(register int i=1;i<=cnt;i++)
		for(register int j=1;j<t[i].size();j++)
			t[i][j]+=t[i][j-1],v[i][j]+=v[i][j-1];
	for(register int i=1;i<=cnt;i++)
		for(register int j=T;j>=0;j--)
			for(register int k=0;k<t[i].size();k++)
			if(j>=t[i][k]) F[j]=max(F[j],F[j-t[i][k]]+v[i][k]);
	printf("%d",F[T]);
	return 0;
}
