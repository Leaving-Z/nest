#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=150007;
const int maxv=1000007;
const int SIZE=3000;
struct change{
    int p,a,b;//[p]:a->b
}c[maxn];
struct query{
    int l,r,id,t;
}q[maxn];
int mk[maxv];
int bl[maxn];
bool operator < (const query &x,const query &y)
{
    if(bl[x.l]!=bl[y.l]) return bl[x.l]<bl[y.l];
    if(bl[x.r]!=bl[y.r]) return bl[x.r]<bl[y.r];
    return x.t<y.t;
}
int N,Q;
int A[maxn],B[maxn];
int ans[maxn];
int apply(int l,int r,change x,int k)
{
    int pos=x.p,a=x.a,b=x.b,re=0;
    if(k) swap(a,b);
    if(pos>=l&&pos<=r) re-=!(--mk[a]);
    A[pos]=b;
    if(pos>=l&&pos<=r) re+=!(mk[b]++);
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]),B[i]=A[i],bl[i]=(i-1)/SIZE+1;
    int totc=0,totq=0;
    char qwq[7];
    for(int i=1;i<=Q;i++)
    {
        scanf("%s",qwq);
        if(qwq[0]=='Q')
        {
            ++totq;
            scanf("%d%d",&q[totq].l,&q[totq].r);
            q[totq].id=totq;q[totq].t=totc;
        }
        else
        {
            ++totc;
            scanf("%d%d",&c[totc].p,&c[totc].b);
            c[totc].a=B[c[totc].p];
            B[c[totc].p]=c[totc].b;
        }
    }
    sort(q+1,q+1+totq);
    int l=1,r=0,ll,rr,t,cur=0,res=0;
    for(int i=1;i<=totq;i++)
    {
        ll=q[i].l;rr=q[i].r;t=q[i].t;
        while(ll<l) res+=!(mk[A[--l]]++);
        while(ll>l) res-=!(--mk[A[l++]]);
        while(rr>r) res+=!(mk[A[++r]]++);
        while(rr<r) res-=!(--mk[A[r--]]);
        while(t>cur) res+=apply(l,r,c[++cur],0);
        while(t<cur) res+=apply(l,r,c[cur--],1);
        ans[q[i].id]=res;
    }
    for(int i=1;i<=totq;i++)
        printf("%d\n",ans[i]);
    return 0;
}