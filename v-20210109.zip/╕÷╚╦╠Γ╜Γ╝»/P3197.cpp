#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int mod=100003;
typedef long long LL;
LL fast_pow(LL b,LL k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&M,&N);
    printf("%lld",(fast_pow(M,N)-M*fast_pow(M-1,N-1)%mod+mod)%mod);
    return 0;
}