#include<cstdio>
#include<algorithm>
#include<bitset>
#include<cstring>
#include<iostream>
using namespace std;
int Trie[500007][26];
bitset <1007> book[500007];
char s[27];
int N,M,all;
inline void Insert(int x)
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	book[p][x]=1;
	return ;
}
inline void check()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
		{
			cout<<' '<<endl;
			return ;
		}
		p=Trie[p][t];
	}
	bool flag=false;
	for(int i=1;i<=N;i++)
	{
		if(book[p][i]==1)
			cout<<i<<' ';
	}
	cout<<endl;
	return ;
}
int reads(char *s)
{
    int len=0,c; while((c=getchar())==10||c==13||c==32);
    if(c==EOF) return -1;
    s[len++]=c;  while((c=getchar())!=10&&c!=13&&c!=32&&c!=EOF)
    s[len++]=c;  s[len]=0; return len;
}
int main()
{
	cin.tie(0);
	cin>>N;
	int x;
	for(int i=1;i<=N;i++)
	{
		cin>>x;
		for(int j=1;j<=x;j++)
		{
			reads(s);
			Insert(i);
		}
	}
	cin>>M;
	for(int i=1;i<=M;i++)
	{
		reads(s);
		check();
	}
	return 0;
} 
