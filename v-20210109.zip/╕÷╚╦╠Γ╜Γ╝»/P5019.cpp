#include<cstdio>
int ans;
int t,x,N;
int main()
{
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&x);
        if(x>t) ans+=x-t;
        t=x;
    }
    printf("%d",ans);
    return 0;
}
