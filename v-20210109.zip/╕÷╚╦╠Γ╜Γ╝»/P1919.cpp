#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=(1<<21)+1;
const double pi=acos(-1);
struct Virt{
	double a,b;
	Virt (double x=0,double y=0) {this->a=x,this->b=y;}
	Virt operator + (const Virt &y) const
		{return Virt(a+y.a,b+y.b);}
	Virt operator - (const Virt &y) const
		{return Virt(a-y.a,b-y.b);} 
	Virt operator * (const Virt &y) const
		{return Virt(a*y.a-b*y.b,a*y.b+b*y.a);}
};
Virt A[maxn],B[maxn];
int rev[maxn];
int N,M;
void FFT(Virt F[],int len,int ty)
{
	for(int i=0;i<len;i++)
	if(i>rev[i]) swap(F[i],F[rev[i]]);
	Virt u,t;
	for(int h=2;h<=len;h<<=1)
	{
		Virt wn(cos(2*pi/h),ty*sin(2*pi/h));
		for(int i=0;i<len;i+=h)
		{
			Virt w(1,0);
			for(int j=i;j<i+h/2;j++)
			{
				u=F[j];t=w*F[j+h/2];
				F[j]=u+t;F[j+h/2]=u-t;
				w=w*wn;
			}
		}
	}
	if(ty==-1)
	{
		for(int i=0;i<=len;i++)
			F[i].a/=len;
	}
	return ;
}
char stk[maxn];
int top;
int main()
{
	freopen("P1919_2.in","r",stdin);
	freopen("QwQ.txt","w",stdout);
	char c;
	while((c=getchar())>'9'||c<'0');
	A[N++].a=c-48;
	while((c=getchar())>='0'&&c<='9')
	A[N++].a=c-48;
	
	while((c=getchar())>'9'||c<'0');
	B[M++].a=c-48;
	while((c=getchar())>='0'&&c<='9')
	B[M++].a=c-48;
	
	for(int i=0;i<N/2;i++)
		swap(A[i],A[N-i-1]);
	for(int i=0;i<M/2;i++)
		swap(B[i],B[M-i-1]);
	/*scanf("%d%d",&N,&M);
	for(int i=0;i<=N;i++)
		scanf("%lf",&A[i].a);
	for(int i=0;i<=M;i++)
		scanf("%lf",&B[i].a);*/
	
	int lim=1,l=0;
	while(lim<=N+M) lim<<=1,l++;
	for(int i=1;i<=lim;i++)
		rev[i]=(rev[i>>1]>>1)|((i&1)<<(l-1));
	FFT(A,lim,1);
	FFT(B,lim,1);
	for(int i=0;i<=lim;i++)
		A[i]=A[i]*B[i];
	FFT(A,lim,-1);
	int tmp;
	while((int)(A[N+M].a+0.5)==0&&N+M>=0) N--;
	for(int i=0;i<=N+M;i++)
	{
		tmp=(int)(A[i].a+0.5);
		if(tmp>=10) A[i+1].a+=tmp/10,tmp%=10,N+=(i==N+M);
		stk[++top]=tmp+48;
	}
	while(top>0) putchar(stk[top--]);
	return 0;
}
