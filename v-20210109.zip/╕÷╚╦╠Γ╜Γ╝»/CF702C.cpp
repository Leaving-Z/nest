#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
typedef long long LL;
LL A[maxn],B[maxn];
int N,M;
int l[maxn],r[maxn];
LL abs_(const LL &x)
{
    return x>=0?x:-x;
}
bool check(LL p)
{
    for(int i=1;i<=N;i++)
    {
        if(!(l[i]&&abs_(B[l[i]]-A[i])<=p||r[i]&&abs_(B[r[i]]-A[i])<=p))
            return false;
    }
    return true;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%lld",&A[i]);
    for(int i=1;i<=M;i++)
        scanf("%lld",&B[i]);
    sort(B+1,B+1+M);
    int p;
    for(int i=1;i<=N;i++)
    {
        p=upper_bound(B+1,B+1+M,A[i])-B;
        if(p!=M+1) r[i]=p;
        if(p!=1) l[i]=p-1;
    }
    LL L=0,R=2e9,mid,ans;
    while(L<=R)
    {
        mid=L+R>>1;
        if(check(mid)) R=mid-1,ans=mid;
        else L=mid+1;
    }
    printf("%lld",ans);
    return 0;
}