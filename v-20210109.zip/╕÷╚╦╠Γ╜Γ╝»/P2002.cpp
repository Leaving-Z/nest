#include<cstdio>
#include<algorithm>
#include<stack>
using namespace std;
inline int R()
{
	char c;
	int f=1,re=0;
	while((c=getchar())>'9'||c<'0')
		if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
		re=re*10+c-48;
	return re*f;
}
stack <int> s;
int S[100007];
struct E{
	int u,v;
}e[500007];
int first[100007],nt[500007];
int C,T;
int dfn[100007],low[100007];
bool instack[100007];
int in[100007];
int N,M;
void Tarjan(int u);
int main()
{
	N=R();M=R();
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		e[i]=(E){u,v};
		nt[i]=first[u];
		first[u]=i;
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	for(int i=1;i<=M;i++)
	{
		if(S[e[i].u]!=S[e[i].v])
			in[S[e[i].v]]++;
	}
	int ans=0;
	for(int i=1;i<=C;i++)
	if(in[i]==0) ans++;
	printf("%d",ans);
	return 0;
}
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	instack[u]=true;
	s.push(u);
	for(int i=first[u];i;i=nt[i])
	{
		if(dfn[e[i].v]==0)
		{
			Tarjan(e[i].v);
			low[u]=min(low[u],low[e[i].v]);
		}
		else if(instack[e[i].v])
		low[u]=min(dfn[e[i].v],low[u]);
	}
	if(low[u]==dfn[u])
	{
		C++;
		int p;
		while(s.top()!=u)
		{
			p=s.top();
			s.pop();
			S[p]=C;
			instack[p]=false;
		}
		s.pop();
		S[u]=C;
		instack[u]=false;
	}
	return ;
}
