#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=500007;
struct E{
	int u,v;
}e[maxn];
int first[maxn],nt[maxn],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int dfn[maxn],low[maxn],T,C;
int stk[maxn],top,S[maxn];
bool ins[maxn],ed[maxn],Ed[maxn];
int val[maxn],V[maxn];
int s,num;
void dfs(int u)
{
	stk[++top]=u;
	ins[u]=true;
	dfn[u]=low[u]=++T;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			V[C]-=val[p];
			S[p]=C;
			if(ed[p]) Ed[C]=true;
		}while(p!=u);
	}
}
queue <int> q;
bool book[maxn];
int dis[maxn];
void SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	dis[s]=V[s];
	int u,v;
	q.push(s);
	book[s]=true;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+V[v]<dis[v])
			{
				dis[v]=dis[u]+V[v];
				if(!book[v])
				{
					q.push(v);
					book[v]=true;
				}
			}
		}
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		addE(u,v);
	}
	for(register int i=1;i<=N;i++)
		val[i]=R();
	s=R();num=R();
	for(register int i=1;i<=num;i++)
	{
		u=R();
		ed[u]=true;
	}
	for(register int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	memset(first,0,sizeof(first));
	memset(nt,0,sizeof(nt));
	ES=0;
	for(register int i=1;i<=M;i++)
	{
		if(S[e[i].u]!=S[e[i].v])
			addE(S[e[i].u],S[e[i].v]);
	}
	s=S[s];
	SPFA();
	int ans=0;
	for(register int i=1;i<=C;i++)
	if(Ed[i]) ans=max(-dis[i],ans);
	printf("%d",ans);
	return 0;
}
