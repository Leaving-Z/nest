#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
const int maxn=4000007;
queue <int> q;
int Trie[maxn][4];
int fail[maxn];
bool book[maxn];
inline int V(char x)
{
	if(x=='E') return 0;
	if(x=='S') return 1;
	if(x=='W') return 2;
	if(x=='N') return 3;
}
char s[10000007],s1[100007][107];
int N,M,all;
inline void Insert(int x)
{
	int p=0,t;
	for(int i=0;s1[x][i];i++)
	{
		t=V(s1[x][i]);
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	return ;
}
inline void Ready()
{
	int u,v;
	for(int i=0;i<4;i++)
	if(Trie[0][i]) q.push(Trie[0][i]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<4;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v);
			else Trie[u][i]=Trie[fail[u]][i];
		} 
	}
	return ;
}
inline void AC_Auto()
{
	Ready();
	int p=0;
	for(int i=0;s[i];i++)
	{
		p=Trie[p][V(s[i])];
		for(int j=p;j;j=fail[j])
			book[j]=true;
	}
	return ;
}
inline int Check(int x)
{
	int p=0,t,ans=0;
	for(int i=0;s1[x][i];i++)
	{
		t=V(s1[x][i]);
		p=Trie[p][t];
		if(book[p]) ans=i+1;
	}
	return ans;
}
int main()
{
	scanf("%d%d",&N,&M);
	scanf("%s",s);
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s1[i]);
		Insert(i);
	}
	AC_Auto();
	for(int i=1;i<=M;i++)
		printf("%d\n",Check(i));
	return 0;
}
