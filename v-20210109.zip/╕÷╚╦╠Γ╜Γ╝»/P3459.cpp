#include<cstdio>
#include<cstring>
#include<cctype>
#include<algorithm>
using namespace std;
const int maxn=250007;
const int maxm=500007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int fa[maxn],sz[maxn],son[maxn],depth[maxn];
int N,M;
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int id[maxn],top[maxn],ix;
void dfs2(int u,int tp)
{
    top[u]=tp;id[u]=++ix;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==son[u]||v==fa[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int C[maxn];
void update(int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&(-x);
    return ;
}
int query(int x)
{
    int re=0;
    while(x) re+=C[x],x-=x&(-x);
    return re;
}
int sum(int l,int r)
{
    if(l>r) return 0;
    return query(r)-query(l-1);
}
int query_path(int x,int y)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re+=sum(id[top[x]],id[x]);
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re+=sum(id[x]+1,id[y]);
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);addE(v,u);
    }
    dfs1(1);dfs2(1,1);
    char s[7];
    int x,y;
    scanf("%d",&M); 
    for(int i=1;i<N+M;i++)
    {
        scanf("%s",s+1);
        if(s[1]=='A')
        {
            scanf("%d%d",&x,&y);
            x=depth[x]>depth[y]?x:y;
            update(id[x],1);
        }
        else
        {
            scanf("%d",&x);
            printf("%d\n",depth[x]-query_path(1,x));
        }
    }
    return 0;
}