#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1000007;
typedef long long LL;
int N;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
LL f[maxn],g[maxn],sz[maxn];
void dfs1(int u,int fa)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa) continue;
		dfs1(v,u);
		sz[u]+=sz[v];
		f[u]+=f[v]+sz[v];
	}
	return ;
}
LL ans1,ans2;
void dfs2(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa) continue;
		g[v]=(N-sz[v])+g[u]-sz[v];
		dfs2(v,u);
	}
	if(g[u]>ans1) {ans1=g[u];ans2=u;}
	return ;
}
int main()
{
	N=R();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	dfs1(1,0);
	g[1]=f[1];
	dfs2(1,0);
	printf("%lld",ans2);
	/*for(int i=1;i<=N;i++)
		printf("f[%d]=%lld g[%d]=%lld\n",i,f[i],i,g[i]);*/
	return 0;
}
