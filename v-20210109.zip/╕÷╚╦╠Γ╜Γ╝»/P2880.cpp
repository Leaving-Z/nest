#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int RMQmin[50007][20],RMQmax[50007][20];
int N,Q;
inline int LOG(int x)//floor(log2(x))
{
	if(x==1) return 0;
	int k=1;
	while((1<<k)<=x) k++;
	return k-1;
} 
int main()
{
	memset(RMQmin,0x7f,sizeof(RMQmin));
	N=R();Q=R();
	for(int i=1;i<=N;i++)
	{
		RMQmin[i][0]=R();
		RMQmax[i][0]=RMQmin[i][0];
	}
	for(int i=1;(1<<i)<=N;i++)
		for(int j=1;j+(1<<i)-1<=N;j++)
		{
			RMQmin[j][i]=min(RMQmin[j][i-1],RMQmin[j+(1<<i-1)][i-1]);
			RMQmax[j][i]=max(RMQmax[j][i-1],RMQmax[j+(1<<i-1)][i-1]);
		}
	int k,A,B;
	for(int i=1;i<=Q;i++)
	{
		A=R();B=R();
		if(A==B) printf("0\n");
		else
		{
			k=LOG(B-A+1);
			printf("%d\n",max(RMQmax[A][k],RMQmax[B-(1<<k)+1][k])-min(RMQmin[A][k],RMQmin[B-(1<<k)+1][k]));
		}
	}
	return 0;
}
