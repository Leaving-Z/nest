#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int N,M;
const int maxn=207;
const int maxm=40007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
bool book[maxn];
int match[maxn];
inline bool dfs(int u)
{
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!book[v])
		{
			book[v]=true;
			if(!match[v]||dfs(match[v]))
			{
				match[u]=v;
				match[v]=u;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	N=R();M=R();
	int u,v;
	while(true)
	{
		u=R();v=R();
		if(u==-1) break;
		addE(u,v);addE(v,u);
	}
	int ans=0;
	for(int i=1;i<=N;i++)
	{
		memset(book,0,sizeof(book));
		if(dfs(i)) ++ans;
	}
	printf("%d",ans);
	for(register int i=1;i<=N;i++)
	{
		if(match[i])
			printf("\n%d %d",i,match[i]);
	}
	return 0;
}
