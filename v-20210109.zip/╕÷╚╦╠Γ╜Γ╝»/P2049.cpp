#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=107;
int F[maxn][maxn][maxn];
int m[maxn][maxn];
int N,M,K;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d%d",&N,&M,&K);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%d",&m[i][j]);
	F[1][1][m[1][1]%K]=1;
	int t;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			for(int k=0;k<K;k++)
			{
				t=k*m[i][j]%K;
				if(i>1) F[i][j][t]+=F[i-1][j][k];
				if(j>1) F[i][j][t]+=F[i][j-1][k];
			}
	int ans=0;
	for(int i=0;i<K;i++)
	if(F[N][M][i]) ans++;
	printf("%d\n",ans);
	for(int i=0;i<K;i++)
	if(F[N][M][i]) printf("%d ",i);
	return 0;
}
