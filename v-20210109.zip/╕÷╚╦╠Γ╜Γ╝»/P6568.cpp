#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=1000007;
int sum[maxn];
int N,K;
int ans;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	//freopen("kettle.in","r",stdin);
	//freopen("kettle.out","w",stdout);
	N=R();K=R();
	K++;
	for(register int i=1;i<=N;i++)
	{
		sum[i]=R();
		sum[i]+=sum[i-1];
		if(i>=K) ans=max(ans,sum[i]-sum[i-K]);
	}
	printf("%d",ans);
	return 0;
}
