#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1000007;
int sum[maxn<<1];
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int q[maxn<<1];
int head=1,tail;
int N,ans;
int main()
{
	//freopen("P2629_1.in","r",stdin);
	N=R();
	for(register int i=1;i<=N;i++)
		sum[i]=R(),sum[i]+=sum[i-1];
	for(register int i=1;i<=N;i++)
		sum[i+N]=sum[i]-sum[i-1]+sum[i+N-1];
	for(register int i=1;i<2*N;i++)
	{
		while(head<=tail&&q[head]<=i-N) head++;
		while(head<=tail&&sum[i]<=sum[q[tail]]) tail--;
		q[++tail]=i;;
		if(i-N>=0&&sum[q[head]]-sum[i-N]>=0) ans++;
	}
	printf("%d",ans);
	return 0;
}
