#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
char s1[maxn],s[maxn];
int p[maxn],cnt,D,pos,N;
int mn[maxn<<2],tg[maxn<<2];
#define ls (i<<1)
#define rs (i<<1|1)
void update(int L,int R,int l,int r,int k,int i)
{
    if(l<=L&&R<=r)
    {
        mn[i]=min(mn[i],k);
        tg[i]=min(tg[i],k);
        return ;
    }
    int mid=L+R>>1;
    if(l<=mid) update(L,mid,l,r,k,ls);
    if(r>mid) update(mid+1,R,l,r,k,rs);
    mn[i]=min(mn[i],min(mn[ls],mn[rs]));
    return ;
}
int query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return min(tg[i],mn[i]);
    int re=tg[i];
    int mid=L+R>>1;
    if(l<=mid) re=min(re,query(L,mid,l,r,ls));
    if(r>mid) re=min(re,query(mid+1,R,l,r,rs));
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%s",s1+1);
    N=strlen(s1+1);
    for(int i=1;i<=N;i++)
        s[++cnt]='*',s[++cnt]=s1[i];
    s[++cnt]='*';
    p[1]=1;pos=1;
    for(int i=2,i1;i<=cnt;i++)
    {
        if(i>D)
        {
            while(p[i]<i&&i+p[i]<=cnt&&s[i-p[i]]==s[i+p[i]]) ++p[i];
            D=i+p[i]-1;pos=i;
        }
        else
        {
            i1=(pos<<1)-i;
            p[i]=min(p[i1],D-i+1);
            if(p[i]==D-i+1)
                while(p[i]<i&&i+p[i]<=cnt&&s[i-p[i]]==s[i+p[i]]) ++p[i];
            if(i+p[i]-1>D) D=i+p[i]-1,pos=i;
        }
    }
    memset(mn,0x3f,sizeof(mn));
    memset(tg,0x3f,sizeof(tg));
    int ans=0,t;
    for(int i=2;i<=cnt-1;i++)
    {
        t=query(1,cnt,max(1,i-p[i]+1),i,1);
        ans=max(ans,i-t);
        update(1,cnt,i,i+p[i]-1,i,1);
    }
    printf("%d",ans);
    return 0;
}