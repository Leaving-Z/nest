#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=40007;
const int maxm=80007;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
const int lim=40000;
int N,K;
int C[maxn];
void update(int x,int k) {while(x<=lim) C[x]+=k,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re+=C[x],x&=(x-1);return re;}
struct node{
    int anc,dis;
}A[maxn];
bool com1(const node &x,const node &y)
{
    return x.dis<y.dis||x.dis==y.dis&&x.anc<y.anc;
}
bool com2(const node &x,const node &y)
{
    return x.anc<y.anc||x.anc==y.anc&&x.dis<y.dis;
}
int root,sz[maxn],maxsz[maxn],cnt;
bool vis[maxn];
void findrt(int u,int fa,int totsz)
{
    sz[u]=1;maxsz[u]=0;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        findrt(v,u,totsz);
        sz[u]+=sz[v];
        maxsz[u]=max(maxsz[u],sz[v]);
    }
    maxsz[u]=max(maxsz[u],totsz-sz[u]);
    if(!root||maxsz[u]<maxsz[root]) root=u;
    return ;
}
void dfs(int u,int fa,int d,int an)
{
    int v;
    ++cnt;
    A[cnt].anc=an;A[cnt].dis=d;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa||vis[v]) continue;
        dfs(v,u,d+e[i].w,an);
    }
    return ;
}
int ans;
void calc(int u)
{
    int v;
    cnt=0;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(vis[v]) continue;
        dfs(v,u,e[i].w,v);
    }
    sort(A+1,A+1+cnt,com1);
    for(int i=1;i<=cnt;i++)
        if(A[i].dis<=K)
            ans+=query(K-A[i].dis)+1,update(A[i].dis,1);
    for(int i=1;i<=cnt;i++)
        if(A[i].dis<=K) update(A[i].dis,-1);
    sort(A+1,A+1+cnt,com2);
    int p,st;
    for(int i=1;i<=cnt;i++)
    {
        p=A[i].anc;
        st=i;
        while(i<=cnt&&A[i].anc==p)
        {
            if(A[i].dis<=K)
                ans-=query(K-A[i].dis),update(A[i].dis,1);
            ++i;
        }
        for(int k=st;k<i;k++)
            if(A[k].dis<=K)
                update(A[k].dis,-1);
        if(i==cnt+1) break;
        else --i;
    }
}
void solve(int u)
{
    vis[u]=true;
    calc(u);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(vis[v]) continue;
        root=0;
        findrt(v,u,sz[u]);
        solve(root);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v,w;
    for(int i=1;i<N;i++)
        scanf("%d%d%d",&u,&v,&w),addE(u,v,w),addE(v,u,w);
    scanf("%d",&K);
    findrt(1,0,N);
    solve(root);
    printf("%d",ans);
    return 0;
}