#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=507;
int N,M;
struct E{
	int u,v;
}e[maxn<<2];
int first[maxn],nt[maxn<<2],ES;
int w1[maxn],v1[maxn],w[maxn],V[maxn];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int dfn[maxn],low[maxn],ix;
int st[maxn],top;
bool ins[maxn],book[maxn];
int id[maxn],C=1;
void dfs(int u)
{
	st[++top]=u;
	ins[u]=true;
	dfn[u]=low[u]=++ix;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v])
		{
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		do{
			p=st[top--];
			id[p]=C;
			ins[p]=false;
			w[C]+=w1[p];
			V[C]+=v1[p];
		}while(p!=u);
	}
	return ;
}
int F[maxn][maxn];
void dfs(int u,int fa)
{
	int v;
	if(w[u]>M) return ;
	for(int i=w[u];i<=M;i++)
		F[u][i]=V[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			for(int j=M;j>=w[u];j--)
			{
				for(int k=w[u];k<=j;k++)
					F[u][j]=max(F[u][j],F[u][k]+F[v][j-k]);
			}
		}
	}
	return ;
}
int main()
{
	//freopen("Hack.txt","r",stdin);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		scanf("%d",&w1[i]);
	for(int i=1;i<=N;i++)
		scanf("%d",&v1[i]);
	int d;
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&d);
		if(d) addE(d,i);
	}
	for(int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	memset(first,0,sizeof(first));
	memset(nt,0,sizeof(nt));
	int t=ES;
	for(int i=1;i<=t;i++)
	{
		if(id[e[i].u]!=id[e[i].v])
		{
			addE(id[e[i].u],id[e[i].v]);
			book[id[e[i].v]]=true;
		}
	}
	for(int i=2;i<=C;i++)
	if(!book[i]) addE(1,i);
	dfs(1,0);
	printf("%d",F[1][M]);
	return 0;
}
