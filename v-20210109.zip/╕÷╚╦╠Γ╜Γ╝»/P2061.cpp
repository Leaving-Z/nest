#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=80007;
struct Line{
    int l,r,h,v;
}line[maxn<<1];
bool operator < (const Line &x,const Line &y)
{
    return x.h<y.h;
}
int N;
int d[maxn<<1],id[maxn<<1][2];
struct seg_tree{
    int sum,len;
}TREE[maxn<<3];
#define sum(i) TREE[i].sum
#define len(i) TREE[i].len
#define Ls (i<<1)
#define Rs (i<<1|1)
#define mid (L+R>>1)
void pushup(int L,int R,int i)
{
    if(sum(i)) len(i)=d[R+1]-d[L];
    else len(i)=len(Ls)+len(Rs);
    return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
    if(l>r) return ;
    if(l<=L&&R<=r)
    {
        sum(i)+=k;
        pushup(L,R,i);
        return ;
    }
    if(l<=mid) Update(L,mid,l,r,k,Ls);
    if(r>mid) Update(mid+1,R,l,r,k,Rs);
    pushup(L,R,i);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int l,r,h;
    for(int i=1;i<=N;i++)
    {
        scanf("%d%d%d",&l,&r,&h);
        line[i*2]=(Line){l,r,0,1};
        line[i*2-1]=(Line){l,r,h,-1};
        d[i*2]=l;d[i*2-1]=r;
    }
    N<<=1;
    sort(d+1,d+1+N);
    sort(line+1,line+1+N);
    int tot=unique(d+1,d+1+N)-d-1;
    for(int i=1;i<=N;i++)
    {
        id[i][0]=lower_bound(d+1,d+1+tot,line[i].l)-d;
        id[i][1]=lower_bound(d+1,d+1+tot,line[i].r)-d;
    }
    long long ans=0;
    for(int i=1;i<N;i++)
    {
        Update(1,tot,id[i][0],id[i][1]-1,line[i].v,1);
        ans+=1ll*len(1)*(line[i+1].h-line[i].h);
    }
    printf("%lld",ans);
    return 0;
}