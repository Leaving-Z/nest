#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
int T;
int A[maxn],B[maxn],N;
void check()
{
    for(register int i=1;i<=N;i++)
    {
        if(A[i]==B[i]) continue;//在自己应该待的位置上
        if(A[i]%B[1]) {puts("NO");return ;}
        //不在自己位置上而且无法交换
    }
    puts("YES");
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&N);
        for(register int i=1;i<=N;i++)
            scanf("%d",&A[i]),B[i]=A[i];
        sort(B+1,B+1+N);
        check();
    }
    return 0;
}