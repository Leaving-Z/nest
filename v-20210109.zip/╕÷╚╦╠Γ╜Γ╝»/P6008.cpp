#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1007;
const int mod=1e9+7;
typedef long long LL;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
char m[maxn][maxn];
int S[maxn*maxn];
LL sz[maxn*maxn];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int N,M;
int id(int i,int j) {return (i-1)*M+j;}
void _merge(int i1,int j1,int i2,int j2)
{
    if(m[i2][j2]!='.') return ;
    int f1=f(id(i1,j1)),f2=f(id(i2,j2));
    if(f1!=f2)
    {
        S[f1]=f2;
        sz[f2]=sz[f1]*sz[f2]%mod;
    }
    return ;
}
bool book[maxn*maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%s",m[i]+1);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
            S[id(i,j)]=id(i,j),sz[id(i,j)]=1;
    int fa;
    for(int i=N;i>0;i--)
    {
        for(int j=1;j<=M;j++)
        {
            if(m[i][j]=='#') continue;
            _merge(i,j,i+1,j);
            _merge(i,j,i,j-1);
            _merge(i,j,i,j+1);
        }
        for(int j=1;j<=M;j++)
        {
            if(m[i][j]=='#') continue;
            fa=f(id(i,j));
            if(book[fa]) continue;
            book[fa]=true;sz[fa]++;
        }
        for(int j=1;j<=M;j++)
        {
            if(m[i][j]=='#') continue;
            book[f(id(i,j))]=false;
        }
    }
    LL ans=1;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        if(m[i][j]=='.'&&S[id(i,j)]==id(i,j)) (ans*=sz[id(i,j)])%=mod;
    printf("%lld",ans);
    return 0;
}