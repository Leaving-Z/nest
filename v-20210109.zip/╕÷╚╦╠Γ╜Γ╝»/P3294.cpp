#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<vector>
using namespace std;
const int maxn=510007;
const int n=100007;
int N,all;
long long ans;//Surprise Mother fker
char s[maxn];
int Trie[maxn][26],tag[maxn],sz[maxn];
bool book[maxn];
vector <int> E[maxn];
inline void Insert()
{
	int p=0,t,l;
	l=strlen(s)-1;
	for(int i=l;i>=0;i--)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];	
	}
	book[p]=true;
	return ;
}
inline void Cut(int u)
{
	if(book[u]&&u)
	{
		E[tag[u]].push_back(u);
		tag[u]=u;
	}
	for(int i=0;i<26;i++)
	{
		if(Trie[u][i])
		{
			tag[Trie[u][i]]=tag[u];
			Cut(Trie[u][i]);
		}
	}
	return ;
}
bool com(const int &a,const int &b)
{
	return sz[a]<sz[b];
}//DO NOT OVERLOAD OPERATOR!!
inline void DFS(int u)
{
	sz[u]=1;
	for(int i=0;i<E[u].size();i++)
	{
		DFS(E[u][i]);
		sz[u]+=sz[E[u][i]];
	}
	sort(E[u].begin(),E[u].end(),com);
	return ;
}
long long ix;
inline void dfs(int u)
{
	long long t=ix++;//He is a fool when he uses '++i
	for(int i=0;i<E[u].size();i++)
	{
		ans+=ix-t;
		dfs(E[u][i]);
	}
	return ;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert();
	}
	book[0]=true;//This is sooo important
	Cut(0);
	DFS(0);
	dfs(0);
	printf("%lld",ans);
	return 0;
}
