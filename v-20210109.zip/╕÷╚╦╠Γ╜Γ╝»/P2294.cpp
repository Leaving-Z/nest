#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=2007;
const int maxm=4007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int T,N,M;
bool book[maxn];
int dis[maxn];
bool dfs(int u)
{
	int v;
	book[u]=true;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dis[u]+e[i].w<dis[v])
		{
			dis[v]=dis[u]+e[i].w;
			if(book[v]||!dfs(v)) return false;
		}
	}
	book[u]=false;
	return true;
}
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		memset(first,0,sizeof(first));
		memset(nt,0,sizeof(nt));
		memset(book,0,sizeof(book));
		memset(dis,0x7f,sizeof(dis));
		ES=0;
		scanf("%d%d",&N,&M);
		int u,v,w;
		for(int i=1;i<=M;i++)
		{
			scanf("%d%d%d",&u,&v,&w);
			addE(u-1,v,w);
			addE(v,u-1,-w);
		}
		dis[0]=0;
		if(dfs(0)) puts("true");
		else puts("false");
	}
	return 0;
}
