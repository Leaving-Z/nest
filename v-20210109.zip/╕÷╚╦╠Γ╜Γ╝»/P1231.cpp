#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=50007;
const int maxm=200007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);
	addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N1,N2,N3,M1,M2,S,T;
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int d,sum=0,v;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min_(f,cf(i)));
			if(d>0)
			{
				f-=d;
				sum+=d;
				cf(i)-=d;cf(i^1)+=d; 
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	N1=R();N2=R();N3=R();
	T=N1+N1+N2+N3+1;
	M1=R();
	int u,v;
	for(register int i=1;i<=M1;i++)
	{
		u=R()+N1;v=R();
		add(v,u,1);
	}
	M2=R();
	for(register int i=1;i<=M2;i++)
	{
		u=R()+N1+N1;v=R()+N1+N1+N2;
		add(u,v,1);
	}
	for(register int i=1;i<=N2;i++)
		add(S,i,1);
	for(register int i=1;i<=N3;i++)
		add(i+N1+N1+N2,T,1);
	for(register int i=1;i<=N1;i++)
		add(i+N1,i+N1+N1,1);
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
