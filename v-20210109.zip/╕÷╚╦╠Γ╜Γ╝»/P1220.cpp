#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
#define R (L+len-1)
LL light[57][2];
LL power[57];
LL N,C;
LL DP[57][57][2];
int main()
{
	memset(DP,0x7f,sizeof(DP));
	scanf("%lld%lld",&N,&C);
	DP[C][C][0]=DP[C][C][1]=0;
	for(int i=1;i<=N;i++)
	{
		scanf("%lld%lld",&light[i][0],&light[i][1]);
		power[i]=power[i-1]+light[i][1];
	}
	for(int len=2;len<=N;len++)
		for(int L=1;R<=N;L++)
		{
			DP[L][R][0]=min(DP[L+1][R][0]+(light[L+1][0]-light[L][0])*(power[L]-power[R]+power[N])//��ǰ��ȥ�ص�Lյ�Ƶ�·�ϳ�������[L+1,R]���ĵ������ƶ��ĵ� 
						   ,DP[L+1][R][1]+(light[R][0]-light[L][0])*(power[L]-power[R]+power[N]));
			DP[L][R][1]=min(DP[L][R-1][1]+(light[R][0]-light[R-1][0])*(power[L-1]-power[R-1]+power[N])
						   ,DP[L][R-1][0]+(light[R][0]-light[L][0])*(power[L-1]-power[R-1]+power[N]));
		}
	printf("%lld",min(DP[1][N][0],DP[1][N][1]));
	return 0;
}
