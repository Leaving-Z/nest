#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1000007;
const int mod=1e9+7;
typedef long long LL;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
int N,T,M;
LL fact[maxn],inv[maxn],D[maxn];
LL C(int x,int y)
{
    return fact[x]*inv[y]%mod*inv[x-y]%mod;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    for(int i=fact[0]=1;i<maxn;i++)
        fact[i]=fact[i-1]*i%mod;
    inv[maxn-1]=fast_pow(fact[maxn-1],mod-2);
    for(int i=maxn-2;i>=0;i--)
        inv[i]=inv[i+1]*(i+1)%mod;
    D[2]=1;
    D[0]=1;
    for(int i=3;i<maxn;i++)
        D[i]=(i-1)*(D[i-1]+D[i-2])%mod;
    while(T--)
    {
        scanf("%d%d",&N,&M);
        printf("%lld\n",C(N,M)*D[N-M]%mod);
    }
    return 0;
}