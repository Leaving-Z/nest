#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=14;
const int mod=10000007;
typedef long long LL;
struct Matrix
{
    LL m[maxn][maxn];
    Matrix() {memset(m,0,sizeof(m));return ;}
    void reset()
    {
        memset(m,0,sizeof(m));
        return ;
    }
}ini,trans;
int N,M;
Matrix operator * (const Matrix &x,const Matrix &y)
{
    Matrix t;
    for(int k=1;k<=N+2;k++)
        for(int i=1;i<=N+2;i++)
            for(int j=1;j<=N+2;j++)
                t.m[i][j]=(t.m[i][j]+x.m[i][k]*y.m[k][j]%mod)%mod;
    return t;
}
Matrix operator ^ (Matrix x,int k)
{
    Matrix s;
    for(int i=1;i<=N+2;i++)
        s.m[i][i]=1;
    while(k)
    {
        if(k&1) s=s*x;
        x=x*x;
        k>>=1;
    }
    return s;
}
LL A[maxn][maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    while(scanf("%d%d",&N,&M)!=EOF)
    {
        A[0][1]=233;
        for(int i=2;i<=N+1;i++)
            A[0][i]=(A[0][i-1]*10+3)%mod;
        for(int i=1;i<=N;i++)
            scanf("%lld",&A[i][0]);
        for(int i=1;i<=N;i++)
            for(int j=1;j<N-i+1;j++)
                A[i][j]=(A[i-1][j]+A[i][j-1])%mod;
        ini.reset();trans.reset();
        for(int i=1;i<=N+1;i++)
            ini.m[1][i]=A[i-1][N-i+1];
        ini.m[1][N+2]=3;
        trans.m[1][1]=10;
        trans.m[N+2][1]=1;
        for(int i=2;i<=N+1;i++)
            trans.m[i-1][i]=trans.m[i][i]=1;
        trans.m[N+2][N+2]=1;
        trans=trans^(M);
        ini=ini*trans;
        printf("%lld\n",ini.m[1][N+1]);
    }
    return 0;
}