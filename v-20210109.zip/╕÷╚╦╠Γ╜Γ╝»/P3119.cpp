#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<ctime>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=100007;
struct E{
    int u,v;
};
struct Graph{
    E e[maxm];
    int first[maxn],nt[maxm],ES;
    inline void addE(int u,int v)
    {
        e[++ES]=(E){u,v};
        nt[ES]=first[u];
        first[u]=ES;
        return ;
    }
}G0,G1,G2;
int S[maxn],C,T,top,sz[maxn];
int low[maxn],dfn[maxn],stk[maxn];
bool ins[maxn];
int N,M;
void dfs(int u)
{
    ins[u]=true;
    stk[++top]=u;
    low[u]=dfn[u]=++T;
    int v;
    for(int i=G0.first[u];i;i=G0.nt[i])
    {
        v=G0.e[i].v;
        if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
        else if(ins[v]) low[u]=min(low[u],dfn[v]);
    }
    if(low[u]==dfn[u])
    {
        int p;C++;
        do{
            p=stk[top--];
            ins[p]=false;
            S[p]=C;
            sz[C]++;
        }while(p!=u);
    }
    return ;
}
int dis1[maxn],dis2[maxn];
bool book[maxn];
void SPFA(Graph G,int *dis)
{
    //memset(dis,-1,sizeof(dis));
    int u,v;
    q.push(S[1]);
    dis[S[1]]=sz[S[1]];
    book[S[1]]=true;
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=G.first[u];i;i=G.nt[i])
        {
            v=G.e[i].v;
            if(dis[u]+sz[v]>dis[v])
            {
                dis[v]=dis[u]+sz[v];
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        G0.addE(u,v);
    }
    for(int i=1;i<=N;i++)
    if(!dfn[i]) dfs(i);
    for(int i=1;i<=M;i++)
    if(S[G0.e[i].u]!=S[G0.e[i].v])
    {
        G1.addE(S[G0.e[i].u],S[G0.e[i].v]),G2.addE(S[G0.e[i].v],S[G0.e[i].u]);
        if(S[G0.e[i].u]==1) puts("qaq");
    }
        
    SPFA(G1,dis1);SPFA(G2,dis2);
    int ans=sz[S[1]];
    for(int i=1;i<=G1.ES;i++)
    if(dis1[G1.e[i].v]&&dis2[G1.e[i].u])
        ans=max(ans,dis1[G1.e[i].v]+dis2[G1.e[i].u]-sz[S[1]]);
    printf("%d",ans);
    return 0;
}