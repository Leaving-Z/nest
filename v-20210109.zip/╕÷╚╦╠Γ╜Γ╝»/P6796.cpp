#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxn=100007;
const int mod=998244353;
LL f[maxn],d[maxn],p[maxn];
LL A[maxn];
int op[maxn];
int N;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	char c;
	scanf("%lld",&A[1]);
	for(int i=2;i<=N;i++)
	{
		while((c=getchar())!='+'&&c!='*');
		if(c=='*') op[i]=2;
		else op[i]=1;
		scanf("%lld",&A[i]);
	}
	f[1]=d[1]=p[1]=A[1];
	for(int i=2;i<=N;i++)
	{
		if(op[i]==1)
		{
			f[i]=(f[i-1]+d[i-1]+i*A[i]%mod)%mod;
			d[i]=(d[i-1]+i*A[i]%mod)%mod;
			p[i]=i*A[i]%mod;
		}
		else
		{
			f[i]=(f[i-1]+d[i-1]+A[i]+p[i-1]*(A[i]-1)%mod)%mod;
			d[i]=(d[i-1]+A[i]+p[i-1]*(A[i]-1)%mod)%mod;
			p[i]=(p[i-1]*A[i]%mod+A[i])%mod;
		}
	}
	printf("%lld",f[N]);
	return 0;
}