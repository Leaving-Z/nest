#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
#include<stack>
using namespace std;
const int maxn=1007;
const int maxm=1000007;
int A[maxn];
int N;
int f[maxn];
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int c[maxn];
bool dfs(int u,int k)
{
    c[u]=k;
    int v;bool d=true;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(c[v]&&c[v]==k) return false;
        else if(!c[v]) d=d&&dfs(v,k^1);
    }
    return d;
}
stack <int> s1,s2;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    f[N]=A[N];f[N+1]=0x7f7f7f7f;
    for(int i=N-1;i>0;i--)
        f[i]=min(f[i+1],A[i]);
    for(int i=1;i<=N;i++)
        for(int j=i+1;j<=N;j++)
        if(A[i]<A[j]&&A[i]>f[j+1]) addE(i,j),addE(j,i);
    for(int i=1;i<=N;i++)
    if(!c[i])
        if(!dfs(i,2))
			{printf("0");return 0;}
	int cur=1;
    for(int i=1;i<=N;i++)
    {
		while(!s1.empty()&&s1.top()==cur) s1.pop(),++cur,printf("b ");
		if(c[i]!=c[1]) while(!s2.empty()&&s2.top()==cur) s2.pop(),++cur,printf("d ");
		if(c[i]==c[1]) s1.push(A[i]),printf("a ");
		else s2.push(A[i]),printf("c ");
    }
	while(!s1.empty()||!s2.empty())
	{
		while(!s1.empty()&&s1.top()==cur) printf("b "),s1.pop(),++cur;
		while(!s2.empty()&&s2.top()==cur) printf("d "),s2.pop(),++cur;
	}
    return 0;
}