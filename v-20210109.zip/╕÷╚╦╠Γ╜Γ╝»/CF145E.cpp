#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
	int re;
	char c;
	while(!isdigit(c=getchar()));
	re=c-48;
	while(isdigit(c=getchar()))
	re=re*10+c-48;
	return re;
}
const int maxn=1000007;
int N,Q;
struct seg_tree{
	int LIS,LDS,sum1,sum0;
	//LIS,LDS
}TREE[maxn<<2];
int rev[maxn<<2];
int A[maxn];
char s[maxn];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define LIS(i) TREE[i].LIS
#define LDS(i) TREE[i].LDS
#define sum1(i) TREE[i].sum1
#define sum0(i) TREE[i].sum0
inline void pushup(int i)
{
	LIS(i)=max(max(LIS(Ls)+sum1(Rs),sum0(Ls)+LIS(Rs)),max(sum0(Ls)+sum0(Rs),sum1(Ls)+sum1(Rs)));
	LDS(i)=max(max(sum1(Ls)+LDS(Rs),LDS(Ls)+sum0(Rs)),max(sum0(Ls)+sum0(Rs),sum1(Ls)+sum1(Rs)));
	sum0(i)=sum0(Ls)+sum0(Rs);
	sum1(i)=sum1(Ls)+sum1(Rs);
	return ;
}
void Build(int L,int R,int i)
{
	if(L==R)
	{
		if(A[L]) sum1(i)=LDS(i)=1,sum0(i)=LIS(i)=0;
		else sum0(i)=LIS(i)=1,sum1(i)=LDS(i)=0;
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	pushup(i);
	return ;
}
void REV(int i)
{
	rev[i]^=1;
	swap(sum1(i),sum0(i));
	swap(LIS(i),LDS(i));
	return ;
}
inline void pushdown(int i)
{
	if(!rev[i]) return ;
	REV(Ls);REV(Rs);
	rev[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		REV(i);
		return ;
	}
	pushdown(i);
	if(l<=mid) Update(L,mid,l,r,Ls);
	if(r>mid) Update(mid+1,R,l,r,Rs);
	pushup(i);
	return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();Q=R();
	scanf("%s",s+1);
	for(int i=1;i<=N;i++)
		A[i]=(s[i]=='4'?0:1);
	Build(1,N,1);
	char qwq[7];
	int l,r;
	while(Q--)
	{
		scanf("%s",qwq);
		if(qwq[0]=='s')
		{
			l=R();r=R();
			Update(1,N,l,r,1);
		}
		else printf("%d\n",LIS(1));
	}
	return 0;
}