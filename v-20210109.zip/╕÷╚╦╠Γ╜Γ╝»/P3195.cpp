#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
#define h q[head]
#define h1 q[head+1]
#define t q[tail]
#define t1 q[tail-1]
LL q[50007],tail=1,head=1;
LL N,L;
LL sum[50007],F[50007];
LL A(LL x)
{
	return sum[x]+x;
}
LL B(LL x)
{
	return sum[x]+x+L+1;
}
LL Y(LL x)
{
	return F[x]+B(x)*B(x);
}
long double getk(LL a,LL b)
{
	return (long double)(Y(a)-Y(b))/(B(a)-B(b));
}
int main()
{
	scanf("%lld%lld",&N,&L);
	for(int i=1;i<=N;i++)
	{
		scanf("%lld",&sum[i]);
		sum[i]+=sum[i-1];
	}
	for(LL i=1;i<=N;i++)
	{
		while(head<tail&&getk(h,h1)<=2*(long double)A(i)) head++;
		F[i]=F[h]+(A(i)-B(h))*(A(i)-B(h));
		while(head<tail&&getk(i,t)<getk(t,t1))
			tail--;
		q[++tail]=i;
	}
	printf("%lld",F[N]);
}
