#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=10007;
const int maxm=50007;
int N,M;
struct E{
	int u,v,w;
};
struct Graph{
	E e[maxm];
	int first[maxn],nt[maxm],ES;
	inline void addE(int u,int v,int w)
	{
		e[++ES]=(E){u,v,w};
		nt[ES]=first[u];
		first[u]=ES;
		return ;
	}
};
Graph G1,G2,G3;
int dis[maxn],pre[maxn],pre1[maxn];
bool book[maxn];
void SPFA(Graph G,int s)
{
	memset(dis,0x7f,sizeof(dis));
	dis[s]=0;book[s]=true;
	q.push(s);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=G.first[u];i;i=G.nt[i])
		{
			v=G.e[i].v;
			if(dis[u]+G.e[i].w<dis[v])
			{
				dis[v]=dis[u]+G.e[i].w;
				pre[v]=i;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
bool vis[maxn][2];
int main()
{
	scanf("%d%d",&N,&M);
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		G1.addE(v,u,w);G3.addE(u,v,2);
		scanf("%d",&w);
		G2.addE(v,u,w);
	}
	SPFA(G1,N);
	memcpy(pre1,pre,sizeof(pre));
	SPFA(G2,N);
	for(int i=1;i<N;i++)
	{
		u=i;
		while(u!=N)
		{
			if(vis[u][0]) break;
			vis[u][0]=true;
			G3.e[pre1[u]].w--;
			u=G1.e[pre1[u]].u;
		}
		u=i;
		while(u!=N)
		{
			if(vis[u][1]) break;
			vis[u][1]=true;
			G3.e[pre[u]].w--;
			u=G2.e[pre[u]].u;
		}
	}
	SPFA(G3,1);
	printf("%d",dis[N]);
	return 0;
}
