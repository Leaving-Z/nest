#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<set>
using namespace std;
const int maxn=500007;
int tree[maxn<<2];
int M=1,N,Q,W;
int pr[maxn],A[maxn];
#define ls (i<<1)
#define rs (i<<1|1)
void build()
{
    while(M<N) M<<=1;
    for(int i=1;i<=N;i++)
        tree[i+M]=pr[i];
    for(int i=M-1;i;i--)
        tree[i]=max(tree[ls],tree[rs]);
    return ;
}
void update(int i,int k)
{
    i+=M;
    tree[i]=k;
    while(i>>=1) tree[i]=max(tree[ls],tree[rs]);
    return ;
}
int query(int l,int r)
{
    int re=0;
    for(l=l+M-1,r=r+M+1;l^r^1;l>>=1,r>>=1)
    {
        if(~l&1) re=max(re,tree[l^1]);
        if(r&1) re=max(re,tree[r^1]);
    }
    return re;
}
set <int> s[maxn];
int pre(int x)
{
    int k=A[x];
    set <int>::iterator it1=s[k].lower_bound(x),it2=s[W-k].lower_bound(x);
    if(it2==s[W-k].begin()) return 0;
    if(it1==s[k].begin()) {--it2;return *it2;}
    --it1,--it2;
    if(*it1>*it2) return 0;
    return *it2;
}
int stk[17],top;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&Q,&W);
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        pr[i]=pre(i);
        s[A[i]].insert(i);
    }
    build();
    int cnt=0;
    int op,x,y,k;
    set <int>::iterator it;
    while(Q--)
    {
        scanf("%d%d%d",&op,&x,&y);
        if(op==1)
        {
            top=0;
            if(y==A[x]) continue;
            k=A[x];
            s[k].erase(x);
            stk[++top]=x;
            it=s[k].upper_bound(x);
            if(it!=s[k].end()) stk[++top]=*it;
            it=s[W-k].upper_bound(x);
            if(it!=s[W-k].end()) stk[++top]=*it;
            k=y;
            it=s[k].upper_bound(x);
            if(it!=s[k].end()) stk[++top]=*it;
            it=s[W-k].upper_bound(x);
            if(it!=s[W-k].end()) stk[++top]=*it;
            s[k].insert(x);
            A[x]=y;
            for(int i=1;i<=top;i++) update(stk[i],pre(stk[i]));
        }
        else
        {
            x^=cnt;y^=cnt;
            k=query(x,y);
            if(k>=x) puts("Yes"),++cnt;
            else puts("No");
        }
    }
    return 0;
}