#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N,M;
const int maxn=100007;
const int maxm=200007;
int A[maxn];
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int fa[maxn],depth[maxn],son[maxn],sz[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        fa[v]=u;
        depth[v]=depth[u]+1;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int id[maxn],top[maxn],ix;
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
struct seg_tree{
    int ls,rs,v;
}TREE[maxn*40];
int cnt,root[maxn];
#define Ls(i) TREE[i].ls
#define Rs(i) TREE[i].rs
#define mid (L+R>>1)
#define v(i) TREE[i].v
void Update(int L,int R,int x,int &i)
{
    if(!i) i=++cnt;
    if(L==R) {v(i)++;return ;}
    if(x<=mid) Update(L,mid,x,Ls(i));
    else Update(mid+1,R,x,Rs(i));
    v(i)=v(Ls(i))+v(Rs(i));
    return ;
}
int Query(int L,int R,int l,int r,int i)
{
    if(!i) return 0;
    if(l<=L&&R<=r) return v(i);
    int re=0;
    if(l<=mid) re+=Query(L,mid,l,r,Ls(i));
    if(r>mid) re+=Query(mid+1,R,l,r,Rs(i));
    return re;
}
int Query_Path(int x,int y,int k)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re|=Query(1,N,id[top[x]],id[x],root[k]);
        if(re) return 1;
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re|=Query(1,N,id[x],id[y],root[k]);
    return re;
}
char ans[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    for(register int i=1;i<=N;i++)
        A[i]=R();
    int u,v;
    for(register int i=1;i<N;i++)
    {
        u=R();v=R();
        addE(u,v);
        addE(v,u);
    }
    dfs1(1);dfs2(1,1);
    for(register int i=1;i<=N;i++)
        Update(1,N,id[i],root[A[i]]);
    int ty;
    for(register int i=1;i<=M;i++)
    {
        u=R();v=R();ty=R();
        if(Query_Path(u,v,ty)) ans[i]='1';
        else ans[i]='0';
    }
    for(register int i=1;i<=M;i++)
        putchar(ans[i]);
    return 0;
}