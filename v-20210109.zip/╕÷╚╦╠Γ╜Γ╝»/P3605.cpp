#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=100007;
const int maxm=100007;
int N;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int sz[maxn],id[maxn],ix;
void dfs(int u)
{
    sz[u]=1;
    id[++ix]=u;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        dfs(v);
        sz[u]+=sz[v];
    }
    return ;
}
int A[maxn],root[maxn],cnt;
struct seg_tree{
    int ls,rs,v;
}TREE[maxn*40];
#define Ls(i) TREE[i].ls
#define Rs(i) TREE[i].rs
#define mid (L+R>>1)
#define v(i) TREE[i].v
inline int cp(int i)
{
    TREE[++cnt]=TREE[i];
    return cnt;
}
int Update(int L,int R,int x,int i)
{
    i=cp(i);
    if(L==R) {v(i)++;return i;}
    if(x<=mid) Ls(i)=Update(L,mid,x,Ls(i));
    else Rs(i)=Update(mid+1,R,x,Rs(i));
    v(i)=v(Ls(i))+v(Rs(i));
    return i;
}
int Query(int L,int R,int l,int r,int i1,int i2)
{
    if(l<=L&&R<=r) return v(i2)-v(i1);
    int re=0;
    if(l<=mid) re+=Query(L,mid,l,r,Ls(i1),Ls(i2));
    if(r>mid) re+=Query(mid+1,R,l,r,Rs(i1),Rs(i2));
    return re;
}
int d[maxn],idx[maxn],ans[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    for(register int i=1;i<=N;i++)
        d[i]=A[i]=R();
    int x;
    for(register int i=2;i<=N;i++)
        x=R(),addE(x,i);
    dfs(1);
    sort(d+1,d+1+N);
    int tot=unique(d+1,d+1+N)-d-1;
    for(register int i=1;i<=N;i++)
        idx[i]=lower_bound(d+1,d+1+tot,A[i])-d;
    for(register int i=1;i<=N;i++)
        root[i]=Update(1,tot,idx[id[i]],root[i-1]);
    for(register int i=1;i<=N;i++)
        ans[id[i]]=Query(1,tot,idx[id[i]]+1,tot,root[i],root[i+sz[id[i]]-1]);
    for(register int i=1;i<=N;i++)
        printf("%d\n",ans[i]);
    return 0;
}