#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<string>
#include<unordered_map>
#include<queue>
using namespace std;
const int maxn=500007;
const int maxm=500007;
queue <int> q;
int ix;
string s1,s2;
unordered_map <string,int> mp;
int S[maxn];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int deg[maxn];
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	int u,v,f1,f2;
	for(int i=1;i<maxn;i++)
		S[i]=i;
	int cnt=0;
	s1.resize(20);s2.resize(20);
	while(scanf("%s",&s1[0])!=EOF&&scanf("%s",&s2[0])!=EOF)
	{
		if(!mp[s1]) mp[s1]=++ix;
		if(!mp[s2]) mp[s2]=++ix;
		u=mp[s1];v=mp[s2];
		f1=f(u);f2=f(v);
		if(f1!=f2) ++cnt,S[f2]=f1;
		++deg[u];++deg[v];
		s1.clear();s1.resize(20);
		s2.clear();s2.resize(20);
	}
	if(cnt<ix-1) printf("Impossible");
	else
	{
		int cnt=0;
		for(int i=1;i<=ix;i++)
			cnt+=deg[i]&1;
		if(cnt!=0&&cnt!=2) printf("Impossible");
		else printf("Possible");
	}
	return 0;
}