#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
queue <int> q;
const int maxn=427;
const int maxm=82007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int cnt[maxn],cur[maxn];
int N,M,S,T;
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	int u,v;
	q.push(S);
	cnt[S]=1;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int d,v,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cf(i)>0&&cnt[v]==cnt[u]+1)
		{
			d=dfs(v,min(cf(i),f));
			if(d>0)
			{
				f-=d;sum+=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	M=R();N=R();T=N+M+1;
	int x,ans=0;
	for(register int i=1;i<=M;i++)
		x=R(),ans+=x,add(S,i,x);
	for(register int i=1;i<=N;i++)
		add(M+i,T,R());
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
			add(j,M+i,1);
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans-=dfs(S,inf);
	}
	if(ans) putchar(48);
	else
	{
		puts("1");
		for(register int k=1;k<=M;k++)
		{
			for(register int i=first[k];i;i=nt[i])
			{
				if(e[i].v==S) continue;
				if(cf(i)==0)
					printf("%d ",e[i].v-M);
			}
			puts("");
		}	
	}
	return 0;
}
