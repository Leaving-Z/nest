#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define u_v G.m[mp[u]][mp[v]]
#define v_u G.m[mp[v]][mp[u]]
inline int min_(const int &a,const int &b)
{
	return a>b?b:a;
}
int N,T,S,E,all;
struct Matrix{
	int m[207][207];
	Matrix() {memset(m,0,sizeof(m));};
	Matrix operator * (const Matrix &A) const
	{
		Matrix X;memset(X.m,0x3f,sizeof(X.m));
		for(int k=1;k<=all;k++)
			for(int i=1;i<=all;i++)
				for(int j=1;j<=all;j++)
				X.m[i][j]=min(X.m[i][j],m[i][k]+A.m[k][j]);
		return X;
	}
}G;
int mp[1007];
Matrix operator ^ (Matrix A,int k)
{
	Matrix s=A;k--;
	while(k)
	{
		if(k&1) s=s*A;
		A=A*A;
		k>>=1;
	}
	return s;
}
int main()
{
	//freopen("P2886_2.in","r",stdin);
	scanf("%d%d%d%d",&N,&T,&S,&E);
	int u,v,w;
	memset(G.m,0x3f,sizeof(G.m));
	for(int i=1;i<=T;i++)
	{
		scanf("%d%d%d",&w,&u,&v);
		if(!mp[u]) mp[u]=++all;
		if(!mp[v]) mp[v]=++all;
		u_v=v_u=w;
	}
	G=G^N;
	printf("%d",G.m[mp[S]][mp[E]]);
	return 0;
}
