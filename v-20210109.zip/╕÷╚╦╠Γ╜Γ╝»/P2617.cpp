#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const int maxq=300007;
const int inf=1e9;
int A[maxn];
struct query{
    int l,r,ty,k,id;
}q[maxq],q1[maxq],q2[maxq];
int N,M,Q;
char s[7];
int ans[maxq];
int C[maxn];
void Update(int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&(-x);
    return ;
}
int Query(int x)
{
    int re=0;
    while(x) re+=C[x],x-=x&(-x);
    return re;
}
void solve(int l,int r,int ql,int qr)
{
    //printf("%d %d %d %d\n",l,r,ql,qr);
    if(l==r)
    {
        for(int i=ql;i<=qr;i++)
        if(q[i].ty==2) ans[q[i].id]=l;
        return ;
    }
    int mid=l+r>>1,cnt1=0,cnt2=0,x;
    for(int i=ql;i<=qr;i++)
    {
        if(q[i].ty==1)
        {
            if(q[i].l<=mid) q1[++cnt1]=q[i],Update(q[i].id,q[i].r);
            else q2[++cnt2]=q[i];
        }
        else
        {
            x=Query(q[i].r)-Query(q[i].l-1);
            if(x>=q[i].k) q1[++cnt1]=q[i];
            else q[i].k-=x,q2[++cnt2]=q[i];
        }
    }
    for(int i=1;i<=cnt1;i++)
    if(q1[i].ty==1) Update(q1[i].id,-q1[i].r);
    for(int i=1;i<=cnt1;i++) q[ql+i-1]=q1[i];
    for(int i=1;i<=cnt2;i++) q[ql+cnt1+i-1]=q2[i];
    if(cnt1)
    solve(l,mid,ql,ql+cnt1-1);
    if(cnt2)
    solve(mid+1,r,ql+cnt1,qr);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]),q[++Q]=(query){A[i],1,1,0,i};
    int l,r,x;
    int tot=0;
    for(int i=1;i<=M;i++)
    {
        scanf("%s",s);
        if(s[0]=='Q')
        {
            scanf("%d%d%d",&l,&r,&x);
            q[++Q]=(query){l,r,2,x,++tot};
        }
        else
        {
            scanf("%d%d",&l,&x);
            q[++Q]=(query){A[l],-1,1,0,l};
            q[++Q]=(query){A[l]=x,1,1,0,l};
        }
    }
    solve(-inf,inf,1,Q);
    for(int i=1;i<=tot;i++)
        printf("%d\n",ans[i]);
    return 0;
}