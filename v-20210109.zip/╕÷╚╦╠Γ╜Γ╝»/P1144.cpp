#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring> 
using namespace std;
const int maxn=1000007;
const int maxm=4000007;
const int mod=100003;
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
queue <int> q;
int dis[maxn],ans[maxn];
bool book[maxn];
void SPFA()
{
	q.push(1);
	book[1]=true;
	ans[1]=1;
	int u,v;
	memset(dis,0x7f,sizeof(dis));
	dis[1]=0;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+1<dis[v])
			{
				dis[v]=dis[u]+1;
				ans[v]=ans[u];
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
			else if(dis[u]+1==dis[v])
			{
				ans[v]+=ans[u];ans[v]%=mod;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		addE(u,v);
		addE(v,u);
	}
	SPFA();
	for(int i=1;i<=N;i++)
		printf("%d\n",ans[i]);
	return 0;
}
