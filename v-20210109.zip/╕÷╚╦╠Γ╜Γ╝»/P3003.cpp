#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v,w;
}e[400007];
int first[100007],nt[400007],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u,w};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
struct VD{
	int num,d;
};
bool operator < (const VD &a,const VD &b)
{
	return a.d>b.d;
}
priority_queue <VD> q;
int dis[100007];
int N,M,A,B,S,ansA,ansB;
inline void Dijkstra(int s)
{
	memset(dis,0x7f,sizeof(dis));
	VD t=(VD){s,0};
	int u;
	dis[s]=0;
	q.push(t);
	while(!q.empty())
	{
		t=q.top();q.pop();
		if(dis[t.num]<t.d) continue;
		u=t.num;
		for(int i=first[u];i;i=nt[i])
		{
			if(dis[u]+e[i].w<dis[e[i].v])
			{
				dis[e[i].v]=dis[u]+e[i].w;
				t.num=e[i].v;t.d=dis[e[i].v];
				q.push(t);
			}
		}
	}
	return ;
}
int main()
{
	M=R();N=R();S=R();A=R();B=R();
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
	}
	Dijkstra(A);
	ansA=dis[S];ansB=dis[B];
	Dijkstra(B);
	ansA=min(ansA,dis[S]);
	printf("%d",ansA+ansB);
	return 0;
}
