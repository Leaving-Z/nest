#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=1007;
typedef long long LL;
LL m[maxn][maxn],dis[maxn];
int d[maxn][maxn],f[maxn],t[maxn];
int N,S,T,n;
bool book[maxn];
void SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	dis[S]=0;
	q.push(S);
	book[S]=true;
	int u,v;
	LL w;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=1;i<=n;i++)
		{
			if(m[u][i]>1e18) continue;
			v=i;w=m[u][i];
			if(dis[u]+w<dis[v])
			{
				dis[v]=dis[u]+w;
				f[v]=f[u]+d[u][v];
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
			else if(dis[u]+w==dis[v])
				f[v]=min(f[u]+d[u][v],f[v]);
		}
	}
	return ;
}
int main()
{
	freopen("P3115_6.in","r",stdin); 
	scanf("%d%d%d",&S,&T,&N);
	memset(m,0x7f,sizeof(m));
	int c,x;
	int u,v;
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d",&c,&x);
		for(int j=1;j<=x;j++)
			scanf("%d",&t[j]),n=max(n,t[j]);
		for(int j=1;j<=x;j++)
		{
			u=t[j];
			for(int k=j+1;k<=x;k++)
			{
				v=t[k];
				if(c<m[u][v]) m[u][v]=c,d[u][v]=k-j;
				else if(c==m[u][v]) d[u][v]=min(d[u][v],k-j);
			}
		}
	}
	SPFA();
	if(dis[T]>1e18) {printf("-1 -1");return 0;}
	printf("%lld %d",dis[T],f[T]);
	return 0;
}
