#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=5007;
const int maxm=5007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int C,T;
int dfn[maxn],low[maxn],stk[maxn],top,S[maxn];
bool ins[maxn];
void dfs(int u)
{
    dfn[u]=low[u]=++T;
    ins[u]=true;
    stk[++top]=u;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
        else if(ins[v]) low[u]=min(low[u],dfn[v]);
    }
    if(dfn[u]==low[u])
    {
        C++;
        int p;
        do{
            p=stk[top--];
            S[p]=C;
            ins[p]=false;
        }while(p!=u);
    }
    return ;
}
int N,M;
int in[maxn];
int Cap;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&M,&Cap);
    int u,v;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);
    }
    for(int i=1;i<=N;i++)
    if(!dfn[i]) dfs(i);
    //for(int i=1;i<=N;i++) printf("%d ",S[i]);puts("");
    for(int i=1;i<=ES;i++)
    {
        if(S[e[i].u]!=S[e[i].v])
            in[S[e[i].v]]++;
    }
    int ans=0;
    for(int i=1;i<=C;i++)
    if(i!=S[Cap]&&in[i]==0) ++ans;
    printf("%d",ans);
    return 0;
}