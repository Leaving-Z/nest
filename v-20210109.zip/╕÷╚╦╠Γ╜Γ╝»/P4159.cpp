#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
const int mod=2009;
struct M{
	int m[107][107];
	M() {memset(m,0,sizeof(m));}
	int R,C;
	M operator * (const M &a) const
	{
		M t;
		t.R=R;t.C=a.C;
		for(int i=1;i<=R;i++)
			for(int j=1;j<=t.C;j++)
				for(int k=1;k<=C;k++)
				t.m[i][j]=(t.m[i][j]+(m[i][k]*a.m[k][j])%mod)%mod;
		return t;
	}
}X,ans;
int N,T,l;
M operator ^ (M a,int k)
{
	M s=a;
	while(k)
	{
		if(k&1) s=s*a;
		a=a*a;
		k>>=1;
	}
	return s;
}
char z[17][17];
int main()
{
	cin.sync_with_stdio(false);
	cin>>N>>T;
	for(int i=1;i<=N;i++)
		cin>>z[i];
	for(int i=1;i<=N;i++)
		for(int j=1;j<9;j++)
		X.m[(i-1)*9+j][(i-1)*9+j+1]=1;
	X.C=X.R=N*9;
	int l,x;
	for(int i=1;i<=N;i++)
	{
		l=strlen(z[i]);
		for(int j=0;j<l;j++)
		{
			x=z[i][j]-48;
			if(x)
			X.m[(i-1)*9+x][j*9+1]=1;
		}
	}
	X=X^(T-1);
	printf("%d",X.m[1][N*9-8]);
	return 0;
}
