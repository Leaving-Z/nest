#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=400007;
const int n=200001;
int TREE[maxn<<2];
bool tag[maxn<<2];
int N;
#define v(i) TREE[i]
int low;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
char qwq[7];
inline void LAZY(int i)
{
	if(!tag[i]) return ;
	tag[i<<1]=tag[i<<1|1]=1;
	v(i<<1)=v(i<<1|1)=0;
	tag[i]=0;
	return ;
}
#define mid (L+R>>1)
void Update(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		v(i)=0;tag[i]=1;
		return ;
	}
	LAZY(i);
	if(l<=mid) Update(L,mid,l,r,i<<1);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1);
	v(i)=v(i<<1)+v(i<<1|1);
	return ;
}
void add(int L,int R,int x,int i)
{
	if(L==R) {v(i)++;return ;}
	LAZY(i);
	if(x<=mid) add(L,mid,x,i<<1);
	else add(mid+1,R,x,i<<1|1);
	v(i)=v(i<<1)+v(i<<1|1);
	return ;
}
int Query(int L,int R,int k,int i)
{
	if(L==R) return L;
	LAZY(i);
	if(v(i<<1|1)>=k) return Query(mid+1,R,k,i<<1|1);
	else return Query(L,mid,k-v(i<<1|1),i<<1);
}
int sum(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return v(i);
	LAZY(i);
	int re=0;
	if(l<=mid) re+=sum(L,mid,l,r,i<<1);
	if(r>mid) re+=sum(mid+1,R,l,r,i<<1|1);
	return re;
}
int main()
{
	N=R();low=R();
	int x,ans=0,b=0;
	while(N--)
	{
		scanf("%s",qwq);x=R();
		if(qwq[0]=='I')
		{
			if(x-b<low) continue;
			else add(1,n<<1,x-b+n,1);
		}
		else if(qwq[0]=='A')
			low-=x,b+=x;
		else if(qwq[0]=='S')
		{
			low+=x,b-=x;
			if(v(1)>0) ans+=sum(1,n<<1,1,n+low-1,1),Update(1,n<<1,1,n+low-1,1);
		}
		else
		{
			if(x>v(1)) puts("-1");
			else printf("%d\n",Query(1,n<<1,x,1)+b-n);
		}
	}
	printf("%d",ans);
	return 0;
}
