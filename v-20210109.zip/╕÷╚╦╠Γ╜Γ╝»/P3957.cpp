#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
const int maxn=500007;
int A[maxn],dis[maxn];
int N,D,K;
struct node{
	int d,val;
};
struct que{
	node q[maxn];
	int head,tail;
	void init()
	{
		this->head=1;this->tail=0;
		return ;
	}
	node front()
	{
		return q[head];
	}
	node back()
	{
		return q[tail];
	}
	void pop_front()
	{
		++head;return ;
	}
	void pop_back()
	{
		--tail;return ;
	}
	void push(const node &x)
	{
		q[++tail]=x;return ;
	}
	bool empty()
	{
		return head>tail;
	}
};
que q,temp;
void insert(const node &x)
{
	while(!q.empty()&&q.back().val<x.val) q.pop_back();
	q.push(x);
	return ;
}
bool check(int g)
{
	q.init();temp.init();
	node t;t.d=0;t.val=0;
	int Lim=max(1,D-g),Rim=D+g;
	temp.push(t);
	for(register int i=1;i<=N;i++)
	{
		while(!q.empty()&&q.front().d<dis[i]-Rim) q.pop_front();
		while(!temp.empty()&&temp.front().d<dis[i]-Rim) temp.pop_front();
		while(!temp.empty()&&temp.front().d<=dis[i]-Lim) insert(temp.front()),temp.pop_front();
		if(!q.empty())
		{
			t.d=dis[i];
			t.val=q.front().val+A[i];
			if(t.val>=K) return true;
			temp.push(t);
		}
	}
	return false;
}
#define mid (L+R>>1)
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();D=R();K=R();
	for(register int i=1;i<=N;i++)
		dis[i]=R(),A[i]=R();
	int L=0,R=1e9+1,ans=-1;
	while(L<=R)
	{
		if(check(mid)) ans=mid,R=mid-1;
		else L=mid+1;
	}
	printf("%d",ans);
	return 0;
}
