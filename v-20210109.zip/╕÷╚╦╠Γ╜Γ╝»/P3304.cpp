#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
const int maxm=400007;
typedef long long LL;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
LL dis[maxn],ch[maxn];
int dep[maxn],N;
bool book[maxn];
int fa[maxn];
void dfs(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dis[v]=dis[u]+e[i].w;
        dep[v]=dep[u]+1;
        fa[v]=u;
        dfs(v);
        ch[u]=max(ch[u],ch[v]+e[i].w);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v,w;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        addE(u,v,w);addE(v,u,w);
    }
    dfs(1);
    int lt,rt;
    LL maxx=-1e18,r;
    for(int i=1;i<=N;i++)
    if(dis[i]>maxx) maxx=dis[i],lt=i;
    dis[lt]=0;fa[lt]=0;dep[lt]=0;
    memset(ch,0,sizeof(ch));
    dfs(lt);maxx=-1e18;
    for(int i=1;i<=N;i++)
    if(dis[i]>maxx) maxx=dis[i],rt=i;
    r=maxx;
    u=rt;
    while(u!=lt)
    {
        book[u]=true;
        u=fa[u];
    }
    book[lt]=true;
    u=rt;
    int d1=rt;
    while(u!=lt)
    {
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(book[v]) continue;
            if(dis[v]+ch[v]==r) {d1=u;break;}
        }
        u=fa[u];
    }
    memset(ch,0,sizeof(ch));
    fa[rt]=0;dis[rt]=0;dep[rt]=0;
    dfs(rt);
    u=lt;
    int d2=lt;
    while(u!=rt)
    {
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(book[v]) continue;
            if(dis[v]+ch[v]==r) {d2=u;break;}
        }
        u=fa[u];
    }
    printf("%lld\n%d",r,max(0,dep[d2]-dep[d1]));
    return 0;
}