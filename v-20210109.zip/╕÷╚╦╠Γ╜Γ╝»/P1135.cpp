#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
struct node{
	int cur,step;
};
queue <node> q;
int N,S,F;
int move[207];
bool book[207];
int main()
{
	scanf("%d%d%d",&N,&S,&F);
	for(int i=1;i<=N;i++)
		scanf("%d",&move[i]);
	node p=(node){S,0};
	book[S]=1;
	q.push(p);
	while(!q.empty())
	{
		p=q.front();q.pop();
		if(p.cur==F) break;
		if(p.cur+move[p.cur]<=N&&!book[p.cur+move[p.cur]])
		{
			q.push((node){p.cur+move[p.cur],p.step+1});
			book[p.cur+move[p.cur]]=true;
		}
		if(p.cur-move[p.cur]>0&&!book[p.cur-move[p.cur]])
		{
			q.push((node){p.cur-move[p.cur],p.step+1});
			book[p.cur-move[p.cur]]=true;
		}
	}
	if(p.cur==F)
	printf("%d",p.step);
	else printf("-1");
	return 0;
}
