#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=50007;
struct seg_tree{
    int pre,suf,maxx,sum;
}tree[maxn<<2];
#define pre(i) tree[i].pre
#define suf(i) tree[i].suf
#define Max(i) tree[i].maxx
#define sum(i) tree[i].sum
#define ls (i<<1)
#define rs (i<<1|1)
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.sum=x.sum+y.sum;
    t.pre=max(x.pre,x.sum+y.pre);
    t.suf=max(y.suf,y.sum+x.suf);
    t.maxx=max(x.maxx,y.maxx);
    t.maxx=max(t.maxx,x.suf+y.pre);
    return t;
}
int A[maxn];
void build(int L,int R,int i)
{
    if(L==R)
    {
        pre(i)=suf(i)=Max(i)=sum(i)=A[L];
        return ;
    }
    int mid=L+R>>1;
    build(L,mid,ls);
    build(mid+1,R,rs);
    tree[i]=tree[ls]+tree[rs];
    return ;
}
seg_tree query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return tree[i];
    seg_tree t;
    t.maxx=t.pre=t.suf=-2e9;t.sum=0;
    int mid=L+R>>1;
    if(l<=mid) t=t+query(L,mid,l,r,ls);
    if(r>mid) t=t+query(mid+1,R,l,r,rs);
    return t;
}
int N,Q;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    build(1,N,1);
    scanf("%d",&Q);
    int l,r;
    while(Q--)
    {
        scanf("%d%d",&l,&r);
        printf("%d\n",query(1,N,l,r,1).maxx);
    }
    return 0;
}