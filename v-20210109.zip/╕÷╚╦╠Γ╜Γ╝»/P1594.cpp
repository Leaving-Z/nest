#include<cstdio>
#include<algorithm>
using namespace std;
typedef long double db;
const int maxn=1007;
db F[maxn],T[maxn],maxx[maxn][maxn];
db sum[maxn];
db A[maxn];
db L,W;
int N;
int main()
{
	scanf("%Lf%Lf%d",&W,&L,&N);
	db v;
	for(register int i=1;i<=N;i++)
	{
		scanf("%Lf%Lf",&A[i],&v);
		sum[i]=sum[i-1]+A[i];
		T[i]=L*60.0/v;
		maxx[i][i]=T[i];
	}
	for(register int i=1;i<=N;i++)
		for(register int j=i+1;j<=N;j++)
			maxx[i][j]=max(maxx[i][j-1],T[j]);
	for(int i=1;i<=N;i++)
	{
		F[i]=F[i-1]+T[i];
		for(int j=i-1;j>0;j--)
		{
			if(sum[i]-sum[j-1]>W) break;
			else F[i]=min(F[i],F[j-1]+maxx[j][i]);
		}
	}
	printf("%.1Lf",F[N]);
	return 0;
}
