#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
using namespace std;
const int maxn=250007;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N;
struct node {
    int num,val;
};
bool operator < (const node &x,const node &y)
{
    return x.val>y.val;
}
priority_queue <node> q;
int A[maxn],B[maxn];
int ans;
int ANS[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    for(register int i=1;i<=N;i++)
        A[i]=R();
    for(register int i=1;i<=N;i++)
        B[i]=R();
    node tmp;
    for(int i=N;i>0;i--)
    {
        q.push((node){i,B[i]});
        while(!q.empty()&&A[i]>q.top().val)
        {
            ANS[++ans]=q.top().num;
            A[i]-=q.top().val;
            q.pop();
        }
        if(!q.empty())
        {
            tmp=q.top();q.pop();
            tmp.val-=A[i];
            q.push(tmp);
        }
    }
    printf("%d\n",ans);
    for(int i=1;i<=ans;i++)
        printf("%d ",ANS[i]);
    return 0;
}