#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
int N,Q;
int TREE[maxn<<2];
struct E{
	int u,v;
}e[maxn];
int first[maxn],nt[maxn],ES;
inline void addE(const int &u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int fa[maxn],top[maxn],son[maxn],sz[maxn],id[maxn],anti[maxn],depth[maxn],ix;
inline void DFS(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		depth[v]=depth[u]+1;
		fa[v]=u;
		DFS(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
	return ;
}
inline void dfs(int u,int tp)
{
	id[u]=++ix;anti[ix]=u;
	top[u]=tp;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=son[u])
			dfs(v,v);
	}
	return ;
}
#define L(i) (i<<1)
#define R(i) (i<<1|1)
#define mid (L+R>>1)
#define Lv(i) (TREE[i<<1]==0?-1:depth[TREE[i<<1]])
#define Rv(i) (TREE[i<<1|1]==0?-1:depth[TREE[i<<1|1]])
inline void swap_(int &x,int &y)
{
	int t=x;x=y;y=t;
	return ;
}
inline void Update(int L,int R,int x,int i)
{
	if(L==R)
	{
		TREE[i]=anti[L];
		return ;
	}
	if(x<=mid) Update(L,mid,x,L(i));
	else Update(mid+1,R,x,R(i));
	TREE[i]=Lv(i)>Rv(i)?TREE[L(i)]:TREE[R(i)];
	return ;
}
inline int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
		return TREE[i];
	int ans=0;
	if(l<=mid) ans=Query(L,mid,l,r,L(i));
	if(r>mid)
	{
		int t=Query(mid+1,R,l,r,R(i));
		ans=depth[ans]>depth[t]?ans:t;
	}
	return ans;
}
inline int Query_Path(int x,int y)
{
	int ans=0,t;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap_(x,y);
		t=Query(1,N,id[top[x]],id[x],1);
		ans=depth[ans]>depth[t]?ans:t;
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap_(x,y);
	t=Query(1,N,id[x],id[y],1);
	ans=depth[ans]>depth[t]?ans:t;
	return ans;
}
inline int Read()
{
	int re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
char op[7];
int main()
{
	N=Read();Q=Read();
	int u,v;
	for(register int i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);
	}
	DFS(1);dfs(1,1);
	Update(1,N,id[1],1);depth[0]=-1;
	for(register int i=1;i<=Q;i++)
	{
		scanf("%s",op);u=Read();
		if(op[0]=='C') Update(1,N,id[u],1);
		else printf("%d\n",Query_Path(1,u));
	}
	return 0;
}
