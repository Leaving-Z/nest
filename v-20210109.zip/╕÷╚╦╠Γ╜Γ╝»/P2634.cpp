#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=20007;
const int maxm=40007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
struct node{
	int dis,anc;
}A[maxn];
bool operator < (const node &x,const node &y)
{
	return x.anc<y.anc;
}
int cnt,N;
int sz[maxn],maxsz[maxn];
bool vis[maxn];
int root;
void findrt(int u,int fa,int totsz)
{
	int v;
	sz[u]=1;
	maxsz[u]=0;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||vis[v]) continue;
		findrt(v,u,totsz);
		sz[u]+=sz[v];
		maxsz[u]=max(maxsz[u],sz[v]);
	}
	maxsz[u]=max(maxsz[u],totsz-maxsz[u]);
	if(!root||maxsz[root]>maxsz[u]) root=u;
	return ;
}
void dfs(int u,int fa,int d,int an)
{
	++cnt;
	A[cnt].anc=an;
	A[cnt].dis=d%3;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||vis[v]) continue;
		dfs(v,u,d+e[i].w,an);
	}
	return ;
}
int ans;
void calc(int u)
{
	A[cnt=1].anc=u;A[cnt].dis=0;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(vis[v]) continue;
		dfs(v,u,e[i].w,v);
	}
	sort(A+1,A+1+cnt);
	int z0=0,z1=0,z2=0;
	for(int i=1;i<=cnt;i++)
	{
		if(A[i].dis==0) ++z0;
		else if(A[i].dis==1) ++z1;
		else if(A[i].dis==2) ++z2;
	}
	ans+=z0*(z0-1);
	ans+=z1*z2*2;
	int ty=-1;
	z0=z1=z2=0;
	for(int i=1;i<=cnt;i++)
	{
		if(A[i].anc!=ty)
		{
			ty=A[i].anc;
			--i;
			ans-=z0*(z0-1);
			ans-=z1*z2*2;
			z0=z1=z2=0;
			continue;
		}
		if(A[i].dis==0) ++z0;
		else if(A[i].dis==1) ++z1;
		else if(A[i].dis==2) ++z2;
	}
	ans-=z0*(z0-1);
	ans-=z1*z2*2;
	return ;
}
void solve(int u)
{
	vis[u]=1;
	int v;
	calc(u);
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(vis[v]) continue;
		root=0;
		findrt(v,u,sz[u]);
		solve(root);
	}
	return ;
}
int gcd(int a,int b) {return !b?a:gcd(b,a%b);}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		addE(u,v,w);addE(v,u,w);
	}
	findrt(1,0,N);
	solve(root);
	ans+=N;
	//printf("%d",ans);
	int d=N*N;
	int g=gcd(ans,d);
	printf("%d/%d",ans/g,d/g);
	return 0;
}