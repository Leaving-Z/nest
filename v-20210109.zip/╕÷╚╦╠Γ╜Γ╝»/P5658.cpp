#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=500007;
struct E{
	int u,v;
}e[maxn];
int first[maxn],nt[maxn],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
char s[maxn];
int stk[maxn],fa[maxn],top,N;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
long long add[maxn],sum[maxn];
inline void dfs(int u)
{
	int tmp=0;
	if(s[u]=='(')
		stk[++top]=u;
	else
	{
		if(top) 
		{
			tmp=stk[top--];
			add[u]=add[fa[tmp]]+1;
		}
	}
	int v;
	sum[u]=sum[fa[u]]+add[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dfs(v);
	}
	if(tmp) stk[++top]=tmp;
	else if(top) --top;
	return ;
}
int main()
{
	N=R();
	scanf("%s",s+1);
	for(int i=1;i<N;i++)
		fa[i+1]=R(),addE(fa[i+1],i+1);
	dfs(1);
	long long ans=0;
	for(register int i=1;i<=N;i++)
		ans^=sum[i]*(long long)i;
	printf("%lld",ans);
	return 0;
}
