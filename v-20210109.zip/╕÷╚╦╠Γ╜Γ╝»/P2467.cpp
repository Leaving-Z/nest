#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=4207;
int f[maxn];
int C[maxn][maxn];
int N,mod;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&mod);
    C[0][0]=1;
    for(int i=1;i<=N;i++)
    {
        C[i][0]=1;
        for(int j=1;j<=i;j++)
            C[i][j]=C[i-1][j-1]+C[i-1][j],C[i][j]%=mod;
    }
    f[0]=f[1]=1;
    for(int i=2;i<=N;i++)
        for(int j=0;j<i;j++)
        if(j&1) f[i]+=1ll*f[j]*f[i-j-1]%mod*C[i-1][j]%mod,f[i]%=mod;
    printf("%d",f[N]*2%mod);
    return 0;
}