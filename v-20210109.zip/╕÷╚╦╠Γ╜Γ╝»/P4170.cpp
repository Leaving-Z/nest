#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=57;
int F[maxn][maxn];
char s[maxn];
int N;
#define R (L+len-1)
int main()
{
	scanf("%s",s+1);
	N=strlen(s+1);
	memset(F,0x3f,sizeof(F));
	for(int i=1;i<=N;i++)
		F[i][i]=1;
	bool f;
	for(int len=2;len<=N;len++)
		for(int L=1;R<=N;L++)
		{
			if(s[L]==s[R]) F[L][R]=min(F[L+1][R],F[L][R-1]);
			else
			{
				for(int k=L;k<=R;k++)
					F[L][R]=min(F[L][k]+F[k+1][R],F[L][R]);
			}
		}
	printf("%d",F[1][N]);
	return 0;
}
