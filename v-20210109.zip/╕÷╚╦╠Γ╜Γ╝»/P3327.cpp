#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=50007;
const int lim=50000;
bool book[maxn];
int prime[maxn],cnt,mu[maxn];
long long g[maxn];
void pre()
{
    mu[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,mu[i]=-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else {mu[i*prime[j]]=0;break;}
        }
    }
    for(int i=1;i<=lim;i++)
        mu[i]+=mu[i-1];
    return ;
}
int T,N,M;
long long calc(int n)
{
    int L=1,R;
    long long res=0;
    while(L<=n)
    {
        R=n/(n/L);
        res+=(R-L+1ll)*(n/L);
        L=R+1;
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    pre();
    for(int i=1;i<=lim;i++)
        g[i]=calc(i);
    while(T--)
    {
        scanf("%d%d",&N,&M);
        long long ans=0;
        if(N>M) swap(N,M);
        int L=1,R;
        while(L<=N)
        {
            R=min(N/(N/L),M/(M/L));
            ans+=(mu[R]-mu[L-1])*g[N/L]*g[M/L];
            L=R+1;
        }
        printf("%lld\n",ans);
    }
    return 0;
}