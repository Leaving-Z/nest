#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=20007;
int F[maxn][2];
int L[maxn],R[maxn];
int N;
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d%d",&L[i],&R[i]);
	F[1][0]=R[1]+R[1]-L[1];F[1][1]=R[1]-1;
	for(int i=2;i<=N;i++)
	{
		F[i][0]=min(F[i-1][0]+abs(L[i-1]-R[i]),F[i-1][1]+abs(R[i-1]-R[i]))+R[i]-L[i]+1;
		F[i][1]=min(F[i-1][0]+abs(L[i-1]-L[i]),F[i-1][1]+abs(R[i-1]-L[i]))+R[i]-L[i]+1;
	}
	printf("%d",min(F[N][1]+abs(R[N]-N),F[N][0]+abs(L[N]-N)));
	return 0;
}
