#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=300007;
const int maxq=900007;
int N,M,K,Q;
struct query{
    int l,r,k,ty,id;
}q[maxq],q1[maxq],q2[maxq];
struct E{
    int u,v;
}e[maxn];
int first[maxn],nt[maxn],ES;
void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int C[maxn];
int ans[maxn];
void Update(int x,int k)
{
    while(x<=M+1) C[x]+=k,x+=x&(-x);
    return ;
}
int Query(int x)
{
    int re=0;
    while(x) re+=C[x],x-=x&(-x);
    return re;
}
int A[maxn],sp[maxn];
void solve(int l,int r,int ql,int qr)
{
    if(l==r)
    {
        for(int i=ql;i<=qr;i++)
        if(q[i].ty==1) ans[q[i].id]=l;
        return ;
    }
    int mid=l+r>>1,cnt1=0,cnt2=0,u,v,sum;
    for(int i=ql;i<=qr;i++)
    {
        if(q[i].ty==2)
        {
            if(q[i].id<=mid) Update(q[i].l,q[i].k),Update(q[i].r+1,-q[i].k),q1[++cnt1]=q[i];
            else q2[++cnt2]=q[i];
        }
        else
        {
            u=q[i].l;sum=0;
            for(int k=first[u];k;k=nt[k])
            {
                v=e[k].v;
                sum+=Query(v);
                if(sum>=q[i].k) break;
            }
            if(sum>=q[i].k) q1[++cnt1]=q[i];
            else q[i].k-=sum,q2[++cnt2]=q[i];
        }
    }
    for(int i=1;i<=cnt1;i++)
    if(q1[i].ty==2) Update(q1[i].l,-q1[i].k),Update(q1[i].r+1,q1[i].k);
    for(int i=1;i<=cnt1;i++) q[ql+i-1]=q1[i];
    for(int i=1;i<=cnt2;i++) q[ql+cnt1+i-1]=q2[i];
    if(cnt1) solve(l,mid,ql,ql+cnt1-1);
    if(cnt2) solve(mid+1,r,ql+cnt1,qr);
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=M;i++)
        scanf("%d",&sp[i]);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    scanf("%d",&K);
    int l,r,x;
    for(int i=1;i<=K;i++)
    {
        scanf("%d%d%d",&l,&r,&x);
        if(l<=r)
        q[++Q]=(query){l,r,x,2,i};
        else
        {
            q[++Q]=(query){l,M,x,2,i};
            q[++Q]=(query){1,r,x,2,i};
        }
    }
    memset(ans,0x7f,sizeof(ans));
    for(int i=1;i<=M;i++)
        addE(sp[i],i);
    for(int i=1;i<=N;i++)
        q[++Q]=(query){i,0,A[i],1,i};
    solve(1,K+1,1,Q);
    for(int i=1;i<=N;i++)
    if(ans[i]>K) puts("NIE");
    else printf("%d\n",ans[i]);
    return 0;
}