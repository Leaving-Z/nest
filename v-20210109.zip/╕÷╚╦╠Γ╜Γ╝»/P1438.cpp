#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
int N,M;
int A[maxn];
int TREE[maxn<<2],tag[maxn<<2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
inline void pushdown(int L,int R,int i)
{
	if(!tag[i]) return ;
	tag[Ls]+=tag[i];
	tag[Rs]+=tag[i];
	TREE[Ls]+=tag[i]*(mid-L+1);
	TREE[Rs]+=tag[i]*(R-mid);
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		tag[i]+=k;
		TREE[i]+=(R-L+1)*k;
		return ; 
	}
	pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	TREE[i]=TREE[Ls]+TREE[Rs];
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return TREE[i];
	pushdown(L,R,i);
	int re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;	
}
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=R();M=R();
	for(register int i=1;i<=N;i++)
		A[i]=R();
	int op,l,r,k,d;
	for(register int i=1;i<=M;i++)
	{
		op=R();
		if(op==1)
		{
			l=R();r=R();k=R();d=R();
			Update(1,N,l,l,k,1);
			Update(1,N,l+1,r,d,1);
			if(r+1<=N) Update(1,N,r+1,r+1,(l-r)*d-k,1);
		}
		else
		{
			k=R();
			printf("%d\n",A[k]+Query(1,N,1,k,1));
		}
	}
	return 0;
}
