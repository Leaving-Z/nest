#include<bits/stdc++.h>
using namespace std;
const int mod=19260817;
typedef long long LL;
struct Matrix{
	LL m[5][5];
	Matrix() {memset(m,0,sizeof(m));}
	Matrix operator *(const Matrix &A) const
	{
		Matrix t;
		for(int i=1;i<=3;i++)
			for(int j=1;j<=3;j++)
				for(int k=1;k<=3;k++)
				t.m[i][j]=(t.m[i][j]+m[i][k]*A.m[k][j]%mod)%mod;
		return t;				
	}
}ini,trans;
Matrix operator ^(Matrix A,LL k)
{
	Matrix s;
	for(int i=1;i<=3;i++)
		s.m[i][i]=1;
	while(k)
	{
		if(k&1) s=s*A;
		A=A*A;
		k>>=1;
	}
	return s;
}
LL T,N;
int main()
{
	Matrix A,B;
	ini.m[1][1]=7;ini.m[1][2]=4;ini.m[1][3]=2;
	trans.m[1][1]=trans.m[1][2]=trans.m[2][1]=trans.m[2][3]=trans.m[3][1]=1;
	scanf("%lld",&T);
	while(T--)
	{
		scanf("%lld",&N);
		if(N==1) {puts("2");continue;}
		else if(N==2) {puts("4");continue;}
		else if(N==3) {puts("7");continue;}
		A=ini;B=trans;
		B=B^(N-3);
		A=A*B;
		printf("%lld\n",A.m[1][1]);
	}
	return 0;
}
