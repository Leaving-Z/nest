#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int mod=1e8;
const int maxn=2007;
const int maxv=1007;
int Ri[maxn],F[maxv],temp[maxv];
int f,N;
int main()
{
	scanf("%d%d",&N,&f);
	for(int i=1;i<=N;i++)
		scanf("%d",&Ri[i]);
	F[0]=1;
	for(int i=1;i<=N;i++)
	{
		memcpy(temp,F,sizeof(F));
		for(int j=0;j<f;j++)
			temp[(j+Ri[i])%f]+=F[j],temp[(j+Ri[i])%f]%=mod;
		memcpy(F,temp,sizeof(F));
	}
	printf("%d",F[0]-1);
	return 0;
}
