#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<vector>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=607;
const int maxl=37;
const int maxm=400007;
const int inf=0x7f7f7f7f;
struct E{
    int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf)
{
    e[++ES]=(E){u,v,cf};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int cf)
{
    addE(u,v,cf);
    addE(v,u,0);
    return ;
}
queue <int> q;
int N,M,S,T;
int dep[maxn],cur[maxn];
vector <int> m[maxn];
bool BFS()
{
    memset(dep,0,sizeof(dep));
    dep[S]=1;
    q.push(S);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&!dep[v])
            {
                dep[v]=dep[u]+1;
                q.push(v);
            }
        }
    }
    return dep[T]!=0;
}
int dfs(int u,int f)
{
    if(u==T) return f;
    int sum=0,d,v;
    for(int &i=cur[u];i;i=nt[i])
    {
        v=e[i].v;
        if(dep[v]==dep[u]+1&&cf(i)>0)
        {
            d=dfs(v,min(cf(i),f));
            if(d>0)
            {
                sum+=d;
                f-=d;
                cf(i)-=d;
                cf(i^1)+=d;
                if(f==0) return sum;
            }
        }
    }
    return sum;
}
int Dinic()
{
    int res=0;
    while(BFS()) memcpy(cur,first,sizeof(first)),res+=dfs(S,inf);
    return res;
}
int val[maxl][maxl];
int id(int i,int j)
{
    return (i-1)*M+j;
}
int in[maxn];
bool vis[maxn];
void topo()
{
    for(int i=1;i<=N*M;i++)
    if(!in[i]) q.push(i);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        vis[u]=true;
        for(int i=0;i<m[u].size();i++)
        {
            v=m[u][i];
            --in[v];
            if(!in[v]) q.push(v);
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int ans=0;
    int w,x,y;
    S=N*M+1;T=S+1;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        {
            if(j!=M) m[id(i,j+1)].push_back(id(i,j)),in[id(i,j)]++;
            scanf("%d",&val[i][j]);
            scanf("%d",&w);
            for(int k=1;k<=w;k++)
                scanf("%d%d",&x,&y),m[id(i,j)].push_back(id(x+1,y+1)),in[id(x+1,y+1)]++;
        }
    topo();
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)
        {
            x=id(i,j);
            if(!vis[x]) continue;
            for(int k=0;k<m[x].size();k++)
            {
                y=m[x][k];
                if(vis[y]) add(y,x,inf);
            }
            if(val[i][j]>0) add(S,x,val[i][j]),ans+=val[i][j];
            else add(x,T,-val[i][j]);
        }
    printf("%d",ans-Dinic());
    return 0;
}