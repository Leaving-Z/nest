#include<cstdio>
#include<algorithm>
using namespace std;
int A[5];
int ans,t[27],all;
inline int cal(int x,int k)
{
	int re1=0,re2=0;
	for(int i=0;i<A[k];i++)
	{
		if(x&(1<<i)) re1+=t[i+1];
		else re2+=t[i+1]; 
	}
	return max(re1,re2);
}
int main()
{
	int tmp;
	scanf("%d%d%d%d",&A[1],&A[2],&A[3],&A[4]);
	for(int i=1;i<=4;i++)
	{
		all=(1<<A[i])-1;
		tmp=0x7f7f7f7f;
		for(int j=1;j<=A[i];j++)
			scanf("%d",&t[j]);
		for(int j=0;j<all;j++)
			tmp=min(tmp,cal(j,i));
		ans+=tmp;
	}
	printf("%d",ans);
}
