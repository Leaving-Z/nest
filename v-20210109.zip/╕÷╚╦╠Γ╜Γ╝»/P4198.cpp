#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
int h[maxn];
int mx[maxn<<2],cnt[maxn<<2];
bool com(const int &x,const int &y)//x>y
{
    if(!y) return h[x];
    return 1ll*h[x]*y>1ll*h[y]*x;
}
#define ls (i<<1)
#define rs (i<<1|1)
int calc(int L,int R,int i,int pre)
{
    if(L==R) return com(L,pre)?1:0;
    int mid=L+R>>1;
    if(com(mx[ls],pre)) return calc(L,mid,ls,pre)+cnt[i]-cnt[ls];
    else return calc(mid+1,R,rs,pre);
}
void pushup(int i)
{
    if(com(mx[ls],mx[rs])) mx[i]=mx[ls];
    else mx[i]=mx[rs];
    return ;
}
void build(int L,int R,int i)
{
    mx[i]=L;cnt[i]=1;
    if(L==R) return ;
    int mid=L+R>>1;
    build(L,mid,ls);
    build(mid+1,R,rs);
    return ;
}
void update(int L,int R,int x,int k,int i)
{
    if(L==R)
    {
        h[x]=k;
        return ;
    }
    int mid=L+R>>1;
    if(x<=mid) update(L,mid,x,k,ls);
    else update(mid+1,R,x,k,rs);
    pushup(i);
    cnt[i]=cnt[ls]+calc(mid+1,R,rs,mx[ls]);
    return ;
}
int N,Q;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    build(1,N,1);
    int x,y;
    while(Q--)
    {
        scanf("%d%d",&x,&y);
        update(1,N,x,y,1);
        printf("%d\n",calc(1,N,1,0));
    }
    return 0;
}