#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=50007;
const int maxm=100007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N;
int f[maxn],F[maxn],sz[maxn];
void dfs1(int u,int fa)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        dfs1(v,u);
        sz[u]+=sz[v];
        F[u]+=F[v]+sz[v];
    }
    return ;
}
void dfs2(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        f[v]=f[u]+(N-2*sz[v]);
        dfs2(v,u);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);addE(v,u);
    }
    dfs1(1,0);
    f[1]=F[1];
    dfs2(1,0);
    int maxx=1e9,id;
    for(int i=1;i<=N;i++)
        if(f[i]<maxx) maxx=f[i],id=i;
    printf("%d %d",id,maxx);
    return 0;
}