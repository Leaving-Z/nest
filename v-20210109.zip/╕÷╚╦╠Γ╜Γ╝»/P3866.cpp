#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=1807;
const int maxm=40007;
const int inf=0x7f7f7f7f;
int N,M,S,T,all;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	int u,v;
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;q.push(S);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;} 
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int v,d,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min_(f,cf(i)));
			if(d>0)
			{
				sum+=d;f-=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int m[37][37];
inline int num(int i,int j)
{
	return (i-1)*M+j;
}
int main()
{
	N=R();M=R();all=N*M;T=2*all+1;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
			m[i][j]=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
		{
			if(m[i][j]==-1) continue;
			else if(m[i][j]==0)
				add(num(i,j),num(i,j)+all,inf),add(S,num(i,j),inf);
			else add(num(i,j),num(i,j)+all,m[i][j]);
			if(i>1&&m[i-1][j]!=-1) add(num(i,j)+all,num(i-1,j),inf);
			if(j>1&&m[i][j-1]!=-1) add(num(i,j)+all,num(i,j-1),inf);
			if(i<N&&m[i+1][j]!=-1) add(num(i,j)+all,num(i+1,j),inf);
			if(j<M&&m[i][j+1]!=-1) add(num(i,j)+all,num(i,j+1),inf);
			if(i==1||j==1||i==N||j==M) add(num(i,j)+all,T,inf);
		}
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
