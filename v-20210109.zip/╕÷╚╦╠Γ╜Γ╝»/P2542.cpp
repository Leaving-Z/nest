#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<map>
using namespace std;
struct node{
	int u,v;
};
bool operator < (const node &x,const node &y)
{
	if(x.u!=y.u) return x.u<y.u;
	return x.v<y.v;
}
map <node,int> mp;
inline int R()
{
	int re,fl=1;
	char c;
	while(!isdigit(c=getchar()))
	if(c=='-') fl=-1;
	re=c-48;
	while(isdigit(c=getchar()))
	re=re*10+c-48;
	return re*fl;
}
const int maxn=30007;
const int maxm=200007;
const int maxq=40007;
struct E{
	int u,v;
	bool ok;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
bool acc[maxm],vis[maxn];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v,false};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
int op[maxq][3],Q;
int fa[maxn],sz[maxn],depth[maxn],son[maxn];
void dfs1(int u)
{
	vis[u]=true;
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(e[i].ok||vis[v]) continue;
		acc[i]=acc[i^1]=true;
		fa[v]=u;
		depth[v]=depth[u]+1;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
	return ;
}
int top[maxn],id[maxn],ix;
void dfs2(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;
	if(son[u]) dfs2(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==son[u]||fa[v]!=u) continue;
		dfs2(v,v);
	}
	return ;
}
int TREE[maxn<<2];
bool tag[maxn<<2];
#define val(i) TREE[i]
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
void Build(int L,int R,int i)
{
	val(i)=R-L+1;
	if(L==R) return ;
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	return ;
}
inline void pushdown(int i)
{
	if(!tag[i]) return ;
	tag[Ls]=tag[Rs]=true;
	val(Ls)=val(Rs)=0;
	tag[i]=false;
	return ;
}
void Update(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		tag[i]=true;
		val(i)=0;
		return ;
	}
	pushdown(i);
	if(l<=mid) Update(L,mid,l,r,Ls);
	if(r>mid) Update(mid+1,R,l,r,Rs);
	val(i)=val(Ls)+val(Rs);
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return val(i);
	pushdown(i);
	int re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;
}
void Update_Path(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x]+1,id[y],1);
	return ;
}
int Query_Path(int x,int y)
{
	int re=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		re+=Query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	re+=Query(1,N,id[x]+1,id[y],1);
	return re;
}
int ans[maxq],cnt;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();M=R();
	int u,v;
	node t;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		addE(u,v);
		t.u=u;t.v=v;
		mp[t]=ES;
		addE(v,u);
		t.v=u;t.u=v;
		mp[t]=ES;
	}
	while(1)
	{
		op[++Q][0]=R();
		if(op[Q][0]==-1) {--Q;break;}
		op[Q][1]=R();op[Q][2]=R();
		if(op[Q][0]==0)
		{
			t.u=op[Q][1];t.v=op[Q][2];
			u=mp[t];
			acc[u]=acc[u^1]=true;
			e[u].ok=e[u^1].ok=true;
		}
	}
	dfs1(1);dfs2(1,1);
	Build(1,N,1);
	for(int i=2;i<=ES;i+=2)
		if(!acc[i]) Update_Path(e[i].u,e[i].v);
	for(int i=Q;i>0;i--)
	{
		if(op[i][0]==0) Update_Path(op[i][1],op[i][2]);
		else ans[++cnt]=Query_Path(op[i][1],op[i][2]);
	}
	for(int i=cnt;i>0;i--)
		printf("%d\n",ans[i]);
	return 0;
}