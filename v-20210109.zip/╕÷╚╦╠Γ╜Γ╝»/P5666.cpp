#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int T,N;
const int maxn=300007;
const int J=19;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES=1;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int sn[maxn][J+1],son[maxn][2];
int sz[maxn];
long long ans;
inline void pre(int u)
{
	sn[u][0]=son[u][0];
	for(int i=1;i<=J;i++)
		sn[u][i]=sn[sn[u][i-1]][i-1];
	return ;
}
inline void DFS(int u,int fa)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			DFS(v,u);
			sz[u]+=sz[v];
			if(sz[v]>sz[son[u][0]]) son[u][1]=son[u][0],son[u][0]=v;
			else if(sz[v]>sz[son[u][1]]) son[u][1]=v;
		}
	}
	pre(u);
	return ;
}
inline void cal(int u,int lim)
{
	int tmp=u;
	for(int i=J;i>=0;i--)
	if(sz[sn[u][i]]>lim) u=sn[u][i];
	if(sz[tmp]-sz[u]<=lim) ans+=u;
	u=son[u][0];
	if(sz[tmp]-sz[u]<=lim) ans+=u;
	return ;	
}
inline void dfs(int u,int fa)
{
	int v;
	int szu=sz[u],sonu=son[u][0];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			if(v==sonu) son[u][0]=(N-szu>sz[son[u][1]]?fa:son[u][1]);
			else son[u][0]=(N-szu>sz[sonu]?fa:sonu);
			sz[u]=N-sz[v];
			pre(u);
			cal(u,sz[u]/2);cal(v,sz[v]/2);
			dfs(v,u);
		}
	}
	sz[u]=szu;son[u][0]=sonu;
	pre(u);
	return ;
}
int main()
{
	T=R();
	while(T--)
	{
		N=R();ans=0;ES=1;
		memset(first,0,sizeof(first));
		memset(son,0,sizeof(son));
		int u,v;
		for(int i=1;i<N;i++)
		{
			u=R();v=R();
			addE(u,v);addE(v,u);
		}
		DFS(1,0);
		dfs(1,0);
		printf("%lld\n",ans);
	}
	return 0;
}
