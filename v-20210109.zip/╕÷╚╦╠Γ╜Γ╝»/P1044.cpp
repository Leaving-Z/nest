#include<cstdio>
#include<algorithm>
using namespace std;
long long C[40][40];
long long N;
int main()
{
	C[0][0]=C[1][0]=C[1][1]=1;
	for(int i=2;i<=38;i++)
	{
		C[i][0]=1;
		for(int j=1;j<=i;j++)
		C[i][j]=C[i-1][j-1]+C[i-1][j];
	}
	scanf("%lld",&N);
	printf("%lld",C[2*N][N]/(N+1));
	return 0;
}
