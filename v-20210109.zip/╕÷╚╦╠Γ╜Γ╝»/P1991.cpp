#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=507;
const double eps=1e-10;
int N,M;
struct E{
	int u,v;
	double w;
}e[maxn*maxn];
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int ES;
inline void addE(int u,int v,double w)
{
	e[++ES]=(E){u,v,w};
	return ;
}
inline double getd(int a,int b,int c,int d)
{
	return sqrt((a-c)*(a-c)+(b-d)*(b-d));
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int x[maxn],y[maxn];
int S[maxn];
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
void merge_(int x,int y)
{
	int f1=f(x),f2=f(y);
	S[f1]=f2;
	return ;
}
int main()
{
	M=R();N=R();
	for(register int i=1;i<=N;i++)
		S[i]=i;
	for(register int i=1;i<=N;i++)
		x[i]=R(),y[i]=R();
	double L=0,R=0,mid;
	for(register int i=1;i<=N;i++)
		for(register int j=i+1;j<=N;j++)
			addE(i,j,getd(x[i],y[i],x[j],y[j])),R=max(R,e[ES].w);
	sort(e+1,e+1+ES);
	int tot=0,u,v;double ans;
	for(int i=1;i<=ES;i++)
	{
		u=e[i].u;v=e[i].v;
		if(f(u)!=f(v))
		{
			ans=e[i].w;
			merge_(u,v);
			tot++;
			if(tot==N-M) break;
		}
	}
	printf("%.2f",ans);
	return 0;
}
