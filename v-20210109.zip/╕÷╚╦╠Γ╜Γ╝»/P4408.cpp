#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
typedef long long LL;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
struct E{
	int u,v;
	LL w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
LL dis[maxn],dis1[maxn];
int fa[maxn];
bool vis[maxn];
void dfs(int u)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			dis[v]=dis[u]+e[i].w;
			dfs(v);
		}
	}
	return ;
}
LL dfs1(int u)
{
	vis[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u]&&!vis[v])
		{
			dfs1(v);
			dis1[u]=max(dis1[u],dis1[v]+e[i].w);
		}
	}
	return dis1[u];
}
int main()
{
	N=R();M=R();
	int u,v;LL w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);addE(v,u,w);
	}
	dfs(1);
	int l,r;LL maxx=0;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],r=i;
	memset(fa,0,sizeof(fa));
	dis[r]=0;
	dfs(r);maxx=0;
	for(int i=1;i<=N;i++)
	if(dis[i]>maxx) maxx=dis[i],l=i;
	vis[l]=true;
	LL ans=0;int rt=fa[l];
	while(rt!=r)
	{
		dis1[rt]=0;
		ans=max(min(dis[l]-dis[rt],dis[rt])+dfs1(rt)+dis[l],ans);
		vis[rt]=true;
		rt=fa[rt];
	}
	printf("%lld",ans);
	return 0;
}
