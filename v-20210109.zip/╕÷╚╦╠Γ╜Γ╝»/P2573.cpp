#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=100007;
const int maxm=1000007;
typedef long long LL;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v,w,mk;
}e[maxm];
int h[maxn],S[maxn];
bool operator < (const E &x,const E &y)//This is the key!
{
	if(x.mk!=y.mk) return x.mk>y.mk;
	if(h[x.v]!=h[y.v]) return h[x.v]>h[y.v];
	return x.w<y.w;
}
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w,0};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
LL ans1=1,ans2;
void Kruskal()
{
	int f1,f2;
	sort(e+1,e+1+ES);
	for(register int i=1;i<=ES;i++)
	{
		if(!e[i].mk) continue;
		f1=f(e[i].u);f2=f(e[i].v);
		if(f1!=f2)
		{
			S[f1]=f2;
			ans1++;
			ans2+=e[i].w;
		}
	}
	return ;
}
queue <int> q;
bool book[maxn];
void BFS()
{
	q.push(1);book[1]=true;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;e[i].mk=1;
			if(!book[v])
			{
				q.push(v);
				book[v]=true;
			}
		}
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v,w;
	for(register int i=1;i<=N;i++)
		h[i]=R(),S[i]=i;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		if(h[u]>h[1]||h[v]>h[1]) continue;
		if(h[u]>=h[v]) addE(u,v,w);
		if(h[v]>=h[u]) addE(v,u,w);
	}
	BFS();
	Kruskal();
	printf("%lld %lld",ans1,ans2);
	return 0;
}
