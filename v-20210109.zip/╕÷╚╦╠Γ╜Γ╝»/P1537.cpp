#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=7;
const int maxv=420007;
int V;
int F[maxv];
int v[maxv],cnt;
void subpack(int num,int val)
{
    for(int k=1;k<=num&&k*val<=200000;k<<=1)
    {
        v[++cnt]=k*val;
        num-=k;
    }
    if(num&&num*val<=200000) v[++cnt]=num*val;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    int T=1,x;
    while(T)
    {
        memset(F,0,sizeof(F));
        V=0;cnt=0;
        for(int i=1;i<=6;i++)
            scanf("%d",&x),subpack(x,i),V+=x*i;
        if(V==0) return 0;
        if(V&1)
        {
            printf("Collection #%d:\n",T);
            puts("Can't be divided.\n");
            ++T;
            continue;
        }
        V>>=1;
        F[0]=1;
        for(int i=1;i<=cnt;i++)
            for(int j=V;j>=v[i];j--)
                F[j]+=F[j-v[i]];
        if(F[V])
        {
            printf("Collection #%d:\n",T);
            puts("Can be divided.\n");
        }
        else
        {
            printf("Collection #%d:\n",T);
            puts("Can't be divided.\n");
        }
        T++;
    }
}