#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int SAC=998244353;
int N,M;
LL sum[107],m[107][2007];
LL F[107][207];
LL ans,non;
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%lld",&m[i][j]),sum[i]+=m[i][j],sum[i]=(sum[i]%SAC+SAC)%SAC;
	ans=1ll;
	for(int i=1;i<=N;i++)
		ans*=(sum[i]+1),ans%=SAC;
	ans=((ans-1)%SAC+SAC)%SAC;
	for(int j=1;j<=M;j++)//�������Ƶ���
	{
		memset(F,0,sizeof(F));
		F[0][N]=1;
		for(int i=1;i<=N;i++)
		{
			for(int d=-i;d<=i;d++)//ö�ٲ�ֵ 
			{
				F[i][d+N]=(F[i-1][d+N]//��ѡi��
				+F[i-1][d+N-1]*m[i][j]//ѡȡ��i�е�j��
				+F[i-1][d+N+1]*(sum[i]-m[i][j]))%SAC;//ѡȡ��i�������� 
			}
		}
		for(int d=N+1;d<=(N<<1);d++)
			non+=F[N][d],non%=SAC;
		non=(non+SAC)%SAC;
	}
	printf("%lld",((ans-non)%SAC+SAC)%SAC);
	return 0;
}
