#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=5000007;
const int mod=1e9+7;
const int lim=5000000;
int T,K,N,M;
bool book[maxn];
typedef long long LL;
int fast_pow(int b,int k)
{
    int s=1;
    while(k)
    {
        if(k&1) s=1ll*s*b%mod;
        b=1ll*b*b%mod;
        k>>=1;
    }
    return s;
}
int mu[maxn],prime[maxn],cnt,p[maxn];
int g[maxn];
void pre()
{
    mu[1]=p[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,mu[i]=-1,p[i]=fast_pow(i,K);
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            p[i*prime[j]]=1ll*p[i]*p[prime[j]]%mod;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else break;
        }
    }
    for(int i=1;i<=lim;i++)
    {
        for(int j=i;j<=lim;j+=i)
            g[j]+=p[i]*mu[j/i]%mod,g[j]%=mod;
    }
    for(int i=1;i<=lim;i++)
        g[i]+=g[i-1],g[i]%=mod;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&T,&K);
    pre();
    while(T--)
    {
        scanf("%d%d",&N,&M);
        int L=1,R;
        long long ans=0;
        if(N>M) swap(N,M);
        while(L<=N)
        {
            R=min(N/(N/L),M/(M/L));
            ans+=1ll*(N/L)*(M/L)%mod*(g[R]-g[L-1])%mod;
            ans%=mod;
            L=R+1;
        }
        printf("%lld\n",(ans+mod)%mod);
    }
    return 0;
}