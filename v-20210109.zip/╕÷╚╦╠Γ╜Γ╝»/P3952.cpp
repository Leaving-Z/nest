#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=107;
int stk[maxn],top;
struct sentence{
    int ty,id;
    int O;
}A[maxn];
int N,C,T;
char s1[17],s2[17],s3[17],s4[17];
bool book[maxn];
int calc(char *s)
{
    int t=0;
    int re=0;
    while(s[t]!=0)
        re=re*10+s[t]-48,++t;
    return re;
}
void solve()
{
    int U=0;
    int ans=0,cur=0;
    for(int i=1;i<=N;i++)
    {
        if(A[i].ty==1)
        {
            if(book[A[i].id]) {puts("ERR");return ;}
            book[A[i].id]=true;
            stk[++top]=i;
            if(A[i].O==-1) ++U;
            else if(A[i].O==1)
            if(!U) ans=max(ans,++cur);
        }
        else
        {
            if(!top) {puts("ERR");return ;}
            if(A[stk[top]].O==-1) --U;
            else if(A[stk[top]].O==1)
                if(!U) --cur;
            book[A[stk[top]].id]=false;
            --top;
        }
    }
    if(top) {puts("ERR");return ;}
    if(ans==C) puts("Yes");
    else puts("No");
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    int k1,k2;
    while(T--)
    {
        top=0;memset(stk,0,sizeof(stk));
        memset(book,0,sizeof(book));
        scanf("%d",&N);
        scanf(" O(%s)",s1+1);
        if(strlen(s1+1)==2) C=0;
        else s1[strlen(s1+1)]=0,C=calc(s1+3);
        for(int i=1;i<=N;i++)
        {
            scanf("%s",s1+1);
            if(s1[1]=='F')
            {
                A[i].ty=1;
                scanf("%s",s2+1);
                scanf("%s",s3+1);
                scanf("%s",s4+1);
                A[i].id=s2[1]-'a'+1;
                if(s3[1]=='n'&&s4[1]=='n') A[i].O=0;
                else if(s3[1]=='n') A[i].O=-1;
                else if(s4[1]=='n') A[i].O=1;
                else
                {
                    k1=calc(s3+1);k2=calc(s4+1);
                    if(k1<=k2) A[i].O=0;
                    else A[i].O=-1;
                } 
            }
            else A[i].ty=-1;
        }
        solve();
    }
    return 0;
}