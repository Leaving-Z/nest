#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=10007;
const int maxm=20007;
struct E{
	int u,v,w1,w2,num;
}e[maxm];
int first[maxn],nt[maxm],ES;
bool operator < (const E &x,const E &y)
{
	if(x.w1!=y.w1) return x.w1<y.w1;
	return x.w2<y.w2;
}
inline void addE(int u,int v,int w1,int w2,int i)
{
	e[++ES]=(E){u,v,w1,w2,i};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,K;
int S[maxn];
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
struct pp{
	int num,ty;
}use[maxn],ANS[maxn];
bool operator < (const pp &x,const pp &y)
{
	return x.num<y.num;
}
bool check(int p)
{
	for(register int i=1;i<=N;i++)
		S[i]=i;
	int cnt=0,f1,f2,cntK=0;
	pp t;
	for(register int i=1;i<=ES;i++)
	{
		f1=f(e[i].u);f2=f(e[i].v);
		if(f1!=f2)
		{
			if(e[i].w2<=p)
			{
				if(e[i].w1<=p) cntK++,t.ty=1;
				else t.ty=2;
				S[f1]=f2;
				t.num=e[i].num;
				use[++cnt]=t;
			}
		}
		if(cnt==N-1) break;
	}
	return cntK>=K&&cnt==N-1;
}
#define mid (l+r>>1)
int main()
{
	scanf("%d%d%d",&N,&K,&M);
	int u,v,w1,w2;
	for(register int i=1;i<M;i++)
	{
		scanf("%d%d%d%d",&u,&v,&w1,&w2);
		addE(u,v,w1,w2,i);
	}
	sort(e+1,e+1+ES);
	int l=1,r=30001,ans;
	while(l<=r)
	{
		if(check(mid)) ans=mid,memcpy(ANS,use,sizeof(use)),r=mid-1;
		else l=mid+1;
	}
	printf("%d",ans);
	sort(ANS+1,ANS+N);
	for(int i=1;i<N;i++)
	printf("\n%d %d",ANS[i].num,ANS[i].ty);
	return 0;	
}
