#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int maxn=100007;
const int mod=1e9+7;
LL F[maxn][3];
int N,K;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline void dfs(int u,int fa)
{
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			F[u][0]*=(F[v][1]+F[v][2])%mod;F[u][0]%=mod;
			F[u][1]*=(F[v][0]+F[v][2])%mod;F[u][1]%=mod;
			F[u][2]*=(F[v][0]+F[v][1])%mod;F[u][2]%=mod;
		}
	}
	return ;
}
int main()
{
	N=R();K=R();
	for(register int i=1;i<=N;i++)
		F[i][0]=F[i][1]=F[i][2]=1;
	int u,v;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	for(register int i=1;i<=K;i++)
	{
		u=R();v=R();
		F[u][0]=F[u][1]=F[u][2]=0;
		F[u][v-1]=1;
	}
	dfs(1,0);
	printf("%lld",(F[1][0]+F[1][1]+F[1][2])%mod);
	return 0;
}
