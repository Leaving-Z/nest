#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int mod=9901;
int fast_pow(int b,int k)
{
    b%=mod;
    int s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
int a,b;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&a,&b);
    int mii;
    int ans=1;
    for(int i=2;i*i<=a;i++)
    {
        if(a%i==0)
        {
            mii=0;
            while(a%i==0) a/=i,mii++;
            mii*=b;
            if(i%mod==1) ans*=(mii/b+1),ans%=mod;
            else ans*=(fast_pow(i,mii+1)-1+mod)%mod*fast_pow(i-1,mod-2)%mod;ans%=mod;
        }
    }
    if(a!=1)
    {
        if(a%mod==1) ans=ans*(b+1)%mod;
        else ans*=(fast_pow(a,b+1)-1+mod)%mod*fast_pow(a-1,mod-2)%mod,ans%=mod;
    }
    printf("%d",ans);
    return 0;
}