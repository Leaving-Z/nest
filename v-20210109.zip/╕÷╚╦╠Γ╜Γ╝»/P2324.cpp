#include<bits/stdc++.h>
using namespace std;
char s[7][7];
int comp[6][6]=
{
	{0,0,0,0,0,0},
	{0,2,2,2,2,2},
	{0,1,2,2,2,2},
	{0,1,1,0,2,2},
	{0,1,1,1,1,2},
	{0,1,1,1,1,1}
};
int m[6][6];
int xy[8][2]=
{
	{1,2},
	{1,-2},
	{-2,1},
	{-2,-1},
	{2,1},
	{2,-1},
	{-1,2},
	{-1,-2}
};
int limit;
bool solve;
inline int H()
{
	int re=0;
	for(int i=1;i<=5;i++)
		for(int j=1;j<=5;j++)
		re+=(comp[i][j]!=m[i][j]);
	return re;
}
inline void swap_(int &x,int &y) {int t=x;x=y;y=t;return ;}
inline void DFS(int x,int y,int step,int last)
{
	if(step==limit)
	{	
		if(H()==0)
			solve=false;
		return ;
	}
	if(!solve) return ;
	int nx,ny;
	for(int i=0;i<8;i++)
	{
		nx=x+xy[i][0];ny=y+xy[i][1];
		if(nx<1||nx>5||ny<1||ny>5||i+last==7) continue;//��ֹ������������ȥ 
		swap_(m[x][y],m[nx][ny]);
		if(H()+step<=limit&&solve) DFS(nx,ny,step+1,i);
		swap_(m[x][y],m[nx][ny]);
	}
	return ; 
}
int T,sx,sy;
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		for(int i=1;i<=5;i++)
			scanf("%s",s[i]+1);
		for(int i=1;i<=5;i++)
			for(int j=1;j<=5;j++)
			{
				if(s[i][j]=='1') m[i][j]=2;
				else if(s[i][j]=='0') m[i][j]=1;
				else sx=i,sy=j,m[i][j]=0;
			}
		for(limit=1,solve=true;limit<=15;limit++)
		{
			DFS(sx,sy,0,-1);
			if(!solve) {printf("%d\n",limit);break;}
		}
		if(solve) printf("-1\n");
	}
	return 0;
}
