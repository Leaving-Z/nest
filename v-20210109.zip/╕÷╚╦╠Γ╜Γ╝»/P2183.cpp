#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxn=100007;
LL N,M,P,K;
LL fast_pow(LL b,LL k,LL mod)
{
    LL s=1;
    while(k)
    {
        if(k&1) (s*=b)%=mod;
        (b*=b)%=mod;
        k>>=1;
    }
    return s;
}
LL g;
void Exgcd(LL a,LL b,LL &x,LL &y)
{
    if(!b)
    {
        g=a;
        x=1;y=0;
        return ;
    }
    Exgcd(b,a%b,y,x);
    y-=(a/b)*x;
    return ;
}
LL fact(LL n,LL p,LL mod)
{
    if(!n) return 1;
    LL res=1;
    for(LL i=2;i<=mod;i++)
    if(i%p) res=res*i%mod;
    res=fast_pow(res,n/mod,mod);
    for(LL i=n/mod*mod;i<=n;i++)
    if(i%p) res=res*(i%mod)%mod;
    return res*fact(n/p,p,mod)%mod;
}
LL inv(LL k,LL mod)
{
    LL x,y;
    Exgcd(k,mod,x,y);
    return (x+mod)%mod;
}
LL C(LL n,LL m,LL p,LL mod)
{
    LL c=0,nf,mf,nmf,kf;
    for(LL i=n;i;i/=p) c+=i/p;
    for(LL i=m;i;i/=p) c-=i/p;
    for(LL i=n-m;i;i/=p) c-=i/p;
    nf=fact(n,p,mod);mf=inv(fact(m,p,mod),mod);nmf=inv(fact(n-m,p,mod),mod);
    kf=fast_pow(p,c,mod);
    return kf*nf%mod*mf%mod*nmf%mod;
}
LL r[maxn],mi[maxn];
LL ExCRT()
{
    LL ans=0,lcm=1;
    LL x,y,c;
    for(int i=1;i<=K;i++)
    {
        Exgcd(lcm,mi[i],x,y);
        c=((r[i]-ans)%mi[i]+mi[i])%mi[i];
        x=(x*(c/g)%(mi[i]/g)+mi[i]/g)%(mi[i]/g);
        ans+=x*lcm;
        lcm*=mi[i]/g;
        ans=(ans%lcm+lcm)%lcm;
    }
    return ans;
}
LL ExLucas(LL n,LL m,LL mod)
{
    K=0;
    for(LL i=2;i*i<=mod;i++)
    {
        if(mod%i==0)
        {
            mi[++K]=1;
            while(mod%i==0) mi[K]*=i,mod/=i;
            r[K]=C(n,m,i,mi[K]);
        }
    }
    if(mod!=1) mi[++K]=mod,r[K]=C(n,m,mod,mod);
    return ExCRT();
}
LL w[7];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld",&P);
    scanf("%lld%lld",&N,&M);
    LL sum=0;
    for(int i=1;i<=M;i++)
    {
        scanf("%lld",&w[i]);sum+=w[i];
    }
    if(sum>N) {printf("Impossible");return 0;}
    LL ans=1;
    for(int i=1;i<=M;i++)
    {
        ans*=ExLucas(N,w[i],P);
        ans%=P;
        N-=w[i];
    }
    printf("%lld",ans);
    return 0;
}