#include<cstdio>
typedef long long LL;
const int maxn=100007;
LL num[maxn];
LL N,ans;
int main()
{
	scanf("%lld",&N);
	for(register int i=N;i>0;i--)
	{
		num[i]=(N/i)*(N/i);
		for(register int j=i<<1;j<=N;j+=i)
			num[i]-=num[j];
		ans+=i*num[i];
	}
	printf("%lld",ans);
	return 0;
}
