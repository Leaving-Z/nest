#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=32007;
const int maxm=160007;
int N,M;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int stk[maxn],top,S[maxn],C;
int dfn[maxn],low[maxn],T;
bool ins[maxn];
void dfs(int u)
{
	ins[u]=true;
	dfn[u]=low[u]=++T;
	stk[++top]=u;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);N<<=1;
	int u,v;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&u,&v);
		addE(u,v+N);
		addE(v,u+N);
	}
	for(int i=1;i<=N;i+=2)
	{
		addE(i,i+1+N);
		addE(i+1+N,i);
		addE(i+1,i+N);
		addE(i+N,i+1);
	}
	for(int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	for(int i=1;i<=N;i++)
	if(S[i]==S[i+N])
	{
		printf("NIE");
		return 0;
	}
	for(int i=1;i<=N;i++)
	if(S[i]<S[i+N]) printf("%d\n",i);
	return 0;
}
