#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=80007;
const int maxm=200007;
struct E{
	int u,v,w,w1;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w,0};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
int s,Te;
int S[maxn],C;
int dfn[maxn],low[maxn],T;
bool ins[maxn];
int stk[maxn],top;
int A[maxn];
void dfs(int u)
{
	dfn[u]=low[u]=++T;
	ins[u]=true;
	stk[++top]=u;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v])
		{
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
		else if(ins[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int dis[maxn];
bool book[maxn];
queue <int> q;
void SPFA()
{
	memset(dis,0x3f,sizeof(dis));
	dis[s]=A[s];book[s]=true;
	q.push(s);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+e[i].w+A[v]<dis[v])
			{
				dis[v]=dis[u]+e[i].w+A[v];
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&M);
	int u,v,w;double dec;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d%lf",&u,&v,&w,&dec);
		addE(u,v,w);
		while(w)
		{
			e[ES].w1+=w;
			w*=dec;
		}
	}
	for(int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	int t=ES;Te=N+1;
	memset(first,0,sizeof(first));
	memset(nt,0,sizeof(nt));ES=0;
	scanf("%d",&s);
	s=S[s];
	for(int i=1;i<=t;i++)
	{
		if(S[e[i].u]==S[e[i].v])
			A[S[e[i].u]]-=e[i].w1;
		if(S[e[i].u]!=S[e[i].v])
			addE(S[e[i].u],S[e[i].v],-e[i].w);
	}
	for(int i=1;i<=C;i++)
		addE(i,Te,0);
	SPFA();
	printf("%d",-dis[Te]);
	return 0;
}