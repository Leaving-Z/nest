#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
#include<queue>
using namespace std;
const int maxn=37;
const int maxm=907;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int in[maxn],tmp[maxn];
int N,M;
bool vis[maxn];
int ans[maxn];
int topo()
{
    queue <int> q;
    memcpy(in,tmp,sizeof(tmp));
    memset(vis,0,sizeof(vis));
    memset(ans,0,sizeof(ans));
    int t=0;
    for(int i=1;i<=N;i++)
        if(in[i]==0) ++t,q.push(i),ans[1]=i;
    int u,v;
    int ix=1;
    bool f=false;
    if(t>1) f=true;
    while(!q.empty())
    {
        u=q.front();q.pop();
        ++ix;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            in[v]--;
            if(!in[v])
            {
                if(ans[ix]) f=true;
                ans[ix]=v;
                q.push(v);
            }
        }
    }
    if(ix<=N) return 0;
    if(f) return -1;
    return 1;
}
char s[7];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,k;
    for(int i=1;i<=M;i++)
    {
        scanf("%s",s+1);
        u=s[1]-'A'+1;v=s[3]-'A'+1;
        addE(u,v);tmp[v]++;
        k=topo();
        if(k==0) {printf("Inconsistency found after %d relations.",i);return 0;}
        else if(k==1)
        {
            printf("Sorted sequence determined after %d relations: ",i);
            for(int i=1;i<=N;i++)
                putchar(ans[i]+'A'-1);
            putchar('.');
            return 0;
        }
    }
    printf("Sorted sequence cannot be determined.");
    return 0;
}