#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1007;
int F[maxn];
int A[maxn];
int N;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d",&A[i]);
	for(int i=1;i<=N;i++)
		for(int j=i;j>0;j--)
			F[j]=max(F[j],F[j-1]+(A[i]==j));
	int ans=0;
	for(int i=1;i<=N;i++)
		ans=max(ans,F[i]);
	printf("%d",ans);
	return 0;
}
