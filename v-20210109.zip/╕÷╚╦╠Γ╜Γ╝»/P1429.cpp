#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=200007;
typedef long double db;
struct node{
    db x,y;
}A[maxn],T[maxn];
bool com1 (const node &x,const node &y)
{
    return x.x<y.x;
}
bool com2 (const node &x,const node &y)
{
    return x.y<y.y;
}
int N;
#define mid (L+R>>1)
db dis(db a1,db b1,db a2,db b2)
{
    return sqrt((a2-a1)*(a2-a1)+(b2-b1)*(b2-b1));
}
db solve(int L,int R)
{
    if(R==L+1) return dis(A[L].x,A[L].y,A[R].x,A[R].y);
    if(R==L+2) return min(dis(A[L].x,A[L].y,A[L+1].x,A[L+1].y),min(dis(A[L+1].x,A[L+1].y,A[R].x,A[R].y),dis(A[L].x,A[L].y,A[R].x,A[R].y)));
    db d1=solve(L,mid),d2=solve(mid+1,R);
    db d=min(d1,d2);
    int cnt=0;
    for(int i=L;i<=R;i++)
    if(A[i].x>=A[mid].x-d&&A[i].x<=A[mid].x+d) T[++cnt]=A[i];
    sort(T+1,T+1+cnt,com2);
    for(int i=1;i<=cnt;i++)
        for(int j=i+1;j<=cnt;j++)
        {
            if(T[j].y-T[i].y>=d) break;
            d=min(d,dis(T[i].x,T[i].y,T[j].x,T[j].y));
        }
    return d;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    db x,y;
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%Lf%Lf",&A[i].x,&A[i].y);
    sort(A+1,A+1+N,com1);
    printf("%.4Lf",solve(1,N));
    return 0;
}