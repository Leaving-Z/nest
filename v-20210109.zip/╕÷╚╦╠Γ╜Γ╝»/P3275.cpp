#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
const int inf=1e8;
struct E{
	int u,v,w;
}e[400000];
int ES;
int N,M;
int first[100007],nt[400000],dis[100007];
int depth[100007],book[100007];
int cnt[100007];
queue <int> q;
inline int R()
{
	int f=1;
	int re=0;
	char c;
	while((c=getchar())<'0'||c>'9')
		if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
		re=re*10+c-48;
	return f*re;
}
inline void add_(int a,int b,int x)
{
	if(x==1)
	{
		e[++ES]=(E){a,b,0};
		nt[ES]=first[a];
		first[a]=ES;
		e[++ES]=(E){b,a,0};
		nt[ES]=first[b];
		first[b]=ES;
	}
	else if(x==2)
	{
		if(a==b)
		{
			printf("-1");
			exit(0);
		}
		e[++ES]=(E){a,b,1};
		nt[ES]=first[a];
		first[a]=ES;
	}
	else if(x==3)
	{
		e[++ES]=(E){b,a,0};
		nt[ES]=first[b];
		first[b]=ES;
	}
	else if(x==4)
	{
		if(a==b)
		{
			printf("-1");
			exit(0);
		}
		e[++ES]=(E){b,a,1};
		nt[ES]=first[b];
		first[b]=ES;
	}
	else if(x==5)
	{
		e[++ES]=(E){a,b,0};
		nt[ES]=first[a];
		first[a]=ES;
	}
	return ;
}
bool SPFA(int S)
{
	for(int i=1;i<=N;i++)
		dis[i]=-inf;
	dis[0]=1;
	q.push(S);
	book[S]=1;
	cnt[S]=1;
	int t;
	while(!q.empty())
	{
		t=q.front();q.pop();
		book[t]=0;
		for(int i=first[t];i;i=nt[i])
		{
			if(dis[t]+e[i].w>dis[e[i].v])
			{
				dis[e[i].v]=dis[t]+e[i].w;
				depth[e[i].v]=depth[t]+1;
				if(depth[e[i].v]>N) return false;
				
				if(book[e[i].v]==0)
				{
					q.push(e[i].v);cnt[e[i].v]++;
					book[e[i].v]=1;
					if(cnt[e[i].v]>N) return false;
				}
			}
		}
	}
	return true;
}
int main()
{
	N=R();M=R();
	int a,b,k;
	for(int i=1;i<=M;i++)
	{
		k=R();a=R();b=R();
		add_(a,b,k);
	}
	for(int i=N;i>=1;i--)
	{
		e[++ES]=(E){0,i,0};
		nt[ES]=first[0];
		first[0]=ES;
	}
	if(SPFA(0))
	{
		long long sum=0;
		for(int i=1;i<=N;i++)
			sum+=dis[i];
		printf("%lld",sum);
	}
	else printf("-1");
	return 0;
}
