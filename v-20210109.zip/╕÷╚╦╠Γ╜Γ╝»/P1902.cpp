#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=1007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int m[maxn][maxn];
struct node{
	int x,y;
}q[maxn*maxn];
int head,tail;
int N,M;
bool book[maxn][maxn];
int nxt[4][2]=
{
	{1,0},
	{-1,0},
	{0,1},
	{0,-1}
};
bool check(int p)
{
	memset(book,0,sizeof(book));
	head=1;tail=0;
	node t;t.x=1;
	for(register int i=1;i<=M;i++)
		t.y=i,q[++tail]=t;
	node tmp;
	while(head<=tail)
	{
		t=q[head];++head;
		if(t.x==N) return true;
		for(int i=0;i<4;i++)
		{
			tmp.x=t.x+nxt[i][0];
			tmp.y=t.y+nxt[i][1];
			if(tmp.x<1||tmp.x>N) continue;
			if(tmp.y<1||tmp.y>M) continue;
			if(m[tmp.x][tmp.y]>p) continue;
			if(book[tmp.x][tmp.y]) continue;
			book[tmp.x][tmp.y]=true;
			q[++tail]=tmp;
		}
	}
	return false;
}
#define mid (L+R>>1)
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();M=R();
	int maxx=-1;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
			m[i][j]=R(),maxx=max(maxx,m[i][j]);
	int L=0,R=1024,ans;
	while(L<=R)
	{
		if(check(mid)) ans=mid,R=mid-1;
		else L=mid+1;
	}
	printf("%d",ans);
	return 0;
}
