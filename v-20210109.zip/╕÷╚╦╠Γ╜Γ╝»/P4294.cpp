#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<bitset>
#include<ctime>
using namespace std;
const int maxn=107;
const int maxk=11;
const int maxs=(1<<10)+7;
bitset <maxn> fl[maxn][maxs],ml[maxn][maxn];
int f[maxn][maxs];
int C[maxn][maxn];
int m[maxn][maxn];
int N,r,c,K;
int id[maxk];
bool vis[maxn];
int val[maxn];
void Dij(int s)
{
    memset(vis,0,sizeof(vis));
    int minn,minp;
    for(int i=1;i<=N;i++)
    {
        minn=0x7f7f7f7f;
        minp=0;
        for(int j=1;j<=N;j++)
        if(!vis[j]&&f[j][s]<minn) minn=f[j][s],minp=j;
        if(minn>1e9) return ;
        vis[minp]=true;
        for(int j=1;j<=N;j++)
            //f[j][s]=min(f[j][s],f[minp][s]+m[minp][j]);
        if(f[minp][s]+m[minp][j]<f[j][s]) f[j][s]=f[minp][s]+m[minp][j],fl[j][s]=fl[minp][s]|ml[minp][j];
    }
    return ;
}
int ix(int i,int j)
{
    return (i-1)*c+j;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&r,&c);N=r*c;
    memset(m,0x3f,sizeof(m));
    memset(f,0x3f,sizeof(f));
    int t;
    for(int i=1;i<=r;i++)
        for(int j=1;j<=c;j++)
        {
            scanf("%d",&C[i][j]);
            t=ix(i,j);
            if(!C[i][j]) id[++K]=t,f[id[K]][1<<K-1]=0,fl[id[K]][1<<K-1][t]=1;
            m[t][t]=0;
            val[t]=C[i][j];
            ml[t][t][t]=1;
        }
    memset(m,0x3f,sizeof(m));
    for(int i=1;i<=N;i++)
        m[i][i]=0;
    for(int i=1;i<=r;i++)
        for(int j=1;j<=c;j++)
        {
            if(i>1) m[ix(i,j)][ix(i-1,j)]=C[i-1][j];
            if(i<r) m[ix(i,j)][ix(i+1,j)]=C[i+1][j];
            if(j>1) m[ix(i,j)][ix(i,j-1)]=C[i][j-1];
            if(j<c) m[ix(i,j)][ix(i,j+1)]=C[i][j+1];
        }
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
        if(m[i][j]!=0x3f3f3f3f) ml[i][j][i]=ml[i][j][j]=1;
    for(int k=1;k<=N;k++)
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
                //m[i][j]=min(m[i][j],m[i][k]+m[k][j]);
            if(m[i][k]+m[k][j]<m[i][j]) m[i][j]=m[i][k]+m[k][j],ml[i][j]=ml[i][k]|ml[k][j];
    //for(int i=1;i<=K;i++) scanf("%d",&id[i]);
    int all=(1<<K)-1;
    for(int i=1;i<=all;i++)
    {
        for(int j=1;j<=N;j++)
            for(int k=i;k;k=(k-1)&i)
                //f[j][i]=min(f[j][i],f[j][i^k]+f[j][k]);
            if(f[j][i^k]+f[j][k]-val[j]<f[j][i]) f[j][i]=f[j][i^k]+f[j][k]-val[j],fl[j][i]=fl[j][i^k]|fl[j][k];
        Dij(i);
    }
    printf("%d\n",f[id[1]][all]);
    for(int i=1;i<=r;i++,putchar('\n'))
        for(int j=1;j<=c;j++)
        {
            if(!C[i][j]) putchar('x');
            else if(fl[id[1]][all][ix(i,j)]) putchar('o');
            else putchar('_');
        }
    return 0;
}