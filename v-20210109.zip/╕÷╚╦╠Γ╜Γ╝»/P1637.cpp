#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=30007;
typedef long long LL;
int C[maxn<<1],N;
int F[4][maxn];
struct pi{
	int val,num;
}A[maxn];
int ix[maxn],I;
bool operator < (const pi &x,const pi &y)
{
	return x.val<y.val;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline void Update(int x,int v)
{
	while(x<=N)
	{
		C[x]+=v;
		x+=x&(-x);
	}
	return ;
}
inline int sum(int x)
{
	int ans=0;
	while(x)
	{
		ans+=C[x];
		x-=x&(-x);
	}
	return ans;
}
inline void RK()
{
	sort(A+1,A+1+N);
	for(register int i=1;i<=N;i++)
	{
		if(A[i].val==A[i-1].val) ix[A[i].num]=ix[A[i-1].num];
		else ix[A[i].num]=++I;
	}
	return ;
}
int main()
{
	N=R();
	LL ans=0;
	for(register int i=1;i<=N;i++)
		A[i].val=R(),A[i].num=i,F[1][i]=1;
	RK();
	LL t1,t2;
	for(register int i=2;i<=3;i++)
	{
		memset(C,0,sizeof(C));
		for(register int j=1;j<=N;j++)
		{
			F[i][j]=sum(ix[j]-1);
			Update(ix[j],F[i-1][j]);
		}
	}
	for(register int i=1;i<=N;i++)
		ans+=F[3][i];
	printf("%lld",ans);
	return 0;
}
