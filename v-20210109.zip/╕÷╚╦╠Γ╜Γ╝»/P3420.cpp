#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1000007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int S[maxn];
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int N;
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		S[i]=i;
	int v,f1,f2;
	int ans=N;
	for(register int i=1;i<=N;i++)
	{
		v=R();f1=f(i);f2=f(v);
		if(f1!=f2)
		{
			ans--;
			S[f1]=f2;
		}
	}
	printf("%d",ans);
	return 0;
}
