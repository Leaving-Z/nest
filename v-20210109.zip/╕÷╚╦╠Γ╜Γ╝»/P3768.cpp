#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<unordered_map>
using namespace std;
const int maxn=5000007;
const int lim=5000000;
typedef long long LL;
unordered_map <LL,LL> __phi;
int prime[maxn],cnt;
LL phi[maxn];
bool book[maxn];
LL N,P,inv6,inv2;
LL fast_pow(LL b,LL k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%P;
        b=b*b%P;
        k>>=1;
    }
    return s;
}
void pre()
{
    phi[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,phi[i]=i-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]==0)
            {
                phi[i*prime[j]]=phi[i]*prime[j];
                break;
            }
            phi[i*prime[j]]=phi[i]*(prime[j]-1);
        }
    }
    for(int i=1;i<=lim;i++)
        phi[i]=phi[i]*i%P*i%P,phi[i]+=phi[i-1],phi[i]%=P;
    inv6=fast_pow(6,P-2);
    inv2=fast_pow(2,P-2);
    return ;
}
LL f_g_s(LL x)
{
    x%=P;
    LL re=x*(x+1)%P*inv2%P;
    return re*re%P;
}
LL g_s(LL x)
{
    x%=P;
    return x*(x+1)%P*(2*x+1)%P*inv6%P;
}
LL S_phi(LL x)
{
    if(__phi[x]) return __phi[x];
    if(x<=lim) return phi[x];
    LL L=2,R;
    LL res=f_g_s(x);
    while(L<=x)
    {
        R=x/(x/L);
        res-=(g_s(R)-g_s(L-1))*S_phi(x/L)%P;
        res%=P;
        L=R+1;
    }
    if(res<0) res+=P;
    return __phi[x]=res;
}
LL _(LL t)
{
    t%=P;
    return (t+1)*t%P;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&P,&N);
    pre();
    LL L=1,R,ans=0;
    while(L<=N)
    {
        R=N/(N/L);
        ans+=_(N/L)*_(N/L)%P*(S_phi(R)-S_phi(L-1))%P;
        ans%=P;
        L=R+1;
    }
    if(ans<0) ans+=P;
    ans=ans*inv2%P*inv2%P;
    printf("%lld",ans);
    return 0;
}