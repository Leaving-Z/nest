#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
#define x1 bird[i][0]
#define x2 bird[j][0]
#define y1 bird[i][1]
#define y2 bird[j][1]
#define x bird[k][0]
#define y bird[k][1]
const double g=0.0000001;
double _abs (double k)
{
	return k>=0?k:-k;
}
int eff[330];
int DP[300000];
bool book[330];
int cnt;
int N,T,M;
double bird[20][2];
void pre()
{
	double p,q,a,b;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
		{
			if(x1==x2||i==j) continue;
			p=x1/x2;q=(x1*x1)/(x2*x2);
			a=(y2*p-y1)/(x2*x2*p-x1*x1);
			b=(y2*q-y1)/(x2*q-x1);
			if(a>=-g) continue;
			cnt++;
			for(int k=1;k<=N;k++)
			{
				if(_abs(x*x*a+x*b-y)<=g)
				eff[cnt]|=(1<<k-1);
			}
		}
	for(int i=1;i<=N;i++)
	eff[++cnt]|=(1<<i-1);
	return ;
}
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		cnt=0;
		memset(eff,0,sizeof(eff));
		memset(DP,0x7f,sizeof(DP));
		DP[0]=0;
		scanf("%d",&N);scanf("%d",&M);
		for(int i=1;i<=N;i++)
			scanf("%lf%lf",&bird[i][0],&bird[i][1]);
		pre();
		int all=1<<N;
		all--;
		for(int i=0;i<=all;i++)
		{
			for(int j=1;j<=cnt;j++)
			if(DP[i|eff[j]]>DP[i]+1) DP[i|eff[j]]=DP[i]+1;
		}
		printf("%d\n",DP[all]);
	}
}
