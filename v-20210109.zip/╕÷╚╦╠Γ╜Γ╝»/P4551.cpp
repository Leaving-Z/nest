#include<cstdio>
#include<algorithm>
using namespace std; 
struct E{
	int u,v,w;
}e[200007];
int first[100007],nt[200007],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u,w};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
int dis[100007];
inline void DFS(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dis[v]=dis[u]^e[i].w;
			DFS(v,u);
		}
	}
	return ;
}
int Trie[3100007][2];
int N,all,ans;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline void Insert(int x)
{
	int p=0;
	for(int i=(1<<30);i;i>>=1)
	{
		if(dis[x]&i)
		{
			if(Trie[p][1]==0)
				Trie[p][1]=++all;
			p=Trie[p][1];
		}
		else
		{
			if(Trie[p][0]==0)
				Trie[p][0]=++all;
			p=Trie[p][0];
		}
	}
	return ;
}
inline void check(int x)
{
	int p=0,t=0;
	for(int i=(1<<30);i;i>>=1)
	{
		if(dis[x]&i)
		{
			if(Trie[p][0])
				p=Trie[p][0],t|=i;
			else p=Trie[p][1];
		}
		else
		{
			if(Trie[p][1])
				p=Trie[p][1],t|=i;
			else p=Trie[p][0];
		}
	}
	if(t>ans) ans=t;
	return ;
} 
int main()
{
	N=R();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
	}
	DFS(1,0);
	for(int i=1;i<=N;i++)
		Insert(i);
	for(int i=1;i<=N;i++)
		check(i);
	printf("%d",ans);
	return 0;
} 
