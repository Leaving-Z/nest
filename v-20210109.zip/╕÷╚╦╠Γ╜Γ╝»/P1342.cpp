#include<cstdio>
#include<queue>
#include<iostream>
#include<algorithm>
using namespace std;
const int inf=1e8;
struct E{
	int u,v,w;
}e[1000005][2];
int first[1000005][2],nt[1000005][2];
int dis[1000005][2];
struct VD{
	int dis,num;
};
bool operator < (const VD &a,const VD &b)
{
	return a.dis>b.dis;
}
int n,m;
long long ans;
void inff(int k)
{
	for(int i=2;i<=n;i++)
		dis[i][k]=inf;
	return ;
}
priority_queue <VD> q;
void Dijkstra(int k)
{
	//priority_queue <VD> q;
	VD temp;
	temp=(VD){0,1};
	q.push(temp);
	inff(k);
	while(!q.empty())
	{
		temp=q.top();
		q.pop();
		int x=temp.num;
		if(dis[x][k]<temp.dis) continue;
		for(int i=first[x][k];i;i=nt[i][k])
		{
			if(dis[x][k]+e[i][k].w<dis[e[i][k].v][k])
			{
				dis[e[i][k].v][k]=dis[x][k]+e[i][k].w;
				temp=(VD){dis[e[i][k].v][k],e[i][k].v};
				q.push(temp);
			}
		}
	}
	return ;
}
inline int r()
{
    int x=0,f=1;
	char c=getchar();
    while(c>'9'||c<'0') {if(c=='-') f=-1;c=getchar();}
    while(c>='0'&&c<='9') {x=x*10+c-'0'; c=getchar();}
    return x*f;
}
int main()
{
	//freopen("testdata.in","r",stdin);
	n=r();m=r();
	int u,v,w;
	for(int i=1;i<=m;i++)
	{
		u=r();v=r();w=r();
		e[i][0]=(E){u,v,w};
		e[i][1]=(E){v,u,w};
		nt[i][0]=first[u][0];
		nt[i][1]=first[v][1];
		first[u][0]=i;
		first[v][1]=i;		
	}
	Dijkstra(0);
	for(int i=2;i<=n;i++)
		ans+=(long long)dis[i][0];
	Dijkstra(1);
	for(int i=2;i<=n;i++)
		ans+=(long long)dis[i][1];
	printf("%lld",ans);
	return 0;
}
