#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
#define R (L+len-1)
struct INT{
	int num[80];
	int len;
	INT () {memset(num,0,sizeof(num));len=1;}
	bool operator < (const INT &a) const
	{
		if(len<a.len) return true;
		if(a.len>len) return false;
		for(int i=len;i>=1;i--)
		{
			if(num[i]>a.num[i]) return false;
			if(num[i]<a.num[i]) return true;
		}
		return false;
	}
	INT operator + (const INT &a) const
	{
		INT ans;
		int l=max(len,a.len);
		ans.len=l;
		for(int i=1;i<=l;i++)
		{
			ans.num[i]+=num[i]+a.num[i];
			if(ans.num[i]>=10)
			{
				ans.num[i]%=10;
				ans.num[i+1]++;
			}
		}
		while(ans.num[ans.len+1]) ans.len++;
		return ans;
	}
	INT operator * (const INT &a) const
	{
		INT ans;
		ans.len=a.len+len;
		for(int i=1;i<=len;i++)
			for(int j=1;j<=a.len;j++)
			{
				ans.num[i+j-1]+=num[i]*a.num[j];
				if(ans.num[i+j-1]>=10)
				{
					ans.num[i+j]+=ans.num[i+j-1]/10;
					ans.num[i+j-1]%=10;
				}
			}
		while(ans.num[ans.len]==0&&ans.len>0) ans.len--;
		return ans;
	}
	void push(const char s[])
	{
		int l=strlen(s);
		len=l;
		for(int i=1;i<=l;i++)
			num[l-i+1]=s[i-1]-'0';
		return ;
	}
	void print()
	{
		for(int i=len;i>0;i--)
		printf("%d",num[i]);
		return ;
	}
}DP[45][45][8];
int N,K;
char s[60];
char t[60];
int main()
{
	cin>>N>>K;
	cin>>s;
	for(int i=0;i<N;i++)
		for(int j=i;j<N;j++)
		{
			memset(t,0,sizeof(t));
			for(int k=i,k1=0;k<=j;k++,k1++)
				t[k1]=s[k];
			DP[i+1][j+1][0].push(t);
		}
	for(int k=1;k<=K;k++)
		for(int len=2;len<=N;len++)
			for(int L=1;L+len-1<=N;L++)
				for(int b=L;b<R;b++)
					DP[L][R][k]=max(DP[L][b][k-1]*DP[b+1][R][0],DP[L][R][k]);
	DP[1][N][K].print();
	return 0;
}
