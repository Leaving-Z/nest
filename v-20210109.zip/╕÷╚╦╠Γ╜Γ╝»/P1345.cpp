#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=3607;
const int maxm=6000007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
int N,M,ans,S,T,all;
int cur[maxn],cnt[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	q.push(S);
	cnt[S]=1;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i))
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int v,d,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min_(f,cf(i)));
			if(d>0)
			{
				cf(i)-=d;
				cf(i^1)+=d;
				sum+=d;
				f-=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	S=0;
	N=R();
	T=maxn-1;
	int x,cf,cf_;
	for(register int i=1;i<=N;i++)
	{
		cf=R();all+=cf;
		addE(S,i,cf);
		addE(i,S,0);
	}
	for(register int i=1;i<=N;i++)
	{
		cf=R();all+=cf;
		addE(i,T,cf);
		addE(T,i,0);
	}
	M=R();
	for(register int i=1;i<=M;i++)
	{
		x=R();cf=R();cf_=R();all+=cf;all+=cf_;
		addE(S,N+i,cf);addE(N+i,S,0);
		addE(N+i+M,T,cf_);addE(T,N+i+M,0);
		for(register int j=1;j<=x;j++)
		{
			cf=R();
			addE(N+i,cf,inf);addE(cf,N+i,0);
			addE(cf,N+i+M,inf);addE(N+i+M,cf,0);
		}
	}
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",all-ans);
	return 0;
}
