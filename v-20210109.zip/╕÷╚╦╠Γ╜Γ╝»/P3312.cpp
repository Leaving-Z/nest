#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int lim=100000;
const int maxq=20007;
typedef long long LL;
const LL mod=(1ll<<31);
struct node{
    LL s;
    int d;
}A[maxn];
bool com1(const node &x,const node &y)
{
    return x.s<y.s;
}
bool book[maxn];
int prime[maxn],cnt,mu[maxn],cur;
LL pcnt[maxn];
void pre()
{
    mu[1]=1;
    A[1].s=A[1].d=1;
    for(int i=2;i<=lim;i++)
    {
        A[i].d=i;
        if(!book[i]) prime[++cnt]=i,A[i].s=i+1,pcnt[i]=i+1,mu[i]=-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j])
            {
                pcnt[i*prime[j]]=prime[j]+1;
                A[i*prime[j]].s=A[i].s*(prime[j]+1);
                mu[i*prime[j]]=-mu[i];
            }
            else
            {
                pcnt[i*prime[j]]=pcnt[i]*prime[j]+1;
                A[i*prime[j]].s=A[i].s/pcnt[i]*pcnt[i*prime[j]];
                mu[i*prime[j]]=0;
                break;
            }
        }
    }
    sort(A+1,A+1+lim,com1);
    cur=1;
    return ;
}
int N,M,a,T;
LL C[maxn];
void update(int x,int k)
{
    while(x<=lim) C[x]+=k,C[x]%=mod,x+=x&-x;
    return ;
}
LL Query(int x)
{
    LL re=0;
    while(x) re+=C[x],re%=mod,x&=x-1;
    return re;
}
void update()
{
    int x;
    while(A[cur].s<=a&&cur<=lim)
    {
        x=A[cur].d;
        for(int i=x;i<=lim;i+=x)
            update(i,(A[cur].s*mu[i/x])%mod);
        ++cur;
    }
    return ;
}
struct query{
    int n,m,a,id;
}q[maxq];
bool com2(const query &x,const query &y)
{
    return x.a<y.a;
}
long long ans[maxq];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&T);
    pre();
    for(int i=1;i<=T;i++)
    {
        scanf("%d%d%d",&q[i].n,&q[i].m,&q[i].a);
        q[i].id=i;
    }
    sort(q+1,q+1+T,com2);
    for(int i=1;i<=T;i++)
    {
        N=q[i].n;M=q[i].m;a=q[i].a;
        if(N>M) swap(N,M);
        update();
        int L=1,R;
        while(L<=N)
        {
            R=min(N/(N/L),M/(M/L));
            ans[q[i].id]+=(N/L)*(M/L)%mod*(Query(R)-Query(L-1))%mod;
            ans[q[i].id]%=mod;
            L=R+1;
        }
    }
    for(int i=1;i<=T;i++)
        printf("%lld\n",(ans[i]+mod)%mod);
    return 0;
}