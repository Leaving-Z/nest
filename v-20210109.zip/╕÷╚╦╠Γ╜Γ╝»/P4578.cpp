#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=2007;
const int maxm=4007;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,K,T;
bool ins[maxn],vis[maxn],book[maxn];
int dis[maxn];
bool dfs(int u)
{
	int v;
	ins[u]=true;book[u]=true;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dis[u]+e[i].w<dis[v])
		{
			dis[v]=dis[u]+e[i].w;
			if(ins[v]) return false;
			else if(!dfs(v)) return false;
		}
	}
	ins[u]=false;
	return true;
}
int main()
{
	bool f;
	scanf("%d",&T);
	while(T--)
	{
		memset(first,0,sizeof(first));
		memset(nt,0,sizeof(nt));
		ES=0;f=true;
		memset(dis,0x7f,sizeof(dis));
		memset(vis,0,sizeof(vis));
		memset(book,0,sizeof(book));
		memset(ins,0,sizeof(ins));
		scanf("%d%d%d",&N,&M,&K);
		int x,y,z;
		for(int i=1;i<=K;i++)
		{
			scanf("%d%d%d",&x,&y,&z);
			addE(x,y+N,z);vis[x]=vis[y+N]=true;
			addE(y+N,x,-z);
		}
		for(int i=1;i<=N;i++)
		if(vis[i]&&!book[i])
		{
			dis[i]=0;
			if(!dfs(i)) {puts("No"),f=false;break;}
		}	
		if(f) puts("Yes");
	}
	return 0;
}
