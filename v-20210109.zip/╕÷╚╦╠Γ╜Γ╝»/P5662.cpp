#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int DP[10007];
int price[107][107];
int N,T,M;
int ans;
int main()
{
	scanf("%d%d%d",&T,&N,&M);
	ans=M;
	for(int i=1;i<=T;i++)
		for(int j=1;j<=N;j++)
		scanf("%d",&price[i][j]);
	for(int i=1;i<=T;i++)
	{
		memset(DP,~0x7f,sizeof(DP));
		DP[ans]=ans;
		for(int j=1;j<=N;j++)
		{
			for(int k=ans;k>=price[i][j];k--)
				DP[k-price[i][j]]=max(DP[k-price[i][j]],DP[k]-price[i][j]+price[i+1][j]);
		}
		int nt=0;
		for(int k=0;k<=ans;k++)
			nt=max(nt,DP[k]);
		ans=nt;
	}
	printf("%d",ans);
	return 0;
}
