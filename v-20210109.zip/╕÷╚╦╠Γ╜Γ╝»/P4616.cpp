#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
int TREE[maxn<<2];
int id[maxn],top[maxn],sz[maxn],fa[maxn],son[maxn],depth[maxn],anti[maxn],A[maxn],ix;
struct E{
    int u,v,w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
}
int S[maxn],N,M,Q;
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        A[v]=e[i].w;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;anti[ix]=u;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==son[u]||v==fa[u]) continue;
        dfs2(v,v);
    }
    return ;
}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define v(i) TREE[i]
void Build(int L,int R,int i)
{
    if(L==R) {TREE[i]=A[anti[L]];return ;}
    Build(L,mid,Ls);
    Build(mid+1,R,Rs);
    v(i)=max(v(Ls),v(Rs));
    return ;
}
int Query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return v(i);
    int re=0;
    if(l<=mid) re=max(re,Query(L,mid,l,r,Ls));
    if(r>mid) re=max(re,Query(mid+1,R,l,r,Rs));
    return re;
}
int Query_Path(int x,int y)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re=max(re,Query(1,N,id[top[x]],id[x],1));
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re=max(re,Query(1,N,id[x]+1,id[y],1));
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&M,&Q);
    for(int i=1;i<=N;i++)
        S[i]=i;
    int f1,f2;
    for(int i=M;i>0;i--)
    {
        for(int j=i*2;j<=N;j+=i)
        {
            f1=f(i);f2=f(j);
            if(f1!=f2) addE(i,j,M-i+1),addE(j,i,M-i+1),S[f2]=f1;
        }
    }
    dfs1(1);dfs2(1,1);
    Build(1,N,1);
    int u,v;
    while(Q--)
    {
        scanf("%d%d",&u,&v);
        printf("%d\n",Query_Path(u,v));
    }
    return 0;
}