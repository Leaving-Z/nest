#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct E{
	int u,v,w;
}e[200005];
int s[305];
int f(int x)
{
	return s[x]==x?x:s[x]=f(s[x]);
}
void _merge(int x,int y)
{
	int f1=f(x),f2=f(y);
	s[f2]=f1;
	return ;
}
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int n,m;
int main()
{
	scanf("%d%d",&n,&m);
	int u,v,w;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		e[i]=(E){u,v,w};
		e[i+m]=(E){v,u,w}; 
	}
	for(int i=1;i<=n;i++)
		s[i]=i;
	sort(e+1,e+1+2*m);
	int MST=-1,num=0;
	for(int i=1;i<=2*m;i++)
	{
		if(f(e[i].u)==f(e[i].v)) continue;
		MST=max(MST,e[i].w);
		_merge(e[i].u,e[i].v);
		num++;
		if(num==n-1) break;
	}
	printf("%d %d",num,MST);
	return 0;
}
