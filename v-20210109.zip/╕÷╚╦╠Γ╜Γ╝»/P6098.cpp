#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int N,Q,ix;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
int TREE[maxn<<2];
int depth[maxn],sz[maxn],top[maxn],A[maxn];
int son[maxn],id[maxn],anti[maxn],fa[maxn];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	e[ES+N]=(E){v,u};
	nt[ES+N]=first[v];
	first[v]=ES+N;
	return ;
}
inline int Re()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
inline void DFS(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			depth[v]=depth[u]+1;
			fa[v]=u;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[v]>sz[son[u]]) son[u]=v;
		}
	}
	return ;
}
inline void dfs(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u]&&v!=son[u])
			dfs(v,v);
	}
	return ;
}
#define mid (L+R>>1)
inline void Build(int L,int R,int i)
{
	if(L==R)
	{
		TREE[i]=A[anti[L]];
		return ;
	}
	Build(L,mid,i<<1);
	Build(mid+1,R,i<<1|1);
	TREE[i]=TREE[i<<1]^TREE[i<<1|1];
	return ;
}
inline void Update(int L,int R,int x,int i,int k)
{
	if(L==R)
	{
		TREE[i]=k;
		return ;
	}
	if(x<=mid) Update(L,mid,x,i<<1,k);
	else Update(mid+1,R,x,i<<1|1,k);
	TREE[i]=TREE[i<<1]^TREE[i<<1|1];
	return ;
}
inline int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
		return TREE[i];
	int ans=0;
	if(l<=mid) ans^=Query(L,mid,l,r,i<<1);
	if(r>mid) ans^=Query(mid+1,R,l,r,i<<1|1);
	return ans;
}
inline int Query_Path(int x,int y)
{
	int ans=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		ans^=Query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	ans^=Query(1,N,id[x],id[y],1);
	return ans;
}
int main()
{
	N=Re();Q=Re();
	int u,v,s;
	for(int i=1;i<=N;i++)
		A[i]=Re();
	for(int i=1;i<N;i++)
	{
		u=Re();v=Re();
		addE(u,v);
	}
	DFS(1);dfs(1,1);
	Build(1,N,1);
	for(int i=1;i<=Q;i++)
	{
		s=Re();u=Re();v=Re();
		if(s==1)
			 Update(1,N,id[u],1,v);
		else printf("%d\n",Query_Path(u,v));
	}
	return 0;
}
