#include<cstdio>
#include<algorithm>
using namespace std;
inline int max_(const int &x,const int &y)
{
	return x>y?x:y;
}
const int maxn=50007;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
int TREE[maxn<<2],lazy[maxn<<2];
int N,M;
#define L(i) (i<<1)
#define R(i) (i<<1|1)
#define l(i) lazy[i]
#define mid (L+R>>1)
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int Read()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int depth[maxn],id[maxn],sz[maxn],anti[maxn];
int top[maxn],fa[maxn],son[maxn],ix;
inline void DFS(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			depth[v]=depth[u]+1;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[v]>sz[son[u]]) son[u]=v;
		}
	}
	return ;
}
inline void dfs(int u,int tp)
{
	id[u]=++ix;anti[ix]=u;
	top[u]=tp;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs(v,v);
	}
	return ;
}
inline void LAZY(int i)
{
	if(!l(i)) return ;
	TREE[L(i)]+=l(i);
	TREE[R(i)]+=l(i);
	l(L(i))+=l(i);l(R(i))+=l(i);
	l(i)=0;
	return ;
}
inline void Update(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
	{
		TREE[i]++;
		l(i)++;
		return ;
	}
	LAZY(i);
	if(l<=mid) Update(L,mid,l,r,L(i));
	if(r>mid) Update(mid+1,R,l,r,R(i));
	TREE[i]=max_(TREE[L(i)],TREE[R(i)]);
	return ;
}
inline void Update_Path(int u,int v)
{
	while(top[u]!=top[v])
	{
		if(depth[top[u]]<depth[top[v]]) swap(u,v);
		Update(1,N,id[top[u]],id[u],1);
		u=fa[top[u]];
	}
	if(depth[u]>depth[v]) swap(u,v);
	Update(1,N,id[u],id[v],1);
	return ;
}
int main()
{
	N=Read();M=Read();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);addE(v,u);
	}
	DFS(1);dfs(1,1);
	for(int i=1;i<=M;i++)
	{
		u=Read();v=Read();
		Update_Path(u,v);
	}
	printf("%d",TREE[1]);
	return 0;
}
