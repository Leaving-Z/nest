#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=300007;
const int maxm=600007;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int sz[maxn],fa[maxn],son[maxn],dep[maxn],W[maxn],dis[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dep[v]=dep[u]+1;
        fa[v]=u;
        W[v]=e[i].w;
        dis[v]=dis[u]+e[i].w;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int top[maxn];
void dfs2(int u,int tp)
{
    top[u]=tp;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int LCA(int x,int y)
{
    while(top[x]!=top[y])
    {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        x=fa[top[x]];
    }
    return dep[x]>dep[y]?y:x;
}
int sum[maxn];
void dfs(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dfs(v);
        sum[u]+=sum[v];
    }
    return ;
}
struct node{
    int l,r,v;
}Q[maxn];
bool com (const node &x,const node &y)
{
    return x.v<y.v;
}
int N,M;
bool check(int mid)
{
    int u,v,lca,cnt=0;
    memset(sum,0,sizeof(sum));
    int mx=0;
    for(int i=M;i>0;i--)
    {
        if(Q[i].v<=mid) continue;
        ++cnt;
        mx=max(mx,Q[i].v);
        u=Q[i].l;
        v=Q[i].r;
        lca=LCA(u,v);
        sum[u]++;
        sum[v]++;
        sum[lca]-=2;
    }
    dfs(1);
    for(int i=1;i<=N;i++)
    if(sum[i]==cnt)
    {
        if(mx-W[i]<=mid) return true;
    }
    return false;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,w;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        addE(u,v,w);addE(v,u,w);
    }
    dfs1(1);
    dfs2(1,1);
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&Q[i].l,&Q[i].r);
        u=LCA(Q[i].l,Q[i].r);
        Q[i].v=dis[Q[i].l]+dis[Q[i].r]-2*dis[u];
    }
    int L=0,R=1e9,mid,ans;
    while(L<=R)
    {
        mid=L+R>>1;
        if(check(mid)) ans=mid,R=mid-1;
        else L=mid+1;
    }
    printf("%d",ans);
    return 0;
}