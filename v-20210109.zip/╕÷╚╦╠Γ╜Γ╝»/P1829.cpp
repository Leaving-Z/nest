#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=10000007;
const int lim=10000000;
const int mod=20101009;
const int inv2=mod+1>>1;
typedef long long LL;
int N,M;
bool book[maxn];
int prime[maxn],cnt,mu[maxn];
void pre()
{
    mu[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,mu[i]=-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j]) mu[i*prime[j]]=-mu[i];
            else {mu[i*prime[j]]=0;break;}
        }
    }
    for(int i=1;i<=lim;i++)
        mu[i]=mu[i]*1ll*i*i%mod,mu[i]+=mu[i-1],mu[i]%=mod;
    return ;
}
long long calc(int n,int m)
{
    if(n>m) swap(n,m);
    int L=1,R;
    long long res=0,l1,l2;
    while(L<=n)
    {
        R=min(n/(n/L),m/(m/L));
        l1=n/L;l2=m/L;
        res+=((mu[R]-mu[L-1])%mod+mod)%mod*(1+l1)%mod*l1%mod*inv2%mod*(1+l2)%mod*l2%mod*inv2%mod;
        res%=mod;
        L=R+1;
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    pre();
    scanf("%d%d",&N,&M);
    long long ans=0;
    int L=1,R;
    if(N>M) swap(N,M);
    while(L<=N)
    {
        R=min(N/(N/L),M/(M/L));
        ans+=(L+R)*(R-L+1ll)/2%mod*calc(N/L,M/L)%mod;
        ans%=mod;
        L=R+1;
    }
    printf("%lld",ans);
    return 0;
}