#include<bits/stdc++.h>
using namespace std;
const int maxn=10007;
const int maxM=100007;
struct E{
	int u,v;
}e[maxM<<1];
int first[maxn],nt[maxM<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int C[maxn],sz[2];
bool book[maxn];
inline bool dfs(int u,int c)
{
	if(book[u])
	{
		if(C[u]==c) return true;
		else return false;
	}
	book[u]=true;sz[C[u]=c]++;
	int v;
	bool f=true;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		f=f&&dfs(v,c^1);
	}
	return f;
}
int N,M;
inline int Re()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=Re();M=Re();
	int u,v;
	for(int i=1;i<=M;i++)
	{
		u=Re();v=Re();
		addE(u,v);addE(v,u);
	}
	int ans=0;
	for(int i=1;i<=N;i++)
	{
		if(!book[i])
		{
			sz[0]=sz[1]=0;
			if(dfs(i,1))
				ans+=min(sz[0],sz[1]);
			else
			{
				printf("Impossible");
				return 0;
			}
		}
	}
	printf("%d",ans);
	return 0;
}
