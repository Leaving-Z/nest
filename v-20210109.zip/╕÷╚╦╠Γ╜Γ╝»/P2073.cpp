#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cstdlib>
using namespace std;
const int maxn=100007;
struct f{
	int v,mon;
};
struct Treap{
	int l,r,num,pri,s;
	f h;
}TREE[maxn];
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define val(i) TREE[i].h.v
#define pay(i) TREE[i].h.mon
#define c(i) TREE[i].num
#define sz(i) TREE[i].s
#define p(i) TREE[i].pri
int all,root;
int bea,cost,num;
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ; 
}
inline bool Insert(int &i,const int &b,const int &v)
{
	if(!i)
	{
		i=++all;c(i)=sz(i)=1;
		val(i)=b;pay(i)=v;p(i)=rand();
		L(i)=R(i)=0;
		return true;
	}
	++sz(i);
	if(v==pay(i)) return false;
	bool flag;
	if(v<pay(i))
	{
		flag=Insert(L(i),b,v);
		if(p(L(i))<p(i)) Zig(i);
		return flag;
	}
	else
	{
		flag=Insert(R(i),b,v);
		if(p(R(i))<p(i)) Zag(i);
		return flag;
	}
}
inline f Del_min(int &i)
{
	if(!L(i))
	{
		int x=i;
		i=R(i);
		return TREE[x].h;
	}
	--sz(i);
	return Del_min(L(i));
}
inline f Del_max(int &i)
{
	if(!R(i))
	{
		int x=i;
		i=L(i);
		return TREE[x].h;
	}
	--sz(i);
	return Del_max(R(i));
}
inline int Read()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	int op,x,y;
	f t;
	while(1)
	{
		op=Read();
		if(op==-1) break;
		if(op==1)
		{
			x=Read();y=Read();
			if(Insert(root,x,y))
			{
				num++;bea+=x;cost+=y;
			}
		}
		else if(op==2)
		{
			if(num)
			{
				t=Del_max(root);
				num--;
				bea-=t.v;
				cost-=t.mon;
			}
		}
		else
		{
			if(num)
			{
				t=Del_min(root);
				num--;
				bea-=t.v;
				cost-=t.mon;
			}
		}
	}
	printf("%d %d",bea,cost);
}
