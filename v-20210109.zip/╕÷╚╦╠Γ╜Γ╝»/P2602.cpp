#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int maxn=13;
LL F[maxn][maxn][2][2][2][2];
int a[maxn],N;
int A[maxn];
#define curF F[cur][last][a8][a4][l2][l3]
void print()
{
    for(int i=1;i<=N;i++)
        printf("%d",A[i]);
    puts("");
    return ;
}
LL dfs(int cur,int last,bool less,bool a8,bool a4,bool l2,bool l3)
{
    if(a8&&a4) return 0;
    if(less&&curF!=-1) return curF;
    if(cur>N)
    {
        if(l3&&less) {/*print();*/return 1ll;}
        return 0;
    }
    int l=(cur==1?1:0),r=(less?9:a[cur]);
    LL re=0;
    for(int i=l;i<=r;i++)
        A[cur]=i,re+=dfs(cur+1,i,less||i<a[cur],a8||i==8,a4||i==4,i==last,l3||i==last&&l2);
    if(less) curF=re;
    return re;
}
LL L,R;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&L,&R);
    R++;
    while(R)
    {
        a[++N]=R%10;
        R/=10;
    }
    for(int i=1;i<=N/2;i++)
        swap(a[i],a[N-i+1]);
    memset(F,-1,sizeof(F));
    LL re1=dfs(1,10,false,false,false,false,false);
    N=0;
    while(L)
    {
        a[++N]=L%10;
        L/=10;
    }
    for(int i=1;i<=N/2;i++)
        swap(a[i],a[N-i+1]);
    memset(F,-1,sizeof(F));
    printf("%lld\n",re1-dfs(1,10,false,false,false,false,false));
    return 0;
}