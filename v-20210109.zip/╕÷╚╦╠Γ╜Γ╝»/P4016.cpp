#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int ave;
int N,S,T;
const int maxn=107;
const int maxm=807;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf,w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf,int w)
{
	e[++ES]=(E){u,v,cf,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf,int w)
{
	addE(u,v,cf,w);addE(v,u,0,-w);
	return ;
}
int A[maxn];
int dis[maxn],f[maxn],pre[maxn][2];
bool book[maxn];
inline bool SPFA()
{
	memset(book,0,sizeof(book));
	memset(dis,0x7f,sizeof(dis));
	memset(f,0x7f,sizeof(f));
	book[S]=true;
	q.push(S);
	dis[S]=0;int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				f[v]=min(f[u],cf(i));
				pre[v][0]=u;pre[v][1]=i;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=inf;
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int main()
{
	N=R();T=N+1;
	for(register int i=1;i<=N;i++)
		A[i]=R(),ave+=A[i];
	ave/=N;
	for(register int i=1;i<=N;i++)
	{	
		A[i]-=ave;
		if(A[i]<0) add(i,T,-A[i],0);
		else if(A[i]>0) add(S,i,A[i],0);
	}
	for(register int i=1;i<=N;i++)
	{
		if(i!=1) add(i,i-1,inf,1);
		if(i!=N) add(i,i+1,inf,1);
	}
	add(1,N,inf,1);
	add(N,1,inf,1);
	int ans=0;
	while(SPFA())
	{
		ans+=dis[T]*f[T];
		Update();
	}
	printf("%d",ans);
	return 0;
}
