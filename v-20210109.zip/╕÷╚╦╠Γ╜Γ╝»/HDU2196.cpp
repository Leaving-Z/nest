#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=10007;
const int maxm=20007;
typedef long long LL;
int N;
struct E
{
    int u,v;
    LL w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,LL w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
LL F[maxn][2],f[maxn][2];
void reset()
{
    memset(F,0,sizeof(F));
    memset(f,0,sizeof(f));
    memset(first,0,sizeof(first));
    ES=0;
    return ;
}
void dfs1(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        dfs1(v,u);
        if(F[v][0]+e[i].w>F[u][0]) F[u][1]=F[u][0],F[u][0]=F[v][0]+e[i].w;
        else if(F[v][0]+e[i].w>F[u][1]) F[u][1]=F[v][0]+e[i].w;
    }
    return ;
}
void dfs2(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        if(f[u][0]==F[v][0]+e[i].w)
        {
            f[v][0]=max(F[v][0],f[u][1]+e[i].w);
            f[v][1]=max(min(F[v][0],f[u][1]+e[i].w),F[v][1]);
        }
        else
        {
            f[v][0]=f[u][0]+e[i].w;
            f[v][1]=F[v][0];
        }
        dfs2(v,u);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    while(scanf("%d",&N)!=EOF)
    {
        reset();
        int u;
        LL w;
        for(int i=1;i<N;i++)
        {
            scanf("%d%lld",&u,&w);
            addE(u,i+1,w);addE(i+1,u,w);
        }
        dfs1(1,0);f[1][0]=F[1][0];f[1][1]=F[1][1];
        dfs2(1,0);
        for(int i=1;i<=N;i++)
            printf("%lld\n",f[i][0]);
    }
    return 0;
}