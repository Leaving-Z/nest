#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxb=50;
const int MOD=1e6;
const int b=6;
const int maxn=(1<<9)+7;
struct INT{
    int num[maxb];
    int len;
    INT() {memset(num,0,sizeof(num));len=1;return ;}
    void print()
    {
        printf("%d",num[len]);
        for(int i=len-1;i>0;i--)
            printf("%06d",num[i]);
        //puts("");
        return ;
    }
    void fit()
    {
        for(int i=1;i<=len;i++)
        {
            if(num[i]>=MOD) num[i+1]+=num[i]/MOD,num[i]%=MOD;
            if(i==len&&num[i+1]) ++len;
        }
        return ;
    }
}C[maxn][maxn];
INT operator + (const INT &x,const INT &y)
{
    INT res=x;
    for(int i=1;i<=y.len;i++)
        res.num[i]+=y.num[i];
    res.fit();
    return res;
}
int K,W;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    C[0][0].num[1]=1;
    for(int i=1;i<maxn;i++)
    {
        C[i][0].num[1]=1;
        for(int j=1;j<=i;j++)
            C[i][j]=C[i-1][j-1]+C[i-1][j];
    }
    scanf("%d%d",&K,&W);
    int s=(1<<K);
    INT ans;
    int k=W/K+(W%K!=0);
    if(W%K)
    {
        int lim=(1<<W%K);
        for(int i=1;i<lim;i++)
        if(s-i>=k) ans=ans+C[s-i-1][k-1];
        k--;
    }
    for(int i=2;i<=k;i++)
    if(s>=i) ans=ans+C[s-1][i];
    ans.print();
    return 0;
}