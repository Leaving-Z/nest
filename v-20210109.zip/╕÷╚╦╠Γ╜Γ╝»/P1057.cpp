#include<cstdio>
#include<algorithm>
using namespace std;
int F[37][37];
int N,M;
int main()
{
	scanf("%d%d",&N,&M);
	F[1][0]=1;
	for(register int i=1;i<=M;i++)
		for(register int j=1;j<=N;j++)
		{
			if(j>1) F[j][i]+=F[j-1][i-1];
			else F[j][i]+=F[N][i-1];
			if(j<N) F[j][i]+=F[j+1][i-1];
			else F[j][i]+=F[1][i-1];
		}
	printf("%d",F[1][M]);
	return 0;
}
