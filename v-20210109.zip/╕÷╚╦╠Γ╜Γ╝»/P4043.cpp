#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=307;
const int maxm=20007;
const int inf=0x7f7f7f7f;
struct E{
    int u,v,w,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int w,int cf)
{
    e[++ES]=(E){u,v,w,cf};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int w,int cf)
{
    addE(u,v,w,cf);
    addE(v,u,-w,0);
    return ;
}
int fl[maxn];
int ans;
inline void add(int u,int v,int w,int l,int r)
{
    add(u,v,w,r-l);
    fl[v]+=l;
    fl[u]-=l;
    return ;
}
queue <int> q;
int N,S,T,s,t;
bool book[maxn];
int dis[maxn],f[maxn],pre[maxn][2];
bool SPFA()
{
    memset(dis,0x7f,sizeof(dis));
    memset(f,0x7f,sizeof(f));
    dis[S]=0;
    int u,v;
    q.push(S);
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&dis[u]+e[i].w<dis[v])
            {
                dis[v]=dis[u]+e[i].w;
                f[v]=min(f[u],cf(i));
                pre[v][0]=u;
                pre[v][1]=i;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return f[T]!=inf;
}
void update()
{
    int u=T;
    while(u!=S)
    {
        cf(pre[u][1])-=f[T];
        cf(pre[u][1]^1)+=f[T];
        u=pre[u][0];
    }
    return ;
}
int SSP()
{
    int res=0;
    while(SPFA())
    {
        res+=f[T]*dis[T];
        update();
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int k,v,w;
    s=1;
    t=N+1;
    S=t+1;
    T=S+1;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&k);
        if(i!=1) add(i,t,0,0,inf);
        for(int j=1;j<=k;j++)
        {
            scanf("%d%d",&v,&w);
            add(i,v,w,1,inf);
            ans+=w;
        }
    }
    for(int i=1;i<=N;i++)
    if(fl[i]>0) add(S,i,0,fl[i]);
    else if(fl[i]<0) add(i,T,0,-fl[i]);
    add(t,s,0,0,inf);
    printf("%d",ans+SSP());
    return 0;
}