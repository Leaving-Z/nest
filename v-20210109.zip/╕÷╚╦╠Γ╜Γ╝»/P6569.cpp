#include<cstdio>
#include<algorithm>
#include<cstring>
#include<bitset> 
using namespace std;
const int maxn=107;
typedef long long LL;
int N,M,Q;
struct Matrix{
	bitset<107> m[maxn];
	Matrix operator *(const Matrix &A) const
	{
		Matrix t;
		for(int i=1;i<=N;i++)
			for(int j=1;j<=N;j++)
				for(int k=1;k<=N;k++)
				t.m[i][j]=(t.m[i][j]^(m[i][k]&A.m[k][j]));
		return t;
	}
}ini,res[37];
LL A[maxn],F[maxn],g[maxn];
inline void solve(LL k)
{
	LL ans=0;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
		if(res[k].m[i][j])
			g[i]^=F[j];
	for(int i=1;i<=N;i++)
		F[i]=g[i];
	return ;
}
int main()
{
	//freopen("magic.in","r",stdin);
	//freopen("magic.out","w",stdout);
	scanf("%d%d%d",&N,&M,&Q);
	for(int i=1;i<=N;i++)
		scanf("%lld",&A[i]);
	int u,v;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&u,&v);
		ini.m[u][v]=ini.m[v][u]=1ll;
	}
	LL k,ans;
	for(int i=0;i<=32;i++)
	{
		res[i]=ini;
		ini=ini*ini;
	}
	for(int i=1;i<=Q;i++)
	{
		scanf("%lld",&k);
		memcpy(F,A,sizeof(F));
		for(int j=0;k;k>>=1,j++)
		if(k&1)
		{
			memset(g,0,sizeof(g));
			solve(j);
		}
		printf("%lld\n",F[1]);
	}
	return 0;
}
