#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
const int mod=1e9+7;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
long long fast_pow(int k)
{
	long long s=1,b=2;
	while(k)
	{
		if(k&1) s=s*b%mod;
		b=b*b%mod;
		k>>=1;
	}
	return s;
}
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int dfn[maxn],T;
int lt,rt,fa[maxn];
void dfs(int u)
{
	dfn[u]=++T;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		if(dfn[v]) lt=u,rt=v;
		else fa[v]=u,dfs(v);
	}
	return ;
}
int N;
int main()
{
	N=R();
	int u,v;
	for(int i=1;i<=N;i++)
	{
		v=R();
		addE(i,v);
		addE(v,i);
	}
	int len,all=0;
	long long ans=1;
	for(int i=1;i<=N;i++)
	if(!dfn[i])
	{
		lt=rt=0;len=1;
		dfs(i);
		if(lt&&rt)
		{
			if(dfn[lt]<dfn[rt]) swap(lt,rt);
			while(lt!=rt)
				len++,lt=fa[lt];
			all+=len;
			ans*=fast_pow(len)-2;ans%=mod;
		}
	}
	ans*=fast_pow(N-all);ans%=mod;
	printf("%lld",ans);
	return 0;
}
