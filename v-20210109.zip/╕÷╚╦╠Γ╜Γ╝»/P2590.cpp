#include<cstdio>
#include<algorithm>
#include<cstring> 
using namespace std;
const int inf=-1000000;
struct E{
	int u,v;
}e[60007];
int first[30007],nt[60007],ES;
void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	e[++ES]=(E){v,u};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int TREE[120007];
int MAX[120007];
int depth[30007],sz[30007],fa[30007],top[30007],son[30007];
int id[30007],anti[30007];
int ix;
int A[30007];
int N,Q;
void DFS(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			depth[v]=depth[u]+1;
			fa[v]=u;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[son[u]]<sz[v]) son[u]=v;
		}
	}
	return ;
}
void dfs(int u,int s)
{
	id[u]=++ix;
	anti[ix]=u;
	top[u]=s;
	if(son[u]) dfs(son[u],s);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs(v,v);
	}
	return ;
}
void Build(int L,int R,int i)
{
	MAX[i]=inf;
	if(L==R)
	{
		TREE[i]=A[anti[L]];
		MAX[i]=A[anti[L]];
		return ;
	}
	int mid=L+R>>1;
	Build(L,mid,i<<1);
	Build(mid+1,R,i<<1|1);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	MAX[i]=max(MAX[i<<1],MAX[i<<1|1]);
	return ;
}
void Update(int L,int R,int l,int r,int i,int k)
{
	if(l<=L&&R<=r)
	{
		TREE[i]=k;
		MAX[i]=k;
		return ;
	}
	int mid=L+R>>1;
	if(l<=mid) Update(L,mid,l,r,i<<1,k);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	MAX[i]=max(MAX[i<<1],MAX[i<<1|1]);
	return ;
}
int Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
		return TREE[i];
	int mid=L+R>>1;
	int re=0;
	if(l<=mid) re+=Query(L,mid,l,r,i<<1);
	if(r>mid) re+=Query(mid+1,R,l,r,i<<1|1);
	return re;
}
int Query_MAX(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r)
		return MAX[i];
	int mid=L+R>>1;
	int re=inf;
	if(l<=mid) re=max(re,Query_MAX(L,mid,l,r,i<<1));
	if(r>mid) re=max(re,Query_MAX(mid+1,R,l,r,i<<1|1));
	return re;
}
int Query_Path(int x,int y)
{
	int ans=inf;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		ans+=Query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	ans+=Query(1,N,id[x],id[y],1);
	return ans;
}
int Query_PMAX(int x,int y)
{
	int ans=inf;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		ans=max(ans,Query_MAX(1,N,id[top[x]],id[x],1));
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	ans=max(ans,Query_MAX(1,N,id[x],id[y],1));
	return ans;
}
int main()
{
	//freopen("1.txt","r",stdin);
	N=Read();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);
	}
	DFS(1);dfs(1,1);
	for(int i=1;i<=N;i++)
		A[i]=Read();
	Build(1,N,1);
	Q=Read();
	char s[20];
	int x,y,k;
	for(int i=1;i<=Q;i++)
	{
		scanf("%s",s);
		if(s[0]=='C')
		{
			x=Read();k=Read();
			Update(1,N,id[x],id[x],1,k);
		}
		else if(s[0]=='Q')
		{
			x=Read();y=Read();
			if(s[1]=='S')
				printf("%d\n",Query_Path(x,y));
			else if(s[1]=='M')
				printf("%d\n",Query_PMAX(x,y));
		}
	}
	return 0;
}
