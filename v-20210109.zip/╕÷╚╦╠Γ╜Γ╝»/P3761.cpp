#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=5007;
const int maxm=10007;
struct E{
	int u,v,w;
	bool ac;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
int N;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w,true};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int dis1[maxn],dis2[maxn];
int fa[maxn],path[maxn];
void dfs(int u,int f)
{
	int v;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=f&&e[i].ac)
		{
			fa[v]=i^1;
			dis1[v]=dis1[u]+e[i].w;
			dfs(v,u);
		}
	}
	return ;
}
struct pp{
	int a,b;
};
pp work(int num)
{
	memset(dis1,0,sizeof(dis1));
	dfs(num,0);
	
	int maxx=0,num1=0,num2=0;
	
	for(register int i=1;i<=N;i++)
	if(dis1[i]>maxx) maxx=dis1[i],num1=i;
	memset(dis1,0,sizeof(dis1));
	
	dfs(num1,0);maxx=0;
	for(register int i=1;i<=N;i++)
	if(dis1[i]>maxx) maxx=dis1[i],num2=i;
	memcpy(dis2,dis1,sizeof(dis1));
	
	memset(dis1,0,sizeof(dis1));
	dfs(num2,0);
	pp re;
	re.a=0x7f7f7f7f;re.b=0;
	for(register int i=1;i<=N;i++)
	{
		re.b=max(re.b,dis1[i]);
		if(!dis1[i]) continue;
		re.a=min(re.a,max(dis1[i],dis2[i]));
	}
	if(re.a==0x7f7f7f7f) re.a=0;
	return re;
}
inline int solve(int id)
{
	e[id].ac=e[id^1].ac=false;
	pp t1=work(e[id].u);
	pp t2=work(e[id].v);
	e[id].ac=e[id^1].ac=true;
	return max(t1.a+t2.a+e[id].w,max(t1.b,t2.b));
}
int main()
{
	scanf("%d",&N);
	int u,v,w;
	for(register int i=1;i<N;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		addE(u,v,w);addE(v,u,w);
	}
	dfs(1,0);
	int lt=0,rt=0,maxv=0;
	for(register int i=1;i<=N;i++)
	if(dis1[i]>maxv) maxv=dis1[i],lt=i;
	memset(dis1,0,sizeof(dis1));
	dfs(lt,0);maxv=0;
	for(register int i=1;i<=N;i++)
	if(dis1[i]>maxv) maxv=dis1[i],rt=i;
	
	memcpy(path,fa,sizeof(fa));
	
	int ans=0x7f7f7f7f;
	while(rt!=lt)
	{
		ans=min(ans,solve(path[rt]));
		rt=e[path[rt]].v;
	}
	printf("%d",ans);
	return 0;
}
