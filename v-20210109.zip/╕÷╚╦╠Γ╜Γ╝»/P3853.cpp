#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int p[maxn],L,N,K;
bool check(int g)
{
	int t=K,x;
	for(register int i=1;i<N;i++)
	{
		t-=(p[i+1]-p[i]-1)/g;
		if(t<0) return false;
	}
	return true;
}
int main()
{
	L=R();N=R();K=R();
	int l=0,r=0,mid,ans;
	for(register int i=1;i<=N;i++)
		p[i]=R(),r=max(p[i]-p[i-1],r);
	while(l<=r)
	{
		mid=l+r>>1;
		if(check(mid)) r=mid-1,ans=mid;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
