#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=100007;
int N,D;
struct node{
	int d,val;
};
struct p{
	int x,y;
}point[maxn];
bool operator < (const p &a,const p &b)
{
	return a.x<b.x;
}
struct que{
	node q[maxn];
	int head,tail;
	void init()
	{
		this->head=1;this->tail=0;
		return ;
	}
	bool empty()
	{
		return head>tail;
	}
	void pop_front()
	{
		++head;return ;
	}
	void pop_back()
	{
		--tail;return ;
	}
	node front()
	{
		return q[head];
	}
	node back()
	{
		return q[tail];
	}
	void push(const node &x)
	{
		q[++tail]=x;
	}
};
que q1,q2;
void insert(const node &x)
{
	while(!q1.empty()&&q1.back().val>x.val) q1.pop_back();
	q1.push(x);
	while(!q2.empty()&&q2.back().val<x.val) q2.pop_back();
	q2.push(x);
	return ;
}
#define x(i)point[i].x
#define y(i) point[i].y
bool check(int w)
{
	q1.init();q2.init();
	node t;t.d=x(1);t.val=y(1);
	q1.push(t);q2.push(t);
	for(int i=2;i<=N;i++)
	{
		t.d=x(i);t.val=y(i);
		insert(t);
		while(!q1.empty()&&q1.front().d<x(i)-w) q1.pop_front();
		while(!q2.empty()&&q2.front().d<x(i)-w) q2.pop_front();
		if(!q1.empty()&&!q2.empty())
			if(q2.front().val-q1.front().val>=D) return true;
	}
	return false;
}
#define mid (l+r>>1)
int main()
{
	N=R();D=R();
	int l=1,r=1e6,ans=-1;
	for(register int i=1;i<=N;i++)
		x(i)=R(),y(i)=R();
	sort(point+1,point+1+N);
	while(l<=r)
	{
		if(check(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
