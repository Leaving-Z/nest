#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=200007;
typedef long long LL;
LL TREE[maxn<<2];
LL p,N;
LL R()
{
	char c;
	LL re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
#define mid (L+R>>1)
void Update(int i,int L,int R,int x,LL k)
{
	if(L==R)
	{
		TREE[i]=k;
		return ;
	}
	if(x<=mid) Update(i<<1,L,mid,x,k);
	else Update(i<<1|1,mid+1,R,x,k);
	TREE[i]=TREE[i<<1]*TREE[i<<1|1]%p;
	return ;
}
LL Query(int i,int L,int R,int l,int r)
{
	if(l<=L&&R<=r)
		return TREE[i];
	LL re=1;
	if(l<=mid) re*=Query(i<<1,L,mid,l,r),re%=p;
	if(r>mid) re*=Query(i<<1|1,mid+1,R,l,r),re%=p;
	return re;
}
int T;
int main()
{
	T=R();int op;
	while(T--)
	{
		memset(TREE,0,sizeof(TREE));
		N=R();p=R();
		LL x;
		for(register int i=1;i<=N;i++)
		{
			op=R();x=R();
			if(op==1) Update(1,1,N,i,x);
			else Update(1,1,N,i,1),Update(1,1,N,x,1);
			printf("%lld\n",Query(1,1,N,1,i));
		}
	}
	return 0;
}
