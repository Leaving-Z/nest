#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int maxq=50007;
typedef long long LL;
int ans[maxn],A[maxn];
int N,Q;
int C[maxn];
void update(int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&-x;
    return ;
}
int query(int x)
{
    int re=0;
    while(x) re+=C[x],x&=x-1;
    return re;
}
struct Query{
    int p,val,id,ty;
}q[maxq],q1[maxq];
int book[maxn];
int res[maxn];
bool com1(const Query &x,const Query &y) {return x.p<y.p;}
bool com2(const Query &x,const Query &y) {return x.p>y.p;}
void solve(int L,int R)
{
    if(L==R) {res[q[L].id]=ans[q[L].p];return ;}
    int mid=L+R>>1,cnt=0,t=0;
    solve(L,mid);solve(mid+1,R);
    for(int i=L;i<=mid;i++)
        {q1[++cnt]=q[i];q1[cnt].ty=1;}
    for(int i=mid+1;i<=R;i++)
        {q1[++cnt]=q[i];q1[cnt].ty=2;}
    sort(q1+1,q1+1+cnt,com1);
    for(int i=1;i<=cnt;i++)
    {
        if(q1[i].ty==1) update(q1[i].val,1),++t;
        else res[q1[i].id]-=t-query(q1[i].val);
    }
    for(int i=1;i<=cnt;i++) if(q1[i].ty==1) update(q1[i].val,-1);
    for(int i=cnt;i>0;i--)
    {
        if(q1[i].ty==1) update(q1[i].val,1);
        else res[q1[i].id]-=query(q1[i].val);
    }
    for(int i=1;i<=cnt;i++) if(q1[i].ty==1) update(q1[i].val,-1);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("P3157_1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    long long sum=0;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        book[A[i]]=i;
        ans[i]=i-1-query(A[i]);
        sum+=ans[i];
        update(A[i],1);
    }
    memset(C,0,sizeof(C));
    for(int i=N;i>0;i--)
        ans[i]+=query(A[i]),update(A[i],1);
    memset(C,0,sizeof(C));
    for(int i=1;i<=Q;i++)
    {
        scanf("%d",&q[i].val);
        q[i].p=book[q[i].val];
        q[i].id=i;
    }
    solve(1,Q);
    for(int i=1;i<=Q;i++)
    {
        printf("%lld\n",sum);
        sum-=res[i];
    }
    return 0;
}