#include<cstdio>
//-----------------------------�������� 
const int inf=0x7f7f7f7f;
const int maxn=200007;
int N,Q;
struct Tree{
	int x,n,sum;
	bool t;
}TREE[maxn<<2];
struct E{
	int u,v,w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
int sz[maxn],fa[maxn],son[maxn],top[maxn],ix;
int depth[maxn],A[maxn],id[maxn],anti[maxn];
//-----------------------------�궨��
#define mid (L+R>>1)
#define L(i) (i<<1)
#define R(i) (i<<1|1)
#define U(i) TREE[i].t//��������Ƿ���Ҫ����෴�� 
#define max(i) TREE[i].x
#define min(i) TREE[i].n
#define sum(i) TREE[i].sum
//-----------------------------��������
namespace BasicF//�������� 
{
	inline int Re()//------�����Ż�
	{
		int re,f=1;
		char c;
		while((c=getchar())>'9'||c<'0')
		if(c=='-') f=-1;
		re=c-48;
		while((c=getchar())>='0'&&c<='9')
		re=re*10+c-48;
		return re*f;
	}
	inline void addE(int u,int v,int w)//------���ߺ��� 
	{
		e[++ES]=(E){u,v,w};
		nt[ES]=first[u];
		first[u]=ES;
		
		e[ES+N]=(E){v,u,w};
		nt[ES+N]=first[v];
		first[v]=ES+N;
		return ;
	}
	//------max&&min&&swap
	inline int max_(const int &x,const int &y) {return x>y?x:y;}
	inline int min_(const int &x,const int &y) {return x>y?y:x;}
	inline void swap_(int &x,int &y) {int t=x;x=y;y=t;return ;}
}
using namespace BasicF;
namespace Partition
{
	//------DFS&&dfs
	inline void DFS(int u)
	{
		sz[u]=1;
		int v;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(v!=fa[u])
			{
				fa[v]=u;
				depth[v]=depth[u]+1;
				A[v]=e[i].w;
				DFS(v);
				sz[u]+=sz[v];
				if(sz[v]>sz[son[u]]) son[u]=v;
			}
		}
		return ;
	}
	inline void dfs(int u,int tp)
	{
		top[u]=tp;
		id[u]=++ix;anti[ix]=u;
		if(son[u]) dfs(son[u],tp);
		int v;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(v==fa[u]||v==son[u]) continue;
			dfs(v,v);
		}
		return ;
	}
}
using namespace Partition;
//------------------�߶��� 
namespace AssistF
{
	inline void Pushup(int i)//------������Ϣ
	{
		max(i)=max_(max(L(i)),max(R(i)));
		min(i)=min_(min(L(i)),min(R(i)));
		sum(i)=sum(L(i))+sum(R(i));
		return ;
	}
	inline void Turn(int i)//------�����Ϊ�෴��
	{
		U(i)=!U(i);
		//�߷��մ����,�ܶ�����Ϊ�ó�false�Ϳ��Ե��Ǹ������� 
		int t=min(i);
		min(i)=-max(i);
		max(i)=-t;
		sum(i)=-sum(i);
		return ;
	}
	inline void LAZY(int i)//------����´�
	{
		if(!U(i)) return ;
		U(i)=false;
		Turn(L(i));
		Turn(R(i));
		return ;
	}
}
using namespace AssistF; 
namespace Basic_Segment_Tree//���������� 
{
	//------�߶�������
	inline void Build(int L,int R,int i)
	{
		if(L==R)
		{
			sum(i)=max(i)=min(i)=A[anti[L]];
			return ;
		}
		Build(L,mid,L(i));
		Build(mid+1,R,R(i));
		Pushup(i);
		return ;
	}
	//------�����޸� 
	inline void Update_single(int L,int R,int x,int i,int k)
	{
		if(L==R)
		{
			sum(i)=max(i)=min(i)=k;
			return ;
		}
		LAZY(i);
		if(x<=mid) Update_single(L,mid,x,L(i),k);
		else Update_single(mid+1,R,x,R(i),k);
		Pushup(i);
		return ;
	}
	//------ȡ�෴��
	inline void Update_opposite(int L,int R,int l,int r,int i)
	{
		if(l<=L&&R<=r)
		{
			Turn(i);
			return ;
		}
		LAZY(i);
		if(l<=mid) Update_opposite(L,mid,l,r,L(i));
		if(r>mid) Update_opposite(mid+1,R,l,r,R(i));
		Pushup(i);
		return ; 
	}
	//------�������ֵ
	inline int Query_max(int L,int R,int l,int r,int i)
	{
		if(l<=L&&R<=r)
			return max(i);
		LAZY(i);
		int re=-inf;
		if(l<=mid) re=max_(re,Query_max(L,mid,l,r,L(i)));
		if(r>mid) re=max_(re,Query_max(mid+1,R,l,r,R(i)));
		return re;
	}
	//------������Сֵ
	inline int Query_min(int L,int R,int l,int r,int i)
	{
		if(l<=L&&R<=r)
			return min(i);
		LAZY(i);
		int re=inf;
		if(l<=mid) re=min_(re,Query_min(L,mid,l,r,L(i)));
		if(r>mid) re=min_(re,Query_min(mid+1,R,l,r,R(i)));
		return re;
	}
	//------�����
	inline int Query_sum(int L,int R,int l,int r,int i)
	{
		if(l<=L&&R<=r)
			return sum(i);
		LAZY(i);
		int re=0;
		if(l<=mid) re+=Query_sum(L,mid,l,r,L(i));
		if(r>mid) re+=Query_sum(mid+1,R,l,r,R(i));
		return re;
	}
}
using namespace Basic_Segment_Tree;
namespace Path//------------·������
{
	//------·��ȡ�� 
	inline void Update_Path_opposite(int x,int y)
	{
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap_(x,y);
			Update_opposite(1,N,id[top[x]],id[x],1);
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap_(x,y);
		Update_opposite(1,N,id[x]+1,id[y],1);
		return ;
	}
	//------·�����
	inline int Query_Path_sum(int x,int y)
	{
		int ans=0;
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap_(x,y);
			ans+=Query_sum(1,N,id[top[x]],id[x],1);
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap_(x,y);
		ans+=Query_sum(1,N,id[x]+1,id[y],1);
		return ans;
	}
	//------·�������ֵ 
	inline int Query_Path_max(int x,int y)
	{
		int ans=-inf;
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap_(x,y);
			ans=max_(ans,Query_max(1,N,id[top[x]],id[x],1));
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap_(x,y);
		ans=max_(ans,Query_max(1,N,id[x]+1,id[y],1));
		return ans;
	}
	//------·������Сֵ
	inline int Query_Path_min(int x,int y)
	{
		int ans=inf;
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap_(x,y);
			ans=min_(ans,Query_min(1,N,id[top[x]],id[x],1));
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap_(x,y);
		ans=min_(ans,Query_min(1,N,id[x]+1,id[y],1));
		return ans;
	}
}
using namespace Path;
char s[7];
int main()
{
	N=Re();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=Re()+1;v=Re()+1;w=Re();
		addE(u,v,w);
	}
	DFS(1);dfs(1,1);
	Build(1,N,1);
	Q=Re();
	for(int i=1;i<=Q;i++)
	{
		scanf("%s",s);u=Re();v=Re();
		if(s[0]=='C')
		{
			w=depth[e[u].u]>depth[e[u].v]?e[u].u:e[u].v;
			Update_single(1,N,id[w],1,v);
		}
		else if(s[0]=='S')
			printf("%d\n",Query_Path_sum(u+1,v+1));
		else if(s[0]=='N')
			Update_Path_opposite(u+1,v+1);
		else if(s[0]=='M')
		{
			if(s[1]=='I')
				printf("%d\n",Query_Path_min(u+1,v+1));
			else printf("%d\n",Query_Path_max(u+1,v+1));
		}
	}
	return 0;
}
