#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=17;
int a[maxn],cnt;
int F[maxn][maxn][2];
int l,r;
void sep(int x)
{
	cnt=0;
	while(x)
	{
		a[++cnt]=x%10;
		x/=10;
	}
	return ;
}
int Windy(int x)
{
	sep(x);
	memset(F,0,sizeof(F));
	F[cnt][a[cnt]][0]=1;
	for(int j=1;j<a[cnt];j++)
		F[cnt][j][1]=1;
	for(int i=0;i<cnt;i++)
		for(int j=1;j<=9;j++)
			F[i][j][1]=1;
	for(int i=cnt;i>1;i--)
	{
		for(int j=0;j<=9;j++)
		{
			if(abs(a[i-1]-j)>=2) F[i-1][a[i-1]][0]+=F[i][j][0];
			for(int k=0;k<=9;k++)
			{
				if(abs(k-j)>=2)
				{
					F[i-1][k][1]+=F[i][j][1];
					if(k<a[i-1]) F[i-1][k][1]+=F[i][j][0];
				}
			}
		}
	}
	int re=0;
	for(int i=0;i<=9;i++)
		re+=F[1][i][1];
	return re;
}
int main()
{
	scanf("%d%d",&l,&r);
	printf("%d",Windy(r+1)-Windy(l));
	return 0;
}
