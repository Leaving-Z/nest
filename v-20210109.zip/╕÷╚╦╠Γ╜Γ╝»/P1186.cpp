#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring> 
using namespace std;
const int inf=1e8;
struct E{
	int u,v,w;
}e[1000000];
struct VD{
	int dis,num;
};
int first[1005],nt[1000000],dis[1005],tdis[1005];
int pre[1005][2];
int n,m;
void init()
{
	for(int i=1;i<=n;i++)
		tdis[i]=inf;
	tdis[1]=0;
	return ;
}
bool operator <(const VD &a,const VD &b)
{
	return a.dis>b.dis;
}
void Dijkstra()
{
	priority_queue <VD> q1;
	VD temp;
	init();
	temp=(VD){0,1};
	q1.push(temp);
	while(!q1.empty())
	{
		temp=q1.top();q1.pop();
		int x=temp.num;
		if(temp.dis>tdis[x]) continue;
		for(int i=first[x];i;i=nt[i])
		{
			if(tdis[x]+e[i].w<tdis[e[i].v])
			{
				tdis[e[i].v]=tdis[x]+e[i].w;
				temp=(VD){tdis[e[i].v],e[i].v};
				q1.push(temp);
			}
		}
	}
	return ;
}
int ans;
void work(int s)
{
	int d,o;
	if(pre[s][0]!=0)
	{
		d=pre[s][1];
		o=e[d].w;
		e[d].w=e[d-m>0?d-m:d+m].w=inf;
		Dijkstra();
		if(tdis[n]!=inf&&tdis[n]>ans)
			ans=tdis[n];
		e[d].w=e[d-m>0?d-m:d+m].w=o;
		work(pre[s][0]);
	}
	return ;
}
priority_queue <VD> q;
int main()
{
	scanf("%d%d",&n,&m);
	int a,b,V;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&a,&b,&V);
		e[i]=(E){a,b,V};
		e[i+m]=(E){b,a,V};
		nt[i]=first[a];
		nt[i+m]=first[b];
		first[a]=i;
		first[b]=i+m;
	}
	VD t;
	for(int i=1;i<=n;i++)
		dis[i]=inf;
	dis[1]=0;
	t=(VD){0,1};
	q.push(t);
	while(!q.empty())
	{
		t=q.top();q.pop();
		int k=t.num;
		if(dis[k]<t.dis) continue;
		for(int i=first[k];i;i=nt[i])
		{
			if(dis[k]+e[i].w<dis[e[i].v])
			{
				dis[e[i].v]=dis[k]+e[i].w;
				pre[e[i].v][0]=k;
				pre[e[i].v][1]=i;
				t.num=e[i].v;t.dis=dis[e[i].v];
				q.push(t);
			}
		}
	}
	ans=dis[n];
	work(n);
	printf("%d",ans);
	return 0;
}
