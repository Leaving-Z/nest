#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
struct E{
	int u,v,w;
}e[20005];
int edgesum;
int s[105];
int N,M;
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int f(int x)
{
	return s[x]==x?x:s[x]=f(s[x]);
}
void _merge(int x,int y)
{
	int f1=f(x),f2=f(y);
	s[f2]=f1;
	return ;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		s[i]=i;
	int x;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
		{
			scanf("%d",&x);
			if(i==j) continue;
			else e[edgesum++]=(E){i,j,x};
		}
	sort(e,e+edgesum);
	int MST=0,k=0;
	for(int i=0;i<edgesum;i++)
	{
		if(f(e[i].u)==f(e[i].v)) continue;
		k++;
		_merge(e[i].u,e[i].v);
		MST+=e[i].w;
		if(k==N-1) break;
	}
	printf("%d",MST);
	return 0;
}
