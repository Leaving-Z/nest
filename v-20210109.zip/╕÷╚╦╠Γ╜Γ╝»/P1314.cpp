#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=200007;
typedef long long LL;
LL sum1[maxn],sum2[maxn];
LL W[maxn],v[maxn];
int N,M;
LL s,ans;
int range[maxn][2];
#define mid (l+r>>1)
bool check(int w)
{
    for(int i=1;i<=N;i++)
        sum1[i]=sum1[i-1]+(W[i]>=w),sum2[i]=sum2[i-1]+(W[i]>=w)*v[i];
    LL re=0;
    for(int i=1;i<=M;i++)
        re+=(sum1[range[i][1]]-sum1[range[i][0]-1])*(sum2[range[i][1]]-sum2[range[i][0]-1]);
    ans=min(ans,abs(s-re));
    return re>s;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();scanf("%lld",&s);
    for(register int i=1;i<=N;i++)
        W[i]=R(),v[i]=R();
    for(register int i=1;i<=M;i++)
        range[i][0]=R(),range[i][1]=R();
    int l=0,r=1e6;
    ans=1e18;
    while(l<=r)
    {
        if(check(mid)) l=mid+1;
        else r=mid-1;
    }
    printf("%lld",ans);
    return 0;
}
