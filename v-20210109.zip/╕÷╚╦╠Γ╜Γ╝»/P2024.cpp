#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=150007;
int S[maxn];
int N,M;
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int op,x,y;
    for(int i=1;i<=3*N;i++)
        S[i]=i;
    int ans=0,f1,f2;
    while(M--)
    {
        scanf("%d",&op);
        scanf("%d%d",&x,&y);
        if(x>N||y>N) {++ans;continue;}
        if(op==1)
        {
            f1=f(x+N);f2=f(y);
            if(f1==f2) {++ans;continue;}
            f1=f(x);f2=f(y+N);
            if(f1==f2) {++ans;continue;}
            f1=f(x);f2=f(y);
            S[f2]=f1;
            f1=f(x+N);f2=f(y+N);
            S[f2]=f1;
            f1=f(x+2*N);f2=f(y+2*N);
            S[f2]=f1;
        }
        else
        {
            f1=f(x);f2=f(y);
            if(f1==f2) {++ans;continue;}
            f2=f(y+N);
            if(f2==f1) {++ans;continue;}
            f1=f(x+2*N);
            S[f2]=f1;
            f1=f(x+N);f2=f(y);
            S[f2]=f1;
            f1=f(x);f2=f(y+2*N);
            S[f2]=f1;
        }
    }
    printf("%d",ans);
    return 0;
}