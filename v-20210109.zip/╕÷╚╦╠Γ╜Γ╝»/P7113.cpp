#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
typedef __int128 LL;
LL gcd(LL a,LL b)
{
	return !b?a:gcd(b,a%b);
}
const int maxn=100007;
const int maxm=500007;
struct node{
	LL a,b;
	void fit()
	{
		LL g=gcd(a,b);
		a/=g;b/=g;
		return ;
	}
}A[maxn];
node operator + (node x,node y)
{
	node t;
	t.a=x.a*y.b+x.b*y.a;
    LL g=gcd(t.a,x.b);
    x.b/=g;t.a/=g;
    g=gcd(t.a,y.b);
    y.b/=g;t.a/=g;
    t.b=x.b*y.b;
	t.fit();
	return t;
}
node operator / (const node &x,int y)
{
	node t=x;
    LL g=gcd(t.a,1ull*y);
	y/=g;t.a/=g;
    t.b*=y;
	t.fit();
	return t;
}
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int in[maxn];
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	in[v]++;
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
queue <int> q;
int N,M;
int out[maxn];
void topo()
{
	for(int i=1;i<=N;i++)
	{
		A[i].b=1;
		if(!in[i]) q.push(i),A[i].a=1;
	}
	int u,v;
	node t;
	while(!q.empty())
	{
		u=q.front();q.pop();
		if(!out[u]) continue;
		t=A[u]/out[u];
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			--in[v];
			A[v]=A[v]+t;
			if(!in[v]) q.push(v);
		}
	}
	return ;
}
void print(__int128 x)
{
    if(x>=10) print(x/10);
    putchar(x%10+'0');
    return ;
}
int main()
{
	#ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
	scanf("%d%d",&N,&M);
	int v;
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&out[i]);
		for(int k=1;k<=out[i];k++)
		{
			scanf("%d",&v);
			addE(i,v);
		}
	}
	topo();
	for(int i=1;i<=N;i++)
	if(!out[i])
	{
		A[i].fit();
		print(A[i].a);putchar(' ');print(A[i].b);puts("");
	}
	return 0;
}