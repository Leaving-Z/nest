#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
inline LL Read()
{
	LL re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	LL u,v;
}e[100007];
LL first[100007],nt[100007],ES;
LL TREE[400007],add[400007];
LL N,Q;
inline void addE(LL u,LL v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
LL depth[100007],fa[100007],son[100007],top[100007],sz[100007];
LL id[100007],anti[100007];
LL ix;
void DFS(LL u)
{
	sz[u]=1;
	LL v;
	for(LL i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		depth[v]=depth[u]+1;
		DFS(v);
		sz[u]+=sz[v];
		if(sz[son[u]]<sz[v]) son[u]=v;
	}
	return ;
}
void dfs(LL u,LL s)
{
	id[u]=++ix;anti[ix]=u;
	top[u]=s;
	if(son[u]) dfs(son[u],s);
	LL v;
	for(LL i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=son[u])
		dfs(v,v);
	}
	return ;
}
void LAZY(LL L,LL R,LL i)
{
	LL mid=L+R>>1;
	TREE[i<<1]+=(mid-L+1)*add[i];
	add[i<<1]+=add[i];
	TREE[i<<1|1]+=(R-mid)*add[i];
	add[i<<1|1]+=add[i];
	add[i]=0;
	return ;
}
void Update(LL L,LL R,LL l,LL r,LL i,LL k)
{
	if(l<=L&&R<=r)
	{
		TREE[i]+=(R-L+1)*k;
		add[i]+=k;
		return ;
	}
	LL mid=L+R>>1;
	LAZY(L,R,i);
	if(l<=mid) Update(L,mid,l,r,i<<1,k);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
	TREE[i]=TREE[i<<1|1]+TREE[i<<1];
	return ;
}
LL Query(LL L,LL R,LL l,LL r,LL i)
{
	if(l<=L&&R<=r)
	return TREE[i];
	LL mid=L+R>>1;
	LAZY(L,R,i);
	LL ans=0;
	if(l<=mid) ans+=Query(L,mid,l,r,i<<1);
	if(r>mid) ans+=Query(mid+1,R,l,r,i<<1|1);
	return ans;
}
void Update_Path(LL x,LL y,LL k)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],1,k);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x],id[y],1,k);
	return ;
}
int main()
{
	N=Read();
	LL u,v;
	for(LL i=1;i<N;i++)
	{
		u=Read();v=Read();fa[v+1]=u+1;
		addE(u+1,v+1);
	}
	Q=Read();
	DFS(1);
	dfs(1,1);
	LL d;
	char s[20];
	for(LL i=1;i<=Q;i++)
	{
		scanf("%s",s);
		if(s[0]=='A')
		{
			u=Read();v=Read();d=Read();
			u++;v++;
			Update_Path(u,v,d);
		}
		else
		{
			u=Read();u++;
			printf("%lld\n",Query(1,N,id[u],id[u]+sz[u]-1,1));
		}
	}
	return 0;
}
