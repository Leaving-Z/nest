#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
inline LL R()
{
    LL re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N,M,T;
bool check(LL x)
{
    if(x==1||!x) return false;
    if(x==2||x==3) return true;
    for(LL i=2;i*i<=x;i++)
    if(x%i==0) return false;
    return true;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    T=R();
    while(T--)
    {
        N=R();M=R();
        LL x=0,y=0;
        int cnt1=0,cnt2=0;
        for(int i=1;i<=N;i++)
        {
            x=R();
            if(x!=1)
            {
                ++cnt1;
                y^=x;
            }
        }
        for(int i=1;i<=M;i++)
        {
            x=R();
            if(x!=1)
            {
                ++cnt2;
                y^=x;
            }
        }
        if(cnt1==cnt2+1&&check(y)) puts("YES");
        else puts("NO");
    }
    return 0;
}