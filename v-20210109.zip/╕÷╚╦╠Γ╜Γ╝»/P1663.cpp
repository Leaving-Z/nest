#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef double db;
const int maxn=5001;
const db eps=1e-8;
struct Line{
	db k,b;
}line[maxn];
int cnt,N;
void addline(db x1,db y1,db x2,db y2)
{
	++cnt;
	line[cnt].k=(y2-y1)/(x2-x1);
	line[cnt].b=y1-line[cnt].k*x1;
	return ;
}
bool check(db Y)
{
	db Lim=-1,Rim=1e9,X;
	for(int i=1;i<=cnt;i++)
	{
		X=(Y-line[i].b)/line[i].k;
		if(line[i].k>eps) Rim=min(Rim,X);
		else if(line[i].k<-eps) Lim=max(Lim,X);
		else if(line[i].b>Y+eps) return false;
		if(Lim+eps>Rim) return false;
	}
	return true;
}
db x[maxn],y[maxn];
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%lf%lf",&x[i],&y[i]);
	for(int i=2;i<=N;i++)
		addline(x[i],y[i],x[i-1],y[i-1]);
	db L=0,R=1e6,mid,ans;
	while(L+0.002<=R)
	{
		mid=(L+R)/2;
		if(check(mid)) ans=mid,R=mid-0.002;
		else L=mid+0.002;
	}
	printf("%.2f",ans);
	return 0;
}
