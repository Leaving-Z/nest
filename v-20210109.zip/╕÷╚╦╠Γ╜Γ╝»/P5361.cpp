#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=10007;
const int maxm=200007;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int deg[maxn],d[maxn];
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    d[v]++;
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int T,N,M;
int P,Q;
bool del[maxn];
void reset()
{
    for(int i=1;i<=N;i++)
        d[i]=0,first[i]=0;
    ES=0;
    return ;
}
queue <int> q;
int ans1[maxn],ans2[maxn];
bool check(int p)
{
    for(int i=1;i<=N;i++)
    {
        deg[i]=d[i],del[i]=false;
        if(deg[i]<p) q.push(i),del[i]=true;
    }
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(del[v]) continue;
            --deg[v];
            if(deg[v]<p) q.push(v),del[v]=true;
        }
    }
    for(int i=1;i<=N;i++)
    if(deg[i]>=p) return true;
    return false;
}
int tmp[maxn];
void calc()
{
    Q=0;
    int u,v;
    for(int i=1;i<=N;i++)
        del[i]=false;
    for(int k=1;k<=N;k++)
    {
        u=tmp[k];
        if(del[u]) continue;
        ans2[++Q]=u;
        if((Q+1)*(P+1)>=N+1) return ;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            del[v]=true;
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    srand(time(NULL));
    T=R();
    while(T--)
    {
        N=R();M=R();
        reset();
        int u,v;
        for(int i=1;i<=M;i++)
        {
            u=R();v=R();
            addE(u,v);addE(v,u);
        }
        int L=0,R=N+1,mid;
        while(L<=R)
        {
            mid=L+R>>1;
            if(check(mid))
            {
                P=mid,L=mid+1;
                u=0;
                for(int i=1;i<=N;i++)
                if(deg[i]>=mid) ans1[++u]=i;
            }
            else R=mid-1;
        }
        for(int i=1;i<=N;i++)
            tmp[i]=i;
        calc();
        while((Q+1)*(P+1)<N+1)
            random_shuffle(tmp+1,tmp+1+N),calc();
        
        printf("%d",u);
        for(int i=1;i<=u;i++)
            printf(" %d",ans1[i]);
        printf("\n%d",Q);
        for(int i=1;i<=Q;i++)
            printf(" %d",ans2[i]);
        puts("");
    }
    return 0;
}