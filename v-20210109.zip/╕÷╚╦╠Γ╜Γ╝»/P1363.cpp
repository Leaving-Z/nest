#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=1507;
char m[maxn][maxn];
int N,M;
bool vis[maxn][maxn];
int book[maxn][maxn][2];
int nxt[4][2]=
{
    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
};
bool f;
void dfs(int x,int y,int X,int Y)
{
    //printf("(%d,%d) (%d,%d)\n",x,y,X,Y);
    if(f) return ;
    if(book[x][y][0]<=-1000000) book[x][y][0]=X,book[x][y][1]=Y;
    else if(vis[x][y]&&(book[x][y][0]!=X||book[x][y][1]!=Y))
    {
        f=true;
        return ;
    }
    vis[x][y]=true;
    int nx,ny;
    for(int i=0;i<4;i++)
    {
        nx=(x+nxt[i][0]+N)%N;
        ny=(y+nxt[i][1]+M)%M;
        if(m[nx][ny]=='#')
            continue;
        if(vis[nx][ny]&&book[nx][ny][0]==X+nxt[i][0]&&book[nx][ny][1]==Y+nxt[i][1])
            continue;
        dfs(nx,ny,X+nxt[i][0],Y+nxt[i][1]);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    while(scanf("%d%d",&N,&M)!=EOF)
    {
        memset(vis,0,sizeof(vis));
        for(int i=0;i<N;i++)
            for(int j=0;j<M;j++)
                book[i][j][0]=book[i][j][1]=-1000000;
        f=false;
        for(int i=0;i<N;i++)
            scanf("%s",m[i]);
        for(int i=0;i<N;i++)
            for(int j=0;j<M;j++)
            if(m[i][j]=='S') {dfs(i,j,i,j);break;}
        if(f) puts("Yes");
        else puts("No");
    }
    return 0;
}