#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=107;
const int maxm=30007;
const int inf=0x7f7f7f7f;
struct E{
    int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
int fl[maxn];
inline void addE(int u,int v,int cf)
{
    e[++ES]=(E){u,v,cf};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int cf)
{
    addE(u,v,cf);
    addE(v,u,0);
    return ;
}
inline void add(int u,int v,int l,int r)
{
    add(u,v,r-l);
    fl[v]+=l;
    fl[u]-=l;
    return ;
}
int N,S,T,s,t;
int cur[maxn],dep[maxn];
queue <int> q;
bool BFS()
{
    q.push(S);
    memset(dep,0,sizeof(dep));
    dep[S]=1;
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&!dep[v])
            {
                dep[v]=dep[u]+1;
                q.push(v);
            }
        }
    }
    return dep[T]!=0;
}
int dfs(int u,int f)
{
    if(u==T) return f;
    int v,sum=0,d;
    for(int &i=cur[u];i;i=nt[i])
    {
        v=e[i].v;
        if(dep[v]==dep[u]+1&&cf(i)>0)
        {
            d=dfs(v,min(f,cf(i)));
            if(d>0)
            {
                sum+=d;
                f-=d;
                cf(i)-=d;
                cf(i^1)+=d;
                if(f==0) return sum;
            }
        }
    }
    return sum;
}
int Dinic()
{
    int res=0;
    while(BFS())
    {
        memcpy(cur,first,sizeof(first));
        res+=dfs(S,inf);
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    s=N+1;
    t=s+1;
    S=t+1;
    T=S+1;
    int v,k;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&k);
        add(s,i,0,inf);
        add(i,t,0,inf);
        for(int j=1;j<=k;j++)
        {
            scanf("%d",&v);
            add(i,v,1,inf);
        }
    }
    for(int i=1;i<=N;i++)
    {
        if(fl[i]>0) add(S,i,fl[i]);
        else if(fl[i]<0) add(i,T,-fl[i]);
    }
    Dinic();
    add(t,s,0,inf);
    Dinic();
    printf("%d",cf(ES));
    return 0;
}