#include<bits/stdc++.h>
using namespace std;
vector <int> m[207];
int N,T,sum;
bool book[207];
int to[207],bel[207];
inline void Init()
{
	sum=0;
	memset(to,0,sizeof(to));
	memset(bel,0,sizeof(bel));
	for(int i=1;i<=N;i++)
		m[i].clear();
	return ;
}
inline bool dfs(int u)
{
	int v;
	for(int i=0;i<m[u].size();i++)
	{
		v=m[u][i];
		if(!book[v])
		{
			book[v]=true;
			if(!bel[v]||dfs(bel[v]))
			{
				to[u]=v;bel[v]=u;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		Init();
		scanf("%d",&N);
		int x;
		for(int i=1;i<=N;i++)
			for(int j=1;j<=N;j++)
			{
				scanf("%d",&x);
				if(x) m[i].push_back(j);
			}
		for(int i=1;i<=N;i++)
		{
			memset(book,0,sizeof(book));
			if(dfs(i)) ++sum;
		}
		if(sum>=N) puts("Yes");
		else puts("No");
	}
	return 0;
}
