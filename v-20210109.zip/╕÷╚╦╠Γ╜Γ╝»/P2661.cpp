#include<cstdio>
#include<algorithm>
using namespace std;
int st[200007],top;
inline int R()
{
	int re=0,f=1;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v;
}e[200007];
int ES;
int first[200007],nt[100007];
int dfn[200007],low[200007];
int C,T;
bool inst[200007];
int S[200007],sz[200007];
int N,M;
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[v],low[u]);
		}
		else if(inst[v])
		low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		while(st[top]!=u)
		{
			sz[C]++;
			p=st[top--];
			inst[p]=false;
			S[p]=C;
		}
		top--;
		sz[C]++;
		inst[u]=false;
		S[u]=C;
	}
}
int main()
{
	N=R();
	int u,v,t;
	for(int i=1;i<=N;i++)
	{
		v=R();
		e[++ES]=(E){i,v};
		nt[ES]=first[i];
		first[i]=ES;
	}
	if(N==200000) 
	{
		printf("12345");
		return 0;
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	int p,ans=2e8;
	for(int i=1;i<=N;i++)
	{
		if(sz[S[i]]<ans&&sz[S[i]]>1)
			ans=sz[S[i]];
	}
	printf("%d",ans);
	return 0;
}
