#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=507;
const int maxq=320007;
struct query{
    int x1,y1,x2,y2,k,ty,id;
}q[maxq],q1[maxq],q2[maxq];
int N,M,Q;
int ans[maxq];
int C[maxn][maxn];
void Update(int x,int y,int k)
{
    for(int i=x;i<=N;i+=i&(-i))
        for(int j=y;j<=N;j+=j&(-j))
            C[i][j]+=k;
    return ;
}
int Query(int x,int y)
{
    int re=0;
    for(int i=x;i;i-=i&(-i))
        for(int j=y;j;j-=j&(-j))
            re+=C[i][j];
    return re;
}
void solve(int l,int r,int ql,int qr)
{
    if(l==r)
    {
        for(int i=ql;i<=qr;i++)
        if(q[i].ty==2) ans[q[i].id]=l;
        return ;
    }
    int mid=l+r>>1,cnt1=0,cnt2=0,x;
    for(int i=ql;i<=qr;i++)
    {
        if(q[i].ty==1)
        {
            if(q[i].k<=mid) Update(q[i].x1,q[i].y1,1),q1[++cnt1]=q[i];
            else q2[++cnt2]=q[i];
        }
        else
        {
            x=Query(q[i].x2,q[i].y2)-Query(q[i].x2,q[i].y1-1)-Query(q[i].x1-1,q[i].y2)+Query(q[i].x1-1,q[i].y1-1);
            if(x>=q[i].k) q1[++cnt1]=q[i];
            else q[i].k-=x,q2[++cnt2]=q[i];
        }
    }
    for(int i=1;i<=cnt1;i++)
    if(q1[i].ty==1) Update(q1[i].x1,q1[i].y1,-1);
    for(int i=1;i<=cnt1;i++) q[ql+i-1]=q1[i];
    for(int i=1;i<=cnt2;i++) q[ql+cnt1+i-1]=q2[i];
    if(cnt1) solve(l,mid,ql,ql+cnt1-1);
    if(cnt2) solve(mid+1,r,ql+cnt1,qr);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int x,a,b,c,d;
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
            scanf("%d",&x),q[++Q]=(query){i,j,0,0,x,1,0};
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d%d%d",&a,&b,&c,&d,&x);
        q[++Q]=(query){a,b,c,d,x,2,i};
    }
    solve(0,1e9,1,Q);
    for(int i=1;i<=M;i++)
        printf("%d\n",ans[i]);
    return 0;
}