#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;
const int inf=1e8;
queue <int> q;
struct E{
	int u,v,w;
}e[10005];
int dis[1005],nt[10005],first[1005],book[1005],times[1005];
int n,m;
bool SPFA(int S)
{
	for(int i=1;i<=n;i++)
		dis[i]=inf;
	dis[S]=0;
	q.push(S);
	book[S]=1;
	times[S]++;
	int t;
	while(!q.empty())
	{
		t=q.front();
		q.pop();
		for(int i=first[t];i;i=nt[i])
		{
			if(dis[t]+e[i].w<dis[e[i].v])
			{
				dis[e[i].v]=dis[t]+e[i].w;
				if(book[e[i].v]==0)
				{
					times[e[i].v]++;
					if(times[e[i].v]>n) return true;
					q.push(e[i].v);
				}
			}
		}
	}
	return false;
}
int main()
{
	scanf("%d%d",&n,&m);
	int u,v,w;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		e[i]=(E){u,v,-w};
		nt[i]=first[u];
		first[u]=i;
	}
	if(SPFA(1)) {printf("Forever love");return 0;}
	int a=dis[n];
	memset(dis,0,sizeof(dis));
	memset(times,0,sizeof(times));
	if(SPFA(n)) {printf("Forever love");return 0;}
	printf("%d",min(a,dis[1]));
	return 0;
}
