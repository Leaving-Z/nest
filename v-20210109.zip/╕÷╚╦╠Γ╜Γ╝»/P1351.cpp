#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=200007;
const int mod=10007;
const int maxm=400007;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int N;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int sum[maxn],Max[maxn],W[maxn];
int ans1,ans2;
void dfs(int u,int fa)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa) continue;
        dfs(v,u);
        ans1+=2*sum[u]*W[v]%mod;ans1%=mod;
        sum[u]+=W[v];sum[u]%=mod;
        ans1+=2*sum[v]*W[u]%mod;ans1%=mod;
        ans2=max(ans2,W[v]*Max[u]);
        ans2=max(Max[v]*W[u],ans2);
        Max[u]=max(Max[u],W[v]);
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);
        addE(v,u);
    }
    for(int i=1;i<=N;i++)
        scanf("%d",&W[i]);
    dfs(1,1);
    printf("%d %d",ans2,ans1);
    return 0;
}