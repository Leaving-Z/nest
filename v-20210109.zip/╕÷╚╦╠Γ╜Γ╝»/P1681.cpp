#include<cstdio>
#include<algorithm>
using namespace std;
int m[1507][1507];
int F[1507][1507];
int N,M,ans;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();M=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
			m[i][j]=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
		{
			if(i==1||j==1) F[i][j]=1;
			else if(m[i][j]==m[i-1][j-1]&&m[i][j]!=m[i-1][j]&&m[i][j]!=m[i][j-1])
				F[i][j]=min(F[i-1][j-1],min(F[i-1][j],F[i][j-1]))+1;
			else F[i][j]=1;
			if(F[i][j]>ans) ans=F[i][j];
		}
	printf("%d",ans);
	return 0;
}
