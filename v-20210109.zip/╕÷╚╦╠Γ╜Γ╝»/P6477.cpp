#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int maxn=1000007;
const int mod=1e9+7;
struct Tree{
	LL w,W,l;
}TREE[maxn<<2];
#define L(i) (i<<1)
#define R(i) (i<<1|1)
#define mid (L+R>>1)
#define w(i) TREE[i].w
#define W(i) TREE[i].W
#define T(i) TREE[i].l
inline int Read()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline void upd(int L,int R,int i,LL k)
{
	W(i)=(W(i)+2ll*w(i)*k%mod+(R-L+1ll)*k*k%mod)%mod;
	w(i)=(w(i)+(R-L+1ll)*k%mod)%mod;
	return ;
}
inline void LAZY(int L,int R,int i)
{
	if(!T(i)) return ;
	upd(L,mid,L(i),T(i));upd(mid+1,R,R(i),T(i));
	T(L(i))=(T(L(i))+T(i))%mod;
	T(R(i))=(T(R(i))+T(i))%mod;
	T(i)=0;
	return ;
}
inline void Update(int L,int R,int l,int r,int i,int k)
{
	if(l<=L&&R<=r)
	{
		W(i)=(W(i)+2ll*w(i)*k%mod+(R-L+1ll)*k*k%mod)%mod;
		w(i)=(w(i)+(R-L+1ll)*k%mod)%mod;
		T(i)=(T(i)+k)%mod;
		return ;
	}
	LAZY(L,R,i);
	if(l<=mid) Update(L,mid,l,r,L(i),k);
	if(r>mid) Update(mid+1,R,l,r,R(i),k);
	W(i)=(W(L(i))+W(R(i)))%mod;
	w(i)=(w(L(i))+w(R(i)))%mod;
	return ; 
}
struct pp{
	int val,num;
}A[maxn];
bool operator < (const pp &x,const pp &y)
{
	return x.val<y.val;
}
int N;
int id[maxn],Ls[maxn],ix;
inline void rk()
{
	sort(A+1,A+1+N);
	for(register int i=1;i<=N;i++)
	{
		if(A[i].val==A[i-1].val) id[A[i].num]=id[A[i-1].num];
		else id[A[i].num]=++ix;
	}
	return ;
}
int main()
{
	N=Read();
	for(register int i=1;i<=N;i++)
		A[i].val=Read(),A[i].num=i;
	rk();
	LL ans=0;
	for(register int i=1;i<=N;i++)
	{
		Update(1,N,Ls[id[i]]+1,i,1,1);
		ans+=W(1);
		if(ans>mod) ans-=mod;
		Ls[id[i]]=i;
	}
	printf("%lld",ans);
	return 0;
}
