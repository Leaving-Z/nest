#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=67;
const int maxv=32007;
int V,N;
struct ITEM{
	int c,v;
};
struct PART{
	int num;
	ITEM item[7];
}pack[maxn];
int cnt;
int son[maxn][2];
int c[maxn],v[maxn];
bool book[maxn];
#define s0 son[i][0]
#define s1 son[i][1]
int F[maxv];
int main()
{
	scanf("%d%d",&V,&N);
	int q;
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d%d",&c[i],&v[i],&q);
		if(q)
		{
			if(son[q][0]) son[q][1]=i;
			else son[q][0]=i;
		}
		else book[i]=true;
	}
	for(int i=1;i<=N;i++)
	{
		if(book[i])
		{
			++cnt;
			pack[cnt].item[++pack[cnt].num]=(ITEM){c[i],c[i]*v[i]};
			if(son[i][0]) pack[cnt].item[++pack[cnt].num]=(ITEM){c[i]+c[s0],c[i]*v[i]+c[s0]*v[s0]};
			if(son[i][1])
			{
				pack[cnt].item[++pack[cnt].num]=(ITEM){c[i]+c[s1],c[i]*v[i]+c[s1]*v[s1]};
				pack[cnt].item[++pack[cnt].num]=(ITEM){c[i]+c[s1]+c[s0],c[i]*v[i]+c[s1]*v[s1]+c[s0]*v[s0]};
			}
		}
	}
	for(int i=1;i<=cnt;i++)
		for(int j=V;j>=0;j--)
			for(int k=1;k<=pack[i].num;k++)
			if(j>=pack[i].item[k].c) F[j]=max(F[j],F[j-pack[i].item[k].c]+pack[i].item[k].v);
	printf("%d",F[V]);
	return 0;
}
