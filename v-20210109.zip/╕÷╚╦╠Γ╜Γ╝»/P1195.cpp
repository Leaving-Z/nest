#include<cstdio>
#include<algorithm>
using namespace std;
int s[1005];
struct E{
	int u,v,w;
}e[20005];
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int f(int x)
{
	return s[x]==x?x:s[x]=f(s[x]);
}
void _merge(int x,int y)
{
	int f1=f(x),f2=f(y);
	s[f2]=f1;
	return ;
}
int N,M,K;
int main()
{
	scanf("%d%d%d",&N,&M,&K);
	for(int i=1;i<=N;i++)
		s[i]=i;
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		e[i]=(E){u,v,w};
		e[i+M]=(E){v,u,w};
	}
	if(K>N) {printf("No Answer");return 0;}
	//if(K==N) {printf("0");return 0;}
	sort(e+1,e+2*M+1);
	int k=N,ST=0;
	for(int i=1;i<=2*M;i++)
	{
		if(f(e[i].u)==f(e[i].v)) continue;
		k--;
		_merge(e[i].u,e[i].v);
		ST+=e[i].w;
		if(k==K) break;
	}
	if(k==K) printf("%d",ST);
	else printf("No Answer");
	return 0;
} 
