#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
const int maxn=60007;
const int maxm=250007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
}
int N,M,all,S,T;
int m[207][207];
int id[207][207][2],cnt1,cnt2,anti[40007];
queue <int> q;
int cnt[maxn],cur[maxn];
bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
int dfs(int u,int f)
{
	if(u==T) return f;
	int v;
	int d,sum=0;
	for(int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min(f,cf(i)));
			if(d>0)
			{
				sum+=d;f-=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			scanf("%d",&m[i][j]);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			if(m[i][j-1]==2||j==1)
				id[i][j][0]=++cnt1,anti[cnt1]=i;
			else id[i][j][0]=id[i][j-1][0];
	cnt2=cnt1;
	for(int i=1;i<=M;i++)
		for(int j=1;j<=N;j++)
			if(m[j-1][i]==2||j==1)
				id[j][i][1]=++cnt2,anti[cnt2]=i;
			else id[j][i][1]=id[j-1][i][1];
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			if(m[i][j]==0) add(id[i][j][0],id[i][j][1],1);
	T=cnt1+cnt2+1;
	for(int i=1;i<=cnt1;i++)
		add(S,i,1);
	for(int i=cnt1+1;i<=cnt2;i++)
		add(i,T,1);
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	for(int u=1;u<=cnt1;u++)
	{
		for(int i=first[u],v;i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)==0&&v!=S)
				printf("\n%d %d",anti[u],anti[v]);
		}
	}
	return 0;
}
