#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=200007;
const int mod=998244353;
typedef long long LL;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL inv[maxn],fac[maxn];
int N,M,x,y;
LL C(int n,int m)
{
    return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
LL f(int i,int j)
{
    return C(i+j-2,i-1);
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d%d",&M,&N,&x,&y);
    int ty=0;
    if(x>N) x=2*N-x+1,ty^=1;
    if(y>N) y=2*N-y+1,ty^=1;
    fac[0]=1;
    for(int i=1;i<=200005;i++)
        fac[i]=fac[i-1]*i%mod;
    inv[200005]=fast_pow(fac[200005],mod-2);
    for(int i=200005-1;i>=0;i--)
    inv[i]=inv[i+1]*(i+1)%mod;
    LL ans=0;
    if(ty==0)
    {
        if(y<x) swap(x,y);
        for(int i=1;i<=M;i++)
        ans+=f(x,i)*f(N-y+1,M-i+1)%mod*f(N+1,M)%mod,ans%=mod;
    }
    else 
    {
        for(int i=1;i<=M;i++)
        ans+=(f(x,i)*f(N-x+1,M-i+1)%mod*f(y,i)%mod*f(N-y+1,M-i+1)%mod)%mod,ans%=mod;
    }
    printf("%lld",ans);
    return 0;
}