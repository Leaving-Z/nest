#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int W[105],a[105];
int DP[25050];
bool mark[105];
int N,T,max_=-1;
int main()
{
	scanf("%d",&T);
	for(int i=0;i<T;i++)
	{
		memset(DP,0,sizeof(DP));
		scanf("%d",&N);
		for(int j=1;j<=N;j++)
		{
			scanf("%d",&W[j]);
			max_=max(W[j],max_);
		}
		DP[0]=1;
		for(int j=1;j<=N;j++)
		{
			for(int k=W[j];k<=max_;k++)
				DP[k]+=DP[k-W[j]];
		}
		int ans=N;
		for(int l=1;l<=N;l++)
			if(DP[W[l]]>1) ans--;
		printf("%d\n",ans);
	}
	return 0;
}
