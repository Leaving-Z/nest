#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=100007;
int N;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
bool ins[maxn],vis[maxn];
int v[maxn],dfn[maxn],T;
int ans[maxn];
bool f;
int root;
void dfs(int u)
{
	dfn[u]=++T;
	ins[u]=true;
	if(dfn[v[u]])
	{
		if(ins[v[u]])
		{
			ans[u]=T-dfn[v[u]]+1;
			if(v[u]!=u) f=true,root=v[u];
		}
		else ans[u]=ans[v[u]]+1;
	}
	else
	{
		dfs(v[u]);
		if(f) ans[u]=ans[v[u]];
		else ans[u]=ans[v[u]]+1;
		if(u==root) f=false;
	}
	ins[u]=false;
	return ;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		v[i]=R();
	for(register int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	for(register int i=1;i<=N;i++)
		printf("%d\n",ans[i]);
	return 0;
}
