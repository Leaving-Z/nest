#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=2000007;
const int lim=2000000;
long long phi[maxn];
int prime[maxn],cnt;
bool book[maxn];
void pre()
{
    phi[1]=1;
    for(int i=2;i<=lim;i++)
    {
        if(!book[i]) prime[++cnt]=i,phi[i]=i-1;
        for(int j=1;j<=cnt&&i*prime[j]<=lim;j++)
        {
            book[i*prime[j]]=true;
            if(i%prime[j])
                phi[i*prime[j]]=phi[i]*(prime[j]-1);
            else {phi[i*prime[j]]=phi[i]*prime[j];break;}
        }
    }
    for(int i=1;i<=lim;i++)
        phi[i]+=phi[i-1];
    return ;
}
int T,N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    pre();
    scanf("%d",&N);
    int L=1,R;
    long long ans=0;
    while(L<=N)
    {
        R=N/(N/L);
        ans+=(L+R)*(R-L+1ll)/2*phi[N/L];
        L=R+1;
    }
    printf("%lld",ans-N*(N+1ll)/2);
    return 0;
}