#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=5007;
const int maxm=20007;
int N,M;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
bool vis[maxm],ins[maxn];
int C,T;
int dfn[maxn],low[maxn],S[maxn];
int stk[maxn],top;
void dfs(int u)
{
    ins[u]=true;
    stk[++top]=u;
    low[u]=dfn[u]=++T;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        if(vis[i]) continue;
        vis[i]=vis[i^1]=true;
        v=e[i].v;
        if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
        else low[u]=min(low[u],dfn[v]);
    }
    if(dfn[u]==low[u])
    {
        int p;C++;
        do{
            p=stk[top--];
            ins[p]=false;
            S[p]=C;
        }while(p!=u);
    }
    return ;
}
int deg[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);addE(v,u);
    }
    for(int i=1;i<=N;i++)
    if(!dfn[i]) dfs(i);
    for(int i=2;i<=ES;i+=2)
    if(S[e[i].u]!=S[e[i].v])
        deg[S[e[i].u]]++,deg[S[e[i].v]]++;
    int ans=0;
    for(int i=1;i<=C;i++)
    if(deg[i]==1) ++ans;
    printf("%d",(ans+1)>>1);
    return 0;
}