#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<ctime>
using namespace std;
const int maxn=500007;
const int maxm=12*maxn;
typedef long long LL;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
queue <int> q;
LL dis[maxn];
bool book[maxn];
void SPFA()
{
    q.push(0);
    memset(dis,0x3f,sizeof(dis));
    dis[0]=0;
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();book[u]=false;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(dis[u]+e[i].w<dis[v])
            {
                dis[v]=dis[u]+e[i].w;
                if(!book[v])
                {
                    book[v]=true;
                    q.push(v);
                }
            }
        }
    }
    return ;
}
int N,minn;
int A[17];
LL L,R;
LL calc(LL x)
{
    LL re=0;
    for(int i=0;i<minn;i++)
    if(dis[i]<=x) re+=(x-dis[i])/minn+1;
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%lld%lld",&N,&L,&R);
    minn=1e6;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        if(A[i]) minn=min(minn,A[i]);
    }
    for(int i=0;i<minn;i++)
    {
        for(int j=1;j<=N;j++)
        if(A[j]) addE(i,(i+A[j])%minn,A[j]);
    }
    SPFA();
    printf("%lld",calc(R)-calc(L-1));
    return 0;
}