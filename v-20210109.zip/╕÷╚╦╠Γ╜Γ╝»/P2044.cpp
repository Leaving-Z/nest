#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
LL a,c,x0,mod,MOD,N;
inline LL mul(LL x,LL y)
{
	LL t=0;
	x%=mod;y%=mod;
	while(y)
	{
		if(y&1) t=(x+t)%mod;
		x=(x+x)%mod;
		y>>=1;
	}
	return t;
}
struct Matrix{
	LL m[3][3];
	Matrix () {memset(m,0,sizeof(m));}
	Matrix operator * (const Matrix &A) const
	{
		Matrix t;
		for(int i=1;i<=2;i++)
			for(int j=1;j<=2;j++)
				for(int k=1;k<=2;k++)
					t.m[i][j]=(t.m[i][j]+mul(m[i][k],A.m[k][j]))%mod;
		return t;
	}
}ini;
Matrix operator ^ (Matrix A,LL k)
{
	Matrix t;
	t.m[1][1]=t.m[2][2]=1;
	while(k)
	{
		if(k&1) t=A*t;
		A=A*A;
		k>>=1;
	}
	return t;
}
int main()
{
	scanf("%lld%lld%lld%lld%lld%lld",&mod,&a,&c,&x0,&N,&MOD);
	c%=mod;a%=mod;x0%=mod;
	ini.m[1][1]=a;ini.m[2][1]=c;ini.m[2][2]=1;
	ini=ini^(N);
	printf("%lld",((mul(x0,ini.m[1][1])+ini.m[2][1])%mod)%MOD);
	return 0;
}
