#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
struct Hash_Table{
	static const LL MOD=233333;
	LL Hash[MOD+7],V[MOD+7];
	LL stk[MOD+7],top;
	inline void clear() {while(top) Hash[stk[top--]]=0;return ;}
	inline void insert(LL val,LL mi)
	{
		LL h=val%MOD;
		while(Hash[h]&&Hash[h]!=val) h++;
		Hash[h]=val;V[h]=mi;
		stk[++top]=h;
		return ;
	}
	inline LL find(LL val)
	{
		LL h=val%MOD;
		while(Hash[h]&&Hash[h]!=val) h++;
		return Hash[h]==val?V[h]:-1;
	}
}H;
LL A,B,C,D;
LL T;
LL a,b,x1,t,p,iv,ans;
inline LL fast_pow(LL b,LL k,LL m)
{
	LL s=1;
	while(k)
	{
		if(k&1) s=s*b%m;
		b=b*b%m;
		k>>=1;
	}
	return s;
}
LL g;
LL Gcd(LL x,LL y)
{
	return x%y==0?y:Gcd(y,x%y);
}
inline LL inv(LL x,LL m)
{
	return fast_pow(x,m-2,m);
}
inline LL BSGS()
{
	LL ti=B;
	H.clear();
	LL sqrtm=ceil(sqrt(C));
	for(int i=0;i<sqrtm;i++)
	{
		H.insert(ti,(LL)i);
		ti=ti*A%C;
	}
	LL t=fast_pow(A,sqrtm,C),ans;
	ti=D*t%C;
	for(int i=1;i<=sqrtm;i++)
	{
		if(ti&&(ans=H.find(ti))!=-1)
			return i*sqrtm-ans;
		ti=ti*t%C;
	}
	return -1;
}
int main()
{
	scanf("%lld",&T);
	LL re;
	while(T--)
	{
		scanf("%lld%lld%lld%lld%lld",&p,&a,&b,&x1,&t);
		if(t==x1) puts("1");
		else if(a==0)
		{
			if(t==b) puts("2");
			else puts("-1");
		}
		else if(a==1)
		{
			LL x,y;
			C=((t-x1)%p+p)%p;
			A=b;B=p;
			if(C%Gcd(b,p)) puts("-1");
			else
			{
				iv=inv(b,p);
				if((C*iv+1)%p==0)
					printf("%lld\n",p);
				else printf("%lld\n",(C*iv+1)%p);
			}
		}
		else
		{
			iv=b*inv(a-1,p)%p;
			D=(x1+iv)%p;
			B=(t+iv)%p;
			A=a;
			C=p;
			ans=BSGS();
			if(ans>=0) ans++;
			printf("%lld\n",ans);
		}
	}
}
