#include<cstdio>
#include<algorithm>
#include<queue>
using namespace std;
struct n{
	int step,sta;
};
queue <n> q;
bool book[2050];
int ans=0x7f7f7f7f;
int N,M;
int eff[107][15];
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=M;i++)
		for(int j=1;j<=N;j++)
		scanf("%d",&eff[i][j]);
	int state;
	state=(1<<N+1)-2;
	n u;
	book[state]=true;
	q.push((n){0,state});
	while(!q.empty())
	{
		u=q.front();q.pop();
		if(u.sta==0)
		{
			printf("%d",u.step);
			return 0;
		}
		state=u.sta;
		for(int i=1;i<=M;i++)
		{
			for(int j=1;j<=N;j++)
			{
				if(eff[i][j]==1)
					state&=(~(1<<j));
				else if(eff[i][j]==-1)
					state|=(1<<j);
			}
			if(!book[state])
			{
				book[state]=true;
				q.push((n){u.step+1,state});
			}
			state=u.sta;
		}	
	}
	printf("-1");
	return 0;
}
