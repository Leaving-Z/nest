#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int L,R,mid;
int F[1007];
int w[1007],v[1007],N,p,ans=-1;
int S;
inline bool check(int lim)
{
	memset(F,0,sizeof(F));
	for(register int i=1;i<=N;i++)
	{
		if(w[i]>lim) continue;
		for(register int j=S;j>=w[i];j--)
			F[j]=max(F[j],F[j-w[i]]+v[i]);
	}
	return F[S]>=p;
}
inline int r()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=r();p=r();S=r();L=1;
	for(register int i=1;i<=N;i++)
		w[i]=r(),v[i]=r(),R=max(R,w[i]);
	while(L<=R)
	{
		mid=L+R>>1;
		if(check(mid)) ans=mid,R=mid-1;
		else L=mid+1;
	}
	if(ans==-1) printf("No Solution!");
	else printf("%d",ans);
	return 0;
}
