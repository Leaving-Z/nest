#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=10007;
const int maxm=100007;
const int inf=0x7f7f7f7f;
queue <int> q;
struct E{
	int u,v,c;
}e[maxm<<1];
int first[maxn],nt[maxm<<1],ES=1;
#define c(i) e[i].c
inline void addE(int u,int v,int c)
{
	e[++ES]=(E){u,v,c};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,S,T,x;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
bool book[maxn];
int pre[maxn][2];
inline bool KF()
{
	while(!q.empty()) q.pop();
	memset(book,0,sizeof(book));
	q.push(S);book[S]=true;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		if(u==T) return true;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!book[v]&&c(i)>0)
			{
				q.push(v);
				book[v]=true;
				pre[v][0]=u;
				pre[v][1]=i;
			}
		}
	}
	return false;
}
int d;
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline void flow(int u)
{
	int v;
	if(u==S) return ;
	d=min_(d,c(pre[u][1]));
	flow(pre[u][0]);
	int i=pre[u][1];
	c(i)-=d;c(i^1)+=d;
	return ;
}
int main()
{
	N=R();M=R();S=1;T=N;
	x=R();
	int u,v,c;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();c=R();
		addE(u,v,c);addE(v,u,0);
	}
	int ans=0;
	while(KF())
	{
		d=inf;
		flow(T);
		ans+=d;
	}
	if(ans)
    printf("%d %d",ans,x%ans==0?x/ans:x/ans+1);
    else printf("Orz Ni Jinan Saint Cow!");
    return 0;
}
