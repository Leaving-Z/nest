#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
inline LL Read()
{
	char c;
	LL f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	LL u,v;
}e[200007];
LL ES;
LL first[100007],nt[200007];
LL TREE[400007],add[400007];
LL top[100007],id[100007],anti[100007],fa[100007],son[100007],sz[100007],depth[100007];
LL A[100007];
LL ix;
LL N,M;
void DFS(LL u)
{
	LL v;
	sz[u]=1;
	for(LL i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			depth[v]=depth[u]+1;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[son[u]]<sz[v]) son[u]=v;
		}
	}
	return ;
}
void dfs(LL u,LL s)
{
	id[u]=++ix;
	anti[ix]=u;
	top[u]=s;
	if(son[u]) dfs(son[u],s);
	LL v;
	for(LL i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=son[u]&&v!=fa[u])
		dfs(v,v);
	}
	return ;
}
void Build(LL L,LL R,LL i)
{
	if(L==R)
	{
		TREE[i]=A[anti[L]];
		return ;
	}
	LL mid=L+R>>1;
	Build(L,mid,i<<1);
	Build(mid+1,R,i<<1|1);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	return ;
}
void LAZY(LL L,LL R,LL i)
{
	LL mid=L+R>>1;
	TREE[i<<1]+=(mid-L+1)*add[i];
	TREE[i<<1|1]+=(R-mid)*add[i];
	add[i<<1]+=add[i];add[i<<1|1]+=add[i];
	add[i]=0;
	return ;
}
void Update(LL L,LL R,LL l,LL r,LL i,LL k)
{
	if(l<=L&&R<=r)
	{
		TREE[i]+=(R-L+1)*k;
		add[i]+=k;
		return ;
	}
	LL mid=L+R>>1;
	LAZY(L,R,i);
	if(l<=mid) Update(L,mid,l,r,i<<1,k);
	if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
	TREE[i]=TREE[i<<1]+TREE[i<<1|1];
	return ;
}
LL Query(LL L,LL R,LL l,LL r,LL i)
{
	if(l<=L&&R<=r)
	return TREE[i];
	LL mid=L+R>>1,ans=0;
	LAZY(L,R,i);
	if(l<=mid) ans+=Query(L,mid,l,r,i<<1);
	if(r>mid) ans+=Query(mid+1,R,l,r,i<<1|1);
	return ans;
}
LL Query_Path(LL x,LL y)
{
	LL sum=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		sum+=Query(1,N,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	sum+=Query(1,N,id[x],id[y],1);
	return sum;
}
inline void addE(LL u,LL v)
{
	ES++;
	e[ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	ES++;
	e[ES]=(E){v,u};
	nt[ES]=first[v];
	first[v]=ES;
	return ;
}
int main()
{
	N=Read();M=Read();
	for(LL i=1;i<=N;i++)
		A[i]=Read();
	LL u,v;
	for(LL i=1;i<N;i++)
	{
		u=Read();v=Read();
		addE(u,v);
	}
	DFS(1);
	dfs(1,1);
	Build(1,N,1);
	LL s,x,a;
	for(LL i=1;i<=M;i++)
	{
		s=Read();
		if(s==1)
		{
			x=Read();a=Read();
			Update(1,N,id[x],id[x],1,a);
		}
		else if(s==2)
		{
			x=Read();a=Read();
			Update(1,N,id[x],id[x]+sz[x]-1,1,a);
		}
		else if(s==3)
		{
			x=Read();
			printf("%lld\n",Query_Path(x,1));
		}
	}
	return 0;
}
