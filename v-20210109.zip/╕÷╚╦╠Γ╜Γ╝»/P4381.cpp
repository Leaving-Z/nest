#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
const int maxn=1000007;
const int maxm=2000007;
typedef long long LL;
struct E{
	int u,v;
	LL w;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
bool acc[maxm];
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int A[maxn][2],cnt;
int S[maxn],N;
int f(int x) {return S[x]==x?x:S[x]=f(S[x]);}
int pre[maxn];
void dfs1(int u,int fa)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||acc[i]) continue;
		pre[v]=i^1;
		dfs1(v,u);
	}
	return ;
}
LL dis[maxn],maxE[maxn][2];
LL L,D;
void dfs2(int u,int fa)
{
	int v;
	maxE[u][0]=maxE[u][1]=0;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa||acc[i]) continue;
		dis[v]=dis[u]+e[i].w;
		dfs2(v,u);
		if(maxE[v][0]+e[i].w>maxE[u][0])
		{
			maxE[u][1]=maxE[u][0];
			maxE[u][0]=maxE[v][0]+e[i].w;
		}
		else if(maxE[v][0]+e[i].w>maxE[u][1])
			maxE[u][1]=maxE[v][0]+e[i].w;
	}
	D=max(D,maxE[u][1]+maxE[u][0]);
	L=max(L,dis[u]);
	return ;
}
LL B[maxm],C[maxm],w[maxn];
int tot,vis[maxn],len;
void dfs3(int u,int fa)
{
	if(!vis[u]) len++;
	vis[u]++;
	C[tot]=w[u];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		if(acc[i])
		{
			v=e[i].v;
			if(i==fa||vis[v]>1) continue;
			B[tot+1]=B[tot]+e[i].w;
			tot++;
			dfs3(v,i^1);
		}
	}
	return ;
}
int q[maxm],head,tail;
LL work(int lt,int rt)
{
	dfs1(lt,0);
	LL re=0;
	while(rt)
	{
		acc[pre[rt]]=acc[pre[rt]^1]=true;
		dis[rt]=0;D=L=0;
		dfs2(rt,0);
		re=max(re,D);
		w[rt]=L;
		rt=e[pre[rt]].v;
	}
	len=0;tot=1;
	dfs3(lt,0);
	q[0]=q[1]=0;
	head=1;tail=0;
	for(int i=1;i<=tot;i++)
	{
		while(head<=tail&&q[head]<=i-len) ++head;
		re=max(re,C[q[head]]-B[q[head]]+C[i]+B[i]);
		while(head<=tail&&C[q[tail]]-B[q[tail]]<=C[i]-B[i]) --tail;
		q[++tail]=i;
	}
	return re;
}
int main()
{
	N=R();
	for(int i=1;i<=N;i++)
		S[i]=i;
	int v;LL w;
	int f1,f2;
	for(int i=1;i<=N;i++)
	{
		v=R();w=R();
		addE(i,v,w);
		addE(v,i,w);
		f1=f(i);f2=f(v);
		if(f1==f2) acc[ES]=acc[ES^1]=true,A[++cnt][0]=i,A[cnt][1]=v;
		else S[f1]=f2;
	}
	LL ans=0;
	for(int i=1;i<=cnt;i++)
		ans+=work(A[i][0],A[i][1]);
	printf("%lld",ans);
	return 0;
}
