#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=50007;
const int maxm=280007;
const int inf=1e9;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
int cnt[maxn],cur[maxn];
int S,T;
int id[107][107],all;
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);addE(v,u,0);
	return ;
}
bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	q.push(S);cnt[S]=1;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				q.push(v);
				cnt[v]=cnt[u]+1;
			}
		}
	}
	return cnt[T]!=0;
}
int dfs(int u,int f)
{
	if(u==T) return f;
	int v;
	int d,sum=0;
	for(int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min(f,cf(i)));
			if(d>0)
			{
				cf(i)-=d;cf(i^1)+=d;
				f-=d;sum+=d;
				if(f<=0) return sum; 
			}
		}
	}
	return sum;
}
int main()
{
	N=R();M=R();
	int x;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			id[i][j]=++all;
	T=5*all+1;
	int ans=0;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			x=R();ans+=x;
			add(S,id[i][j],x);
		}
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			x=R();ans+=x;
			add(id[i][j],T,x);
		}
	for(int i=1;i<N;i++)
		for(int j=1;j<=M;j++)
		{
			x=R();ans+=x;
			add(id[i][j]+all,id[i][j],inf);
			add(S,id[i][j]+all,x);
			add(id[i][j]+all,id[i+1][j],inf);
		}
	for(int i=1;i<N;i++)
		for(int j=1;j<=M;j++)
		{
			x=R();ans+=x;
			add(id[i][j],id[i][j]+all*2,inf);
			add(id[i][j]+2*all,T,x);
			add(id[i+1][j],id[i][j]+all*2,inf);
		}
	for(int i=1;i<=N;i++)
		for(int j=1;j<M;j++)
		{
			x=R();ans+=x;
			add(id[i][j]+all*3,id[i][j],inf);
			add(S,id[i][j]+3*all,x);
			add(id[i][j]+all*3,id[i][j+1],inf);
		}
	for(int i=1;i<=N;i++)
		for(int j=1;j<M;j++)
		{
			x=R();ans+=x;
			add(id[i][j],id[i][j]+all*4,inf);
			add(id[i][j]+all*4,T,x);
			add(id[i][j+1],id[i][j]+all*4,inf);
		}
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans-=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
