#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int F[207];
int m[207][207];
int N;
int main()
{
	scanf("%d",&N);
	memset(F,0x7f,sizeof(F));
	F[1]=0;
	for(register int i=1;i<=N;i++)
		for(register int j=i+1;j<=N;j++)
			scanf("%d",&m[i][j]),m[j][i]=m[i][j];
	for(register int i=2;i<=N;i++)
		for(register int j=1;j<=N;j++)
			F[i]=min(F[j]+m[j][i],F[i]);
	printf("%d",F[N]);
	return 0;
}
