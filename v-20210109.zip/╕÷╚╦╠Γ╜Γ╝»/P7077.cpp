#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
#include<queue>
using namespace std;
const int maxn=100007;
const int maxm=2000007;
const int mod=998244353;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
typedef long long LL;
int q[maxn],head,tail;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int in[maxn];
inline void addE(int u,int v)
{
    in[v]++;
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,M,Q;
LL f[maxn],p[maxn],mul[maxn],A[maxn],ad[maxn];
int pos[maxn];
int T[maxn];
LL dfs(int u)
{
    if(f[u]!=-1) return f[u];
    f[u]=1;
    if(T[u]==2) return f[u]=mul[u];
    else if(T[u]==3)
    {
        for(int i=first[u];i;i=nt[i])
            f[u]=f[u]*dfs(e[i].v)%mod;
    }
    return f[u];
}
int ord[maxn];
int ix;
void topo()
{
    int u,v;
    head=1;tail=0;
    for(int i=0;i<=M;i++) if(!in[i]) q[++tail]=i;
    while(head<=tail)
    {
        u=q[head++];
        ord[++ix]=u;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            --in[v];
            if(!in[v]) q[++tail]=v;
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();
    memset(f,-1,sizeof(f));
    for(int i=1;i<=N;i++)
        A[i]=R();
    M=R();
    int k,x,y;
    for(int i=1;i<=M;i++)
    {
        T[i]=R();
        if(T[i]==1) pos[i]=R(),ad[i]=R();
        else if(T[i]==2) mul[i]=R();
        else if(T[i]==3)
        {
            k=R();
            for(int j=1;j<=k;j++)
                x=R(),addE(i,x);
        }
    }
    k=R();
    T[0]=3;
    for(int i=1;i<=k;i++)
        x=R(),addE(0,x);
    dfs(0);
    for(int i=1;i<=N;i++) A[i]*=f[0],A[i]%=mod;
    p[0]=1;
    topo();
    LL prod;
    for(int i=1;i<=ix;i++)
    {
        x=ord[i];
        if(T[x]==3)
        {
            prod=p[x];
            for(int k=first[x];k;k=nt[k])
            {
                y=e[k].v;
                p[y]=(p[y]+prod)%mod;
                prod=prod*dfs(y)%mod;
            }
        }
        else if(T[x]==1)
            A[pos[x]]+=p[x]*ad[x]%mod,A[pos[x]]%=mod;
    }
    for(int i=1;i<=N;i++)
        printf("%lld ",A[i]);
    return 0;
}