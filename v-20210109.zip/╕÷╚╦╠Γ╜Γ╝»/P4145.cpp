#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=100007;
typedef long long LL;
int N,M;
struct Tree{
	LL sum,maxx;
}TREE[maxn<<2];
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define sum(i) TREE[i].sum
#define maxx(i) TREE[i].maxx
LL A[maxn];
inline LL R()
{
	char c;
	LL re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
void Build(int L,int R,int i)
{
	if(L==R)
	{
		sum(i)=maxx(i)=A[L];
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	sum(i)=sum(Ls)+sum(Rs);
	maxx(i)=max(maxx(Ls),maxx(Rs));
	return ;
}
void Update(int L,int R,int l,int r,int i)
{
	if(maxx(i)==1) return ;
	if(L==R)
	{
		sum(i)=(LL)sqrt(sum(i));
		maxx(i)=sum(i);
		return ;
	}
	if(l<=mid) Update(L,mid,l,r,Ls);
	if(r>mid) Update(mid+1,R,l,r,Rs);
	sum(i)=sum(Ls)+sum(Rs);
	maxx(i)=max(maxx(Ls),maxx(Rs));
	return ; 
}
LL Query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return sum(i);
	LL re=0;
	if(l<=mid) re+=Query(L,mid,l,r,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,Rs);
	return re;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		A[i]=R();
	int op,l,r;
	Build(1,N,1);
	M=R();
	while(M--)
	{
		op=R();l=R();r=R();
		if(l>r) swap(l,r);
		if(op==0) Update(1,N,l,r,1);
		else printf("%lld\n",Query(1,N,l,r,1));
	}
	return 0;
}
