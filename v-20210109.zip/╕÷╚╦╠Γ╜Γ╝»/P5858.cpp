#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=5507;
typedef long long LL;
LL f[maxn][maxn];
LL A[maxn];
int q[maxn],head,tail;
int N,K,S;
void push(int i,int x)
{
    while(head<=tail&&f[i-1][x]>=f[i-1][q[tail]]) --tail;
    q[++tail]=x;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d%d",&N,&K,&S);
    for(int i=1;i<=N;i++)
        scanf("%lld",&A[i]);
    memset(f,~0x3f,sizeof(f));
    for(int i=0;i<=K;i++)
        f[0][i]=0;
    for(int i=1;i<=N;i++)
    {
        head=1;tail=0;
        push(i,min(i,K));
        for(int k=min(i,K);k>0;k--)
        {
            while(head<=tail&&q[head]>k+S-1) ++head;
            push(i,k-1);
            f[i][k]=f[i-1][q[head]]+k*A[i];
        }
    }
    LL ans=-1e18;
    for(int i=1;i<=K;i++)
        ans=max(ans,f[N][i]);
    printf("%lld",ans);
    return 0;
}