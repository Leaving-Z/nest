#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
const int maxn=300007;
vector <int> m[maxn];
int A[maxn];
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	//freopen("P3939_2.in","r",stdin);
	N=R();M=R();
	int x;
	for(register int i=1;i<=N;i++)
	{
		A[i]=x=R();
		m[x].push_back(i);
	}
	int op,l,r,p1,p2;
	while(M--)
	{
		op=R();
		if(op==1)
		{
			l=R();r=R();
			x=R();
			p1=lower_bound(m[x].begin(),m[x].end(),l)-m[x].begin();
			p2=lower_bound(m[x].begin(),m[x].end(),r)-m[x].begin();
			if(p2!=m[x].end()-m[x].begin()&&m[x][p2]==r) p2++;
			printf("%d\n",p2-p1);
		}
		else
		{
			x=R();
			l=A[x];
			r=A[x+1];
			swap(A[x],A[x+1]);
			p1=lower_bound(m[l].begin(),m[l].end(),x)-m[l].begin();
			m[l][p1]++;
			p1=lower_bound(m[r].begin(),m[r].end(),x+1)-m[r].begin();
			m[r][p1]--;
		}
	}
	return 0;
}
