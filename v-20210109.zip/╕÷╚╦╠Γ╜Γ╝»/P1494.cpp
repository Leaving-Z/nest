#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
const int maxn=50007;
const int SIZE=240;
struct query{
    int l,r,id;
}q[maxn];
bool com1(const query &x,const query &y)
{
    return x.l<y.l||x.l==y.l&&x.r<y.r;
}
bool com2(const query &x,const query &y)
{
    return x.r<y.r;
}
int N,Q;
int A[maxn];
int num[maxn];
vector <query> m[maxn];
long long ans[maxn],down[maxn];
void solve(int k)
{
    sort(m[k].begin(),m[k].end(),com2);
    long long res=0;
    memset(num,0,sizeof(num));
    for(int i=m[k][0].l;i<=m[k][0].r;i++)
    {
        res-=num[A[i]]*num[A[i]];
        num[A[i]]++;
        res+=num[A[i]]*num[A[i]];
    }
    ans[m[k][0].id]=res;
    int d,l,r;
    for(int i=1;i<(int)m[k].size();i++)
    {
        l=m[k][i-1].l;r=m[k][i].l-1;
        if(m[k][i].l>m[k][i-1].l) d=-1;
        else d=1;
        if(l>r)
        {
            l=m[k][i].l;
            r=m[k][i-1].l-1;
        }
        for(int j=l;j<=r;j++)
        {
            res-=num[A[j]]*num[A[j]];
            num[A[j]]+=d;
            res+=num[A[j]]*num[A[j]];
        }
        for(int j=m[k][i-1].r+1;j<=m[k][i].r;j++)
        {
            res-=num[A[j]]*num[A[j]];
            num[A[j]]++;
            res+=num[A[j]]*num[A[j]];
        }
        ans[m[k][i].id]=res;
    }
    return ;
}
long long gcd(long long a,long long b)
{
    return !b?a:gcd(b,a%b);
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    for(int i=1;i<=Q;i++)
        scanf("%d%d",&q[i].l,&q[i].r),q[i].id=i;
    sort(q+1,q+1+Q,com1);
    int x;
    for(int i=1;i<=Q;i++)
        x=(i-1)/SIZE+1,m[x].push_back(q[i]);
    for(int i=1;i<=(Q-1)/SIZE+1;i++)
        solve(i);
    for(int i=1;i<=Q;i++)
    if(q[i].l==q[i].r) ans[q[i].id]=0;
    else ans[q[i].id]-=q[i].r-q[i].l+1,ans[q[i].id]>>=1,down[q[i].id]=(q[i].r-q[i].l+1ll)*(q[i].r-q[i].l)>>1;
    long long a,b,g;
    for(int i=1;i<=Q;i++)
    {
        if(ans[i]==0) puts("0/1");
        else
        {
            a=ans[i];
            b=down[i];
            g=gcd(a,b);
            a/=g;b/=g;
            printf("%lld/%lld\n",a,b);
        }
    }
    return 0;
}