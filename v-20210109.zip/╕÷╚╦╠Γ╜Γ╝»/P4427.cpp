#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
const LL mod=998244353;
const LL maxn=300007;
LL N,Q;
LL TREE[maxn<<2][57];
#define L(i) (i<<1)
#define R(i) (i<<1|1)
#define mid (L+R>>1)
#define sum(i,o) TREE[i][o]
struct E{
	LL u,v;
}e[maxn<<1];
LL first[maxn],nt[maxn<<1],ES;
inline void addE(LL u,LL v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
LL A[maxn],fa[maxn],son[maxn],depth[maxn];
LL sz[maxn],top[maxn],id[maxn],anti[maxn],ix;
inline void DFS(LL u)
{
	sz[u]=1;
	LL v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			fa[v]=u;
			depth[v]=depth[u]+1;
			A[v]=depth[v];
			DFS(v);
			sz[u]+=sz[v];
			if(sz[v]>sz[son[u]]) son[u]=v;
		}
	}
	return ;
}
inline void dfs(LL u,LL tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs(son[u],tp);
	LL v;
	for(int i=first[u];i;i=nt[i]) 
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs(v,v);
	}
	return ;
}
inline void Pushup(LL i)
{
	for(LL k=0;k<=50;k++)
		sum(i,k)=(sum(L(i),k)+sum(R(i),k))%mod;
	return ;
}
inline void Build(LL L,LL R,LL i)
{
	sum(i,0)=1;
	if(L==R)
	{
		for(LL k=1;k<=50;k++)
		sum(i,k)=(sum(i,k-1)*(A[anti[L]])%mod)%mod;
		return ;
	}
	Build(L,mid,L(i));
	Build(mid+1,R,R(i));
	Pushup(i);
	return ;
}
inline LL Query(LL L,LL R,LL l,LL r,LL i,LL k)
{
	if(l<=L&&R<=r)
		return sum(i,k);
	LL ans=0;
	if(l<=mid) ans+=Query(L,mid,l,r,L(i),k);
	if(r>mid) ans+=Query(mid+1,R,l,r,R(i),k);
	return ans%mod;
}
inline LL Query_Path(LL x,LL y,LL k)
{
	LL sum=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		sum+=Query(1,N,id[top[x]],id[x],1,k);
		sum%=mod;
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	sum+=Query(1,N,id[x],id[y],1,k);
	return sum%mod;
}
inline LL Re()
{
	LL re,f=1;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=Re();
	LL u,v,w;
	for(int i=1;i<N;i++)
	{
		u=Re();v=Re();
		addE(u,v);addE(v,u);
	}
	Q=Re();
	DFS(1);dfs(1,1);
	Build(1,N,1);
	for(int i=1;i<=Q;i++)
	{
		u=Re();v=Re();w=Re();
		printf("%lld\n",Query_Path(u,v,w));
	}
	return 0;
}
