#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=800007;
char s[maxn];
int tmp[maxn],rk[maxn],id[maxn],SA[maxn],cnt[maxn],px[maxn];
int N;
int ht[maxn];
int stk[maxn],top,sum1[maxn],sum2[maxn];
struct Range{
    int l,r;
}A[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%s",s+1);
    int len1=N=strlen(s+1);
    len1++;N++;
    s[len1]='#';
    scanf("%s",s+1+N);
    N=strlen(s+1);
    int m=150;
    for(int i=1;i<=N;i++) ++cnt[rk[i]=s[i]];
    for(int i=1;i<=m;i++) cnt[i]+=cnt[i-1];
    for(int i=N;i>=1;i--) SA[cnt[rk[i]]--]=i;
    for(int w=1,p=0;p<N;w<<=1,m=p)
    {
        p=0;
        for(int i=N;i>N-w;i--) id[++p]=i;
        for(int i=1;i<=N;i++)
        if(SA[i]>w) id[++p]=SA[i]-w;
        for(int i=1;i<=m;i++) cnt[i]=0;
        for(int i=1;i<=N;i++) ++cnt[px[i]=rk[id[i]]];
        for(int i=1;i<=m;i++) cnt[i]+=cnt[i-1];
        for(int i=N;i>=1;i--) SA[cnt[px[i]]--]=id[i];
        p=0;memcpy(tmp,rk,sizeof(rk));
        for(int i=1;i<=N;i++)
        if(tmp[SA[i]]==tmp[SA[i-1]]&&tmp[SA[i]+w]==tmp[SA[i-1]+w]) rk[SA[i]]=p;
        else rk[SA[i]]=++p;
    }
    int k=0;
    for(int i=1;i<=N;i++)
    {
        if(k) k--;
        while(i+k<=N&&s[i+k]==s[SA[rk[i]-1]+k]) ++k;
        ht[rk[i]]=k;
    }
    for(int i=1;i<=N;i++)
    {
        A[i].l=A[i].r=i;
        while(top&&ht[i]<=ht[stk[top]])
        {
            A[i].l=A[stk[top]].l;
            A[stk[top--]].r=i-1;
        }
        stk[++top]=i;
    }
    while(top) A[stk[top--]].r=N;
    for(int i=1;i<=N;i++)
    {
        sum1[i]+=sum1[i-1];
        sum2[i]+=sum2[i-1];
        if(SA[i]<len1) sum1[i+1]++;
        else sum2[i]++;
    }
    long long ans=0,t1,t2;
    for(int i=1;i<=N;i++)
    {
        t1=sum1[i]-sum1[A[i].l-1];
        t2=sum2[A[i].r]-sum2[i-1];
        ans+=ht[i]*t1*t2;
    }
    memset(sum1,0,sizeof(sum1));
    memset(sum2,0,sizeof(sum2));
    for(int i=1;i<=N;i++)
    {
        sum1[i]+=sum1[i-1];
        sum2[i]+=sum2[i-1];
        if(SA[i]>len1) sum1[i+1]++;
        else sum2[i]++;
    }
    for(int i=1;i<=N;i++)
    {
        t1=sum1[i]-sum1[A[i].l-1];
        t2=sum2[A[i].r]-sum2[i-1];
        ans+=ht[i]*t1*t2;
    }
    printf("%lld",ans);
    return 0;
}