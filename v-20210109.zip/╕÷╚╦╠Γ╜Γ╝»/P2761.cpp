#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=27;
queue <int> q;
int F[(1<<20)+7];
bool book[(1<<20)+7];
char s[27];
int t[107];
int N,M,all;
int tar[107],forbid[107],fix[107],bug[107];
int main()
{
	scanf("%d%d",&N,&M);all=1<<N;
	for(int i=1;i<=M;i++)
	{
		scanf("%d",&t[i]);
		scanf("%s",s);
		for(int j=0;j<N;j++)
		{
			if(s[j]=='+') tar[i]|=(1<<j);
			if(s[j]=='-') forbid[i]|=(1<<j);
		}
		scanf("%s",s);
		for(int j=0;j<N;j++)
		{
			if(s[j]=='-') fix[i]|=(1<<j);
			if(s[j]=='+') bug[i]|=(1<<j);
		}
		bug[i]^=(all-1);
	}
	memset(F,0x7f,sizeof(F));
	F[0]=0;
	q.push(0);book[0]=true;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		book[u]=false;
		for(int i=1;i<=M;i++)
		{
			if((u&tar[i])||(u&forbid[i])!=forbid[i]) continue;
			v=(u|fix[i])&bug[i];
			if(F[u]+t[i]<F[v])
			{
				F[v]=F[u]+t[i];
				if(!book[v])
				{
					q.push(v);
					book[v]=true;
				}
			}
		}
	}
	if(F[all-1]==0x7f7f7f7f) printf("0");
	else printf("%d",F[all-1]);
	return 0;
}
