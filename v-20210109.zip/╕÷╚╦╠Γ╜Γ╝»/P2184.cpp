#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
int N,M;
struct BIT{
	int C[maxn];
	void Update(int x,int k)
	{
		while(x<=N) C[x]+=k,x+=x&(-x);
		return ;
	}
	int QwQ(int x)
	{
		int re=0;
		while(x) re+=C[x],x-=x&(-x);
		return re;
	}
};
BIT lt,rt;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();M=R();
	int op,l,r;
	for(int i=1;i<=M;i++)
	{
		op=R();l=R();r=R();
		if(op==1)
		{
			lt.Update(l,1);
			rt.Update(r,1);
		}
		else printf("%d\n",lt.QwQ(r)-rt.QwQ(l-1));
	}
	return 0;
}
