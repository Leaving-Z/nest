#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1000007;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
int N,K;
struct node{
    int c,dis;
}A[maxn];
bool operator < (const node &x,const node &y)
{
    return x.dis<y.dis;
}
int q[maxn],head=1,tail;
int mk[67];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();K=R();
    int x;
    int cnt=0;
    for(int i=1;i<=K;i++)
    {
        scanf("%d",&x);
        for(int j=1;j<=x;j++)
            ++cnt,scanf("%d",&A[cnt].dis),A[cnt].c=i;
    }
    sort(A+1,A+1+cnt);
    int cur=0,ans=(1ll<<31)-1;
    for(int i=1;i<=N;i++)
    {
        cur+=!(mk[A[i].c]++);q[++tail]=i;
        while(head<=tail&&mk[A[q[head]].c]>1) --mk[A[q[head++]].c];
        if(cur==K) ans=min(ans,A[i].dis-A[q[head]].dis);
    }
    printf("%d",ans);
    return 0;
}