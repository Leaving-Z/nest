#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL X(LL a, LL b, LL P)
{
    LL L=a*(b>>25LL)%P*(1LL<<25)%P;
    LL R=a*(b&((1LL<<25)-1))%P;
    return (L+R)%P;
}
LL fast_pow(LL b,LL k,LL m)
{
	LL s=1;
	while(k)
	{
		if(k&1) s=X(s,b,m);
		b=X(b,b,m);
		k>>=1;
	}
	return s;
}
LL A=10,B,C;
struct Hash_T{
	static const LL MOD=(1<<20)-1;
	LL Hash[MOD+7],V[MOD+7];
	Hash_T() {memset(Hash,-1,sizeof(Hash));}
	inline void insert(LL val,int mi)
	{
		LL h=val%MOD;
		while(Hash[h]!=-1&&Hash[h]!=val) h++;
		Hash[h]=val;V[h]=mi;
		return ;
	}
	inline LL find(LL val)
	{
		LL h=val%MOD;
		while(Hash[h]!=-1&&Hash[h]!=val) h++;
		return Hash[h]==val?V[h]:-1;
	}
}H;
LL BSGS()
{
	LL D=B%C,sqrtm=ceil(sqrt(C));
	for(register int i=0;i<sqrtm;i++)
	{
		H.insert(D,i);
		D=X(D,A,C);
	}
	LL t=fast_pow(A,sqrtm,C),ans;
	LL ti=t;
	for(register int i=1;i<=sqrtm;i++)
	{
		if((ans=H.find(ti))!=-1)
			return i*sqrtm-ans;
		ti=X(ti,t,C);
	}
	return -1;
}
int main()
{
	scanf("%lld%lld",&B,&C);
	B=B*9+1;
	LL re=BSGS();
	printf("%lld",re);
	return 0;
}
