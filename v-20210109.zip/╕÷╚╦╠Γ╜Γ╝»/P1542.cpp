#include<cstdio>
#include<algorithm>
using namespace std;
typedef long double db;
const int maxn=200007;
int x[maxn],y[maxn],z[maxn];
int N;
inline int Read()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
inline bool check(db v)
{
	db t=0;
	for(register int i=1;i<=N;i++)
	{
		t+=z[i]/v;
		if(t<x[i]) t=x[i];
		if(t>y[i]) return false;
	}
	return true;
}
db L,R,mid,ans;
int main()
{
	N=Read();
	for(register int i=1;i<=N;i++)
		x[i]=Read(),y[i]=Read(),z[i]=Read(),R=max((long double)z[i],R);
	ans=R;
	while(R-L>=0.001)
	{
		mid=(L+R)/2;
		if(check(mid)) R=mid-0.001,ans=mid;
		else L=mid+0.001;
	}
	printf("%.2Lf",ans);
	return 0;
}
