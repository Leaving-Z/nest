#include<bits/stdc++.h>
using namespace std;
const int maxn=57;
vector <int> m[maxn];
int sleep[maxn],belong[maxn];
bool book[maxn],stay[maxn],sch[maxn];
int N,T,sum,stc,vis;
inline void Init()
{
	memset(sleep,0,sizeof(sleep));
	memset(belong,0,sizeof(belong));
	memset(stay,0,sizeof(stay));
	memset(sch,0,sizeof(sch));
	for(int i=1;i<maxn;i++)
		m[i].clear();
	sum=0;stc=0;vis=0;
	return ;
}
inline bool dfs(int u)
{
	int v;
	for(int i=0;i<m[u].size();i++)
	{
		v=m[u][i];
		if(!book[v])
		{
			book[v]=true;
			if(!belong[v]||dfs(belong[v]))
			{
				sleep[u]=v;belong[v]=u;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		Init();
		scanf("%d",&N);
		int sc;
		for(int i=1;i<=N;i++)
		{
			scanf("%d",&sc);
			if(sc) sch[i]=true;
			else vis++;
		}
		for(int i=1;i<=N;i++)
		{
			scanf("%d",&stay[i]);
			if(!stay[i]&&sch[i]) m[i].push_back(i),stc++;
		}
		for(int i=1;i<=N;i++)
			for(int j=1;j<=N;j++)
			{
				scanf("%d",&sc);
				if(sc)
				{
					if(sch[j]&&sch[i]&&!stay[i]
					||!sch[i]&&sch[j]) m[i].push_back(j);
					if(sch[i]&&sch[j]&&!stay[j]
					||!sch[j]&&sch[i]) m[j].push_back(i);
				}
			}
		for(int i=1;i<=N;i++)
		{
			memset(book,0,sizeof(book));
			if(dfs(i)) sum++;
		}
		if(sum==stc+vis) printf("^_^\n");
		else printf("T_T\n");
	}
	return 0;
}
