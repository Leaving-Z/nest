#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=50007;
typedef long long LL;
int N,n;
struct BIT{
	LL C[maxn];
	void Update(int x,int k)
	{
		while(x<=n) C[x]+=k,x+=x&(-x);
		return ; 
	}
	LL Query(int x)
	{
		LL re=0;
		if(!x) return 0;
		while(x) re+=C[x],x-=x&(-x);
		return re;
	}
};
BIT C1,C2,C3,C4;
struct node{
	int x,y;
}A[maxn];
bool operator < (const node &x,const node &y)
{
	return x.x<y.x;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d",&A[i].y,&A[i].x);
		n=max(n,A[i].y);
	}	
	sort(A+1,A+1+N);
	LL ans=0;
	LL t1,t2,t3,t4;
	for(int i=1;i<=N;i++)
		C3.Update(A[i].y,A[i].x),C4.Update(A[i].y,1);
	for(int i=1;i<=N;i++)
	{
		C3.Update(A[i].y,-A[i].x);C4.Update(A[i].y,-1);
		t1=C1.Query(A[i].y);
		t2=C2.Query(A[i].y);
		t3=C3.Query(A[i].y-1);
		t4=C4.Query(A[i].y-1);
		ans+=A[i].y*(t2*A[i].x-t1+t3-A[i].x*t4);
		C1.Update(A[i].y,A[i].x);C2.Update(A[i].y,1);
	}
	printf("%lld",ans);
	return 0;
}
