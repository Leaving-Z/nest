#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
const int maxn=37;
LL f[maxn][2];
LL gcd(LL a,LL b)
{
    return b==0?a:gcd(b,a%b);
}
LL N;
int len(LL x)
{
    int res=0;
    while(x)
    {
        ++res;
        x/=10;
    }
    return res;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld",&N);
    f[1][1]=f[1][0]=1;
    LL g;
    for(int i=2;i<=N;i++)
    {
        g=gcd(N-i+1,f[i-1][0]);
        f[i][0]=f[i-1][0]/g*(N-i+1);
        f[i][1]=(N-i+1)/g*f[i-1][1]+f[i-1][0]/g*N;
    }
    g=gcd(f[N][0],f[N][1]);
    f[N][0]/=g;f[N][1]/=g;
    if(f[N][0]==1) printf("%lld",f[N][1]);
    else
    {
        g=f[N][1]/f[N][0];
        f[N][1]%=f[N][0];
        int l1=len(g),l2=len(f[N][0]);
        for(int i=1;i<=l1;i++)
            putchar(' ');
        printf("%lld\n",f[N][1]);
        printf("%lld",g);
        for(int i=1;i<=l2;i++)
            putchar('-');
        puts("");
        for(int i=1;i<=l1;i++)
            putchar(' ');
        printf("%lld",f[N][0]);
    }
    return 0;
}