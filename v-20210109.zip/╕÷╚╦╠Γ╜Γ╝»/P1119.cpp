#include<cstdio>
#include<algorithm>
using namespace std;
const int inf=1e8;
int m[205][205];
int t[205];
int N,M,Q;
void Floyd(int k)
{
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
		if(m[i][k]+m[k][j]<m[i][j])
			m[i][j]=m[i][k]+m[k][j];
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=0;i<N;i++)
		scanf("%d",&t[i]);
	int x,y,T;
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			m[i][j]=inf;
	for(int i=0;i<N;i++)
		m[i][i]=0;
	for(int i=0;i<M;i++)
	{
		scanf("%d%d%d",&x,&y,&T);
		m[x][y]=m[y][x]=T;
	}
	scanf("%d",&Q);
	int cur=0;
	for(int i=0;i<Q;i++)
	{
		scanf("%d%d%d",&x,&y,&T);
		while(t[cur]<=T&&cur<N)
		{
			Floyd(cur);
			cur++;
		}
		if(m[x][y]==inf||t[x]>T||t[y]>T)
			printf("-1\n");
		else printf("%d\n",m[x][y]);
	}
	return 0;
} 
