#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cstdlib>
using namespace std;
const int maxn=50007;
int N,M,root,all;
struct Treap{
	int l,r,v,pri,s;
}TREE[maxn];
#define val(i) TREE[i].v
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define p(i) TREE[i].pri
#define sz(i) TREE[i].s
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+1;
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+1;
	x=y;
	return ;
}
inline void Insert(int &i,const int &v)
{
	if(!i)
	{
		i=++all;val(i)=v;
		L(i)=R(i)=0;p(i)=rand();
		sz(i)=1;
		return ;
	}
	++sz(i);
	if(v<val(i))
	{
		Insert(L(i),v);
		if(p(L(i))<p(i)) Zig(i);
	}
	else
	{
		Insert(R(i),v);
		if(p(R(i))<p(i)) Zag(i);
	}
	return ;
}
inline void Del(int &i,const int &v)
{
	if(val(i)==v)
	{
		if(!L(i)||!R(i)) i=L(i)+R(i);
		else if(p(L(i))<p(R(i))) Zig(i),Del(i,v);
		else Zag(i),Del(i,v);
		return ;		
	}
	--sz(i);
	if(v<val(i)) Del(L(i),v);
	else Del(R(i),v);
	return ;
}
inline int Forw(const int &v)
{
	int re,i=root;
	while(i)
	{
		if(v>val(i)) re=val(i),i=R(i);
		else i=L(i);
	}
	return re;
}
inline int Backw(const int &v)
{
	int re,i=root;
	while(i)
	{
		if(v<val(i)) re=val(i),i=L(i);
		else i=R(i);
	}
	return re;
}
bool book[maxn];
int stk[maxn],top;
char s[7];
int main()
{
	scanf("%d%d",&N,&M);
	Insert(root,0);
	Insert(root,N+1);
	int x;
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s);
		if(s[0]=='D')
		{
			scanf("%d",&x);
			Insert(root,x);
			book[x]=true;
			stk[++top]=x;
		}
		else if(s[0]=='R')
		{
			Del(root,stk[top]);
			book[stk[top--]]=false;
		}
		else
		{
			scanf("%d",&x);
			if(book[x]) puts("0");
			else
			printf("%d\n",Backw(x)-Forw(x)-1);
		}
	}
	return 0;
}
