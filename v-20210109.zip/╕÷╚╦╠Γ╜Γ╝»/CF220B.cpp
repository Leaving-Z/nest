#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
const int maxn=1000007;
#define getchar() (SS==TT&&(TT=(SS=BB)+fread(BB,1,1<<20,stdin),TT==SS)?EOF:*SS++)
char BB[1<<20],*SS=BB,*TT=BB;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
vector <int> m[maxn];
int C[maxn];
int N,Q;
void update(int x,int k) {while(x<=N) C[x]+=k,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re+=C[x],x&=(x-1);return re;}
int A[maxn],cnt[maxn];
struct range{
    int l,r,id;
}q[maxn];
bool com(const range &x,const range &y)
{
    return x.r<y.r;
}
int ans[maxn];
void print(int x)
{
    if(x>=10) print(x/10);
    putchar(x%10+'0');
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();Q=R();
    for(int i=1;i<=N;i++)
        A[i]=R();
    for(int i=1;i<=Q;i++)
        q[i].l=R(),q[i].r=R(),q[i].id=i;
    sort(q+1,q+1+Q,com);
    int cur=1;
    int l,r;
    for(int i=1;i<=N;i++)
    {
if(A[i]<=N)
        m[A[i]].push_back(i);
        if(A[i]<=N&&m[A[i]].size()>=A[i])
        {
            if(m[A[i]].size()==A[i])
            {
                l=1;
                r=m[A[i]][0];
                update(l,1);
                update(r+1,-1);
            }
            else
            {
                if(!cnt[A[i]])
                {
                    l=1;r=m[A[i]][0]+1;
                    update(l,-1);
                    update(r,1);
                }
                else
                {
                    l=m[A[i]][cnt[A[i]]-1]+1;
                    r=m[A[i]][cnt[A[i]]]+1;
                    update(l,-1);
                    update(r,1);
                }
                ++cnt[A[i]];
                l=r;
                r=m[A[i]][cnt[A[i]]]+1;
                update(l,1);
                update(r,-1);
            }
        }
        while(q[cur].r==i&&cur<=Q)
        {
            ans[q[cur].id]=query(q[cur].l);
            ++cur;
        }
    }
    for(int i=1;i<=Q;i++)
        print(ans[i]),puts("");
    return 0;
}