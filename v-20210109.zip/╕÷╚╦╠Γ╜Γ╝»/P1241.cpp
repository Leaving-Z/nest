#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=107;
int N;
char s[maxn];
bool book[maxn];//0->[ 1->] 2->( 3->) 
int main()
{
	scanf("%s",s+1);
	N=strlen(s+1);
	for(int i=1;i<=N;i++)
	{
		if(s[i]==')')
		{
			for(int j=i-1;j;j--)
				if(s[j]=='('&&!book[j]) {book[i]=book[j]=true;break;}
				else if(s[j]=='['&&!book[j]) break;
		}
		else if(s[i]==']')
		{
			for(int j=i-1;j;j--)
				if(s[j]=='['&&!book[j]) {book[i]=book[j]=true;break;}
				else if(s[j]=='('&&!book[j]) break;
		}
	}
	for(int i=1;i<=N;i++)
	{
		if(book[i]) putchar(s[i]);
		else
		{
			if(s[i]=='['||s[i]==']') printf("[]");
			else printf("()");
		}
	}
	return 0;
}
