#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1000007;
const int mod=1e9+7;
char s[maxn];
int kmp[maxn];
int T,N;
int fa[20][maxn];
int st(int p)
{
	int re=0;
	int p1=p,p2=p,lim1=0,lim2=p/2;
	for(int k=19;k>=0;k--)
	{
		if(fa[k][p1]>lim1) p1=fa[k][p1],re+=(1<<k);
		if(fa[k][p2]>lim2) p2=fa[k][p2],re-=(1<<k);
	}
	return re;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d",&T);
	while(T--)
	{
		scanf("%s",s+1);
		N=strlen(s+1);
		memset(fa,0,sizeof(fa));
		memset(kmp,0,sizeof(kmp));
		for(int i=2,j=0;i<=N;i++)
		{
			while(j&&s[i]!=s[j+1]) j=kmp[j];
			if(s[i]==s[j+1]) ++j;
			kmp[i]=j;
			fa[0][i]=kmp[i];
		}
		for(int k=1;k<=19;k++)
			for(int i=1;i<=N;i++)
				fa[k][i]=fa[k-1][fa[k-1][i]];
		long long ans=1;
		for(int i=1;i<=N;i++)
			ans=ans*(st(i)+1)%mod;
		printf("%lld\n",ans);
	}
	return 0;
}