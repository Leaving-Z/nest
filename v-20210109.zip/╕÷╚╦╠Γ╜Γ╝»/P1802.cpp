#include<cstdio>
#include<algorithm>
using namespace std;
inline long long max_(const long long &x,const long long &y) {return x>y?x:y;}
long long F[1007];
int u[1007],win[1007],lose[1007];
int N,x;
int main()
{
	scanf("%d%d",&N,&x);
	for(register int i=1;i<=N;i++)
		scanf("%d%d%d",&lose[i],&win[i],&u[i]);
	for(int i=1;i<=N;i++)
		for(int j=x;j>=0;j--)
			if(j>=u[i])
			F[j]=max(F[j]+lose[i],F[j-u[i]]+win[i]);
			else F[j]=F[j]+lose[i];
	printf("%lld",F[x]*5);
	return 0;
}
