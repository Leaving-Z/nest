#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std; 
queue <int> q;
const int maxn=200007;
const int maxm=1000007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
struct E{
	int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int dfn[maxn],low[maxn],T;
int S[maxn],C;
int stk[maxn],top;
bool ins[maxn];
void dfs(int u)
{
	ins[u]=true;
	stk[++top]=u;
	dfn[u]=low[u]=++T;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int dis[maxn];
bool book[maxn];
void SPFA(int s)
{
	memset(dis,0x7f,sizeof(dis));
	dis[s]=0;book[s]=true;
	q.push(s);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
	}
	for(int i=1;i<=N;i++)
	if(!dfn[i]) dfs(i);
	int t=ES;
	memset(first,0,sizeof(first));
	memset(nt,0,sizeof(nt));ES=0;
	for(int i=1;i<=t;i++)
		if(S[e[i].u]!=S[e[i].v])
			addE(S[e[i].u],S[e[i].v],e[i].w);
	SPFA(S[1]);
	printf("%d",dis[S[N]]);
	return 0;
}
