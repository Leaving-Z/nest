#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<iostream>
using namespace std;
const int maxn=100107;
const int all=(1<<30)-1;
int N,M,Q,node=1;
struct seg_tree{
    int ap0,ap1,q;
}tree[maxn<<2];
#define x0(i) tree[i].ap0
#define x1(i) tree[i].ap1
#define q(i) tree[i].q
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.ap0=x.ap0|y.ap0;
    t.ap1=x.ap1|y.ap1;
    t.q=x.q&y.q;
    return t;
}
void update(int x,seg_tree k)
{
    x+=node;
    tree[x]=k;
    x>>=1;
    while(x) tree[x]=tree[x<<1]+tree[x<<1|1],x>>=1;
    return ;
}
seg_tree query(int l,int r)
{
    seg_tree re;
    re.ap0=re.ap1=0;re.q=all;
    for(l=l+node-1,r=r+node+1;l^r^1;l>>=1,r>>=1)
    {
        if(~l&1) re=re+tree[l^1];
        if(r&1) re=re+tree[r^1];
    }
    return re;
}
int solve(int l,int r)
{
    seg_tree re=query(l,r);
    if(re.ap0&re.ap1) return 0;
    int res=1;
    for(int i=1;i<=M;i++)
    if(re.q&(1<<i-1)) res<<=1;
    return res;
}
seg_tree tobit(char *s)
{
    seg_tree re;re.ap0=re.ap1=re.q=0;
    for(int i=1;i<=M;i++)
    {
        if(s[i]=='0') re.ap0|=(1<<i-1);
        else if(s[i]=='1') re.ap1|=(1<<i-1);
        else re.q|=(1<<i-1);
    }
    return re;
}
char m[37];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    cin.tie(0);
    cin>>M>>N>>Q;
    while(node<=N) node<<=1;
    for(int i=1;i<=N;i++)
    {
        cin>>m+1;
        update(i,tobit(m));
    }
    int op,l,r,ans=0;
    while(Q--)
    {
        cin>>op;
        if(op==1)
        {
            cin>>l;
            cin>>m+1;
            update(l,tobit(m));
        }
        else
        {
            cin>>l>>r;
            ans^=solve(l,r);
        }
    }
    printf("%d",ans);
    return 0;
}