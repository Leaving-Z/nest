#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
const int maxn=1000007;
int head=1,tail;
int Range[maxn][2],N;
struct node{
	int i,h;
}q[maxn];
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();
	for(int i=1;i<=N;i++)
		Range[i][0]=R(),Range[i][1]=R();
	int ans=1;
	node t;
	for(int i=1;i<=N;i++)
	{
		while(head<=tail&&Range[i][1]<q[head].h) ++head;
		if(head<=tail) ans=max(ans,i-q[head].i+1);
		t.h=Range[i][0];t.i=i;
		while(head<=tail&&t.h>=q[tail].h) t.i=min(t.i,q[tail--].i);
		q[++tail]=t;
	}
	printf("%d",ans);
	return 0;
}
