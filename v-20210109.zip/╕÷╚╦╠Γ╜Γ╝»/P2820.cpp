#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct E{
	int u,v,w;
}e[10005];
int s[105];
int f(int x)
{
	return s[x]==x?x:s[x]=f(s[x]);
}
void _merge(int x,int y)
{
	int f1=f(x),f2=f(y);
	s[f2]=f1;
	return ;
}
bool operator < (const E &a,const E &b)
{
	return a.w<b.w;
}
int N,k;
int main()
{
	scanf("%d%d",&N,&k);
	for(int i=1;i<=N;i++)
		s[i]=i;
	int u,v,w,sum=0;
	for(int i=1;i<=k;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		sum+=w;
		e[i]=(E){u,v,w};
		e[i+k]=(E){v,u,w};
	}
	int MST=0;
	sort(e+1,e+2*k+1);
	for(int i=1;i<=2*k;i++)
	{
		if(f(e[i].u)==f(e[i].v)) continue;
		MST+=e[i].w;
		_merge(e[i].u,e[i].v);
	}
	printf("%d",sum-MST);
	return 0;
}
