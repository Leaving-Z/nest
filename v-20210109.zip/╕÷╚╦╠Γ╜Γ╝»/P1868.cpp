#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=3000007;
int F[maxn];
int lim;
int N,book[maxn][2];
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();
	int l,r;
	for(int i=1;i<=N;i++)
	{
		l=R();r=R();
		book[l][0]=1;
		book[l][1]=r-l+1;
		lim=max(r,lim);
	}
	lim++;
	for(int i=1;i<=lim;i++)
	{
		F[i]=max(F[i],F[i-1]);
		if(book[i][0]) F[i+book[i][1]]=max(F[i]+book[i][1],F[i+book[i][1]]);
	}
	printf("%d",F[lim]);
	return 0;
}
