#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<map>
#include<set>
using namespace std;
const int maxn=1000007;
struct node{
    int lt,rt,mx,mn,g,mxp;
}tree[maxn<<2];
int N,Q;
int gcd(int a,int b) {return !b?a:gcd(b,a%b);}
int abs_(const int &x) {return x>=0?x:-x;}
node operator + (const node &x,const node &y)
{
    node t;
    t.mx=max(x.mx,y.mx);
    t.mn=min(x.mn,y.mn);
    t.g=gcd(gcd(x.g,y.g),abs_(x.rt-y.lt));
    t.lt=x.lt;
    t.rt=y.rt;
    t.mxp=max(x.mxp,y.mxp);
    return t;
}
int M=1;
int A[maxn],pre[maxn];
#define ls (i<<1)
#define rs (i<<1|1)
void build()
{
    while(M<=N) M<<=1;
    for(int i=1;i<=N;i++)
        tree[i+M]=(node){A[i],A[i],A[i],A[i],0,pre[i]};
    for(int i=M-1;i;i--)
        tree[i]=tree[ls]+tree[rs];
    return ;
}
void update(int i,node k)
{
    i+=M;
    tree[i]=k;
    while(i>>=1) tree[i]=tree[ls]+tree[rs];
    return ;
}
node query(int l,int r)
{
    node lre,rre;
    bool f1=false,f2=false;
    for(l=l+M-1,r=r+M+1;l^r^1;l>>=1,r>>=1)
    {
        if(~l&1)
        {
            if(f1) lre=lre+tree[l^1];
            else lre=tree[l^1],f1=true;
        }
        if(r&1)
        {
            if(f2) rre=tree[r^1]+rre;
            else rre=tree[r^1],f2=true;
        }
    }
    if(f1&&!f2) return lre;
    if(f2&&!f1) return rre;
    return lre+rre;
}
map <int,int> mp;
set <int> s[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    int tmp,ix=0;
    set <int>::iterator it;
    for(int i=1;i<=N;i++)
    {
        scanf("%d",&A[i]);
        tmp=mp[A[i]];
        if(!tmp) mp[A[i]]=++ix,tmp=ix;
        if(s[tmp].size())
        {
            it=s[tmp].end();
            --it;
            pre[i]=*it;
        }
        s[tmp].insert(i);
    }
    int op,l,r,k;
    node t;
    build();
    while(Q--)
    {
        scanf("%d",&op);
        if(op==1)
        {
            scanf("%d%d",&l,&k);
            //nxt of insert position
            tmp=mp[A[l]];
            it=s[tmp].lower_bound(l);
            s[tmp].erase(it);
            it=s[tmp].lower_bound(l);
            if(it!=s[tmp].end())
            {
                r=*it;
                t=tree[r+M];
                if(it==s[tmp].begin()) t.mxp=0;
                else --it,t.mxp=*it;
                update(r,t);
            }
            //the insert position
            tmp=mp[k];
            if(!tmp) mp[k]=++ix,tmp=ix;
            s[tmp].insert(l);
            t=tree[l+M];
            A[l]=t.lt=t.mn=t.mx=t.rt=k;
            it=s[tmp].lower_bound(l);
            if(it==s[tmp].begin()) t.mxp=0;
            else --it,t.mxp=*it;
            update(l,t);
            //the nxt of new insert value
            it=s[tmp].upper_bound(l);
            if(it!=s[tmp].end())
            {
                r=*it;t=tree[r+M];
                t.mxp=l;
                update(r,t);
            }
        }
        else
        {
            scanf("%d%d",&l,&r);k=1;
            t=query(l,r);
            if(l==r) puts("damushen");
            else if(t.g!=k) puts("yuanxing");
            else if(t.mx-t.mn!=(r-l)*1ll*k) puts("yuanxing");
            else if(t.mxp>=l) puts("yuanxing");
            else puts("damushen");
        }
    }
    return 0;
}