#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
typedef long long LL;
LL N;
LL phi(LL x)
{
    LL re=x;
    for(LL i=2;i*i<=x;i++)
    {
        if(x%i==0) re=re*(i-1)/i;
        while(x%i==0) x/=i;
    }
    if(x!=1) re=re*(x-1)/x;
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld",&N);
    LL ans=0;
    for(LL i=1;i*i<=N;i++)
    {
        if(N%i) continue;
        ans+=i*phi(N/i);
        if(i*i!=N) ans+=(N/i)*phi(i);
    }
    printf("%lld",ans);
    return 0;
}