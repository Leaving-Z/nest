#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
#include<cctype>
using namespace std;
const int maxb=60;
const int maxn=500007;
inline long long R()
{
	char c;
	long long re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
		re=re*10+c-48;
	return re; 
}
int ch[maxn*maxb][2],all,root[maxn],book[maxn*maxb],ed[maxn*maxb];
void insert(int a,int b,long long val,int cnt,int p)
{
	if(cnt<0) {ed[a]=p;return ;}
	int t;
	if(val&(1ll<<cnt)) t=1;
	else t=0;
	ch[a][t^1]=ch[b][t^1];
	ch[a][t]=++all;
	book[all]=book[ch[b][t]]+1;
	insert(ch[a][t],ch[b][t],val,cnt-1,p);
	return ;
}
int query(int a,int b,long long val,int cnt)
{
	if(cnt<0) return ed[b];
	int t;
	if(val&(1ll<<cnt)) t=0;
	else t=1;
	if(book[ch[b][t]]-book[ch[a][t]]>0)
		return query(ch[a][t],ch[b][t],val,cnt-1);
	return query(ch[a][t^1],ch[b][t^1],val,cnt-1);
}
int query(int l,int r,long long v)
{
	if(!l) return query(0,root[r],v,31);
	return query(root[l-1],root[r],v,31);
}
long long sum[maxn];
int N,K;
struct node{
	long long val;
	int l,r,mid,p;
};
bool operator < (const node &x,const node &y)
{
	return x.val<y.val;
}
priority_queue <node> q;
node ship(int l,int r,int x)
{
	node re;
	re.p=x;
	re.l=l;re.r=r;
	re.mid=query(l,r,sum[x]);
	re.val=sum[x]^sum[re.mid];
	return re;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	N=R();K=R();
	long long x;
	for(int i=1;i<=N;i++)
		sum[i]=sum[i-1]^(x=R());
	root[0]=++all;
	insert(root[0],0,0,31,0);
	for(int i=1;i<=N;i++)
	{
		root[i]=++all;
		insert(root[i],root[i-1],sum[i],31,i);
	}
	node t;
	for(int i=1;i<=N;i++)
	{
		t=ship(0,i-1,i);
		q.push(t);
	}
	long long ans=0;
	while(K--)
	{
		t=q.top();q.pop();
		ans+=t.val;
		if(t.l<t.mid) q.push(ship(t.l,t.mid-1,t.p));
		if(t.r>t.mid) q.push(ship(t.mid+1,t.r,t.p));
	}
	printf("%lld",ans);
	return 0;
}