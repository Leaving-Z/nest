#include<bits/stdc++.h>
using namespace std;
const int maxn=2007;
int N,M,ans;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ; 
}
int match[maxn];
int ANS[maxn];
bool book[maxn];
inline bool dfs(int u)
{
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!book[v])
		{
			book[v]=true;
			if(!match[v]||dfs(match[v]))
			{
				match[v]=u;match[u]=v;
				return true;
			}
		}
	}
	return false;
}
int main()
{
	scanf("%d%d",&N,&M);
	int u,v;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&u,&v);
		addE(i+N,u+1);
		addE(i+N,v+1);
	}
	for(int i=N+1;i<=N+M;i++)
	{
		memset(book,0,sizeof(book));
		if(dfs(i)) ++ans;
		else break;
	}
	printf("%d\n",ans);
	for(int i=N+1;i<=N+ans;i++)
		printf("%d\n",match[i]-1);
	return 0;
}
