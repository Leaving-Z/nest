#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=400007;
int N;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int fa[maxn],sz[maxn];
int rt;
void dfs1(int u)
{
	int v;
	sz[u]=1;
	bool f=true;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		fa[v]=u;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>N/2) f=false;
	}
	if(N-sz[u]>N/2) f=false;
	if(f) rt=u;
	return ;
}
int Max[maxn][2];
void dfs2(int u)
{
	int v;
	sz[u]=1;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		fa[v]=u;
		dfs2(v);
		sz[u]+=sz[v];
		if(sz[v]>N/2) continue;
		if(sz[v]>Max[u][0]) Max[u][1]=Max[u][0],Max[u][0]=sz[v];
		else if(sz[v]>Max[u][1]) Max[u][1]=sz[v];
	}
	return ;
}
int cut[maxn];
bool ans[maxn];
void dfs3(int u,int maxx)
{
	int v;
	cut[u]=maxx;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		if(N-sz[u]<=N/2) maxx=max(maxx,N-sz[u]);
		if(Max[u][0]==sz[v]) dfs3(v,max(maxx,Max[u][1]));
		else dfs3(v,max(maxx,Max[u][0]));
	}
	if(N-sz[u]-cut[u]<=N/2||u==rt) ans[u]=true;
	return ;
}
int main()
{
	N=R();
	int u,v;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);
		addE(v,u);
	}
	dfs1(1);
	fa[rt]=0;
	dfs2(rt);
	dfs3(rt,0);
	for(int i=1;i<=N;i++)
	if(ans[i]) putchar('1'),putchar(32);
	else putchar('0'),putchar(32);
	return 0;
}
