#include<cstdio>
#include<algorithm>
using namespace std;
const int J=20;
inline int R()
{
	char c;
	int f=1,re=0;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v;
}e[1000007];
int first[500007],nt[1000007];
int N,M;
int depth[500007],f[500007][21];
void DFS(int u)
{
	for(int i=0;i<J;i++)
		f[u][i+1]=f[f[u][i]][i];
	for(int i=first[u];i;i=nt[i])
	{
		if(e[i].v!=f[u][0])
		{
			f[e[i].v][0]=u;
			depth[e[i].v]=depth[u]+1;
			DFS(e[i].v);
		}
	}
	return ;
}
int LCA(int x,int y)
{
	if(depth[x]<depth[y]) swap(x,y);
	int k=depth[x]-depth[y];
	for(int i=0;(1<<i)<=k;i++)
	if((1<<i)&k) x=f[x][i];
	if(x==y) return x;
	for(int i=J;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])
		{
			x=f[x][i];
			y=f[y][i];
		}
	}
	return f[x][0];
}
int main()
{
	N=R();M=R();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=R();v=R();
		e[i]=(E){u,v};
		nt[i]=first[u];
		first[u]=i;
		e[i+N]=(E){v,u};
		nt[i+N]=first[v];
		first[v]=i+N;
	}
	DFS(1);
	int lca1,lca2,lca3,lca;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		lca1=LCA(u,v);
		lca2=LCA(v,w);
		lca3=LCA(w,u);
		if(lca1==lca2)
		lca=lca3;
		else if(lca1==lca3)
		lca=lca2;
		else if(lca2==lca3)
		lca=lca1;
		printf("%d %d\n",lca,depth[u]+depth[v]+depth[w]-depth[lca1]-depth[lca2]-depth[lca3]);
	}
	return 0;
}
