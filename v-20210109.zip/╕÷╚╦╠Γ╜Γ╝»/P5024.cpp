#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int maxn=100007;
const int lim=17;
const LL inf=1e10;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
LL F[maxn][lim+1][2][2],dp[maxn][2],cost[maxn];
int fa[maxn][lim+1],depth[maxn];
inline void dfs(int u)
{
	int v;
	dp[u][1]=cost[u];
	for(int i=1;i<=lim;i++)
		fa[u][i]=fa[fa[u][i-1]][i-1];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u][0])
		{
			fa[v][0]=u;
			depth[v]=depth[u]+1;
			dfs(v);
			dp[u][0]+=dp[v][1];
			dp[u][1]+=min(dp[v][0],dp[v][1]);
		}
	}
	return ;
}
inline LL cal(int u,int x,int v,int y)
{
	LL u0,u1,v0,v1,l0,l1,t0,t1,l;
	if(depth[u]<depth[v]) swap(u,v),swap(x,y);
	
	if(x) {u0=inf;u1=dp[u][1];}
	else {u1=inf;u0=dp[u][0];}
	if(y) {v0=inf;v1=dp[v][1];}
	else {v1=inf;v0=dp[v][0];}
	
	for(int i=lim;i>=0;i--)
	{
		if(depth[fa[u][i]]>=depth[v])
		{
			t0=u0;t1=u1;
			u0=min(t0+F[u][i][0][0],t1+F[u][i][1][0]);
			u1=min(t0+F[u][i][0][1],t1+F[u][i][1][1]);
			u=fa[u][i];
		}
	}
	if(u==v)
	{
		l=v;
		if(y) {l0=inf;l1=u1;}
		else {l1=inf;l0=u0;}
	}
	else
	{
		for(int i=lim;i>=0;i--)
		{
			if(fa[u][i]!=fa[v][i])
			{
				t0=u0;t1=u1;
				u0=min(t0+F[u][i][0][0],t1+F[u][i][1][0]);
				u1=min(t0+F[u][i][0][1],t1+F[u][i][1][1]);
				u=fa[u][i];
				
				t0=v0;t1=v1;
				v0=min(t0+F[v][i][0][0],t1+F[v][i][1][0]);
				v1=min(t0+F[v][i][0][1],t1+F[v][i][1][1]);
				v=fa[v][i];
			}
		}
		l=fa[u][0];
		l1=dp[l][1]-min(dp[u][0],dp[u][1])-min(dp[v][0],dp[v][1])+min(u1,u0)+min(v1,v0);
		l0=dp[l][0]-dp[u][1]-dp[v][1]+u1+v1;
	}
	for(int i=lim;i>=0;i--)
	{
		if(depth[fa[l][i]])
		{
			t0=l0;t1=l1;
			l0=min(t0+F[l][i][0][0],t1+F[l][i][1][0]);
			l1=min(t0+F[l][i][0][1],t1+F[l][i][1][1]);
			l=fa[l][i];
		}
	}
	LL ans=min(l1,l0);
	if(ans<inf) return ans;
	else return -1;
}
char qwq[7];
int main()
{
	N=R();M=R();scanf("%s",qwq);
	int u,v;
	for(register int i=1;i<=N;i++)
		cost[i]=R();
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);addE(v,u);
	}
	depth[1]=1;
	dfs(1);
	for(int u=1;u<=N;u++)
	{
		F[u][0][0][0]=inf;
		F[u][0][1][0]=dp[fa[u][0]][0]-dp[u][1];
		F[u][0][0][1]=F[u][0][1][1]=dp[fa[u][0]][1]-min(dp[u][1],dp[u][0]);
	}
	int t;
	for(int u=1;u<=N;u++)
		for(int i=1;i<=lim;i++)
		{
			t=fa[u][i-1];
			F[u][i][0][0]=min(F[u][i-1][0][0]+F[t][i-1][0][0],F[u][i-1][0][1]+F[t][i-1][1][0]);
			F[u][i][1][0]=min(F[u][i-1][1][0]+F[t][i-1][0][0],F[u][i-1][1][1]+F[t][i-1][1][0]);
			F[u][i][0][1]=min(F[u][i-1][0][0]+F[t][i-1][0][1],F[u][i-1][0][1]+F[t][i-1][1][1]);
			F[u][i][1][1]=min(F[u][i-1][1][0]+F[t][i-1][0][1],F[u][i-1][1][1]+F[t][i-1][1][1]);
		}
	int x,y;
	for(int i=1;i<=M;i++)
	{
		u=R();x=R();v=R();y=R();
		printf("%lld\n",cal(u,x,v,y));
	}
	return 0;
}
