#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int J=20;
inline int R()
{
	char c;
	int f=1,re=0;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
} 
struct E{
	int u,v,w;
}e1[100007],e[100007];
int first[10007],nt[100007];
int ES;
bool operator < (const E &a,const E &b)
{
	return a.w>b.w;
}
int N,M,Q;
int s[10007];
inline int fa(int x)
{
	return s[x]==x?x:s[x]=fa(s[x]);
}
inline void _merge(int x,int y)
{
	int f1=fa(x),f2=fa(y);
	s[f2]=f1;
	return ;
}
int f[10007][21],minE[10007][21];
int depth[10007];
bool visit[10007];
void DFS(int u)
{
	for(int i=0;i<J;i++)
	{
		f[u][i+1]=f[f[u][i]][i];
		minE[u][i+1]=min(minE[u][i],minE[f[u][i]][i]);
	}
	for(int i=first[u];i;i=nt[i])
	{
		if(e[i].v!=f[u][0])
		{
			depth[e[i].v]=depth[u]+1;
			minE[e[i].v][0]=e[i].w;
			f[e[i].v][0]=u;
			DFS(e[i].v);
		}
	}
	return ;
}
int LCA(int x,int y)
{
	if(depth[x]<depth[y]) swap(x,y);
	int k=depth[x]-depth[y];
	for(int i=0;(1<<i)<=k;i++)
	if((1<<i&k)) x=f[x][i];
	if(x==y) return x;
	for(int i=J;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])
		{
			x=f[x][i];
			y=f[y][i];
		}
	}
	return f[x][0];
}
int main()
{
	memset(minE,0x7f,sizeof(minE));
	N=R();M=R();
	for(int i=1;i<=N;i++)
	s[i]=i; 
	int u,v,w;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		e1[i]=(E){u,v,w};
	}
	sort(e1+1,e1+M+1);
	int o=0;
	for(int i=1;i<=M;i++)
	{
		if(fa(e1[i].u)==fa(e1[i].v)) continue;
		_merge(e1[i].u,e1[i].v);
		o++;
		e[++ES]=e1[i];
		nt[ES]=first[e1[i].u];
		first[e1[i].u]=ES;
		e[++ES]=(E){e1[i].v,e1[i].u,e1[i].w};
		nt[ES]=first[e1[i].v];
		first[e1[i].v]=ES;
		if(o==N-1) break;
	}
	for(int i=1;i<=N;i++)
	if(f[i][0]==0) DFS(i);
	int lca,k,ans;
	Q=R();
	for(int j=1;j<=Q;j++)
	{
		ans=2e8;
		u=R();v=R();
		lca=LCA(u,v);
		if(lca==0)
		{
			printf("-1\n");
			continue;
		}
		k=depth[u]-depth[lca];
		for(int i=0;(1<<i)<=k;i++)
		if((1<<i)&k)
		{
			ans=min(ans,minE[u][i]);
			u=f[u][i];
		}
		k=depth[v]-depth[lca];
		for(int i=0;(1<<i)<=k;i++)
		if((1<<i)&k)
		{
			ans=min(ans,minE[v][i]);
			v=f[v][i];
		}
		if(ans==2e8) printf("-1\n");
		else printf("%d\n",ans);
	}
	return 0;
}
