#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
const int maxb=30;
int A[maxn];
int trie[maxn*maxb][2],all;
int N;
long long ans;
void insert(int x)
{
    int t,p=0;
    for(int i=29;i>=0;i--)
    {
        if(x&(1<<i)) t=1;
        else t=0;
        if(!trie[p][t]) trie[p][t]=++all;
        p=trie[p][t];
    }
    return ;
}
long long dfs(int u1,int u2,int d)
{
    if(!d) return 0;
    long long t1=1e18,t2=1e18,t3=1e18,res;
    if(trie[u1][0]&&trie[u2][0]) t1=dfs(trie[u1][0],trie[u2][0],d-1);
    if(trie[u1][1]&&trie[u2][1]) t2=dfs(trie[u1][1],trie[u2][1],d-1);
    res=min(t1,t2);
    if(res>1e17&&(trie[u1][0]&&!trie[u2][0]||trie[u1][1]&&!trie[u2][1]))
    {
        t3=1<<d-1;
        if(trie[u1][0]) t3+=dfs(trie[u1][0],trie[u2][1],d-1);
        else if(trie[u2][0]) t3+=dfs(trie[u1][1],trie[u2][0],d-1);
        res=t3;
    }
    return res;
}
void solve(int u,int d)
{
    if(trie[u][0]&&trie[u][1]) ans+=dfs(trie[u][0],trie[u][1],d-1)+(1<<d-1);
    if(trie[u][0]) solve(trie[u][0],d-1);
    if(trie[u][1]) solve(trie[u][1],d-1);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]),insert(A[i]);
    solve(0,30);
    printf("%lld",ans);
    return 0;
}