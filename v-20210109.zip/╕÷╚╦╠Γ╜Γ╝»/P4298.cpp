#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<queue>
using namespace std;
const int maxn=207;
const int maxm=160007;
bool m[maxn][maxn];
struct E{
    int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
int CF[maxm];
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
    e[++ES]=(E){u,v,cf};
    CF[ES]=cf;
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
inline void add(int u,int v,int cf)
{
    addE(u,v,cf);
    addE(v,u,0);
    return ;
}
int N,M,S,T;
queue <int> q;
int dep[maxn];
bool BFS()
{
    memset(dep,0,sizeof(dep));
    dep[S]=1;
    q.push(S);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(cf(i)>0&&!dep[v])
            {
                dep[v]=dep[u]+1;
                q.push(v);
            }
        }
    }
    return dep[T]!=0;
}
int cur[maxn];
int dfs(int u,int f)
{
    if(u==T) return f;
    int v,sum=0,d;
    for(int &i=cur[u];i;i=nt[i])
    {
        v=e[i].v;
        if(dep[v]==dep[u]+1&&cf(i)>0)
        {
            d=dfs(v,min(f,cf(i)));
            if(d>0)
            {
                cf(i)-=d;
                cf(i^1)+=d;
                f-=d;sum+=d;
                if(f==0) return sum;
            }
        }
    }
    return sum;
}
int Dinic()
{
    int res=0;
    while(BFS())
    {
        memcpy(cur,first,sizeof(first));
        res+=dfs(S,0x7f7f7f7f);
    }
    return res;
}
bool vis[maxn];
void dfs(int u)
{
    if(u<=N&&!vis[u]||u>N&&vis[u]) return ;
    int v;
    if(u<=N)
    {
        vis[u]=0;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(CF[i]&&cf(i))
                dfs(v);
        }
    }
    else
    {
        vis[u]=1;
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            if(CF[i^1]&&!cf(i^1))
                dfs(v);
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d",&u,&v);
        m[u][v]=1;
    }
    for(int k=1;k<=N;k++)
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
                m[i][j]=m[i][j]|(m[i][k]&m[k][j]);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
        if(i!=j&&m[i][j]) add(i,j+N,1);
    S=2*N+1;T=S+1;
    for(int i=1;i<=N;i++)
        add(S,i,1),add(i+N,T,1),vis[i]=true;
    int ans1=N;
    ans1-=Dinic();
    printf("%d\n",ans1);
    for(int i=first[S];i;i=nt[i])
    {
        v=e[i].v;
        if(CF[i]&&cf(i)) dfs(v);
    }
    for(int i=1;i<=N;i++)
        printf("%d",(vis[i]|vis[i+N])^1);
    puts("");
    for(int k=1;k<=N;k++)
    {
        ES=1;
        memset(first,0,sizeof(first));
        for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
        if(i!=j&&m[i][j]&&i!=k) add(i,j+N,1);
        u=0;
        for(int i=1;i<=N;i++)
        if(i!=k&&!m[i][k]&&!m[k][i]) add(S,i,1),add(i+N,T,1),++u;
        v=u-Dinic();
        printf("%d",(ans1-1==v));
    }
    return 0;
}