#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
#define R (L+len-1)
const int inf=0x7f7f7f7f;
int del[30],add[30];
int cost[30];
int DP[2007][2007];
char s[2007];
int N,M;
int LEN;
int main()
{
	ios::sync_with_stdio(false);
	cin>>N>>M;
	cin>>s;
	LEN=strlen(s);
	char c;
	int x;
	for(int i=1;i<=N;i++)
	{
		cin>>c;
		cin>>x;
		add[c-96]=x;
		cin>>x;
		del[c-96]=x;
		cost[c-96]=min(add[c-96],del[c-96]);
	}
	for(int len=2;len<=LEN;len++)
		for(int L=0;L+len<=LEN;L++)
		{
			DP[L][R]=inf;
			if(s[L]==s[R])
			DP[L][R]=DP[L+1][R-1];
			else
			DP[L][R]=min(DP[L+1][R]+cost[s[L]-96],DP[L][R-1]+cost[s[R]-96]);
		}
	printf("%d",DP[0][LEN-1]);
}
