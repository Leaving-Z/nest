#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
#define R (L+len-1)
const int maxn=207;
int F[maxn<<1][maxn<<1],f[maxn<<1][maxn<<1];
int N;
int sum[maxn<<1],A[maxn<<1];
int main()
{
	scanf("%d",&N);
	memset(F,0x7f,sizeof(F));
	for(int i=1;i<=N;i++)
	{
		scanf("%d",&A[i]);
		sum[i]=sum[i-1]+A[i];
		F[i][i]=0;
	}
	for(int i=N+1;i<=2*N;i++)
	{
		A[i]=A[i-N];
		sum[i]=sum[i-1]+A[i];
		F[i][i]=0;
	}
	for(int len=2;len<=N;len++)
	{
		for(int L=1;L+len-1<=2*N;L++)
		{
			for(int k=L;k<R;k++)
			{
				F[L][R]=min(F[L][k]+F[k+1][R],F[L][R]);
				f[L][R]=max(f[L][k]+f[k+1][R],f[L][R]);
			}
			f[L][R]+=(sum[R]-sum[L-1]);
			F[L][R]+=(sum[R]-sum[L-1]);
		} 
	}
	int ans=0x7f7f7f7f,g=-1;
	for(int i=1;i<=N;i++)
	{
		ans=min(F[i][i+N-1],ans);
		g=max(f[i][i+N-1],g);
	}
	printf("%d\n%d",ans,g);
	return 0;
}
