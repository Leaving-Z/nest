#include<cstdio>
#include<cstring>
long long borad[25][25];
int main()
{
	int m,n,a,b;
	scanf("%d%d%d%d",&a,&b,&n,&m);
	borad[0][0]=1;
	borad[n][m]=-1;
	if(n>0&&m>1) borad[n-1][m-2]=-1;
	if(n>0&&m<18) borad[n-1][m+2]=-1;
	if(n<19&&m>1) borad[n+1][m-2]=-1;
	if(n<19&&m<18) borad[n+1][m+2]=-1;
	if(m>0&&n>1) borad[n-2][m-1]=-1;
	if(m>0&&n<18) borad[n+2][m-1]=-1;
	if(m<19&&n>1) borad[n-2][m+1]=-1;
	if(m<19&&n<18) borad[n+2][m+1]=-1;
	for(int i=0;i<25;i++)
		for(int j=0;j<25;j++)
		{
			if(borad[i][j]==-1) continue;
			if(i>0&&borad[i-1][j]!=-1) borad[i][j]+=borad[i-1][j];
			if(j>0&&borad[i][j-1]!=-1) borad[i][j]+=borad[i][j-1];
		}
	printf("%lld",borad[a][b]);
	return 0;
}
