#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=17;
const int maxs=(1<<16)+7;
const int inf=0x3f3f3f3f;
int F[maxs];
int p[maxs],w[maxs];
int wi[maxn],ti[maxn];
int N,all,W;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&W,&N);
    all=(1<<N)-1;
    for(int i=0;i<N;i++)
        scanf("%d%d",&ti[i],&wi[i]);
    for(int i=1;i<=all;i++)
    {
        for(int k=0;k<N;k++)
            if(i&(1<<k)) w[i]+=wi[k],p[i]=max(p[i],ti[k]);
    }
    memset(F,0x3f,sizeof(F));
    F[0]=0;
    for(int i=0;i<=all;i++)
        for(int j=i;;j=i&(j-1))
        {
            if(w[j]<=W) F[i]=min(F[i],p[j]+F[i^j]);
            if(!j) break;
        }
    printf("%d",F[all]);
    return 0;
}
