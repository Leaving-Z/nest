#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;
inline int R()
{
    int re;
    char c;
    while(!isdigit(c=getchar()));
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re;
}
const int maxn=200007;
int A[maxn];
int N,M;
int book[maxn],mk[maxn];
struct pp{
    int num,val;
};
vector <pp> m[maxn],tmp;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();M=R();
    for(int i=1;i<=N;i++)
        A[i]=R(),book[A[i]%M]++,m[A[i]%M].push_back((pp){i,A[i]});
    memcpy(mk,book,sizeof(book));
    int lim=N/M;
    long long ans=0;
    for(int i=0;i<=M-1;i++)
    {
        if(book[i]>lim)
        {
            ans+=book[i]-lim;
            if(i==M-1) book[0]+=book[i]-lim;
            else book[i+1]+=book[i]-lim;
            book[i]=lim;
        }
    } 
    for(int i=0;i<=M-1;i++)
    {
        if(book[i]>lim)
        {
            ans+=book[i]-lim;
            if(i==M-1) book[0]+=book[i]-lim;
            else book[i+1]+=book[i]-lim;
            book[i]=lim;
        }
    }
    for(int i=0;i<=M-1;i++)
    {
        if(mk[i]>book[i])
        {
            while(m[i].size()>lim&&mk[i]>lim)
            {
                tmp.push_back(m[i][m[i].size()-1]);
                m[i].pop_back();
                --mk[i];
            }
        }
        else
        {
            while(tmp.size()&&mk[i]<book[i])
            {
                m[i].push_back(tmp[tmp.size()-1]);
                tmp.pop_back();
                ++mk[i];
            }
        }
    }
    for(int i=0;i<=M-1;i++)
    {
        if(mk[i]>book[i])
        {
            while(m[i].size()>lim&&mk[i]>lim)
            {
                tmp.push_back(m[i][m[i].size()-1]);
                m[i].pop_back();
                --mk[i];
            }
        }
        else
        {
            while(tmp.size()&&mk[i]<book[i])
            {
                m[i].push_back(tmp[tmp.size()-1]);
                tmp.pop_back();
                ++mk[i];
            }
        }
    }
    for(int i=0;i<=M-1;i++)
    {
        for(int k=0;k<m[i].size();k++)
        {
            if(m[i][k].val%M<=i)
                A[m[i][k].num]=m[i][k].val+i-m[i][k].val%M;
            else
                A[m[i][k].num]=m[i][k].val+M+i-m[i][k].val%M;
        }
    }
    printf("%lld\n",ans);
    for(int i=1;i<=N;i++)
        printf("%d ",A[i]);
    return 0;
}