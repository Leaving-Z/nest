#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int m[307][307];
int N,M,V,E;
int c[2007],d[2007];
double k[2007];
double F[2007][2007][2];//1 means submit
int main()
{
	//freopen("P1850_2.in","r",stdin);
	scanf("%d%d%d%d",&N,&M,&V,&E);
	for(int i=1;i<=N;i++)
		scanf("%d",&c[i]);
	for(int i=1;i<=N;i++)
		scanf("%d",&d[i]);
	for(int i=1;i<=N;i++)
		scanf("%lf",&k[i]);
	memset(m,0x7f,sizeof(m));
	for(int i=1;i<=V;i++)
		m[i][i]=0;
	int u,v,w;
	for(int i=1;i<=E;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		if(w<m[u][v])
		m[u][v]=m[v][u]=w;
	}
	for(int k1=1;k1<=V;k1++)
		for(int i=1;i<=V;i++)
			for(int j=1;j<=V;j++)
			if(m[i][k1]<m[0][0]&&m[k1][j]<m[0][0]&&m[i][j]>m[i][k1]+m[k1][j])
			m[j][i]=m[i][j]=m[i][k1]+m[k1][j];
	double t1,t2;
	memset(F,0x7f,sizeof(F));
	F[1][0][0]=0;F[1][1][1]=0;
	for(int i=2;i<=N;i++)//��i�ڿ�
	{
		F[i][0][0]=F[i-1][0][0]+m[c[i-1]][c[i]];
		for(int k1=1;k1<=M;k1++)//��k1������
		{
			if(k1>i) break; 
		//if we don't submit this time
			t1=F[i-1][k1][0]+m[c[i-1]][c[i]];
			t2=F[i-1][k1][1]+m[c[i-1]][c[i]]*(1-k[i-1])+m[d[i-1]][c[i]]*k[i-1];
			F[i][k1][0]=min(t1,t2);
		 //What if we want to change our classroom?
		 	t1=F[i-1][k1-1][0]+m[c[i-1]][c[i]]*(1-k[i])+m[c[i-1]][d[i]]*k[i];
		 	t2=F[i-1][k1-1][1];
		 	t2+=m[c[i-1]][c[i]]*(1-k[i-1])*(1-k[i]);
		 	t2+=m[d[i-1]][c[i]]*k[i-1]*(1-k[i]);
		 	t2+=m[c[i-1]][d[i]]*(1-k[i-1])*k[i];
		 	t2+=m[d[i-1]][d[i]]*k[i-1]*k[i];
		 	F[i][k1][1]=min(t1,t2);
		}
	}
	double ans=F[N][0][0];
	for(int i=1;i<=M;i++)
		ans=min(ans,min(F[N][i][0],F[N][i][1]));
	printf("%.2lf",ans);
	return 0;
}
