#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<queue>
#include<ctime>
using namespace std;
queue <int> q;
const int maxn=100007;
const int maxm=200007;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int N,M;
int in[maxn],out[maxn];
double p[maxn],res[maxn];
void topo()
{
    p[1]=1;
    q.push(1);
    int u,v;
    while(!q.empty())
    {
        u=q.front();q.pop();
        for(int i=first[u];i;i=nt[i])
        {
            v=e[i].v;
            in[v]--;
            p[v]+=p[u]/out[u];
            res[v]+=(res[u]+p[u]*e[i].w)/out[u];
            if(!in[v]) q.push(v);
        }
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,w;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        addE(u,v,w);in[v]++;out[u]++;
    }
    topo();
    printf("%.2f",res[N]);
    return 0;
}