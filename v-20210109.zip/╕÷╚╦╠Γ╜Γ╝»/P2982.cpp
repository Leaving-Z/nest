#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=100007;
const int maxm=200007;
int C[maxn];
int N;
void update(int x,int k)
{
    while(x<=N) C[x]+=k,x+=x&(-x);
    return ;
}
int query(int x)
{
    int re=0;
    while(x) re+=C[x],x&=(x-1);
    return re;
}
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int A[maxn];
int depth[maxn],fa[maxn],son[maxn],sz[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;
    }
    return ;
}
int top[maxn],id[maxn],ix;
void dfs2(int u,int tp)
{
    int v;
    id[u]=++ix;
    top[u]=tp;
    if(son[u]) dfs2(son[u],tp);
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int query_path(int x,int y)
{
    int re=0;
    while(top[x]!=top[y])
    {
        if(depth[top[x]]<depth[top[y]]) swap(x,y);
        re+=query(id[x])-query(id[top[x]]-1);
        x=fa[top[x]];
    }
    if(depth[x]>depth[y]) swap(x,y);
    re+=query(id[y])-query(id[x]-1);
    return re;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d",&u,&v);
        addE(u,v);addE(v,u);
    }
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    dfs1(1);dfs2(1,1);
    for(int i=1;i<=N;i++)
    {
        printf("%d\n",query_path(1,A[i]));
        update(id[A[i]],1);
    }
    return 0;
}