#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
const int mod=1e9+7;
const int maxn=500007;
typedef long long LL;
LL fast_pow(LL b,int k)
{
	LL s=1;
	while(k)
	{
		if(k&1) s=s*b%mod;
		b=b*b%mod;
		k>>=1;
	}
	return s;
}
int N,M,K;
LL q;
int A[maxn];
LL f(int u)
{
	if(u>M) return 0;
	return (A[u]+q*f(u+1)%mod)%mod;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d%d%lld",&N,&M,&K,&q);
	q%=mod;
	for(int i=0;i<=M;i++)
		scanf("%d",&A[i]);
	LL tmp=(f(0)+mod)%mod;
	LL factn=1,invk=1,invn=1;
	for(int i=1;i<=N;i++)
		factn=factn*i%mod;
	for(int i=1;i<=K;i++)
		invk=invk*i%mod;
	for(int i=1;i<=N-K;i++)
		invn=invn*i%mod;
	invk=fast_pow(invk,mod-2);
	invn=fast_pow(invn,mod-2);
	printf("%lld",tmp*factn%mod*invk%mod*invn%mod);
	return 0;
}
