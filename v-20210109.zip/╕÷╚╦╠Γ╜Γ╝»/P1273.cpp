#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int DP[3007][3007];
int sz[3007];
struct E{
	int u,v,w;
}e[3007];
int first[3007],nt[3007],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M;
int va[3007];
int dfs(int u)
{
	int v;
	sz[u]=1;
	int cu=0;
	if(first[u]==0)
	{
		DP[u][1]=va[u];
		return 1;
	}
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		cu+=dfs(v);
		sz[u]+=sz[v];
		
		for(int V=cu;V>0;V--)
			for(int j=1;j<=V;j++)
				DP[u][V]=max(DP[v][j]+DP[u][V-j]-e[i].w,DP[u][V]);
	}
	return cu;
}
int main()
{
	N=Read();M=Read();
	memset(DP,~0x7f,sizeof(DP));
	for(int i=1;i<=N;i++)
	DP[i][0]=0;
	int u,k,w;
	for(int i=1;i<=N-M;i++)
	{
		k=Read();
		for(int j=1;j<=k;j++)
		{
			u=Read();w=Read();
			addE(i,u,w);
		}
	}
	for(int i=N-M+1;i<=N;i++)
	va[i]=Read();
	dfs(1);
	for(int i=M;i>0;i--)
	{
		if(DP[1][i]>=0)
		{
			printf("%d",i);
			return 0;
		}
	}
}
