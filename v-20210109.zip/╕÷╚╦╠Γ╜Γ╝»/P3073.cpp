#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=507*507;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v,w;
}e[maxn<<1];
int m[507][507];
int N,lim;
bool operator < (const E &x,const E &y)
{
	return x.w<y.w;
}
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int id (int i,int j)
{
	return (i-1)*N+j;
}
int S[maxn],sz[maxn];
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
int Kruskal()
{
	sort(e+1,e+1+ES);
	int f1,f2,ans=-1;
	for(register int i=1;i<=ES;i++)
	{
		f1=f(e[i].u);f2=f(e[i].v);
		if(f1!=f2)
		{
			ans=max(ans,e[i].w);
			S[f1]=f2;
			sz[f2]+=sz[f1];
			if(sz[f2]>=lim) break;
		}
	}
	return ans;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=N;j++)
			m[i][j]=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=N;j++)
		{
			if(i<N) addE(id(i,j),id(i+1,j),abs(m[i][j]-m[i+1][j]));
			if(j<N) addE(id(i,j),id(i,j+1),abs(m[i][j]-m[i][j+1]));
		}
	lim=(N*N)/2;
	for(register int i=1;i<=N*N;i++)
		sz[i]=1,S[i]=i;
	printf("%d",Kruskal());
	return 0;
}
