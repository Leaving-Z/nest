#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=5007;
int sum[maxn][maxn];
short m[maxn][maxn];
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M;
int r,c;
int main()
{
	N=R();M=R();
	int x,y,v;
	for(register int i=1;i<=N;i++)
	{
		x=R();y=R();v=R();
		x++;y++;
		m[x][y]+=v;
		r=max(r,x);c=max(c,y);
	}
	r++;c++;
	int ans=0;
	for(register int i=1;i<=r;i++)
		for(register int j=1;j<=c;j++)
		{
			sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+m[i][j];
			if(i>M) x=i-M;
			else x=0;
			if(j>M) y=j-M;
			else y=0;
			ans=max(ans,sum[i][j]-sum[i][y]-sum[x][j]+sum[x][y]);
		}
	printf("%d",ans);
	return 0;
}
