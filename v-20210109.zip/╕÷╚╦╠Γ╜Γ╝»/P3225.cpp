#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
inline int R()
{
	char c;
	int f=1,re=0;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v;
}e[1007];
int first[507],nt[1007];
int dfn[507],low[507];
bool cut[507];
int bt[507][507];
int _top[507];
int st[507],top;
int C,T,root;
int N;
void _init()
{
	for(int i=1;i<=507;i++)
	{
		first[i]=0;
		dfn[i]=0;
		cut[i]=0;
		low[i]=0;
		_top[i]=0;
	}
	C=0;T=0;
	memset(nt,0,sizeof(nt));
	memset(bt,0,sizeof(bt));
	return ;
}
void Tarjan(int u)
{
	int child=0;
	dfn[u]=low[u]=++T;
	st[++top]=u;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);child++;
			low[u]=min(low[u],low[v]);
			if(low[v]>=dfn[u]&&u!=root||u==root&&child>1)
				cut[u]=1;
			if(low[v]>=dfn[u])
			{
				C++;
				while(st[top]!=u)
					bt[C][++_top[C]]=st[top--];
				bt[C][++_top[C]]=u;
			}
		}
		else low[u]=min(dfn[v],low[u]);
	}
}
int main()
{
	int o=0;
	while(1)
	{
		N=R();
		if(N==0) return 0;
		_init();
		int u,v;
		for(int i=1;i<=N;i++)
		{
			u=R();v=R();
			e[i]=(E){u,v};
			e[i+N]=(E){v,u};
			nt[i]=first[u];
			nt[i+N]=first[v];
			first[u]=i;
			first[v]=i+N;
		}
		for(int i=1;i<=N;i++)
		if(dfn[i]==0) {root=i;Tarjan(i);}
		LL num;
		LL ans1=0,ans2=1,sum;
		for(int i=1;i<=C;i++)
		{
			sum=0;
			num=_top[i];
			for(int j=1;j<=num;j++)
			if(cut[bt[i][j]]) sum++;
			if(sum==0) ans1+=2,ans2*=(num-1)*num/2;
			else if(sum==1) ans1++,ans2*=(num-1);
		}
		printf("Case %d:",++o);
		printf(" %lld %lld\n",ans1,ans2);
	}
	return 0;
}
