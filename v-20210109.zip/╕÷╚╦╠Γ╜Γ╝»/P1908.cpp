#include<cstdio>
#include<algorithm>
using namespace std;
inline int Read()
{
	char c;
	int f=1,re;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct B{
	int data,num;
}b[500007];
int Rank[500007];
int N;
long long ans;
int C[500007];
int A[500007];
bool comp(const B &x,const B &y)
{
	if(x.data!=y.data) return x.data<y.data;
	return x.num<y.num;
}
void S()
{
	sort(b+1,b+1+N,comp);
	Rank[b[1].num]=1;
	for(int i=2;i<=N;i++)
		Rank[b[i].num]=b[i].data==b[i-1].data?Rank[b[i-1].num]:i;
	return ;
}
void Update(int x,int data)
{
	while(x<=N)
	{C[x]+=data;x+=(x&(-x));}
	return ;
}
int Query(int x)
{
	int a=0;
	while(x>0)
	{a+=C[x];x-=(x&(-x));}
	return a;
}
int main()
{
	N=Read();
	for(int i=1;i<=N;i++)
	{
		A[i]=Read();
		b[i]=(B){A[i],i};
	}
	S();
	for(int i=1;i<=N;i++)
	{
		Update(Rank[i],1);
		ans+=Query(N)-Query(Rank[i]);
	}
	printf("%lld",ans);
	return 0;
}
