#include<cstdio>
#include<algorithm>
using namespace std;
int st[5007],top;
inline int R()
{
	int re=0,f=1;
	char c;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
struct E{
	int u,v;
}e[100007];
int ES;
int first[5007],nt[100007];
int dfn[5007],low[5007];
int C,T;
bool inst[5007];
int S[5007],sz[5007];
int N,M;
void Tarjan(int u)
{
	dfn[u]=low[u]=++T;
	st[++top]=u;
	inst[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[v],low[u]);
		}
		else if(inst[v])
		low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		while(st[top]!=u)
		{
			sz[C]++;
			p=st[top--];
			inst[p]=false;
			S[p]=C;
		}
		top--;
		sz[C]++;
		inst[u]=false;
		S[u]=C;
	}
}
int main()
{
	N=R();M=R();
	int u,v,t;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();t=R();
		if(t==1)
		{
			e[++ES]=(E){u,v};
			nt[ES]=first[u];
			first[u]=ES;
		}
		else
		{
			e[++ES]=(E){u,v};
			nt[ES]=first[u];
			first[u]=ES;
			e[++ES]=(E){v,u};
			nt[ES]=first[v];
			first[v]=ES;
		}
	}
	for(int i=1;i<=N;i++)
	if(dfn[i]==0) Tarjan(i);
	int p,ans=-1;
	for(int i=1;i<=N;i++)
	{
		if(sz[S[i]]>ans)
		{
			ans=sz[S[i]];
			p=S[i];
		}
	}
	printf("%d\n",ans);
	for(int i=1;i<=N;i++)
	{
		if(S[i]==p)
			printf("%d ",i);
	}
}
