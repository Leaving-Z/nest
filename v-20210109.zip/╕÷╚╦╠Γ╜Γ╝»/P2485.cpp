#include<cstdio>
#include<algorithm>
#include<map>
#include<cmath>
using namespace std;
typedef long long LL;
LL N,K;
LL y,z,p;
map <LL, LL> mp;
LL fast_pow(LL a,LL b)
{
	LL s=1;
	while(b)
	{
		if(b&1)
		s=(s*a)%p;
		a=(a*a)%p;
		b>>=1;
	}
	return s;
}
LL g,xx,yx;
inline void EXGCD(LL a,LL b,LL &x1,LL &y1)
{
	if(!b)
	{
		x1=1;y1=0;g=a;
		return ;
	}
	EXGCD(b,a%b,y1,x1);
	y1-=(a/b)*x1;
	return ;
}
namespace Q1
{
	void solve()
	{
		for(int i=1;i<=N;i++)
		{
			scanf("%lld%lld%lld",&y,&z,&p);
			printf("%lld\n",fast_pow(y,z));
		}
		return ;
	}
}
namespace Q2
{
	void solve()
	{
		for(int i=1;i<=N;i++)
		{
			scanf("%lld%lld%lld",&y,&z,&p);
			EXGCD(y,p,xx,yx);
			if(z%g)
				puts("Orz, I cannot find x!");
			else
			{
				xx*=z/g;
				printf("%lld\n",(xx%(p/g)+(p/g))%(p/g));
			}
		}
		return ;
	}
}
namespace Q3
{
	void solve()
	{
		for(int i=1;i<=N;i++)
		{
			LL zh=0;
			scanf("%lld%lld%lld",&y,&z,&p);
			LL m=ceil(sqrt(p));
			if(y%p==0&&z)
				puts("Orz, I cannot find x!");
			else
			{
				mp.clear();
				LL bi=z%p,b=fast_pow(y,m);
				mp[bi]=0;
				for(int i=1;i<=m;i++)
				{
					bi=(bi*y)%p;
					mp[bi]=(LL)i;
				}
				bi=1;
				bool flag=true;
				for(int i=1;i<=m;i++)
				{
					bi=(bi*b)%p;
					if(mp[bi]!=0)
					{
						printf("%lld\n",(i*m-mp[bi]+p)%p);
						flag=false;break;
					}
				}
				if(flag) puts("Orz, I cannot find x!");
			}
		}
	}
}
int main()
{
	scanf("%lld%lld",&N,&K);
	if(K==1)
	Q1::solve();
	else if(K==2)
	Q2::solve();
	else Q3::solve();
	return 0;
}
