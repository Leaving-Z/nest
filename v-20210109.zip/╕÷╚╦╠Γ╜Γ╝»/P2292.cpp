#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
const int maxn=1050;
int Trie[maxn][27];
bool word[maxn];
int N,M,all;
char s[maxn];
bool book[maxn];
inline void Insert()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	word[p]=true;
	return ;
}
inline void Reset(int x)
{
	int p=0,t;
	for(int i=x+1;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t])
		{
			p=Trie[p][t];
			if(word[p])
				book[i]=true;
		}
		else break;
	}
	return ;
}
inline void check()
{
	memset(book,0,sizeof(book));
	int p=0,t,ans=0;
	Reset(-1);
	for(int i=0;s[i];i++)
	{
		if(book[i])
		{
			ans=i+1;
			Reset(i);
		}
	}
	printf("%d\n",ans);
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert();
	}
	for(int i=1;i<=M;i++)
	{
		scanf("%s",s);
		check();
	}
	return 0;
}
