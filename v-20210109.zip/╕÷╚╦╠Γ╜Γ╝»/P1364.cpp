#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=107;
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES=1;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N;
int dis[maxn],sz[maxn],W[maxn];
inline void dfs(int u,int fa)
{
	sz[u]=W[u];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			sz[u]+=sz[v];
			dis[u]+=dis[v]+sz[v];
		}
	}
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();
	int v;
	for(int i=1;i<=N;i++)
	{
		W[i]=R();
		v=R();
		if(v) addE(i,v),addE(v,i);
		v=R();
		if(v) addE(i,v),addE(v,i);
	}
	int ans=0x7f7f7f7f;
	for(int i=1;i<=N;i++)
	{
		memset(dis,0,sizeof(dis));
		dfs(i,0);
		ans=min(ans,dis[i]);
	}
	printf("%d",ans);
	return 0;
}
