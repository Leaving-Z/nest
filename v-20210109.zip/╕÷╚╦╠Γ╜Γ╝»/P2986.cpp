#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
typedef long long LL;
struct E{
	LL u,v,w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES=1;
inline void addE(LL u,LL v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N;
LL sz[maxn],dis[maxn],C[maxn],all,ans=1e18;
inline void DFS(int u,int fa)
{
	sz[u]=C[u];
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			DFS(v,u);
			sz[u]+=sz[v];
			dis[u]+=dis[v]+sz[v]*e[i].w;
		}
	}
	return ;
}
inline void dfs(int u,int fa,LL sum)
{
	int v;ans=min(ans,sum+dis[u]);
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
			dfs(v,u,sum+(dis[u]-dis[v])+(all-2*sz[v])*e[i].w);
	}
	return ;
}
inline LL R()
{
	char c;
	LL re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();
	for(register int i=1;i<=N;i++) C[i]=R(),all+=C[i];
	LL u,v,w;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);addE(v,u,w);
	}
	DFS(1,0);
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
