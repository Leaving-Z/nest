#include<cstdio>
#include<algorithm>
#include<stack>
using namespace std;
int S[10005];
stack <int> s;
struct E{
	int u,v;
}e[50005];
int first[10005],nt[50005];
int dfn[10005],low[10005];
int T,C;
bool ins[10005];
int in[10005],out[10005];
int N,M;
int shrink[10005];
void Tarjan(int u)
{
	s.push(u);
	ins[u]=true;
	dfn[u]=low[u]=++T;
	for(int i=first[u];i;i=nt[i])
	{
		int v=e[i].v;
		if(dfn[v]==0)
		{
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(ins[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;
		C++;
		do{
			p=s.top();
			s.pop();
			ins[p]=false;
			S[p]=C;
			shrink[C]++;
		}while(p!=u);
	}
}
int main()
{
	scanf("%d%d",&N,&M);
	int x,y;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&x,&y);
		e[i]=(E){x,y};
		nt[i]=first[x];
		first[x]=i;
	}
	for(int i=1;i<=N;i++)
	{
		if(dfn[i]==0)
			Tarjan(i);
	}
	for(int i=1;i<=M;i++)
	{
		if(S[e[i].v]!=S[e[i].u])
		{
			in[S[e[i].v]]++;
			out[S[e[i].u]]++;
		}
	}
	int zero=0;
	for(int i=1;i<=C;i++)
	{
		if(out[i]==0) 
		{
			if(zero)
			{
				printf("0");
				return 0;
			}
			zero=i;
		}
	}
	printf("%d",shrink[zero]);
	return 0;
}
