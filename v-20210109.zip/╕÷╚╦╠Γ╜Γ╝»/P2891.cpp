#include<cstdio>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
queue <int> q;
const int maxn=407;
const int maxm=41007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,cf;
}e[maxm];
#define cf(i) e[i].cf
int first[maxn],nt[maxm],ES=1;
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int cf)
{
	addE(u,v,cf);
	addE(v,u,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M,P,Q,S,T;
int cnt[maxn],cur[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)>0&&!cnt[v])
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int v,d,sum=0;
	for(register int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cf(i)>0&&cnt[v]==cnt[u]+1)
		{
			d=dfs(v,min(cf(i),f));
			if(d>0)
			{
				sum+=d;f-=d;
				cf(i)-=d;cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	N=R();P=R();Q=R();T=N+N+Q+P+1;
	int fi,di,x;
	for(register int i=1;i<=N;i++)
	{
		fi=R();di=R();
		for(register int j=1;j<=fi;j++)
		{
			x=R();
			add(x,P+i,1);
		}
		for(register int j=1;j<=di;j++)
		{
			x=R();
			add(P+N+i,P+N+N+x,1);
		}
	}
	for(register int i=1;i<=P;i++)
		add(S,i,1);
	for(register int i=1;i<=N;i++)
		add(P+i,P+N+i,1);
	for(register int i=1;i<=Q;i++)
		add(P+N+N+i,T,1);
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(cur));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
