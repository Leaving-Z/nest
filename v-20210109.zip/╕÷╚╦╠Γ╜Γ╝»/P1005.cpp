#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
#define R (L+len-1)
struct INT{
	int num[80];
	int len;
	INT()
	{
		memset(num,0,sizeof(num));
		len=1;
	}
	bool operator < (const INT &a) const
	{
		if(len<a.len) return true;
		if(a.len>len) return false;
		for(int i=len;i>=1;i--)
		{
			if(num[i]>a.num[i]) return false;
			if(num[i]<a.num[i]) return true;
		}
		return false;
	}
	INT operator + (const INT &a) const
	{
		INT ans;
		int l=max(len,a.len);
		ans.len=l;
		for(int i=1;i<=l;i++)
		{
			ans.num[i]+=num[i]+a.num[i];
			if(ans.num[i]>=10)
			{
				ans.num[i]%=10;
				ans.num[i+1]++;
			}
		}
		while(ans.num[ans.len+1]) ans.len++;
		return ans;
	}
	INT operator * (const INT &a) const
	{
		INT ans;
		ans.len=a.len+len;
		for(int i=1;i<=len;i++)
			for(int j=1;j<=a.len;j++)
			{
				ans.num[i+j-1]+=num[i]*a.num[j];
				if(ans.num[i+j-1]>=10)
				{
					ans.num[i+j]+=ans.num[i+j-1]/10;
					ans.num[i+j-1]%=10;
				}
			}
		while(ans.num[ans.len]==0&&ans.len>0) ans.len--;
		return ans;
	}
	void push(const char s[])
	{
		int l=strlen(s);
		len=l;
		for(int i=1;i<=l;i++)
			num[l-i+1]=s[i-1]-'0';
		return ;
	}
	void print()
	{
		for(int i=len;i>0;i--)
		printf("%d",num[i]);
		return ;
	}
	void Clear()
	{
		memset(num,0,sizeof(num));
		len=1;
		return ;
	}
}p2[85];
INT m[85][85];
INT k;
INT ANS;
INT DP[85][85];
int N,M;
char t[5];
int main()
{
	scanf("%d%d",&N,&M);
	t[0]='1';
	p2[0].push(t);
	t[0]='2';
	k.push(t);
	for(int i=1;i<=M;i++)
		p2[i]=p2[i-1]*k;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
		{
			scanf("%s",t);
			m[i][j].push(t);
		}
	for(int i=1;i<=N;i++)
	{
		for(int len=1;len<=M;len++)
			for(int L=1;L+len-1<=M;L++)
			{
				DP[L][R].Clear();
				DP[L][R]=max(DP[L+1][R]+m[i][L]*p2[M-len+1],DP[L][R-1]+m[i][R]*p2[M-len+1]);
			}
		ANS=ANS+DP[1][M];
	}
	ANS.print();
	return 0;
}
