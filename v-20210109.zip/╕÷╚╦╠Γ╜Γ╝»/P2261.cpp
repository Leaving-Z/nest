#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long LL;
LL N,K;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%lld%lld",&N,&K);
    LL ans=N*K;
    LL L=1,R;
    while(L<=N)
    {
        if(K/L!=0) R=min(K/(K/L),N);
        else R=N;
        ans-=(K/L)*(R-L+1)*(L+R)/2;
        L=R+1;
    }
    printf("%lld",ans);
    return 0;
}