#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=100007;
const int maxm=400007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
queue <int> q;
int N,M,S,K,P,Q;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
bool book[maxn],acc[maxn];
long long dis[maxn],V[maxn];
void SPFA(int s)
{
	int u,v;
	memset(dis,0x7f,sizeof(dis));
	dis[s]=0;
	q.push(s);
	book[s]=true;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+V[v]<dis[v])
			{
				dis[v]=dis[u]+V[v];
				if(!book[v])
				{
					q.push(v);
					book[v]=true;
				}
			}
		}
	}
	return ;
}
int main()
{
	freopen("P3393_4.in","r",stdin); 
	N=R();M=R();K=R();S=R();
	P=R();Q=R();
	int u,v;
	for(int i=1;i<=N;i++)
		V[i]=1;
	for(int i=1;i<=K;i++)
		acc[R()]=true;
	for(int i=1;i<=M;i++)
	{
		u=R();v=R();
		if(acc[u]) u=0;
		if(acc[v]) v=0;
		if(u!=v) addE(u,v),addE(v,u);
	}
	SPFA(0);V[0]=1e16;
	V[N]=0;
	for(int i=1;i<N;i++)
	if(dis[i]<=S) V[i]=Q;
	else V[i]=P;
	SPFA(1);
	printf("%lld",dis[N]);
	return 0;
}
