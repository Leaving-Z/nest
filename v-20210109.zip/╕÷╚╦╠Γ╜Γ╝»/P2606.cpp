#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=1000007;
int mod;
typedef long long LL;
LL fast_pow(LL b,int k)
{
    LL s=1;
    while(k)
    {
        if(k&1) s=s*b%mod;
        b=b*b%mod;
        k>>=1;
    }
    return s;
}
LL fact[maxn],inv[maxn];
LL C(int n,int m) {return fact[n]*inv[m]%mod*inv[n-m]%mod;}
LL f[maxn];
int l[maxn],r[maxn];
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&mod);
    for(int i=fact[0]=1;i<=N;i++)
        fact[i]=fact[i-1]*i%mod;
    inv[N]=fast_pow(fact[N],mod-2);
    for(int i=N-1;i>=0;i--)
        inv[i]=inv[i+1]*(i+1)%mod;
    int d=0;
    for(int i=1;i<=N;i++)
    {
        if(i>=(1<<d+1)) d++;
        l[i]=min(l[i-1]+1,(1<<d)-1);
        r[i]=i-1-l[i];
    }
    f[1]=f[0]=1;
    for(int i=2;i<=N;i++)
        f[i]=f[l[i]]*f[r[i]]%mod*C(i-1,l[i])%mod;
    printf("%lld",f[N]);
    return 0;
}