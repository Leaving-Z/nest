#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=10007;
const int maxk=1007;
typedef unsigned long long LL;
LL F[maxn][maxk];
LL N,K,p;
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%llu%llu%llu",&N,&K,&p);
	F[0][0]=1;
	for(int i=1;i<=N;i++)
		for(int k=1;k<=i&&k<=K;k++)
			F[i][k]=(F[i-1][k-1]+F[i-1][k]*k%p)%p;
	printf("%llu",F[N][K]);
	return 0;
}
