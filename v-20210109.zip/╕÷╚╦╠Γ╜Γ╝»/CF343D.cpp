#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=500007;
int TREE[maxn<<2],tag[maxn<<2];
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ; 
}
int N,M;
int sz[maxn],top[maxn],fa[maxn],son[maxn];
int depth[maxn],id[maxn],ix;
void DFS(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			depth[v]=depth[u]+1;
			fa[v]=u;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[son[u]]<sz[v]) son[u]=v;
		}
	}
	return ;
}
void dfs(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u]&&v!=son[u])
			dfs(v,v);
	}
	return ;
}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
inline void Pushdown(int L,int R,int i)
{
	if(!tag[i]) return ;
	if(tag[i]==1)
	{
		TREE[Ls]=mid-L+1;
		TREE[Rs]=R-mid;
	}
	else
	{
		TREE[Ls]=0;
		TREE[Rs]=0;
	}
	tag[Ls]=tag[Rs]=tag[i];
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		if(k) TREE[i]=R-L+1,tag[i]=1;
		else TREE[i]=0,tag[i]=2;
		return ;
	}
	Pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	TREE[i]=TREE[Ls]+TREE[Rs];
	return ;
}
int Query(int L,int R,int x,int i)
{
	if(L==R) return TREE[i];
	Pushdown(L,R,i);
	if(x<=mid) return Query(L,mid,x,Ls);
	else return Query(mid+1,R,x,Rs);
}
void Update_Path(int x,int y,int k)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]]) swap(x,y);
		Update(1,N,id[top[x]],id[x],k,1);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y]) swap(x,y);
	Update(1,N,id[x],id[y],k,1);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int main()
{
	N=R();
	int u,v;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();
		addE(u,v);
		addE(v,u);
	}
	DFS(1);dfs(1,1);
	M=R();
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();
		if(u==1)
			Update(1,N,id[v],id[v]+sz[v]-1,1,1);
		else if(u==2) Update_Path(1,v,0);
		else printf("%d\n",Query(1,N,id[v],1));
	}
	return 0;
}
