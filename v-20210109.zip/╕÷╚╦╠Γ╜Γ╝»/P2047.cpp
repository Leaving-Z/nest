#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
#include<bitset>
using namespace std;
typedef long long LL;
const int maxn=207;
int m[maxn][maxn];
LL sum[maxn][maxn];
int N,M;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    int x,y,w;
    memset(m,0x3f,sizeof(m));
    scanf("%d%d",&N,&M);
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d",&x,&y,&w);
        m[x][y]=m[y][x]=w;
        sum[x][y]=sum[y][x]=1;
    }
    for(int k=1;k<=N;k++)
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
            {
                if(m[i][k]+m[k][j]<m[i][j])
                {
                    m[i][j]=m[i][k]+m[k][j];
                    sum[i][j]=sum[i][k]*sum[k][j];
                }
                else if(m[i][k]+m[k][j]==m[i][j])
                    sum[i][j]+=sum[i][k]*sum[k][j];
            }
    double res;
    for(int k=1;k<=N;k++)
    {
        res=0;
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
            {
                if(k==i||k==j||i==j) continue;
                if(m[i][k]+m[k][j]==m[i][j]) res+=1.0*(sum[i][k]*sum[k][j])/sum[i][j];    
            }
        printf("%.3f\n",res);
    }
    return 0;
}