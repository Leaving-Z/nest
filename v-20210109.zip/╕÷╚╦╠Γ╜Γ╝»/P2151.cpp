#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int mod=45989;
struct Matr{
	int m[150][150];
	int R,C;
	Matr() {memset(m,0,sizeof(m));}
	Matr operator * (const Matr &a) const
	{
		Matr t;
		t.R=R;t.C=a.C;
		for(int i=1;i<=R;i++)
			for(int j=1;j<=t.C;j++)
				for(int k=1;k<=C;k++)
				t.m[i][j]=(t.m[i][j]+(m[i][k]*a.m[k][j])%mod)%mod;
		return t;
	}
}ini,trans;
struct E{
	int u,v;
}e[127];
int first[57],nt[127],ES;
int N,M,S,T,t;
Matr operator ^ (Matr a,int k)
{
	Matr s=a;k--;
	while(k)
	{
		if(k&1) s=s*a;
		a=a*a;
		k>>=1;
	}
	return s;
}
int anti(int x)
{
	return x%2==0?x-1:x+1;
}
int main()
{
	scanf("%d%d%d%d%d",&N,&M,&t,&S,&T);
	int u,v;S++;T++;
	for(int i=1;i<=M;i++)
	{
		scanf("%d%d",&u,&v);u++;v++;
		e[++ES]=(E){u,v};
		nt[ES]=first[u];
		first[u]=ES;
		e[++ES]=(E){v,u};
		nt[ES]=first[v];
		first[v]=ES;
	}
	for(int i=1;i<=ES;i++)
	{
		for(int k=first[e[i].v];k;k=nt[k])
		{
			if(k!=anti(i))
			trans.m[k][i]++;
		}
	}
	trans.C=trans.R=ES;
	ini.R=ES;ini.C=1;
	for(int i=first[S];i;i=nt[i])
		ini.m[i][1]++;
	trans=trans^(t-1);
	trans=trans*ini;
	int ans=0;
	for(int i=first[T];i;i=nt[i])
		ans=(ans+trans.m[anti(i)][1])%mod;
	printf("%d",ans);
	return 0;
}
