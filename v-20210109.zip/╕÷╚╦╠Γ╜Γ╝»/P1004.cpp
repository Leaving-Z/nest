# include <cstdio>
# include <iostream>
# include <algorithm>
# include <cstring>
# include <cmath> 
using namespace std;
int x[10][10];
int ans[10][10][10][10];
int imax(int a,int b,int c,int d)
{
	return max(max(a,b),max(c,d));
}
int main()
{
	int n;
	cin>>n;
	int a,b,c; 
	while(cin>>a>>b>>c&&a!=0)
	{
		x[b][a]=c;
	}
	for(int i1=1;i1<=n;i1++)
	{
		for(int i2=1;i2<=n;i2++)
		{
			for(int i3=1;i3<=n;i3++)
			{
				for(int i4=1;i4<=n;i4++)
				{
					ans[i1][i2][i3][i4]=imax(ans[i1-1][i2][i3-1][i4],ans[i1-1][i2][i3][i4-1],ans[i1][i2-1][i3-1][i4],ans[i1][i2-1][i3][i4-1])+x[i1][i2]+x[i3][i4];
                     if(i1==i3&&i4==i2)
					 ans[i1][i2][i3][i4]-=x[i1][i2];
				}
			}
		}
	}
	cout<<ans[n][n][n][n];
 }
