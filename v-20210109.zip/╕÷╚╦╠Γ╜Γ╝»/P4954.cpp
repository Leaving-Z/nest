#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
int f[maxn][2];
int q[maxn],head=1,tail;
int N,A[maxn],sum[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    for(int i=N;i>=1;i--)
        scanf("%d",&A[i]);
    for(int i=1;i<=N;i++)
        sum[i]=sum[i-1]+A[i];
    q[++tail]=0;
    for(int i=1;i<=N;i++)
    {
        while(head<tail&&sum[i]>=f[q[head+1]][1]+sum[q[head+1]]) ++head;
        f[i][0]=f[q[head]][0]+1;
        f[i][1]=sum[i]-sum[q[head]];
        while(head<=tail&&sum[i]+f[i][1]<=f[q[tail]][1]+sum[q[tail]]) --tail;
        q[++tail]=i;
    }
    printf("%d",f[N][0]);
    return 0;
}