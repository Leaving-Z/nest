#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
using namespace std;
const int maxn=50007;
const int maxm=100007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,Q;
int A[maxn];
int sz[maxn],fa[maxn],dep[maxn],son[maxn];
void dfs1(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]) continue;
		dep[v]=dep[u]+1;
		fa[v]=u;
		dfs1(v);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
	return ;
}
int top[maxn],id[maxn],anti[maxn],ix;
void dfs2(int u,int tp)
{
	id[u]=++ix;
	anti[ix]=u;
	top[u]=tp;
	if(son[u]) dfs2(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return ;
}
struct seg_tree{
	int mx,mn,d1,d2;
}tree[maxn<<2];
int add[maxn<<2];
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
	seg_tree t;
	t.mn=min(x.mn,y.mn);
	t.mx=max(x.mx,y.mx);
	t.d1=max(x.d1,y.d1);
	t.d1=max(t.d1,x.mx-y.mn);
	t.d2=max(x.d2,y.d2);
	t.d2=max(t.d2,y.mx-x.mn);
	return t;
}
#define ls (i<<1)
#define rs (i<<1|1)
void build(int L,int R,int i)
{
	if(L==R)
	{
		tree[i].mn=tree[i].mx=A[anti[L]];
		return ;
	}
	int mid=L+R>>1;
	build(L,mid,ls);
	build(mid+1,R,rs);
	tree[i]=tree[ls]+tree[rs];
	return ;
}
void pushdown(int i)
{
	if(!add[i]) return ;
	add[ls]+=add[i];add[rs]+=add[i];
	tree[ls].mn+=add[i];tree[ls].mx+=add[i];
	tree[rs].mn+=add[i];tree[rs].mx+=add[i];
	add[i]=0;
	return ;
}
void init(seg_tree &re)
{
	re.mn=2e9;re.mx=-2e9;re.d1=0;re.d2=0;
	return ;
}
void update(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		tree[i].mn+=k;
		tree[i].mx+=k;
		add[i]+=k;
		return ; 
	}
	int mid=L+R>>1;
	pushdown(i);
	if(l<=mid) update(L,mid,l,r,k,ls);
	if(r>mid) update(mid+1,R,l,r,k,rs);
	tree[i]=tree[ls]+tree[rs];
	return ;
}
seg_tree query(int L,int R,int l,int r,int i)
{
	if(l<=L&&R<=r) return tree[i];
	pushdown(i);
	seg_tree re;
	init(re);
	int mid=L+R>>1;
	if(l<=mid) re=re+query(L,mid,l,r,ls);
	if(r>mid) re=re+query(mid+1,R,l,r,rs);
	return re;
}
void update(int x,int y,int k)
{
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		update(1,N,id[top[x]],id[x],k,1);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	update(1,N,id[x],id[y],k,1);
	return ;
}
seg_tree query(int x,int y)
{
	seg_tree ans1,ans2,tmp;
	init(ans1);init(ans2);
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]])
		{
			ans2=query(1,N,id[top[y]],id[y],1)+ans2;
			y=fa[top[y]];
		}
		else
		{
			tmp=query(1,N,id[top[x]],id[x],1);
			swap(tmp.d1,tmp.d2);
			ans1=ans1+tmp;
			x=fa[top[x]];
		}
	}
	if(dep[x]>dep[y])
	{
		tmp=query(1,N,id[y],id[x],1);
		swap(tmp.d1,tmp.d2);
		ans1=ans1+tmp;
	}
	else ans2=query(1,N,id[x],id[y],1)+ans2;
	return ans1+ans2;
}
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif 
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d",&A[i]);
	int u,v;
	for(int i=1;i<N;i++)
	{
		scanf("%d%d",&u,&v);
		addE(u,v);addE(v,u);
	}
	dfs1(1);dfs2(1,1);
	build(1,N,1);
	scanf("%d",&Q);
	int w;
	while(Q--)
	{
		scanf("%d%d%d",&u,&v,&w);
		printf("%d\n",query(u,v).d2);
		update(u,v,w);
	}
	return 0;
}
