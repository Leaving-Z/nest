// luogu-judger-enable-o2
#include<cstdio>
struct flat
{
	int a,b,g,k;
}a[10000];
int main()
{
	int n,x,y,answer=-1;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%d%d%d%d",&a[i].a,&a[i].b,&a[i].g,&a[i].k);
	scanf("%d%d",&x,&y);
	for(int i=0;i<n;i++)
		if(x>=a[i].a&&x<=a[i].a+a[i].g&&y>=a[i].b&&y<=a[i].b+a[i].k)
			answer=i+1;
	printf("%d",answer);
	return 0;
}
