#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=30007;
const int maxm=60007;
const int maxbit=10;
int N,Q;
struct E{
    int u,v,w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,int w)
{
    e[++ES]=(E){u,v,w};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int A[maxn],V[maxn];
int depth[maxn],fa[maxn],sz[maxn],son[maxn];
void dfs1(int u)
{
    int v;
    sz[u]=1;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        depth[v]=depth[u]+1;
        fa[v]=u;
        A[v]=A[u]^e[i].w;
        V[v]=e[i].w;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[son[u]]<sz[v]) son[u]=v; 
    }
    return ;
}
int top[maxn],id[maxn],anti[maxn],ix;
void dfs2(int u,int tp)
{
    top[u]=tp;
    id[u]=++ix;anti[ix]=u;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
struct seg_tree{
    int sum0,sum1;
}TREE[maxn<<2][maxbit];
seg_tree operator + (const seg_tree &x,const seg_tree &y)
{
    seg_tree t;
    t.sum0=x.sum0+y.sum0;
    t.sum1=x.sum1+y.sum1;
    return t;
}
int rev[maxn<<2][maxbit];
#define val0(i,j) TREE[i][j].sum0
#define val1(i,j) TREE[i][j].sum1
#define v(i,j) TREE[i][j]
#define Ls (i<<1)
#define Rs (i<<1|1)
#define mid (L+R>>1)
void Build(int L,int R,int i)
{
    if(L==R)
    {
        for(int k=0;k<maxbit;k++)
        {
            if(A[anti[L]]&(1<<k))
            val0(i,k)=0,val1(i,k)=1;
            else
            val0(i,k)=1,val1(i,k)=0;
        }
        return ;
    }
    Build(L,mid,Ls);
    Build(mid+1,R,Rs);
    for(int k=0;k<maxbit;k++)
        v(i,k)=v(Ls,k)+v(Rs,k);
    return ;
}
void pushdown(int i,int k)
{
    if(rev[i][k])
    {
        rev[Ls][k]^=1;
        rev[Rs][k]^=1;
        swap(val0(Ls,k),val1(Ls,k));
        swap(val0(Rs,k),val1(Rs,k));
        rev[i][k]=0;
    }
    return ;
}
void Update(int L,int R,int l,int r,int k,int i)
{
    if(l<=L&&R<=r)
    {
        rev[i][k]^=1;
        swap(val0(i,k),val1(i,k));
        //printf("[%d,%d][%d] from %d to %d,tag is %d\n",L,R,k,val0(i,k),val1(i,k),rev[i][k]);
        return ;
    }
    pushdown(i,k);
    if(l<=mid) Update(L,mid,l,r,k,Ls);
    if(r>mid) Update(mid+1,R,l,r,k,Rs);
    v(i,k)=v(Ls,k)+v(Rs,k);
    return ;
}
seg_tree Query(int L,int R,int l,int r,int k,int i)
{
    if(l<=L&&R<=r) return v(i,k);
    pushdown(i,k);
    seg_tree t;
    t.sum0=t.sum1=0;
    if(l<=mid) t=t+Query(L,mid,l,r,k,Ls);
    if(r>mid) t=t+Query(mid+1,R,l,r,k,Rs);
    return t;
}
long long Query_Path(int u,int v)
{
    seg_tree re;
    int x,y;
    long long ans=0;
    for(int k=0;k<maxbit;k++)
    {
        x=u;y=v;re.sum0=re.sum1=0;
        while(top[x]!=top[y])
        {
            if(depth[top[x]]<depth[top[y]]) swap(x,y);
            re=re+Query(1,N,id[top[x]],id[x],k,1);
            x=fa[top[x]];
        }
        if(depth[x]>depth[y]) swap(x,y);
        re=re+Query(1,N,id[x],id[y],k,1);
        ans+=(1ll<<k)*re.sum1*re.sum0;
    }
    return ans;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    freopen("1.out","w",stdout);
    #endif
    scanf("%d%d",&N,&Q);
    int u,v,w;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        addE(u,v,w);addE(v,u,w);
    }
    dfs1(1);dfs2(1,1);
    Build(1,N,1);
    /*for(int i=1;i<=N;i++)
        printf("fa[%d]=%d\n",i,fa[i]);
    for(int i=1;i<=N;i++)
        printf("A[%d]=%d\n",i,A[i]);*/
    int op;
    while(Q--)
    {
        scanf("%d%d%d",&op,&u,&v);
        if(op==1) printf("%lld\n",Query_Path(u,v));
        else
        {
            scanf("%d",&w);
            u=depth[u]>depth[v]?u:v;
            //printf("A[%d] from %d to %d,fa is %d\n",u,A[u],w,fa[u]);
            for(int i=0;i<maxbit;i++)
            if((V[u]^w)&(1<<i)) Update(1,N,id[u],id[u]+sz[u]-1,i,1);
            V[u]=w;
        }
    }
    return 0;
}