#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxm=2000007;
const int maxq=800007;
struct Query{
    int x,y,v,id,ty;
}q[maxq],q1[maxq];
int ans[maxq];
int C[maxm];
int m[maxq][4];
int W,S,Q,tot,qwq;
void update(int x,int k) {while(x<=W) C[x]+=k,x+=x&(-x);return ;}
int query(int x) {int re=0;while(x) re+=C[x],x-=x&(-x);return re;}
bool operator < (const Query &x,const Query &y)
{
    if(x.x!=y.x) return x.x<y.x;
    else if(x.y!=y.y) return x.y<y.y;
    return x.ty<y.ty;
}
void solve(int l,int r)
{
    if(l==r) return ;
    int mid=(l+r>>1),cnt=0;
    solve(l,mid);solve(mid+1,r);
    for(int i=l;i<=mid;i++)
    if(q[i].ty==1) q1[++cnt]=q[i];
    for(int i=mid+1;i<=r;i++)
    if(q[i].ty==2) q1[++cnt]=q[i];
    sort(q1+1,q1+1+cnt);
    for(int i=1;i<=cnt;i++)
    {
        if(q1[i].ty==2) ans[q1[i].id]+=query(q1[i].y);
        else update(q1[i].y,q1[i].v);
    }
    for(int i=1;i<=cnt;i++)
    if(q1[i].ty==1) update(q1[i].y,-q1[i].v);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&S,&W);
    int x1,x2,y1,y2,v,op;
    while('t'+'j'+'q'+'A'+'K'+'I'+'O'+'I')
    {
        scanf("%d",&op);
        if(op==3) break;
        if(op==1)
        {
            scanf("%d%d%d",&x1,&y1,&v);
            q[++Q]=(Query){x1,y1,v,0,1};
        }
        else
        {
            scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
            q[++Q]=(Query){x2,y2,0,++tot,2};
            q[++Q]=(Query){x1-1,y2,0,++tot,2};
            q[++Q]=(Query){x2,y1-1,0,++tot,2};
            q[++Q]=(Query){x1-1,y1-1,0,++tot,2};
            ++qwq;
            m[qwq][0]=x1;m[qwq][1]=y1;m[qwq][2]=x2;m[qwq][3]=y2;
        }
    }
    solve(1,Q);
    for(int i=1;i<=qwq;i++)
    {
        v=(m[i][3]-m[i][1]+1)*(m[i][2]-m[i][0]+1)*S;
        v+=ans[i*4]-ans[i*4-1]-ans[i*4-2]+ans[i*4-3];
        printf("%d\n",v);
    }
    return 0;
}