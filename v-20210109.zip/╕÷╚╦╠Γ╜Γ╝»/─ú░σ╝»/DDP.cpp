#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int maxm=200007;
const int inf=0x3f3f3f3f;
struct E{
    int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v)
{
    e[++ES]=(E){u,v};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
struct Matrix{
    int m[2][2];
    Matrix () {memset(m,~0x3f,sizeof(m));return ;}
}g[maxn],tree[maxn<<2];
Matrix operator * (const Matrix &x,const Matrix &y)
{
    Matrix t;
    for(int k=0;k<2;k++)
        for(int i=0;i<2;i++)
            for(int j=0;j<2;j++)
                t.m[i][j]=max(t.m[i][j],x.m[i][k]+y.m[k][j]);
    return t;
}
int N,Q;
int sz[maxn],son[maxn],fa[maxn],dep[maxn];
void dfs1(int u)
{
    sz[u]=1;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dep[v]=dep[u]+1;
        fa[v]=u;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[v]>sz[son[u]]) son[u]=v;   
    }
    return ;
}
int top[maxn],id[maxn],anti[maxn],ix,ed[maxn];
int f[maxn][2],A[maxn];
void dfs2(int u,int tp)
{
    id[u]=++ix;anti[ix]=u;
    top[u]=tp;
    f[u][1]=A[u];
    g[u].m[0][0]=g[u].m[0][1]=0;
    g[u].m[1][0]=A[u];
    if(son[u])
    {
        dfs2(son[u],tp);
        f[u][0]+=max(f[son[u]][0],f[son[u]][1]);
        f[u][1]+=f[son[u]][0];
    }
    else ed[top[u]]=id[u];
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
        f[u][0]+=max(f[v][0],f[v][1]);
        f[u][1]+=f[v][0];
        g[u].m[0][0]+=max(f[v][0],f[v][1]);
        g[u].m[0][1]=g[u].m[0][0];
        g[u].m[1][0]+=f[v][0];
    }
    return ;
}
#define ls (i<<1)
#define rs (i<<1|1)
void build(int L,int R,int i)
{
    if(L==R)
    {
        tree[i]=g[anti[L]];
        return ;
    }
    int mid=L+R>>1;
    build(L,mid,ls);
    build(mid+1,R,rs);
    tree[i]=tree[ls]*tree[rs];
    return ;
}
void update(int L,int R,int x,int i)
{
    if(L==R) {tree[i]=g[anti[L]];return ;}
    int mid=L+R>>1;
    if(x<=mid) update(L,mid,x,ls);
    else update(mid+1,R,x,rs);
    tree[i]=tree[ls]*tree[rs];
    return ;
}
Matrix query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return tree[i];
    Matrix t;
    t.m[0][0]=t.m[1][1]=0;
    int mid=L+R>>1;
    if(l<=mid) t=t*query(L,mid,l,r,ls);
    if(r>mid) t=t*query(mid+1,R,l,r,rs);
    return t;
}
void update_path(int x,int k)
{
    Matrix bef,aft;
    g[x].m[1][0]+=k-A[x];
    A[x]=k;
    while(x)
    {
        bef=query(1,N,id[top[x]],ed[top[x]],1);
        update(1,N,id[x],1);
        aft=query(1,N,id[top[x]],ed[top[x]],1);
        x=fa[top[x]];
        g[x].m[0][0]+=max(aft.m[0][0],aft.m[1][0])-max(bef.m[0][0],bef.m[1][0]);
        g[x].m[0][1]=g[x].m[0][0];
        g[x].m[1][0]+=aft.m[0][0]-bef.m[0][0];
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&Q);
    int u,v;
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    for(int i=1;i<N;i++)
        scanf("%d%d",&u,&v),addE(u,v),addE(v,u);
    dfs1(1);
    dfs2(1,1);
    build(1,N,1);
    Matrix res;
    while(Q--)
    {
        scanf("%d%d",&u,&v);
        update_path(u,v);
        res=query(1,N,id[1],ed[1],1);
        printf("%d\n",max(res.m[0][0],res.m[1][0]));
    }
    return 0;
}