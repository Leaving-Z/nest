#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int Trie[1000007][26];
int N,all,ans;
char s[1000007];
int word[1000007],fail[1000007];
queue <int> q;
inline void Insert()
{
	int p=0,t;
	for(int i=0;s[i];i++)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	word[p]++;
	return ;
}
inline void Ready()
{
	int u,v;
	for(int i=0;i<26;i++)
	if(Trie[0][i]) q.push(Trie[0][i]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<26;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v);
			else Trie[u][i]=Trie[fail[u]][i];
		}
	}
	return ;
}
inline void AC_Auto()
{
	Ready();
	int p=0;
	for(int i=0;s[i];i++)
	{
		p=Trie[p][s[i]-'a'];
		for(int j=p;j&&word[j]!=-1;j=fail[j])
		{
			ans+=word[j];
			word[j]=-1;
		}
	}
	return ;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		Insert();
	}
	scanf("%s",s);
	AC_Auto();
	printf("%d",ans);
	return 0;
}
