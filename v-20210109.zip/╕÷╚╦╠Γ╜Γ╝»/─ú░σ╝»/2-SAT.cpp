#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=2000007;
const int maxm=2000007;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int N,M;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int dfn[maxn],low[maxn],T;
int stk[maxn],top,S[maxn],C;
bool ins[maxn];
void dfs(int u)
{
	stk[++top]=u;
	dfn[u]=low[u]=++T;
	ins[u]=true;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int main()
{
	N=R();M=R();
	int u,a,v,b;
	for(int i=1;i<=M;i++)
	{
		u=R();a=R();v=R();b=R();
		addE(u+N*(a&1),v+N*(b^1));
		addE(v+N*(b&1),u+N*(a^1));
	}
	for(int i=1;i<=2*N;i++)
	if(!dfn[i]) dfs(i);
	for(int i=1;i<=N;i++)
	if(S[i]==S[i+N])
		{printf("IMPOSSIBLE");return 0;}
	puts("POSSIBLE")	;
	for(int i=1;i<=N;i++)
	if(S[i]<S[i+N]) printf("1 ");
	else printf("0 ");
	return 0;
}
