#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
LL m[17],r[17];
LL N;
void EXGCD(LL a,LL b,LL &x,LL &y)
{
	if(!b)
	{
		x=1;y=0;
		return ;
	}
	EXGCD(b,a%b,y,x);
	y-=(a/b)*x;
	return ;
}
LL CRT()
{
	LL pro=1;
	for(LL i=1;i<=N;i++)
		pro*=m[i];
	LL x,y,Mi;LL ans=0;
	for(LL i=1;i<=N;i++)
	{
		Mi=pro/m[i];
		EXGCD(Mi,m[i],x,y);
		ans=(ans+Mi*r[i]*x)%pro; 
	}
	return (ans+pro)%pro;
}
int main()
{
	scanf("%lld",&N);
	for(LL i=1;i<=N;i++)
		scanf("%lld%lld",&m[i],&r[i]);
	printf("%lld",CRT());
	return 0;
}
