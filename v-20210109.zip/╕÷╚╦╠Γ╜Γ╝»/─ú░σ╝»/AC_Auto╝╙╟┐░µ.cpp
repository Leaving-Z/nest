#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;
int Trie[10700][26];
int N,all,ans[157];
char s1[157][77],s[1000007];
int word[10700],fail[10700];
int b[10700];
queue <int> q;
inline void Insert(int x)
{
	int p=0,t;
	for(int i=0;s1[x][i];i++)
	{
		t=s1[x][i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	word[p]++;b[p]=x;
	return ;
}
inline void Ready()
{
	int u,v;
	for(int i=0;i<26;i++)
	if(Trie[0][i]) q.push(Trie[0][i]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<26;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v);
			else Trie[u][i]=Trie[fail[u]][i];
		}
	}
	return ;
}
inline void AC_Auto()
{
	Ready();
	int p=0;
	for(int i=0;s[i];i++)
	{
		p=Trie[p][s[i]-'a'];
		for(int j=p;j;j=fail[j])
			ans[b[j]]+=word[j];
	}
	int maxx=-1,x;
	for(int i=1;i<=N;i++)
	{
		if(ans[i]>maxx)
		{
			maxx=ans[i];
			x=i;
		}
	}
	printf("%d\n",maxx);
	for(int i=1;i<=N;i++)
	{
		if(ans[i]==maxx)
			puts(s1[i]);
	}
	return ;
}
int main()
{
	while(1)
	{
		memset(Trie,0,sizeof(Trie));
		memset(word,0,sizeof(word));
		memset(fail,0,sizeof(fail));
		memset(s1,0,sizeof(s1));
		memset(b,0,sizeof(b));
		memset(ans,0,sizeof(ans));all=0;
		scanf("%d",&N);
		if(N==0) return 0;
		for(int i=1;i<=N;i++)
		{
			scanf("%s",s1[i]);
			Insert(i);
		}
		scanf("%s",s);
		AC_Auto();
	}
}
