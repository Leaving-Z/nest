#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
LL m[100007],r[100007];
LL N;
inline LL R()
{
	LL re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
LL g;
inline void EXGCD(LL a,LL b,LL &x,LL &y)
{
	if(!b)
	{
		g=a;
		x=1;y=0;
		return ;
	}
	EXGCD(b,a%b,y,x);
	y-=(a/b)*x;
	return ;
}
inline LL X(LL a,LL b,LL mod)//���ٳ� 
{
	LL s=0;
	if(b<0) b=-b,a=-a; 
	while(b)
	{
		if(b&1) s=(s+a)%mod;
		a=(a+a)%mod;
		b>>=1;
	}
	return s;
}
inline LL EXCRT()
{
	LL ans=0,pro=1;
	LL x,y,c;
	for(int i=1;i<=N;i++)
	{
		EXGCD(pro,m[i],x,y);
		c=((r[i]-ans)%m[i]+m[i])%m[i];
		//if(c%g) return -1;
		x=(X(x,c/g,m[i]/g)+(m[i]/g))%(m[i]/g);
		ans+=x*pro;
		pro*=m[i]/g;
		ans=(ans%pro+pro)%pro;		
	}
	return (ans%pro+pro)%pro;
}
int main()
{
	N=R();
	for(int i=1;i<=N;i++)
	{
		m[i]=R();r[i]=R();
	}
	printf("%lld",EXCRT());
	return 0;
}
