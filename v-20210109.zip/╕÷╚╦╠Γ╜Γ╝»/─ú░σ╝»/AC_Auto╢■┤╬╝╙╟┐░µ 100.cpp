/*
The previous solution can get 76pts
Because the trditional AC_auto algorithm
is Not fast enough for this problem
The key is to speed up the process when the pointer is
jumping through the array[fail]
We aim to make sure
each point of Trie is stepped only once
We use 'toposort' to speed it up
*/
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#include<iostream>
using namespace std;
const int maxn=200007;
int Trie[maxn][26];
queue <int> q;
int N,all;
int mp[maxn],book[maxn],fail[maxn],in[maxn];
char s[2000007];
inline int Insert()
{
	int p=0,t;
	for(int i=0;s[i];++i)
	{
		t=s[i]-'a';
		if(Trie[p][t]==0)
			Trie[p][t]=++all;
		p=Trie[p][t];
	}
	return p;
}
inline void Ready()
{
	int u,v;
	for(int i=0;i<26;i++)
	if(Trie[0][i]) q.push(Trie[0][i]);
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(int i=0;i<26;i++)
		{
			v=Trie[u][i];
			if(v) fail[v]=Trie[fail[u]][i],q.push(v),in[Trie[fail[u]][i]]++;
			else Trie[u][i]=Trie[fail[u]][i];
		}
	}
	return ;
}
inline void AC_Auto()
{
	Ready();
	int p=0;
	for(int i=0;s[i];i++)
	{
		p=Trie[p][s[i]-'a'];
		book[p]++; 
	}
	return ;
}
inline void topo()
{
	for(int i=0;i<=all;i++)
	if(in[i]==0) q.push(i);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		in[fail[u]]--;
		book[fail[u]]+=book[u];
		if(in[fail[u]]==0) q.push(fail[u]);
	}
	return ;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;++i)
	{
		scanf("%s",s);
		mp[i]=Insert();
	}
	scanf("%s",s);
	AC_Auto();
	topo();
	for(int i=1;i<=N;i++)
	printf("%d\n",book[mp[i]]);
	return 0;
}
