#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
#define R (L+len-1)
struct INT{
	int num[100];
	int len;
	INT (){memset(num,0,sizeof(num));len=1;}
	bool operator < (const INT &a) const
	{
		if(len<a.len) return true;
		if(len>a.len) return false;
		for(int i=len;i>0;i--)
		{
			if(a.num[i]>num[i]) return true;
			if(a.num[i]<num[i]) return false;
		}
		return false;
	}
	INT operator + (const INT &a) const
	{
		INT ans;
		ans.len=max(len,a.len);
		for(int i=1;i<=ans.len;i++)
		{
			ans.num[i]+=num[i]+a.num[i];
			if(ans.num[i]>=10)
			{
				ans.num[i]%=10;
				ans.num[i+1]++;
			}
		}
		while(ans.num[ans.len+1]) ans.len++;
		return ans;
	}
	INT operator * (const INT &a) const
	{
		INT ans;
		ans.len=a.len+len;
		for(int i=1;i<=len;i++)
			for(int j=1;j<=a.len;j++)
			{
				ans.num[i+j-1]+=num[i]*a.num[j];
				if(ans.num[i+j-1]>=10)
				{
					ans.num[i+j]+=ans.num[i+j-1]/10;
					ans.num[i+j-1]%=10;
				}
			}
		while(ans.num[ans.len]==0&&ans.len>0) ans.len--;
		return ans;
	}
	void push(char s[])
	{
		int l=strlen(s);
		len=l;
		for(int i=1;i<=l;i++)
			num[i]=s[l-i]-48;
		return ;
	}
	void print()
	{
		for(int i=len;i>0;i--)
		printf("%d",num[i]);
		return ;
	}
}DP[101][101],v[101];
char s[20];
int N;
INT A;
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
	{
		scanf("%s",s);
		v[i].push(s);
	}
	for(int len=3;len<=N;len++)
		for(int L=1;L+len-1<=N;L++)
		{
			DP[L][R].len=90;
			for(int k=L+1;k<R;k++)
			{
				A=v[L]*v[k]*v[R];
				A=A+DP[L][k];
				A=A+DP[k][R];
				DP[L][R]=min(DP[L][R],A);
			}
		}	
	DP[1][N].print();
	return 0;
}
