#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=200007;
const int maxm=400007;
struct E{
    int u,v,w1,w2;
}e[maxm];
int first[maxn],nt[maxm],ES;
int N;
inline void addE(int u,int v,int w1,int w2)
{
    e[++ES]=(E){u,v,w1,w2};
    nt[ES]=first[u];
    first[u]=ES;
    return ;
}
int dep[maxn],fa[maxn],sz[maxn],son[maxn],A[maxn][2];
void dfs1(int u)
{
    sz[u]=1;
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dep[v]=dep[u]+1;
        fa[v]=u;
        A[v][0]=e[i].w1;
        A[v][1]=e[i].w2;
        dfs1(v);
        sz[u]+=sz[v];
        if(sz[son[u]]<sz[v]) son[u]=v;
    }
    return ;
}
int top[maxn];
void dfs2(int u,int tp)
{
    top[u]=tp;
    if(son[u]) dfs2(son[u],tp);
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]||v==son[u]) continue;
        dfs2(v,v);
    }
    return ;
}
int LCA(int x,int y)
{
    while(top[x]!=top[y])
    {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        x=fa[top[x]];
    }
    return dep[x]>dep[y]?y:x;
}
int sum[maxn];
void dfs3(int u)
{
    int v;
    for(int i=first[u];i;i=nt[i])
    {
        v=e[i].v;
        if(v==fa[u]) continue;
        dfs3(v);
        sum[u]+=sum[v];
    }
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    int u,v,w1,w2;
    for(int i=1;i<N;i++)
    {
        scanf("%d%d%d%d",&u,&v,&w1,&w2);
        addE(u,v,w1,w2);addE(v,u,w1,w2);
    }
    dfs1(1);
    dfs2(1,1);
    int lca;
    for(int i=1;i<N;i++)
    {
        sum[i]++;
        sum[i+1]++;
        lca=LCA(i,i+1);
        sum[lca]-=2;
    }
    dfs3(1);
    long long ans=0;
    for(int i=1;i<=N;i++)
        ans+=min(1ll*A[i][1],1ll*sum[i]*A[i][0]);
    printf("%lld",ans);
    return 0;
}