#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=21;
const int maxs=(1<<20)+7;
const int mod=1e8+7;
int f[maxn][maxs];
int m[maxn][maxn];
int x[maxn],y[maxn];
int bitsum[maxs];
int N;
bool between(int i,int j,int k)
{
	return ((x[k]-x[i])>=0)!=((x[k]-x[j])>0)&&((y[k]-y[i])>=0)!=((y[k]-y[j])>0);
}
bool coline(int i,int j,int k)
{
	return (y[j]-y[i])*(x[k]-x[i])==(x[j]-x[i])*(y[k]-y[i])&&between(i,j,k);
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
		{
			if(i^j)
			{
				for(int k=1;k<=N;k++)
				if(i!=k&&j!=k&&coline(i,j,k)) m[i][j]|=(1<<k-1);
			}
		}
	int all=(1<<N)-1;
	for(int i=1;i<=N;i++)
		f[i][1<<i-1]=1;
	int ans=0;
	for(int i=1;i<=all;i++)
	{
		bitsum[i]=bitsum[i>>1]+(i&1);
		for(int j=1;j<=N;j++)
		{
			if(i&(1<<j-1))
			{
				for(int k=1;k<=N;k++)
				{
					if(i&(1<<k-1)) continue;
					if((m[j][k]&i)!=m[j][k]) continue;
					f[k][i|(1<<k-1)]+=f[j][i];
					f[k][i|(1<<k-1)]%=mod;
				}
			}
			if(bitsum[i]>=4) ans=(ans+f[j][i])%mod;
		}
	}
	printf("%d",ans);
	return 0;
}
