#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
const int maxn=1000007;
typedef long long LL;
struct E{
	int u,v;
	LL w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
int N;
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
LL sz[maxn],ans;
void dfs(int u,int fa)
{
	int v;sz[u]=1;
	for(register int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
			sz[u]+=sz[v];
			ans+=e[i].w*abs(N-2*sz[v]);
		}
	}
	return ;
}
int main()
{
	N=R();
	int u,v;LL w;
	for(register int i=1;i<N;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
		addE(v,u,w);
	}
	dfs(1,0);
	printf("%lld",ans);
	return 0;
}
