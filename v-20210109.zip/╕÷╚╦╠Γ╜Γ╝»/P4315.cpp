#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int TREE[maxn<<2];
int lazy[maxn<<2],tag[maxn<<2];
int N,ix;
char s[17];
struct E{
	int u,v,w;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
int depth[maxn],anti[maxn],top[maxn],son[maxn];
int fa[maxn],id[maxn],sz[maxn],A[maxn];
#define mid (L+R>>1)
inline void addE(int u,int v,int w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	e[ES+N]=(E){v,u,w};
	nt[ES+N]=first[v];
	first[v]=ES+N;
	return ;
}
inline int READ()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
inline void DFS(int u)
{
	sz[u]=1;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u])
		{
			depth[v]=depth[u]+1;
			fa[v]=u;
			A[v]=e[i].w;
			DFS(v);
			sz[u]+=sz[v];
			if(sz[v]>sz[son[u]]) son[u]=v;
		}
	}
	return ;
}
inline void dfs(int u,int tp)
{
	top[u]=tp;
	id[u]=++ix;anti[ix]=u;
	if(son[u]) dfs(son[u],tp);
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v!=fa[u]&&v!=son[u]) dfs(v,v);
	}
	return ;
}
namespace Tree
{
	inline void Build(int L,int R,int i)
	{
		tag[i]=-1;
		if(L==R)
		{
			TREE[i]=A[anti[L]];
			return ;
		}
		Build(L,mid,i<<1);
		Build(mid+1,R,i<<1|1);
		TREE[i]=max(TREE[i<<1],TREE[i<<1|1]);
		return ;
	}
	inline void LAZY(int i)
	{
		if(tag[i]>=0)
		{
			lazy[i<<1]=lazy[i<<1|1]=0;
			TREE[i<<1]=TREE[i<<1|1]=tag[i<<1]=tag[i<<1|1]=tag[i];
			tag[i]=-1;
		}
		if(lazy[i])
		{
			TREE[i<<1]+=lazy[i];TREE[i<<1|1]+=lazy[i];
			lazy[i<<1]+=lazy[i];lazy[i<<1|1]+=lazy[i];
			lazy[i]=0;
		}
		return ;
	}
	inline void Update(int L,int R,int l,int r,int i,int k)
	{
		if(l<=L&&R<=r)
		{
			TREE[i]=k;tag[i]=k;lazy[i]=0;
			return ;
		}
		LAZY(i);
		if(l<=mid) Update(L,mid,l,r,i<<1,k);
		if(r>mid) Update(mid+1,R,l,r,i<<1|1,k);
		TREE[i]=max(TREE[i<<1],TREE[i<<1|1]);
		return ;
	}
	inline void ADD(int L,int R,int l,int r,int i,int k)
	{
		if(l<=L&&R<=r)
		{
			TREE[i]+=k;lazy[i]+=k;
			return ;
		}
		LAZY(i);
		if(l<=mid) ADD(L,mid,l,r,i<<1,k);
		if(r>mid) ADD(mid+1,R,l,r,i<<1|1,k);
		TREE[i]=max(TREE[i<<1],TREE[i<<1|1]);
		return ;
	}
	inline int Query(int L,int R,int l,int r,int i)
	{
		if(l<=L&&R<=r)
			return TREE[i];
		LAZY(i);
		int ans=0;
		if(l<=mid) ans=max(ans,Query(L,mid,l,r,i<<1));
		if(r>mid) ans=max(ans,Query(mid+1,R,l,r,i<<1|1));
		return ans;
	}
	inline void Update_Path(int x,int y,int k)
	{
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap(x,y);
			Update(1,N,id[top[x]],id[x],1,k);
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap(x,y);
		Update(1,N,id[x]+1,id[y],1,k);
		return ; 
	}
	inline void ADD_Path(int x,int y,int k)
	{
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap(x,y);
			ADD(1,N,id[top[x]],id[x],1,k);
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap(x,y);
		ADD(1,N,id[x]+1,id[y],1,k);
		return ; 
	}
	inline int Query_Path(int x,int y)
	{
		int ans=0;
		while(top[x]!=top[y])
		{
			if(depth[top[x]]<depth[top[y]]) swap(x,y);
			ans=max(ans,Query(1,N,id[top[x]],id[x],1));
			x=fa[top[x]];
		}
		if(depth[x]>depth[y]) swap(x,y);
		ans=max(ans,Query(1,N,id[x]+1,id[y],1));
		return ans;
	}
}
int main()
{
	N=READ();
	int u,v,w;
	for(int i=1;i<N;i++)
	{
		u=READ();v=READ();w=READ();
		addE(u,v,w);
	}
	DFS(1);
	dfs(1,1);
	Tree::Build(1,N,1);
	while(true)
	{
		scanf("%s",s);
		if(s[0]=='S') return 0;
		else if(s[0]=='M')
		{
			u=READ();v=READ();
			printf("%d\n",Tree::Query_Path(u,v));
		}
		else if(s[0]=='A')
		{
			u=READ();v=READ();w=READ();
			Tree::ADD_Path(u,v,w);
		}
		else if(s[1]=='h')
		{
			u=READ();w=READ();
			v=depth[e[u].u]>depth[e[u].v]?e[u].u:e[u].v;
			Tree::Update(1,N,id[v],id[v],1,w);
		}
		else if(s[1]=='o')
		{
			u=READ();v=READ();w=READ();
			Tree::Update_Path(u,v,w);
		}
	}
}
