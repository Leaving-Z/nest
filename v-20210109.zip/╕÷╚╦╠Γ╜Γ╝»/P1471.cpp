#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=100007;
struct Tree{
	double sum,sum2;
}TREE[maxn<<2];
double tag[maxn<<2];
double A[maxn];
int N,M;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
#define mid (L+R>>1)
#define Ls (i<<1)
#define Rs (i<<1|1)
#define sum(i) TREE[i].sum
#define sum2(i) TREE[i].sum2
void Build(int L,int R,int i)
{
	if(L==R)
	{
		sum2(i)=A[L]*A[L];
		sum(i)=A[L];
		return ;
	}
	Build(L,mid,Ls);
	Build(mid+1,R,Rs);
	sum2(i)=sum2(Ls)+sum2(Rs);
	sum(i)=sum(Ls)+sum(Rs);
	return ;
}
inline void add(int L,int R,int i,double k)
{
	sum2(i)+=2*k*sum(i)+(R-L+1)*k*k;
	sum(i)+=(R-L+1)*k;
	tag[i]+=k;
	return ;
}
inline void pushdown(int L,int R,int i)
{
	add(L,mid,Ls,tag[i]);
	add(mid+1,R,Rs,tag[i]);
	tag[i]=0;
	return ;
}
void Update(int L,int R,int l,int r,double k,int i)
{
	if(l<=L&&R<=r)
	{
		add(L,R,i,k);
		return ;
	}
	pushdown(L,R,i);
	if(l<=mid) Update(L,mid,l,r,k,Ls);
	if(r>mid) Update(mid+1,R,l,r,k,Rs);
	sum2(i)=sum2(Ls)+sum2(Rs);
	sum(i)=sum(Ls)+sum(Rs);
	return ;
}
double Query(int L,int R,int l,int r,int k,int i)
{
	if(l<=L&&R<=r)
	{
		if(k) return sum2(i);
		else return sum(i);
	}
	pushdown(L,R,i);
	double re=0;
	if(l<=mid) re+=Query(L,mid,l,r,k,Ls);
	if(r>mid) re+=Query(mid+1,R,l,r,k,Rs);
	return re; 
}
int main()
{
	N=R();M=R();
	for(register int i=1;i<=N;i++)
		scanf("%lf",&A[i]);
	Build(1,N,1);
	int op,x,y;double k,tmp,ave;
	for(register int i=1;i<=M;i++)
	{
		op=R();x=R();y=R();
		if(op==1)
		{
			scanf("%lf",&k);
			Update(1,N,x,y,k,1);
		}
		else if(op==2)
		{
			tmp=Query(1,N,x,y,0,1);
			printf("%.4f\n",tmp/(y-x+1));
		}
		else
		{
			tmp=Query(1,N,x,y,0,1);
			k=Query(1,N,x,y,1,1);
			ave=tmp/(y-x+1);
			printf("%.4f\n",(k-2*tmp*ave)/(y-x+1)+ave*ave);
		}
	}
	return 0;
}
