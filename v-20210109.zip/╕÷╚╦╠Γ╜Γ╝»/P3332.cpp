#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=50007;
const int maxq=100007;
typedef long long LL;
struct query{
    int l,r,ty,id;
    LL k;
}q[maxq],q1[maxq],q2[maxq];
int N,M,Q;
LL sum[maxn<<2],add[maxn<<2];
#define ls (i<<1)
#define rs (i<<1|1)
#define mid (L+R>>1)
void pushdown(int L,int R,int i)
{
    if(!add[i]) return ;
    sum[ls]+=add[i]*(mid-L+1);
    sum[rs]+=add[i]*(R-mid);
    add[ls]+=add[i];add[rs]+=add[i];
    add[i]=0;
    return ;
}
void Update(int L,int R,int l,int r,LL k,int i)
{
    if(l<=L&&R<=r)
    {
        add[i]+=k;
        sum[i]+=(R-L+1)*k;
        return ;
    }
    pushdown(L,R,i);
    if(l<=mid) Update(L,mid,l,r,k,ls);
    if(r>mid) Update(mid+1,R,l,r,k,rs);
    sum[i]=sum[ls]+sum[rs];
    return ;
}
LL Query(int L,int R,int l,int r,int i)
{
    if(l<=L&&R<=r) return sum[i];
    LL re=0;
    pushdown(L,R,i);
    if(l<=mid) re+=Query(L,mid,l,r,ls);
    if(r>mid) re+=Query(mid+1,R,l,r,rs);
    return re;
}
int ans[maxn];
#undef mid
void solve(int l,int r,int ql,int qr)
{
    if(l==r)
    {
        for(int i=ql;i<=qr;i++)
        if(q[i].ty==2) ans[q[i].id]=l;
        return ;
    }
    int mid=l+r>>1,cnt1=0,cnt2=0;LL x;
    for(int i=ql;i<=qr;i++)
    {
        if(q[i].ty==1)
        {
            if(q[i].k>mid) Update(1,N,q[i].l,q[i].r,1,1),q2[++cnt2]=q[i];
            else q1[++cnt1]=q[i];
        }
        else
        {
            x=Query(1,N,q[i].l,q[i].r,1);
            if(x>=q[i].k) q2[++cnt2]=q[i];
            else q[i].k-=x,q1[++cnt1]=q[i];
        }
    }
    for(int i=1;i<=cnt2;i++)
    if(q2[i].ty==1) Update(1,N,q2[i].l,q2[i].r,-1,1);
    for(int i=1;i<=cnt1;i++) q[ql+i-1]=q1[i];
    for(int i=1;i<=cnt2;i++) q[ql+cnt1+i-1]=q2[i];
    if(cnt1) solve(l,mid,ql,ql+cnt1-1);
    if(cnt2) solve(mid+1,r,ql+cnt1,qr);
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int l,r,op;LL x;
    int tot=0;
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d%lld",&op,&l,&r,&x);
        if(op==1) q[++Q]=(query){l,r,1,0,x};
        else q[++Q]=(query){l,r,2,++tot,x};
    }
    solve(-N,N,1,Q);
    for(int i=1;i<=tot;i++)
        printf("%d\n",ans[i]);
    return 0;
}