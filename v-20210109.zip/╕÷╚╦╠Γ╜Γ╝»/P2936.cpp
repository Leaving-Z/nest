#include<bits/stdc++.h>
#include<queue>
using namespace std;
const int maxn=137;
const int maxm=40007;
const int inf=0x7f7f7f7f;
queue <int> q;
int m[maxn][maxn];
struct E{
	int u,v,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int cf)
{
	e[++ES]=(E){u,v,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
char s[7],s1[7];
int N,S,T;
int cur[maxn],cnt[maxn];
inline bool BFS()
{
	memset(cnt,0,sizeof(cnt));
	cnt[S]=1;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(!cnt[v]&&cf(i)>0)
			{
				cnt[v]=cnt[u]+1;
				q.push(v);
			}
		}
	}
	return cnt[T]!=0;
}
inline int min_(const int &x,const int &y) {return x<y?x:y;}
inline int dfs(int u,int f)
{
	if(u==T) return f;
	int sum=0,d,v;
	for(int &i=cur[u];i;i=nt[i])
	{
		v=e[i].v;
		if(cnt[v]==cnt[u]+1&&cf(i)>0)
		{
			d=dfs(v,min_(f,cf(i)));
			if(d>0)
			{
				sum+=d;
				f-=d;
				cf(i)-=d;
				cf(i^1)+=d;
				if(f<=0) return sum;
			}
		}
	}
	return sum;
}
int main()
{
	scanf("%d",&N);
	int cf;
	S='A';T='Z';
	for(register int i=1;i<=N;i++)
	{
		scanf("%s",s);
		scanf("%s",s1);
		scanf("%d",&cf);
		addE((int)s[0],(int)s1[0],cf);
		addE((int)s1[0],(int)s[0],0);
	}
	int ans=0;
	while(BFS())
	{
		memcpy(cur,first,sizeof(first));
		ans+=dfs(S,inf);
	}
	printf("%d",ans);
	return 0;
}
