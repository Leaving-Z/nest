#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=807;
const int maxm=80007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,w,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int w,int cf)
{
	e[++ES]=(E){u,v,w,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int w,int cf)
{
	addE(u,v,w,cf);addE(v,u,-w,0);
	return ;
}
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int N,M,S,T;
int dis[maxn],f[maxn],pre[maxn][2];
bool book[maxn];
inline bool SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	memset(f,0x7f,sizeof(f));
	dis[S]=0;
	q.push(S);book[S]=true;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();
		book[u]=false;
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(cf(i)&&dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				f[v]=min(f[u],cf(i));
				pre[v][0]=u;pre[v][1]=i;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=inf;
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int main()
{
	M=R();N=R();T=N+N*M+1;
	int x;
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=M;j++)
		{
			x=R();
			for(register int k=1;k<=N;k++)
				add(i,N+(k-1)*M+j,k*x,1);
		}
	for(register int i=1;i<=N;i++)
		add(S,i,0,1);
	for(register int i=1;i<=N*M;i++)
		add(N+i,T,0,1);
	int ans=0;
	while(SPFA())
	{
		ans+=dis[T]*f[T];
		Update();
	}
	printf("%.2lf",(double)ans/N);
	return 0;
}
