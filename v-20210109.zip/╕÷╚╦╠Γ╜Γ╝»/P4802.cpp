#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
const int maxn=19;
const int maxs=(1<<18)+7;
const int inf=-2139062144;
int f[maxs][maxn];
int N,M;
int m[maxn][maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    int u,v,w;
    memset(m,~0x7f,sizeof(m));
    for(int i=1;i<=M;i++)
    {
        scanf("%d%d%d",&u,&v,&w);
        m[u][v]=max(m[u][v],w);
    }
    memset(f,~0x7f,sizeof(f));
    f[1][0]=0;
    int all=(1<<N)-1;
    for(int i=1;i<=all;i++)
    {
        for(int j=0;j<N;j++)
        {
            if((i&(1<<j))==0) continue;
            for(int k=0;k<N;k++)
            {
                if(i&(1<<k)) continue;
                if(m[j][k]==inf) continue;
                f[i|(1<<k)][k]=max(f[i|(1<<k)][k],f[i][j]+m[j][k]);
            }
        }
    }
    int ans=-1e9;
    for(int i=1;i<=all;i++)
    if((i&1)&&(i&(1<<N-1))) ans=max(ans,f[i][N-1]);
    printf("%d",ans);
    return 0;
}