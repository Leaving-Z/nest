#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=407;
const int maxm=2007;
struct E{
	int u,v;
}e[maxm];
int first[maxn],nt[maxm],ES;
int N,M,T_;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
char s1[7],s2[7];
int toint(char s[])
{
	int p=2,f=0;
	if(s[1]=='m') f=N;
	int re=0;
	while(s[p]>='0'&&s[p]<='9')
		re=re*10+s[p]-48,p++;
	return re+f;
}
int rev(int u) {return u>N?u-N:u+N;}
int stk[maxn],dfn[maxn],low[maxn],T,top;
int S[maxn],C;
bool ins[maxn];
void dfs(int u)
{
	ins[u]=true;
	stk[++top]=u;
	dfn[u]=low[u]=++T;
	int v;
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(!dfn[v]) dfs(v),low[u]=min(low[u],low[v]);
		else if(ins[v]) low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int p;C++;
		do{
			p=stk[top--];
			ins[p]=false;
			S[p]=C;
		}while(p!=u);
	}
	return ;
}
int main()
{
	scanf("%d",&T_);
	while(T_--)
	{
		T=0;ES=0;C=0;
		memset(dfn,0,sizeof(dfn));
		memset(low,0,sizeof(low));
		memset(first,0,sizeof(first));
		memset(nt,0,sizeof(nt));
		scanf("%d%d",&N,&M);
		int u,v;
		for(int i=1;i<=M;i++)
		{
			scanf("%s",s1+1);
			u=toint(s1);
			scanf("%s",s2+1);
			v=toint(s2);
			addE(rev(u),v);
			addE(rev(v),u);
		}
		for(int i=1;i<=2*N;i++)
		if(!dfn[i]) dfs(i);
		bool f=true;
		for(int i=1;i<=N;i++)
		if(S[i]==S[i+N]) {f=false;break;}
		if(f) puts("GOOD");
		else puts("BAD");
	}
	return 0;
}
