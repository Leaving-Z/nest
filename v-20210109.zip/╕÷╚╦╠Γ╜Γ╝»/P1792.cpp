#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
using namespace std;
const int maxn=200007;
inline int R()
{
    int re,f=1;
    char c;
    while(!isdigit(c=getchar()))
    if(c=='-') f=-1;
    re=c-48;
    while(isdigit(c=getchar()))
    re=re*10+c-48;
    return re*f;
}
int N,K;
struct node {
    int num,val;
};
bool operator < (const node &x,const node &y)
{
    return x.val<y.val;
}
priority_queue <node> q;
int A[maxn],lx[maxn],rx[maxn];
bool out[maxn];
int op;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    N=R();K=R();
    op=N/2;
    if(K>op) {printf("Error!");return 0;}
    node t;
    for(int i=1;i<=N;i++)
    {
        t.num=i;
        t.val=A[i]=R(),lx[i]=i-1,rx[i]=i+1;
        q.push(t);
    }
    lx[1]=N;rx[N]=1;
    int ans=0;
    while(K--)
    {
        while(!q.empty()&&out[q.top().num]) q.pop();
        t=q.top();q.pop();
        ans+=t.val;

        t.val=A[lx[t.num]]+A[rx[t.num]]-t.val;

        A[t.num]=t.val;

        out[lx[t.num]]=out[rx[t.num]]=true;

        lx[t.num]=lx[lx[t.num]];
        
        rx[lx[t.num]]=t.num;

        rx[t.num]=rx[rx[t.num]];
        
        lx[rx[t.num]]=t.num;
        
        q.push(t);
    }
    printf("%d",ans);
    return 0;
}