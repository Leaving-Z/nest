#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int maxn=100007;
const int maxm=37;
int A[maxn][maxm],d[maxn];
int N,M;
typedef long long LL;
LL val[maxn],di[maxn];
const LL b=114513;
const LL mod=99824435307;
int fst[maxn];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("P1360_2.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    for(int i=1;i<=N;i++)
        scanf("%d",&d[i]);
    int t;
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=M;j++)
            A[i][j]=A[i-1][j];
        t=N;
        for(int j=1;j<=M;j++)
        {
            if(d[i]&(1<<j-1)) A[i][j]++;
            t=min(t,A[i][j]);
        }
        for(int j=1;j<=M;j++)
            A[i][j]-=t,val[i]=(val[i]*b%mod+A[i][j])%mod;
        di[i]=val[i];
    }
    sort(di+1,di+2+N);
    int tot=unique(di+1,di+2+N)-di-1,ans=0;
    memset(fst,-1,sizeof(fst));
    t=lower_bound(di+1,di+1+tot,0)-di;
    fst[t]=0;
    for(int i=1;i<=N;i++)
    {
        t=lower_bound(di+1,di+1+tot,val[i])-di;
        if(fst[t]!=-1) ans=max(ans,i-fst[t]);
        else fst[t]=i;
    }
    printf("%d",ans);
    return 0;
}