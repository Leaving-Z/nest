#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=1000007;
typedef long long LL;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re; 
}
struct E{
	int u,v;
}e[maxn<<1];
int first[maxn],nt[maxn<<1],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
LL val[maxn],F[maxn][2];
int N;
int S[maxn];
int A[maxn>>1][2],cnt;
int f(int x)
{
	return S[x]==x?x:S[x]=f(S[x]);
}
void dfs(int u,int fa)
{
	int v;
	F[u][1]=val[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		if(v==fa) continue;
		dfs(v,u);
		F[u][0]+=max(F[v][0],F[v][1]);
		F[u][1]+=F[v][0];
	}
	return ;
}
LL work(int lt,int rt)
{
	LL ans1,ans2,ans3;
	swap(val[0],val[rt]);
	memset(F,0,sizeof(F));
	dfs(lt,0);
	ans1=F[lt][0];ans2=F[lt][1];
	swap(val[0],val[rt]);
	swap(val[0],val[lt]);
	memset(F,0,sizeof(F));
	dfs(rt,0);
	ans3=F[rt][1];
	swap(val[lt],val[0]);
	return max(ans1,max(ans2,ans3));
}
int main()
{
	N=R();
	val[0]=-1e12;
	int v,f1,f2;
	for(int i=1;i<=N;i++)
		S[i]=i;
	for(int i=1;i<=N;i++)
	{
		val[i]=R();
		v=R();
		f1=f(i);f2=f(v);
		if(f1==f2) A[++cnt][0]=i,A[cnt][1]=v;
		else addE(i,v),addE(v,i),S[f1]=f2;
	}
	LL ans=0;
	for(int i=1;i<=cnt;i++)
		ans+=work(A[i][0],A[i][1]);
	printf("%lld",ans);
	return 0;
}
