#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=1007;
int m[maxn][maxn];
int N,M,C,ansx,ansy,ans=-0x7f7f7f7f;
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=R();M=R();C=R();
	for(register int i=1;i<=N;i++)
		for(register int j=1;j<=N;j++)
			m[i][j]=R(),m[i][j]+=m[i-1][j]+m[i][j-1]-m[i-1][j-1];
	int x,y;
	for(register int i=C;i<=N;i++)
		for(register int j=C;j<=M;j++)
		{
			x=i-C;y=j-C;
			if(m[i][j]-m[i][y]-m[x][j]+m[x][y]>ans)
				ans=m[i][j]-m[i][y]-m[x][j]+m[x][y],ansx=x+1,ansy=y+1;
		}
	printf("%d %d",ansx,ansy);
	return 0;
}
