#include<cstdio>
#include<algorithm>
#include<cstring>
#include<map>
using namespace std;
const int maxn=57;
int A[maxn];
int sum[maxn];
int ans,N;
struct node{
	int step,h1,h2;
};
bool operator < (const node &x,const node &y)
{
	if(x.step!=y.step) return x.step<y.step;
	if(x.h1!=y.h1) return x.h1<y.h1;
	return x.h2<y.h2;
}
map <node,int> mp;
int dfs(int step,int sum1,int sum2)
{
	node t;
	t.step=step;t.h1=sum1;t.h2=sum2;
	if(mp[t]) return mp[t];
	if(step>N)
	{
		if(sum1==sum2) return ans=max(ans,sum1);
		return -1;
	}
	if(max(sum1,sum2)+sum[N]-sum[step-1]<=ans) return -1;
	if(sum1+sum[N]-sum[step-1]<sum2) return -1;
	if(sum2+sum[N]-sum[step-1]<sum1) return -1;
	if(sum1+sum2+sum[N]-sum[step-1]<=ans*2) return -1;
	int re=-0x7f7f7f7f;
	re=max(re,dfs(step+1,sum1+A[step],sum2));
	re=max(re,dfs(step+1,sum1,sum2+A[step]));
	re=max(re,dfs(step+1,sum1,sum2));
	mp[t]=re;
	return re;
}
bool com(const int &x,const int &y)
{
	return x>y;
}
int main()
{
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		scanf("%d",&A[i]);
	sort(A+1,A+1+N,com);
	for(int i=1;i<=N;i++)
		sum[i]=sum[i-1]+A[i];
	dfs(1,0,0);
	printf("%d",ans==0?-1:ans);
	return 0;
}
