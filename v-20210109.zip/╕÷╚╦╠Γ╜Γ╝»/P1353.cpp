#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=10507;
const int maxm=507;
int N,M;
int d[maxn];
int F[maxn][maxm];
int main()
{
	#ifndef ONLINE_JUDGE
	freopen("1.in","r",stdin);
	#endif
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;i++)
		scanf("%d",&d[i]);
	F[1][1]=d[1];
	for(int i=1;i<=N;i++)
		for(int j=0;j<=min(i,M);j++)
		{
			if(!j) F[i][0]=max(F[i][0],F[i-1][0]);
			else F[i+j][0]=max(F[i][j],F[i+j][0]);
			F[i+1][j+1]=max(F[i+1][j+1],F[i][j]+d[i+1]);
		}
	printf("%d",F[N][0]);
	return 0;
}
