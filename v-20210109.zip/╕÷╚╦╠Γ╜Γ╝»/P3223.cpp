#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<ctime>
using namespace std;
const int MAX=6007;
const int MOD=1e4;
struct INT{
    int num[MAX],len;
    INT() {memset(num,0,sizeof(num));len=1;}
    void fit()
    {
        for(int i=1;i<=len;i++)
        {
            if(num[i]>=MOD) num[i+1]+=num[i]/MOD,num[i]%=MOD;
            if(i==len&&num[i+1]) ++len;
        }
        return ;
    }
    void print()
    {
        printf("%d",num[len]);
        for(int i=len-1;i;i--)
            printf("%04d",num[i]);
        return ;
    }
}ans1,ans2;
INT operator * (const INT &x,const int &y)
{
    INT re=x;
    for(int i=1;i<=re.len;i++)
        re.num[i]*=y;
    re.fit();
    return re;
}
INT operator + (const INT &x,const INT &y)
{
    INT re;
    re.len=max(x.len,y.len);
    for(int i=1;i<=re.len;i++)
        re.num[i]=x.num[i]+y.num[i];
    re.fit();
    return re;
}
int N,M;
void A(int n,int m,INT &x)
{
    if(!m) return ;
    if(n<m) {x=x*0;return ;}
    for(int i=n-m+1;i<=n;i++)
        x=x*i;
    return ;
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d%d",&N,&M);
    ans1.num[1]=1;
    ans2.num[1]=1;
    A(N,N,ans1);
    A(N+1,2,ans1);
    A(N+3,M,ans1);

    A(N,N,ans2);
    A(N+1,1,ans2);
    A(2,2,ans2);
    A(M,1,ans2);
    A(N+2,M-1,ans2);
    ans1=ans1+ans2;
    ans1.print();
    return 0;
}