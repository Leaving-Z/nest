#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;
const int maxn=100007;
struct Treap{
	int l,r,pri,num,v,s;
}TREE[maxn];
int N,M,all,root;
#define L(i) TREE[i].l
#define R(i) TREE[i].r
#define p(i) TREE[i].pri
#define c(i) TREE[i].num
#define val(i) TREE[i].v
#define sz(i) TREE[i].s
inline void Zig(int &x)
{
	int y=L(x);
	L(x)=R(y);
	R(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Zag(int &x)
{
	int y=R(x);
	R(x)=L(y);
	L(y)=x;
	sz(y)=sz(x);
	sz(x)=sz(L(x))+sz(R(x))+c(x);
	x=y;
	return ;
}
inline void Insert(int &i,const int &v)
{
	if(!i)
	{
		i=++all;val(i)=v;
		sz(i)=c(i)=1;
		L(i)=R(i)=0;
		return ;
	}
	++sz(i);
	if(v==val(i)) c(i)++;
	else if(val(i)>v) Insert(L(i),v);
	else Insert(R(i),v);
	return ;
}
inline int KTH(int k)
{
	int i=root;
	while(i)
	{
		if(sz(L(i))+c(i)>=k&&sz(L(i))<k) return val(i);
		if(sz(L(i))>=k) i=L(i);
		else k-=sz(L(i))+c(i),i=R(i);
	}
}
inline int Read()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re*f;
}
int main()
{
	N=Read();M=Read();
	int op,x;
	for(int i=1;i<=N;i++)
	{
		x=Read();
		Insert(root,x);
	}
	for(int i=1;i<=M;i++)
	{
		op=Read();x=Read();
		if(op==1) printf("%d\n",KTH(N-x+1));
		else Insert(root,x),N++;
	}
	return 0;
}
