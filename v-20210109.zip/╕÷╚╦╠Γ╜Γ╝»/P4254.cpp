#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cstdlib>
#include<cmath>
#include<ctime>
using namespace std;
const int maxn=50007;
const int lim=50000;
struct Line{
    double k,b;
    bool f;
}tree[maxn<<2];
#define f(i) tree[i].f
#define ls (i<<1)
#define rs (i<<1|1)
double F(Line k,int x) {return k.k*x+k.b;}
double cross(Line x,Line y) {return (x.b-y.b)/(y.k-x.k);}
void update(int l,int r,int i,Line x)
{
    if(!f(i)) {tree[i]=x;return ;}
    double dl,dr,xl,xr;
    dl=F(tree[i],l);dr=F(tree[i],r);
    xl=F(x,l);xr=F(x,r);
    if(xl>dl&&xr>dr) tree[i]=x;
    else if(xl<dl&&xr<dr) return ;
    else
    {
        int mid=l+r>>1;
        double k=cross(tree[i],x);
        if(k<=mid)
        {
            if(dl>xl) swap(tree[i],x);
            update(l,mid,ls,x);
        }
        else
        {
            if(dl<xl) swap(tree[i],x);
            update(mid+1,r,rs,x);
        }
    }
    return ;
}
double query(int l,int r,int x,int i)
{
    if(l==r) return F(tree[i],x);
    double re=F(tree[i],x);
    int mid=l+r>>1;
    if(x<=mid) return max(re,query(l,mid,x,ls));
    else return max(re,query(mid+1,r,x,rs));
}
char s[17];
int N;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("1.in","r",stdin);
    #endif
    scanf("%d",&N);
    double k,b,res;
    Line tmp;
    int T;
    tmp.f=true;
    while(N--)
    {
        scanf("%s",s+1);
        if(s[1]=='P')
        {
            scanf("%lf%lf",&b,&k);
            b-=k;
            tmp.k=k;tmp.b=b;
            update(1,lim,1,tmp);
        }
        else
        {
            scanf("%d",&T);
            res=query(1,lim,T,1);
            printf("%d\n",(int)res/100);
        }
    }
    return 0;
}