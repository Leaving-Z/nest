#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std; 
const int maxn=10007;
const int maxm=100007;
int N,M,B;
queue <int> q;
typedef long long LL;
struct E{
	int u,v;
	LL w;
}e[maxm];
int first[maxn],nt[maxm],ES;
inline void addE(int u,int v,LL w)
{
	e[++ES]=(E){u,v,w};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int c[maxn];
inline int R()
{
	char c;
	int re,f=1;
	while((c=getchar())>'9'||c<'0')
	if(c=='-') f=-1;
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
LL dis[maxn];
bool book[maxn];
bool SPFA(int lim)
{
	memset(dis,0x7f,sizeof(dis));
	dis[1]=0;
	q.push(1);
	book[1]=true;
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(c[v]>lim) continue;
			if(dis[u]+e[i].w<dis[v])
			{
				dis[v]=dis[u]+e[i].w;
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[N]<=B;
}
int main()
{
	N=R();M=R();B=R();
	int u,v;LL w;
	int l=0x7f7f7f7f,mid,r=0;
	for(register int i=1;i<=N;i++)
		c[i]=R(),r=max(r,c[i]),l=min(l,c[i]);
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		addE(u,v,w);
		addE(v,u,w);
	}
	r++;l--;
	int ans=0x7f7f7f7f;
	while(l<=r)
	{
		mid=l+r>>1;
		if(SPFA(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	if(ans==0x7f7f7f7f) printf("AFK");
	else printf("%d",ans);
	return 0;
}
