#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
queue <int> q;
const int maxn=407;
const int maxm=45007;
const int inf=0x7f7f7f7f;
struct E{
	int u,v,w,cf;
}e[maxm];
int first[maxn],nt[maxm],ES=1;
#define cf(i) e[i].cf
inline void addE(int u,int v,int w,int cf)
{
	e[++ES]=(E){u,v,w,cf};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
inline void add(int u,int v,int w,int cf)
{
	addE(u,v,w,cf);addE(v,u,-w,0);
	return ;
}
int N,M,S,T;
inline int R()
{
	char c;
	int re;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int dis[maxn],f[maxn],pre[maxn][2];
bool book[maxn];
inline bool SPFA()
{
	memset(dis,0x7f,sizeof(dis));
	dis[S]=0;
	memset(f,0x7f,sizeof(f));
	book[S]=true;
	q.push(S);
	int u,v;
	while(!q.empty())
	{
		u=q.front();q.pop();book[u]=false;
		for(register int i=first[u];i;i=nt[i])
		{
			v=e[i].v;
			if(dis[u]+e[i].w<dis[v]&&cf(i)>0)
			{
				dis[v]=dis[u]+e[i].w;
				pre[v][0]=u;pre[v][1]=i;
				f[v]=min(f[u],cf(i));
				if(!book[v])
				{
					book[v]=true;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=inf;
}
inline void Update()
{
	int u=T;
	while(u!=S)
	{
		cf(pre[u][1])-=f[T];
		cf(pre[u][1]^1)+=f[T];
		u=pre[u][0];
	}
	return ;
}
int main()
{
	N=R();M=R();S=N+1;T=N;
	int u,v,w;
	for(register int i=1;i<=M;i++)
	{
		u=R();v=R();w=R();
		add(N+u,v,w,1);
	}
	for(register int i=1;i<=N;i++)
		add(i,N+i,0,1);
	int ans1=0,ans2=0;
	while(SPFA())
	{
		ans2++;
		ans1+=f[T]*dis[T];
		Update();
	}
	printf("%d %d",ans2,ans1);
	return 0;
}
