#include<cstdio>
#include<algorithm>
using namespace std;
long long s[150],cnt,sum[150];
int N,K;
void pre()
{
	int a=(1<<N)-1;
	for(int i=0;i<=a;i++)
	{
		if((i&(i<<1))==0)
		{
			s[++cnt]=i;
			int x=i;
			while(x)
			{
				sum[cnt]++;
				x-=x&(-x);
			}
		}
	}
	return ;
}
long long DP[11][150][120];
int main()
{
	scanf("%d%d",&N,&K);
	pre();
	DP[0][1][0]=1;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=cnt;j++)
			for(int k=0;k<=K;k++)
			{
				if(sum[j]>k) continue;
				for(int l=1;l<=cnt;l++)
				{
					if(!((s[j]&s[l])||((s[j]<<1)&s[l])||((s[j]>>1)&s[l])))
						DP[i][j][k]+=DP[i-1][l][k-sum[j]];
				}
			}
	long long ANS=0;
	for(int i=1;i<=cnt;i++)
	ANS+=DP[N][i][K];
	printf("%lld",ANS);
	return 0;
}
