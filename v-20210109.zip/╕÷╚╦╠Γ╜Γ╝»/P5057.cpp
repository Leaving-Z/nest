#include<cstdio>
#include<algorithm>
using namespace std;
inline int Read()
{
	int re;
	char c;
	while((c=getchar())>'9'||c<'0');
	re=c-48;
	while((c=getchar())>='0'&&c<='9')
	re=re*10+c-48;
	return re;
}
int C[100007];
int N,M;
void Update(int x)
{
	for(int i=x;i<=N;i+=(i&(-i)))
	C[i]^=1;
	return ;
}
int Q(int x)
{
	int ans=0;
	for(int i=x;i>0;i-=(i&(-i)))
	ans^=C[i];
	return ans;
}
int main()
{
	N=Read();M=Read();
	int t,L,R;
	for(int i=1;i<=M;i++)
	{
		t=Read();
		if(t==1)
		{
			L=Read();R=Read();
			Update(R+1);Update(L);
		}
		else
		{
			L=Read();
			printf("%d\n",Q(L));
		}
	}
	return 0;
}
