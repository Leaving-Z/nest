#include<cstdio>
#include<algorithm>
using namespace std;
struct E{
	int u,v;
}e[307];
int first[307],nt[307],ES;
inline void addE(int u,int v)
{
	e[++ES]=(E){u,v};
	nt[ES]=first[u];
	first[u]=ES;
	return ;
}
int N,M,root;
int DP[307][307];
int va[307];
int sz[307];
void dfs(int u)
{
	sz[u]=1;
	int v,lt;
	DP[u][1]=va[u];
	for(int i=first[u];i;i=nt[i])
	{
		v=e[i].v;
		dfs(v);
		sz[u]+=sz[v];
		lt=min(sz[u],M);
		for(int j=lt;j>0;j--)
		{
			for(int k=0;k<j;k++)
				DP[u][j]=max(DP[u][j],DP[v][k]+DP[u][j-k]);
		}
	}
	return ;
}
int main()
{
	scanf("%d%d",&N,&M);M++;
	int k,s;
	for(int i=1;i<=N;i++)
	{
		scanf("%d%d",&k,&s);
		va[i]=s;
		addE(k,i);
	}
	dfs(0);
	printf("%d",DP[0][M]);
	return 0;
}
