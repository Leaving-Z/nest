
inline int test(int s) {
    int totv = 0, totw = 0;
    for (int i = 0; i < n; i++) {
        if (s & (1 << i)) {
            totv += v[i];
            totw += w[i];
        } 
    }
    return totw > maxw ? -1 : totv;
}

int maxv = 0, maxs = 0;
for (int s = 0; s < (1 << n); s++) {
    int totv = test(s);
    if (totv > maxv) {
        maxv = totv;
        maxs = totv;
    }
}

for (int s = 0; s < (1 << n); s++) {
    for (int t = 0; t < (1 << n); t++) {
        if (s & t == t) test(s, t);
    }
}

for (int s = 0; s < (1 << n); s++) {
    for (int t = s; t; t = (t - 1) & s) {
        test(s, t);
    }
}