#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 30;

int p[MAXN];

int n;
char s[3][MAXN];

int ord[MAXN];
int chk[MAXN];

bool vis[MAXN];
void dfs(int now, int lastchk, int lastc) {
    if (now == n && !lastc){
        for (int i = 0; i < n; i++) {
            printf("%d%c", p[i], " \n"[i==n-1]);
        }
        exit(0);
        return;
    }
    int ch = ord[now];
    for (int i = 0; i < n; i++) {
        if (vis[i]) continue;
        vis[i] = true;
        p[ch] = i;

        bool flag = true;
        int nextchk = lastchk, c = lastc;
        if (now == n-1 || chk[ch]) {
            for (int j = lastchk-1; j >= chk[ch]; j--) {
                int t = p[s[0][j]] + p[s[1][j]] + c;
                if (t >= n) {
                    c = 1;
                    t -= n;
                } else {
                    c = 0;
                }
                if (t != p[s[2][j]]) {
                    flag = false;
                    break;
                }
            }
            if (flag) nextchk = chk[ch];
        }


        if (flag) dfs(now+1, nextchk, c);         
        vis[i] = false;
    }
}

int main() {
    scanf("%d", &n);
    scanf("%s%s%s", s[0], s[1], s[2]);

    int tmp = 0, cnt = 0;
    for (int i = n-1; i >= 0; i--) {
        for (int j = 0; j < 3; j++) {
            int ch = s[j][i] -= 'A';
            if (!vis[ch]) {
                vis[ch] = true;
                tmp = ch;
                ord[cnt++] = ch;
            }
        }
        chk[tmp] = i;
    }
    memset(vis, 0, sizeof(vis));
    dfs(0, n, 0);
}