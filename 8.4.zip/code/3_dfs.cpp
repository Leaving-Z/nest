#include <cstdio>
#include <algorithm>

using namespace std;

const int MAXN = 30;

int p[MAXN];

int n;
char x[MAXN], y[MAXN], z[MAXN];

inline bool test() {
    int c = 0;
    for (int i = n - 1; i >= 0; i--) {
        int s = p[x[i] - 'A'] + p[y[i] - 'A'] + c;
        if (s >= n) {
            c = 1;
            s -= n;
        } else {
            c = 0;
        }
        if (s != p[z[i] - 'A']) return false;
    }
    return !c;
}


bool vis[MAXN];
void dfs(int now) {
    if (now == n){
        if (test()) {
            for (int i = 0; i < n; i++) {
                printf("%d%c", p[i], " \n"[i==n-1]);
            }
        }
        return;
    }
    for (int i = 0; i < n; i++) {
        if (vis[i]) continue;
        vis[i] = true;
        p[now] = i;
        dfs(now+1); 
        vis[i] = false;
    }
}

int main() {
    scanf("%d", &n);
    scanf("%s%s%s", x, y, z);
    dfs(0);
}