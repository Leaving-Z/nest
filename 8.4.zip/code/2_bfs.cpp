#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <map>
#include <set>
#include <list>
#include <queue>
#include <stack>
#include <algorithm>
#include <ctime>

using namespace std;
typedef long long LL;

const int MAXN = 18;
const int MAXP = (1 << MAXN) + 20;
const int INF = 0x3f3f3f3f;

struct Point {
    double x, y;
    Point(double _x = 0, double _y = 0): x(_x), y(_y) {}
    bool operator<(const Point& rhs) const {
        return y / x < rhs.y / rhs.x;
    }
};
int n, m, T;
int d[MAXP];
Point pigs[MAXN];
double eps = 1e-8;

inline void solve(double &a, double &b, double x0, double y0, double x1, double y1) {
    b = (y0 * x1 * x1 - y1 * x0 * x0) / x0 / x1 / (x1 - x0);
    a = (y0 - b * x0) / x0 / x0;
}

int q[MAXP], qhead = 0, qtail = 0;
inline void extend(int u, int v) {
    if (d[v] == INF) {
        d[v] = d[u] + 1;
        q[qtail++] = v;   
    }
}
inline int bfs(int s) {
    d[s] = 0;
    qhead = qtail = 0;
    q[qtail++] = s;
    while (qhead != qtail) {
        int now = q[qhead++];
        if (now == (1 << n) - 1) return d[now];
        int p0 = 0;
        for (int t = now; t & 1; t>>=1) p0++;
        extend(now, now | (1<<p0));
        for (int i = p0 + 1; i < n; i++) {
            double a, b;
            if (pigs[i].x + 0.0001 > pigs[p0].x) continue;
            if (abs(pigs[i].x / pigs[i].y - pigs[p0].x / pigs[p0].y) < eps) continue;
            solve(a, b, pigs[p0].x, pigs[p0].y, pigs[i].x, pigs[i].y);
            int to = now | (1<<p0) | (1<<i);
            for (int j = i + 1; j < n; j++) {
                double delta = abs(a * pigs[j].x * pigs[j].x + b * pigs[j].x - pigs[j].y);
                if (delta < eps){
                    to |= 1 << j;
                }
            }
            extend(now, to);
        }
    }
}

int main() {
    
    scanf("%d", &T);
    while (T--) {
        scanf("%d%d", &n, &m);
        memset(d, 0x3f, sizeof(d));
        for (int i = 0; i < n; i++) {
            double x, y;
            scanf("%lf%lf", &x, &y);
            pigs[i] = Point(x, y);
        }
        sort(pigs, pigs + n);
        printf("%d\n", bfs(0));
    }

    return 0;
}